const TEXT = {
  he: {
    appTitle: 'לומדים דרך חידונים',
    appSubtitle: 'גרסה מתוקנת עם עברית/אנגלית, מצב זמן או ללא זמן, ותשובות דו-לשוניות.',
    categoryJewish: 'תורה ויהדות',
    categoryMath: 'מתמטיקה',
    categoryGeo: 'גאוגרפיה',
    categoryCommon: 'ידע כללי',
    timed: 'עם זמן',
    untimed: 'ללא זמן',
    pause: 'השהיה',
    resume: 'המשך',
    paused: 'מושהה',
    voiceInput: 'קלט קולי',
    speechUnsupported: 'הדפדפן הזה לא תומך בזיהוי קולי.',
    micStart: 'האזנה...',
    micStop: 'ההאזנה נעצרה.',
    matchFlag: 'בחר את הדגל הנכון',
    scrambledCountryHint: 'פענח את שם המדינה המבולבל.',
    movePlacedHint: 'לחץ על דמות שכבר מוקמה כדי להזיז אותה למקום אחר.',
    back: 'חזרה',
    reveal: 'גלה תשובות',
    revealOne: 'גלה תשובה אחת',
    teachMe: 'למד אותי',
    didYouKnow: 'הידעת?',
    close: 'סגור',
    reset: 'אתחול',
    guessed: 'ניחושים',
    score: 'ניקוד',
    personalBest: 'שיא אישי',
    noLimit: 'ללא הגבלה',
    completed: 'כל הכבוד, השלמת את החידון.',
    correct: 'נכון',
    wrong: 'לא נכון',
    gematriaCalculator: 'מצב מחשבון',
    gematriaLiveValue: 'ערך חי',
    pickMonth: 'בחר חודש',
    chronologyPool: 'מאגר לבחירה',
    continentBoxes: 'תיבות יבשות',
    commandmentsPool: 'דיברות לבחירה',
    solarMatchStage: 'שלב התאמה',
    solarOrderStage: 'שלב סדר',
    halachaDailyStage: 'חיי יומיום',
    halachaShabbatStage: 'שבת',
    halachaKosherStage: 'כשרות',
    halachaInterpersonalStage: 'בין אדם לחברו',
    commonKnowledgeSoon: 'החידון הזה יתווסף בקרוב.',
    quizCards: {
      tanakh: { title: '24 ספרי התנ"ך', desc: 'כתוב את כל 24 ספרי התנ"ך. כל ספר יופיע אוטומטית במקום הנכון.', badge: '24 ספרים' },
      shas: { title: 'שישה סדרים ומסכתות', desc: 'כתוב את ששת הסדרים ואת כל המסכתות. כל מסכת תמוקם אוטומטית.', badge: '69 פריטים' },
      parashot: { title: '54 פרשות השבוע', desc: 'כתוב את כל פרשות התורה לפי הסדר.', badge: '54 פרשות' },
      gematria: { title: 'גמטריה', desc: 'מופיעה מילה, ואתה מזין את ערך הגמטריה שלה.', badge: '20 מילים' },
      tannaim: { title: 'תנאים ואמוראים', desc: 'זהה אם הדמות היא תנא או אמורא.', badge: '20 שאלות' },
      chronology: { title: 'סדר כרונולוגי של דמויות', desc: 'בחר דמות ואז מקם אותה במקום הנכון על הציר.', badge: '12 דמויות' },
      relations: { title: 'יחסים בין דמויות', desc: 'ענה רב-ברירה: מה הקשר בין שתי הדמויות?', badge: '12 שאלות' },
    
  continentQuiz: {
    continents: [
      {id:'asia',he:'אסיה',en:'Asia',color:'#c0392b'},
      {id:'europe',he:'אירופה',en:'Europe',color:'#3498db'},
      {id:'africa',he:'אפריקה',en:'Africa',color:'#8e44ad'},
      {id:'northAmerica',he:'אמריקה הצפונית',en:'North America',color:'#f39c12'},
      {id:'southAmerica',he:'אמריקה הדרומית',en:'South America',color:'#27ae60'}
    ],
    countries: [
      {he:'ישראל',en:'Israel',continent:'asia',flag:'🇮🇱'},
      {he:'יפן',en:'Japan',continent:'asia',flag:'🇯🇵'},
      {he:'הודו',en:'India',continent:'asia',flag:'🇮🇳'},
      {he:'גרמניה',en:'Germany',continent:'europe',flag:'🇩🇪'},
      {he:'צרפת',en:'France',continent:'europe',flag:'🇫🇷'},
      {he:'ספרד',en:'Spain',continent:'europe',flag:'🇪🇸'},
      {he:'מצרים',en:'Egypt',continent:'africa',flag:'🇪🇬'},
      {he:'קניה',en:'Kenya',continent:'africa',flag:'🇰🇪'},
      {he:'ניגריה',en:'Nigeria',continent:'africa',flag:'🇳🇬'},
      {he:'קנדה',en:'Canada',continent:'northAmerica',flag:'🇨🇦'},
      {he:'מקסיקו',en:'Mexico',continent:'northAmerica',flag:'🇲🇽'},
      {he:'ארצות הברית',en:'United States',continent:'northAmerica',flag:'🇺🇸'},
      {he:'ברזיל',en:'Brazil',continent:'southAmerica',flag:'🇧🇷'},
      {he:'ארגנטינה',en:'Argentina',continent:'southAmerica',flag:'🇦🇷'},
      {he:'פרו',en:'Peru',continent:'southAmerica',flag:'🇵🇪'},
      {he:'יוון',en:'Greece',continent:'europe',flag:'🇬🇷'},
      {he:'סין',en:'China',continent:'asia',flag:'🇨🇳'},
      {he:'מרוקו',en:'Morocco',continent:'africa',flag:'🇲🇦'},
      {he:'גואטמלה',en:'Guatemala',continent:'northAmerica',flag:'🇬🇹'},
      {he:'צ׳ילה',en:'Chile',continent:'southAmerica',flag:'🇨🇱'},
      {he:'איטליה',en:'Italy',continent:'europe',flag:'🇮🇹'},
      {he:'בריטניה',en:'United Kingdom',continent:'europe',flag:'🇬🇧'},
      {he:'דרום אפריקה',en:'South Africa',continent:'africa',flag:'🇿🇦'},
      {he:'אתיופיה',en:'Ethiopia',continent:'africa',flag:'🇪🇹'},
      {he:'דרום קוריאה',en:'South Korea',continent:'asia',flag:'🇰🇷'},
      {he:'אינדונזיה',en:'Indonesia',continent:'asia',flag:'🇮🇩'},
      {he:'קולומביה',en:'Colombia',continent:'southAmerica',flag:'🇨🇴'}
    ]
  },
  worldCountries: { title: 'מדינות העולם', desc: 'כתוב מדינה והיא תמוקם ביבשת הנכונה.', badge: '196 מדינות' },
      worldCapitals: { title: 'בירות העולם', desc: 'כתוב עיר בירה והיא תופיע ליד המדינה.', badge: '20 בירות' },
      officialLanguages: { title: 'מדינות לפי שפה רשמית', desc: 'זהה מדינה לפי השפות הרשמיות שלה.', badge: '20 מדינות' },
      countryFlags: { title: 'מדינה לדגל', desc: 'בחר את הדגל הנכון עבור המדינה הנתונה.', badge: '12 שאלות' },
      scrambledCountries: { title: 'מדינות מבולבלות', desc: 'פענח שמות מדינות מבולבלים.', badge: '12 מדינות' },
      mentalMathTF: { title: 'חישוב מהיר – נכון או לא נכון', desc: 'האם התוצאה נכונה? בחר נכון או לא נכון.', badge: '12 שאלות' },
      equationCompletion: { title: 'השלם את המשוואה', desc: 'השלם את המספר החסר בכל משוואה.', badge: '12 משוואות' },
      multiplication: { title: 'לוח הכפל 12×12', desc: 'מלא את לוח הכפל. אפשר ללחוץ על כל תא.', badge: '144 תאים' },
      fastMultiplication: { title: 'כפל מהיר', desc: 'פתור סדרת תרגילי כפל מהירים.', badge: '20 תרגילים' },
      fastAddition: { title: 'חיבור מהיר', desc: 'פתור סדרת תרגילי חיבור מהירים.', badge: '20 תרגילים' },
      romanNumerals: { title: 'ספרות רומיות', desc: 'המר ספרות רומיות למספרים רגילים.', badge: '20 מספרים' },
      tenCommandments: { title: 'עשרת הדיברות', desc: 'סדר את עשרת הדיברות לפי הסדר.', badge: '10 פריטים' },
      holidaysMonths: { title: 'חגים וחודשים', desc: 'התאם חג לחודש העברי הנכון.', badge: '12 שאלות' },
      continentQuiz: { title: 'מדינה ליבשת', desc: 'בחר מדינה ואז מקם אותה ביבשת הנכונה.', badge: '27 מדינות' },
      europeProfileMatch: { title: 'אירופה: התאמת פרופיל למדינה', desc: 'בחר מדינה והתאם אותה לפרופיל הנכון.', badge: '10 מדינות' },
      europeCountryRanking: { title: 'אירופה: דירוג מדינות', desc: 'דרג מדינות באירופה לפי כלכלה, אוכלוסייה, שטח, תוצר לנפש וצפיפות.', badge: '5 מצבים' },
      europeCountryFits: { title: 'אירופה: איזו מדינה מתאימה?', desc: 'קרא רמזים ובחר את המדינה המתאימה מתוך 4 אפשרויות.', badge: '12 שאלות' },
      europeCorrectWrong: { title: 'אירופה: נכון או לא נכון', desc: 'קרא טענה על מדינה ובחר אם היא נכונה או לא נכונה.', badge: '20 שאלות' },
      europeLandmarks: { title: 'אירופה: אתרים מפורסמים', desc: 'קרא רמז על אתר מפורסם ובחר את המדינה המתאימה.', badge: '10 שאלות' },
      europeExportMatch: { title: 'אירופה: התאמת פרופיל יצוא', desc: 'בחר מדינה והתאם אותה לפרופיל היצוא המתאים.', badge: '10 מדינות' },
      europeCompareCountries: { title: 'אירופה: השוואת מדינות', desc: 'קרא שאלה והשווה בין שתי מדינות.', badge: '10 שאלות' },
      romanMath: { title: 'חשבון רומי', desc: 'חיבור מהיר עם מספרים רומיים.', badge: '20 תרגילים' },
      solarSystem: { title: 'כוכבי הלכת במערכת השמש', desc: 'שלב 1: זהה את כוכבי הלכת בתמונה. שלב 2: התאם כל כוכב לפרט הנכון עליו.', badge: '2 שלבים' },
      agesHumanity: { title: 'עידני האנושות', desc: 'שלב 1: סדר את התקופות. שלב 2: התאם כל תקופה להמצאות, גילויים וטווח הזמן.', badge: '2 שלבים' },
      humanBody: { title: 'גוף האדם', desc: 'מיני-סט: איבר לתפקיד, איבר למערכת גוף, ותיוג דיאגרמה.', badge: '3 שלבים' },
      inventionInventor: { title: 'המצאה → ממציא', desc: 'בחר את הממציא הנכון לכל המצאה.', badge: '12 שאלות' },
      symptomOrgan: { title: 'תסמין → איבר', desc: 'בחר את האיבר המתאים לכל תסמין.', badge: '12 שאלות' },
      largestCountriesRanking: { title: 'סדר מדינות לפי שטח', desc: 'שלב 1: סדר את המדינות מהגדולה לקטנה. שלב 2: התאם כל מדינה לדגל שלה.', badge: '2 שלבים' },
      whoSaidIt: { title: 'מי אמר את זה?', desc: 'בחר מי אמר כל ציטוט.', badge: '12 ציטוטים' },
      halacha: { title: 'הלכה', desc: '4 תתי-קטגוריות של שאלות נכון/לא נכון: חיי יומיום, שבת, כשרות ובין אדם לחברו.', badge: '4 קטגוריות' }
    },
    placeholders: {
      tanakh: 'הקלד שם ספר...',
      shas: 'הקלד סדר או מסכת...',
      parashot: 'הקלד שם פרשה...',
      gematria: 'הקלד ערך מספרי...',
      worldCountries: 'הקלד שם מדינה...',
      worldCapitals: 'הקלד שם עיר בירה...',
      officialLanguages: 'הקלד שם מדינה...',
      scrambledCountries: 'הקלד שם המדינה...',
      multiplication: 'הקלד תשובה...',
      equationCompletion: 'הקלד את המספר החסר...',
      gematriaCalc: 'הקלד כל מילה...',
      default: 'הקלד תשובה...',
      halacha: ''
    },
    instructions: {
      tanakh: 'הקלד שם ספר בעברית או באנגלית. הספר יופיע במדור המתאים.',
      shas: 'אפשר להקליד סדר או מסכת. הכול ימוקם אוטומטית.',
      parashot: 'אפשר להקליד פרשה בעברית או בתעתיק אנגלי.',
      gematria: 'המערכת מקבלת תשובה מספרית מדויקת.',
      tannaim: 'בחר אם הדמות היא תנא או אמורא.',
      chronology: 'בחר דמות מצד אחד ואז לחץ על מיקום בצד השני.',
      relations: 'בחר את הקשר הנכון בין שתי הדמויות.',
      worldCountries: 'כתוב מדינה והיא תופיע ביבשת המתאימה.',
      worldCapitals: 'כתוב עיר בירה והיא תופיע ליד המדינה המתאימה.',
      officialLanguages: 'כתוב מדינה ותמלא את השורה המתאימה.',
      countryFlags: 'בחר את הדגל הנכון למדינה.',
      scrambledCountries: 'פענח את שם המדינה וכתוב אותו.',
      mentalMathTF: 'קרא את התרגיל ובחר אם התוצאה שמופיעה נכונה או לא נכונה.',
      equationCompletion: 'הקלד את המספר החסר בכל משוואה. תשובה נכונה ננעלת אוטומטית.',
      multiplication: 'מלא את לוח הכפל. אפשר ללחוץ על כל תא כדי לבחור אותו.',
      fastMultiplication: 'מלא את תיבות התשובה. תשובות נכונות ננעלות אוטומטית.',
      fastAddition: 'מלא את תיבות התשובה. תשובות נכונות ננעלות אוטומטית.',
      romanNumerals: 'המר כל ספרה רומית למספר רגיל.',
      tenCommandments: 'בחר פריט מצד אחד ואז מקם אותו במספר המתאים.',
      holidaysMonths: 'בחר את החודש העברי הנכון לכל חג.',
      continentQuiz: 'בחר מדינה מהמאגר ואז לחץ על היבשת הנכונה.',
      romanMath: 'פתור חיבורי מספרים רומיים. כתוב את התוצאה במספר רגיל.',
      solarSystem: 'שלב 1: חבר שם לכוכב הלכת הנכון בתמונה. שלב 2: התאם כל כוכב לכת לפרט הנכון עליו.',
      agesHumanity: 'שלב 1: סדר את התקופות. שלב 2: התאם כל תקופה לתיאור התקופה, ההמצאות וטווח הזמן.',
      humanBody: 'השלם שלושה שלבים: איבר לתפקיד, איבר למערכת גוף, ותיוג דיאגרמה.',
      inventionInventor: 'בחר את הממציא הנכון לכל המצאה.',
      symptomOrgan: 'בחר את האיבר המתאים לכל תסמין.',
      largestCountriesRanking: 'שלב 1: בחר מדינה מהמאגר ומקם אותה מהגדולה לקטנה. שלב 2: התאם כל מדינה לדגל שלה.',
      europeProfileMatch: 'בחר מדינה מהמאגר ואז לחץ על תיבת הפרופיל המתאימה.',
      europeCountryRanking: 'בחר מצב דירוג, בחר מדינה מהמאגר ולחץ על המיקום הנכון בדירוג.',
      europeCountryFits: 'קרא את הרמז ובחר את המדינה המתאימה מתוך ארבע אפשרויות.',
      europeCorrectWrong: 'קרא את הטענה ובחר אם היא נכונה או לא נכונה.',
      europeLandmarks: 'קרא את הרמז על האתר ובחר את המדינה המתאימה מתוך ארבע אפשרויות.',
      europeExportMatch: 'בחר מדינה מהמאגר ואז לחץ על תיבת פרופיל היצוא המתאימה.',
      europeCompareCountries: 'קרא את השאלה ובחר איזו משתי המדינות מתאימה יותר.',
      whoSaidIt: 'בחר מי אמר כל ציטוט.',
      halacha: 'בחר אם כל קביעה נכונה או לא נכונה בתוך תת-הקטגוריה שנבחרה.'
    },
    sections: { torah: 'תורה', neviim: 'נביאים', ketuvim: 'כתובים' },
    promptGematria: 'מה הגמטריה של המילה?',
    chronologyPool: 'דמויות לבחירה',
    chronologySlots: 'סדר כרונולוגי',
    correctPlacements: 'מיקומים נכונים',
    relationQuestion: 'מה הקשר?',
    categoryTanna: 'תנא',
    categoryAmora: 'אמורא',
    revealed: 'התשובות נחשפו',
    relations: {
      fatherOf: 'אבי', motherOf: 'אמו של', brotherOf: 'אחיו של', sisterOf: 'אחותו של',
      wifeOf: 'אשתו של', husbandOf: 'בעלה של', teacherOf: 'מורו של', studentOf: 'תלמידו של',
      uncleOf: 'דודו של', daughterInLawOf: 'כלתה של', friendOf: 'ידידו של', successorOf: 'ממשיכו של'
    }
  },
  en: {
    appTitle: 'Learning through quizzes',
    appSubtitle: 'Fixed version with Hebrew/English, timed or untimed mode, and bilingual answers.',
    categoryJewish: 'Torah and Judaism',
    categoryMath: 'Math',
    categoryGeo: 'Geography',
    categoryCommon: 'Common Knowledge',
    timed: 'Timed',
    untimed: 'Untimed',
    pause: 'Pause',
    resume: 'Resume',
    paused: 'Paused',
    voiceInput: 'Voice input',
    speechUnsupported: 'This browser does not support speech recognition.',
    micStart: 'Listening...',
    micStop: 'Listening stopped.',
    matchFlag: 'Pick the correct flag',
    scrambledCountryHint: 'Unscramble the country name.',
    movePlacedHint: 'Click a placed figure to move it to a different slot.',
    back: 'Back',
    reveal: 'Reveal answers',
    revealOne: 'Reveal one',
    teachMe: 'Teach me',
    didYouKnow: 'Did you know?',
    close: 'Close',
    reset: 'Reset',
    guessed: 'Guessed',
    score: 'Score',
    personalBest: 'Personal best',
    noLimit: 'No limit',
    completed: 'Well done. You completed the quiz.',
    correct: 'Correct',
    wrong: 'Wrong',
    gematriaCalculator: 'Calculator Mode',
    gematriaLiveValue: 'Live value',
    pickMonth: 'Pick month',
    chronologyPool: 'Pool',
    continentBoxes: 'Continent boxes',
    commandmentsPool: 'Commandments to place',
    solarMatchStage: 'Match stage',
    solarOrderStage: 'Order stage',
    halachaDailyStage: 'Daily Life',
    halachaShabbatStage: 'Shabbat',
    halachaKosherStage: 'Kosher',
    halachaInterpersonalStage: 'Interpersonal',
    commonKnowledgeSoon: 'This quiz will be added soon.',
    quizCards: {
      tanakh: { title: '24 Books of Tanakh', desc: 'Type all 24 books of Tanakh. Each book is placed automatically.', badge: '24 books' },
      shas: { title: 'Six Orders and Tractates', desc: 'Type the six sedarim and all masechtot. Each one is placed automatically.', badge: '69 items' },
      parashot: { title: '54 Weekly Parashot', desc: 'Type all Torah portions in order.', badge: '54 portions' },
      gematria: { title: 'Gematria', desc: 'A word appears and you enter its gematria value.', badge: '20 words' },
      tannaim: { title: 'Tannaim and Amoraim', desc: 'Identify whether the figure is a Tanna or an Amora.', badge: '20 questions' },
      chronology: { title: 'Chronological Biblical Figures', desc: 'Pick a figure and place it in the right chronological slot.', badge: '12 figures' },
      relations: { title: 'Relationships Between Figures', desc: 'Multiple choice: what is the relationship between the figures?', badge: '12 questions' },
    
  continentQuiz: {
    continents: [
      {id:'asia',he:'אסיה',en:'Asia',color:'#c0392b'},
      {id:'europe',he:'אירופה',en:'Europe',color:'#3498db'},
      {id:'africa',he:'אפריקה',en:'Africa',color:'#8e44ad'},
      {id:'northAmerica',he:'אמריקה הצפונית',en:'North America',color:'#f39c12'},
      {id:'southAmerica',he:'אמריקה הדרומית',en:'South America',color:'#27ae60'}
    ],
    countries: [
      {he:'ישראל',en:'Israel',continent:'asia',flag:'🇮🇱'},
      {he:'יפן',en:'Japan',continent:'asia',flag:'🇯🇵'},
      {he:'הודו',en:'India',continent:'asia',flag:'🇮🇳'},
      {he:'גרמניה',en:'Germany',continent:'europe',flag:'🇩🇪'},
      {he:'צרפת',en:'France',continent:'europe',flag:'🇫🇷'},
      {he:'ספרד',en:'Spain',continent:'europe',flag:'🇪🇸'},
      {he:'מצרים',en:'Egypt',continent:'africa',flag:'🇪🇬'},
      {he:'קניה',en:'Kenya',continent:'africa',flag:'🇰🇪'},
      {he:'ניגריה',en:'Nigeria',continent:'africa',flag:'🇳🇬'},
      {he:'קנדה',en:'Canada',continent:'northAmerica',flag:'🇨🇦'},
      {he:'מקסיקו',en:'Mexico',continent:'northAmerica',flag:'🇲🇽'},
      {he:'ארצות הברית',en:'United States',continent:'northAmerica',flag:'🇺🇸'},
      {he:'ברזיל',en:'Brazil',continent:'southAmerica',flag:'🇧🇷'},
      {he:'ארגנטינה',en:'Argentina',continent:'southAmerica',flag:'🇦🇷'},
      {he:'פרו',en:'Peru',continent:'southAmerica',flag:'🇵🇪'},
      {he:'יוון',en:'Greece',continent:'europe',flag:'🇬🇷'},
      {he:'סין',en:'China',continent:'asia',flag:'🇨🇳'},
      {he:'מרוקו',en:'Morocco',continent:'africa',flag:'🇲🇦'},
      {he:'גואטמלה',en:'Guatemala',continent:'northAmerica',flag:'🇬🇹'},
      {he:'צ׳ילה',en:'Chile',continent:'southAmerica',flag:'🇨🇱'},
      {he:'איטליה',en:'Italy',continent:'europe',flag:'🇮🇹'},
      {he:'בריטניה',en:'United Kingdom',continent:'europe',flag:'🇬🇧'},
      {he:'דרום אפריקה',en:'South Africa',continent:'africa',flag:'🇿🇦'},
      {he:'אתיופיה',en:'Ethiopia',continent:'africa',flag:'🇪🇹'},
      {he:'דרום קוריאה',en:'South Korea',continent:'asia',flag:'🇰🇷'},
      {he:'אינדונזיה',en:'Indonesia',continent:'asia',flag:'🇮🇩'},
      {he:'קולומביה',en:'Colombia',continent:'southAmerica',flag:'🇨🇴'}
    ]
  },
  worldCountries: { title: 'Countries of the World', desc: 'Type a country and it will appear in the correct continent.', badge: '67 countries' },
      worldCapitals: { title: 'World Capitals', desc: 'Type the capital city for each country.', badge: '20 capitals' },
      officialLanguages: { title: 'Countries by Official Language', desc: 'Identify a country from its official languages.', badge: '20 countries' },
      countryFlags: { title: 'Country to Flag', desc: 'Select the correct flag for the given country.', badge: '12 questions' },
      scrambledCountries: { title: 'Scrambled Countries', desc: 'Unscramble country names.', badge: '12 countries' },
      mentalMathTF: { title: 'Mental Math – True or False', desc: 'Decide whether each result is correct or wrong.', badge: '12 questions' },
      equationCompletion: { title: 'Complete the Equation', desc: 'Fill in the missing number in each equation.', badge: '12 equations' },
      multiplication: { title: '12×12 Multiplication Grid', desc: 'Fill the multiplication grid and click any cell.', badge: '144 cells' },
      fastMultiplication: { title: 'Fast Multiplication', desc: 'Solve multiplication problems quickly.', badge: '20 problems' },
      fastAddition: { title: 'Fast Addition', desc: 'Solve addition problems quickly.', badge: '20 problems' },
      romanNumerals: { title: 'Roman Numerals', desc: 'Convert Roman numerals.', badge: '20 numbers' },
      tenCommandments: { title: 'The 10 Commandments', desc: 'Place the Ten Commandments in order.', badge: '10 items' },
      holidaysMonths: { title: 'Holidays & Months', desc: 'Match each holiday to the correct Hebrew month.', badge: '12 questions' },
      continentQuiz: { title: 'Country to Continent', desc: 'Pick a country and place it in the correct continent box.', badge: '27 countries' },
      europeProfileMatch: { title: 'Europe Profile Match', desc: 'Pick a country and match it to the correct profile.', badge: '10 countries' },
      europeCountryRanking: { title: 'Europe Country Ranking', desc: 'Rank European countries by economy, population, area, GDP per capita, and density.', badge: '5 modes' },
      europeCountryFits: { title: 'Europe: Which Country Fits?', desc: 'Read the clue and pick the matching country from 4 options.', badge: '12 questions' },
      europeCorrectWrong: { title: 'Europe: Correct or Wrong', desc: 'Read a statement about a country and decide if it is correct or wrong.', badge: '20 questions' },
      europeLandmarks: { title: 'Europe: Famous Landmarks', desc: 'Read a landmark clue and pick the matching country.', badge: '10 questions' },
      europeExportMatch: { title: 'Europe: Export Profile Match', desc: 'Pick a country and match it to the correct export profile.', badge: '10 countries' },
      europeCompareCountries: { title: 'Europe: Compare Two Countries', desc: 'Read the comparison clue and choose the better fit.', badge: '10 questions' },
      romanMath: { title: 'Roman Math', desc: 'Fast addition with Roman numerals.', badge: '20 problems' },
      solarSystem: { title: 'Solar System Planets', desc: 'Stage 1: identify the planets in the picture. Stage 2: match each planet to the correct detail.', badge: '2 stages' },
      agesHumanity: { title: 'Ages of Humanity', desc: 'Stage 1: order the eras. Stage 2: match each era to inventions, discoveries, and time period.', badge: '2 stages' },
      humanBody: { title: 'Human Body', desc: 'Mini-set: organ to function, organ to body system, and diagram labeling.', badge: '3 stages' },
      inventionInventor: { title: 'Invention → Inventor', desc: 'Choose the correct inventor for each invention.', badge: '12 questions' },
      symptomOrgan: { title: 'Symptom → Organ', desc: 'Choose the matching organ for each symptom.', badge: '12 questions' },
      largestCountriesRanking: { title: 'Largest Countries Ranking', desc: 'Stage 1: arrange the countries from largest to smallest. Stage 2: match each country to its flag.', badge: '2 stages' },
      whoSaidIt: { title: 'Who Said It?', desc: 'Choose who said each quote.', badge: '12 quotes' },
      halacha: { title: 'Halacha', desc: '4 true/false subdivisions: Daily Life, Shabbat, Kosher, and Interpersonal.', badge: '4 categories' }
    },
    placeholders: {
      tanakh: 'Type a book name...',
      shas: 'Type a seder or tractate...',
      parashot: 'Type a parasha name...',
      gematria: 'Type a numeric value...',
      worldCountries: 'Type a country name...',
      worldCapitals: 'Type a capital city...',
      officialLanguages: 'Type a country name...',
      scrambledCountries: 'Type the country name...',
      multiplication: 'Type an answer...',
      equationCompletion: 'Type the missing number...',
      gematriaCalc: 'Type any word...',
      default: 'Type your answer...',
      halacha: ''
    },
    instructions: {
      tanakh: 'Type a book name in Hebrew or English. It will appear in the correct section.',
      shas: 'You can type either an order or a tractate. Everything is placed automatically.',
      parashot: 'You can type the parasha in Hebrew or English transliteration.',
      gematria: 'The system expects an exact numeric answer.',
      tannaim: 'Choose whether the figure is a Tanna or an Amora.',
      chronology: 'Select a figure on one side, then click a slot on the other side.',
      relations: 'Choose the correct relationship between the two figures.',
      worldCountries: 'Type a country and it will appear in the proper continent.',
      worldCapitals: 'Type the capital city for the displayed country.',
      officialLanguages: 'Type the country that matches each official-language clue.',
      countryFlags: 'Select the correct flag for the given country.',
      scrambledCountries: 'Unscramble the country name and type it.',
      mentalMathTF: 'Read the exercise and choose whether the shown result is correct or wrong.',
      equationCompletion: 'Type the missing number in each equation. Correct answers lock in automatically.',
      multiplication: 'Click any box in the grid and answer it.',
      fastMultiplication: 'Fill the answer boxes. Correct answers lock in automatically.',
      fastAddition: 'Fill the answer boxes. Correct answers lock in automatically.',
      romanNumerals: 'Convert each Roman numeral into an Arabic number.',
      tenCommandments: 'Pick an item from the pool and place it in the correct numbered slot.',
      holidaysMonths: 'Choose the correct Hebrew month for each holiday.',
      continentQuiz: 'Pick a country from the pool and click the correct continent.',
      romanMath: 'Solve Roman numeral additions. Type the result as a regular number.',
      solarSystem: 'Stage 1: match each planet name to the correct planet in the picture. Stage 2: match each planet to the correct detail.',
      agesHumanity: 'Stage 1: order the eras. Stage 2: match each era to the correct inventions, discoveries, and time period.',
      humanBody: 'Complete three stages: organ to function, organ to body system, and diagram labeling.',
      inventionInventor: 'Choose the correct inventor for each invention.',
      symptomOrgan: 'Choose the matching organ for each symptom.',
      largestCountriesRanking: 'Stage 1: pick a country from the pool and place it from largest to smallest. Stage 2: match each country to its flag.',
      europeProfileMatch: 'Pick a country from the pool, then click the matching profile box.',
      europeCountryRanking: 'Choose a ranking mode, pick a country from the pool, and click the correct rank slot.',
      europeCountryFits: 'Read the clue and choose the matching country from four options.',
      europeCorrectWrong: 'Read the statement and choose whether it is correct or wrong.',
      europeLandmarks: 'Read the landmark clue and choose the matching country from four options.',
      europeExportMatch: 'Pick a country from the pool, then click the matching export profile box.',
      europeCompareCountries: 'Read the question and choose which of the two countries fits better.',
      whoSaidIt: 'Choose who said each quote.',
      halacha: 'Choose whether each statement is right or wrong inside the selected subdivision.'
    },
    sections: { torah: 'Torah', neviim: 'Neviim', ketuvim: 'Ketuvim' },
    promptGematria: 'What is the gematria of this word?',
    chronologyPool: 'Figures to place',
    chronologySlots: 'Chronological order',
    correctPlacements: 'Correct placements',
    relationQuestion: 'What is the relationship?',
    categoryTanna: 'Tanna',
    categoryAmora: 'Amora',
    revealed: 'Answers revealed',
    relations: {
      fatherOf: 'father of', motherOf: 'mother of', brotherOf: 'brother of', sisterOf: 'sister of',
      wifeOf: 'wife of', husbandOf: 'husband of', teacherOf: 'teacher of', studentOf: 'student of',
      uncleOf: 'uncle of', daughterInLawOf: 'daughter-in-law of', friendOf: 'friend of', successorOf: 'successor of'
    }
  }
};

const DATA = {
  tanakh: [
    { id:'genesis', he:'בראשית', en:'Genesis', section:'torah', aliases:['bereshit'] },
    { id:'exodus', he:'שמות', en:'Exodus', section:'torah', aliases:['shemot'] },
    { id:'leviticus', he:'ויקרא', en:'Leviticus', section:'torah', aliases:['vayikra'] },
    { id:'numbers', he:'במדבר', en:'Numbers', section:'torah', aliases:['bamidbar'] },
    { id:'deuteronomy', he:'דברים', en:'Deuteronomy', section:'torah', aliases:['devarim'] },
    { id:'joshua', he:'יהושע', en:'Joshua', section:'neviim', aliases:['yehoshua'] },
    { id:'judges', he:'שופטים', en:'Judges', section:'neviim', aliases:['shofetim'] },
    { id:'samuel', he:'שמואל', en:'Samuel', section:'neviim', aliases:[] },
    { id:'kings', he:'מלכים', en:'Kings', section:'neviim', aliases:[] },
    { id:'isaiah', he:'ישעיהו', en:'Isaiah', section:'neviim', aliases:['ישעיה'] },
    { id:'jeremiah', he:'ירמיהו', en:'Jeremiah', section:'neviim', aliases:['ירמיה'] },
    { id:'ezekiel', he:'יחזקאל', en:'Ezekiel', section:'neviim', aliases:[] },
    { id:'twelve', he:'תרי עשר', en:'Twelve Prophets', section:'neviim', aliases:['שנים עשר','the twelve','minor prophets'] },
    { id:'psalms', he:'תהילים', en:'Psalms', section:'ketuvim', aliases:['tehillim','תהלים'] },
    { id:'proverbs', he:'משלי', en:'Proverbs', section:'ketuvim', aliases:['mishlei'] },
    { id:'job', he:'איוב', en:'Job', section:'ketuvim', aliases:['iyov'] },
    { id:'song', he:'שיר השירים', en:'Song of Songs', section:'ketuvim', aliases:['shir hashirim','song of solomon'] },
    { id:'ruth', he:'רות', en:'Ruth', section:'ketuvim', aliases:[] },
    { id:'lamentations', he:'איכה', en:'Lamentations', section:'ketuvim', aliases:['eicha'] },
    { id:'ecclesiastes', he:'קהלת', en:'Ecclesiastes', section:'ketuvim', aliases:['kohelet'] },
    { id:'esther', he:'אסתר', en:'Esther', section:'ketuvim', aliases:[] },
    { id:'daniel', he:'דניאל', en:'Daniel', section:'ketuvim', aliases:[] },
    { id:'ezra-nehemiah', he:'עזרא-נחמיה', en:'Ezra-Nehemiah', section:'ketuvim', aliases:['ezra','nehemiah','עזרא','נחמיה'] },
    { id:'chronicles', he:'דברי הימים', en:'Chronicles', section:'ketuvim', aliases:['divrei hayamim'] }
  ],
  shas: {
    zeraim: { he:'זרעים', en:'Zeraim', color:'#27ae60', tractates:[
      {he:'ברכות',en:'Berakhot',aliases:['berachot']},{he:'פאה',en:'Peah',aliases:[]},{he:'דמאי',en:'Demai',aliases:[]},{he:'כלאים',en:'Kilayim',aliases:[]},{he:'שביעית',en:'Sheviit',aliases:['sheviis']},{he:'תרומות',en:'Terumot',aliases:[]},{he:'מעשרות',en:'Maasrot',aliases:['maasros']},{he:'מעשר שני',en:'Maaser Sheni',aliases:[]},{he:'חלה',en:'Challah',aliases:['hallah']},{he:'ערלה',en:'Orlah',aliases:[]},{he:'ביכורים',en:'Bikkurim',aliases:['bikurim']}
    ]},
    moed: { he:'מועד', en:'Moed', color:'#2980b9', tractates:[
      {he:'שבת',en:'Shabbat',aliases:['shabbos']},{he:'עירובין',en:'Eruvin',aliases:['eruvin']},{he:'פסחים',en:'Pesachim',aliases:['pesahim']},{he:'שקלים',en:'Shekalim',aliases:[]},{he:'יומא',en:'Yoma',aliases:[]},{he:'סוכה',en:'Sukkah',aliases:['succah']},{he:'ביצה',en:'Beitzah',aliases:['beitza']},{he:'ראש השנה',en:'Rosh Hashanah',aliases:[]},{he:'תענית',en:'Taanit',aliases:['taanis']},{he:'מגילה',en:'Megillah',aliases:[]},{he:'מועד קטן',en:'Moed Katan',aliases:[]},{he:'חגיגה',en:'Chagigah',aliases:['chagiga']}
    ]},
    nashim: { he:'נשים', en:'Nashim', color:'#8e44ad', tractates:[
      {he:'יבמות',en:'Yevamot',aliases:['yevamos']},{he:'כתובות',en:'Ketubot',aliases:['kesubos']},{he:'נדרים',en:'Nedarim',aliases:[]},{he:'נזיר',en:'Nazir',aliases:[]},{he:'סוטה',en:'Sotah',aliases:['sota']},{he:'גיטין',en:'Gittin',aliases:['gitin']},{he:'קידושין',en:'Kiddushin',aliases:['kidushin']}
    ]},
    nezikin: { he:'נזיקין', en:'Nezikin', color:'#c0392b', tractates:[
      {he:'בבא קמא',en:'Bava Kamma',aliases:['bk']},{he:'בבא מציעא',en:'Bava Metzia',aliases:['bm']},{he:'בבא בתרא',en:'Bava Batra',aliases:['bb']},{he:'סנהדרין',en:'Sanhedrin',aliases:[]},{he:'מכות',en:'Makkot',aliases:['makos']},{he:'שבועות',en:'Shevuot',aliases:['shevuos']},{he:'עדויות',en:'Eduyot',aliases:['eduyos']},{he:'עבודה זרה',en:'Avodah Zarah',aliases:['avoda zara']},{he:'אבות',en:'Avot',aliases:['pirkei avot','avos']},{he:'הוריות',en:'Horayot',aliases:['horios']}
    ]},
    kodashim: { he:'קדשים', en:'Kodashim', color:'#e67e22', tractates:[
      {he:'זבחים',en:'Zevachim',aliases:['zevahim']},{he:'מנחות',en:'Menachot',aliases:['menahot']},{he:'חולין',en:'Chullin',aliases:['hullin']},{he:'בכורות',en:'Bekhorot',aliases:['bechoros']},{he:'ערכין',en:'Arakhin',aliases:['arachin']},{he:'תמורה',en:'Temurah',aliases:[]},{he:'כריתות',en:'Keritot',aliases:['kerisus']},{he:'מעילה',en:'Meilah',aliases:[]},{he:'תמיד',en:'Tamid',aliases:[]},{he:'מידות',en:'Middot',aliases:['midos']},{he:'קינים',en:'Kinnim',aliases:['kinim']}
    ]},
    taharot: { he:'טהרות', en:'Taharot', color:'#16a085', tractates:[
      {he:'כלים',en:'Kelim',aliases:[]},{he:'אהלות',en:'Oholot',aliases:['oholos']},{he:'נגעים',en:'Negaim',aliases:['negaim']},{he:'פרה',en:'Parah',aliases:['para']},{he:'טהרות',en:'Tohorot',aliases:['taharos']},{he:'מקוואות',en:'Mikvaot',aliases:['mikvaos']},{he:'נידה',en:'Niddah',aliases:['nidda']},{he:'מכשירין',en:'Makhshirin',aliases:['machshirin']},{he:'זבים',en:'Zavim',aliases:['zavin']},{he:'טבול יום',en:'Tevul Yom',aliases:[]},{he:'ידים',en:'Yadayim',aliases:['yadayim']},{he:'עוקצין',en:'Uktzin',aliases:['oktzin']}
    ]}
  },
  parashot: [
    ['בראשית','Bereishit'],['נח','Noach'],['לך לך','Lech Lecha'],['וירא','Vayera'],['חיי שרה','Chayei Sarah'],['תולדות','Toledot'],['ויצא','Vayetzei'],['וישלח','Vayishlach'],['וישב','Vayeshev'],['מקץ','Miketz'],['ויגש','Vayigash'],['ויחי','Vayechi'],['שמות','Shemot'],['וארא','Vaera'],['בא','Bo'],['בשלח','Beshalach'],['יתרו','Yitro'],['משפטים','Mishpatim'],['תרומה','Terumah'],['תצוה','Tetzaveh'],['כי תשא','Ki Tisa'],['ויקהל','Vayakhel'],['פקודי','Pekudei'],['ויקרא','Vayikra'],['צו','Tzav'],['שמיני','Shemini'],['תזריע','Tazria'],['מצורע','Metzora'],['אחרי מות','Acharei Mot'],['קדושים','Kedoshim'],['אמור','Emor'],['בהר','Behar'],['בחוקותי','Bechukotai'],['במדבר','Bamidbar'],['נשא','Naso'],['בהעלותך','Behaalotecha'],['שלח','Shelach'],['קרח','Korach'],['חקת','Chukat'],['בלק','Balak'],['פינחס','Pinchas'],['מטות','Matot'],['מסעי','Masei'],['דברים','Devarim'],['ואתחנן','Vaetchanan'],['עקב','Eikev'],['ראה','Reeh'],['שופטים','Shoftim'],['כי תצא','Ki Tetze'],['כי תבוא','Ki Tavo'],['נצבים','Nitzavim'],['וילך','Vayelech'],['האזינו','Haazinu'],['וזאת הברכה','Vezot Haberakhah']
  ].map((x,i)=>({index:i+1,he:x[0],en:x[1],aliases:[x[1].toLowerCase()]})),
  gematria: [
    {he:'אמת',en:'Truth',value:441},{he:'שלום',en:'Peace',value:376},{he:'אהבה',en:'Love',value:13},{he:'אחד',en:'One',value:13},{he:'תורה',en:'Torah',value:611},{he:'שבת',en:'Shabbat',value:702},{he:'ישראל',en:'Israel',value:541},{he:'ירושלים',en:'Jerusalem',value:586},{he:'חיים',en:'Life',value:68},{he:'מים',en:'Water',value:90},{he:'אש',en:'Fire',value:301},{he:'רוח',en:'Spirit',value:214},{he:'נפש',en:'Soul',value:430},{he:'מלך',en:'King',value:90},{he:'כסף',en:'Silver',value:160},{he:'זהב',en:'Gold',value:14},{he:'לחם',en:'Bread',value:78},{he:'דבש',en:'Honey',value:306},{he:'יין',en:'Wine',value:70},{he:'מצוה',en:'Mitzvah',value:141}
  ],


  solarSystem: {
    image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA34AAAH2CAYAAAAvVV6IAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAP+lSURBVHhe7J0HgB1Hff9/V15/16tOV9QlS7bkbuPeuw3GFBtMNaYGgiGkkvxDQhJCCTVAEgjFEAgQAoHQYoptDDa2wRX3ot7vdLre3vv/vr/ZeW/v6STdSdfv+5Hm3u7s7Ozs7O7MfKcWZRUhhBBCCCGEEDJvKQ5+CSGEEEIIIYTMUyj8CCGEEEIIIWSeQ+FHCCGEEEIIIfMcCj9CCCGEEEIImedQ+BFCCCGEEELIPIfCjxBCCCGEEELmORR+hBBCCCGEEDLPofAjhBBCCCGEkHkOhR8hhBBCCCGEzHMo/AghhBBCCCFknkPhRwghhBBCCCHzHAo/QgghhBBCCJnnUPgRQgghhBBCyDyHwo8QQgghhBBC5jkUfoQQQgghhBAyz6HwI4QQQgghhJB5DoUfIYQQQgghhMxzKPwIIYQQQgghZJ5D4UcIIYQQQggh8xwKP0IIIYQQQgiZ51D4EUIIIYQQQsg8h8KPEEIIIYQQQuY5FH6EEEIIIYQQMs+h8COEEEIIIYSQeQ6FHyGEEEIIIYTMcyj8CCGEEEIIIWSeQ+FHCCGEEEIIIfMcCj9CCCGEEEIImedQ+BFCCCGEEELIPIfCjxBCCCGEEELmORR+hBBCCCGEEDLPofAjhBBCCCGEkHkOhR8hhBBCCCGEzHMo/AghhBBCCCFknlOUVYJtchCGh4elr79PBgYHZGhoSDKZjIyMjARHCSGEEEIIIfONkpISKS4ulkgkIrFoTBLxhJSWlgZH5x4Ufoegp6dHunq6ZOvWrXLXL++S++69Tx599FHZtGmT7Nu3zwQhIYQQQgghZH4BgVdZWSmtra2ybt06OfmUk+XMs86UxYsXS1mqTFKpVOBy7kDhNwbdPd2yf/9++elPfyr/8R//IT/64Y+CI0dHUVGRzGR0z/T1CSHTRywWk8HBQX7zhBBCyCRy2eWXySte8Qq58MILpby8XNKpdHBk9kPhFwIteB37OuSuu+6Sj/7TR+WOO+4IjkwOqCHYvn27dRWdTtBMjVoL3B+7qBKyMGhpaZFt27bxmyeEEEKmgHPOOUduedctcuaZZ0pVZdWc6AJK4RfQ398ve9r3yMc/9nH58Ic+HNhOLmVlZdLd3T3tNfDol9zQ0CC7du2yFgBCyPwH3z3GJBNCCCFk6vij9/yR/OE7/1Bqq2slHo8HtrMTCj+lt69Xdu7aKe98xzvlf/7nfwLbPJPZRXImulvimjDT3dJICCGEEELIfOeaa66Rj33iY9JQ3yDJRDKwnX0seOGHlr7tO7fL61/7evnFL34R2DrQRbKiosLUO9xhQheKJ0IIIYQQMttBpT/GoKG3V19fX2BLporzzjtP/v2L/y6LGhbN2pa/Bb2OH8a8oXsnWvoKRR/A9K1LliyRV7/61XLGGWfYZAmEEEIIIYTMBSD62GgxPUBLQFNAW8zWmf8XtPDDRC4Y0zdW904PakuqqqpsfB6EICGEEEIIIbMddOpDS9/AwEBgQ6YaaApoC2iM2ciC7eqJJRtuu+02ufZF1wY2BwKhh/U7YKDcMTkKunwSQgghZPygEhUs8NElhEwKmLX53HPPleOPP956pqGBgo0TRw9aRjs6OuT555+XBx54QG6//XbZvHlzcHRi/Pd3/lsuuuiiWbfUw4IVftu2b5Mbrr/hkEs2+IwKvz6amGnNX6LRqCWcFPeEEDJ5YKwLpjlHlzPMNMt8lJAjA4LvNa95ja0fR6YHrOn9pS99acICEEs9fO3rX5OmRU2BzexgQVYP9PT02IM83Dp9yJxgUAPgt8n8BOIewm+2T8NLCCFzCYyNR4sEar7b2tpsmRFCyMS56qqr5Itf/CJF3zSD+Ea8I/4nAjQGtAY0x2xiQQq/rp4u+Y//+I9gjxAH1ljs7OwM9giZHFKplFUqELIQwezY9fX1ctZZZ0lNTY3t+940hJDxceONN8q73/1uduecIRDviH88h4kArQHNMZtYcF09MVbvwYcflJNPPDmwIYSQqcNPpc0uxGQhgi6eEH6NjY2ybds22b17t4yMjARHCSGHAy1NEB1kdvCRj3xEvv/97wd7h+e+394nG47bYGnhbGDBVR309ffJXb+8K9gjhJCpZf/+/RR9ZMGCytadO3fKI488QtFHyATBmL5bbrkl2DtyMGSpu6eHyzqEQLsX4mRoeCiwGR94Hngu4wWaA9pjtrDghN/A4IDcd+99wR4hhBBCphIUNtHqTdFHyMTARC7j7d7ZuX+/3Hf//fLDH/9InnjyiVGCZsfOnfKFL33RfokDs/t/UePk2WefC2zGB54Hnst4geaA9pgtLDjhhxnFHn300WCPEEIIIVMJJ0YjZOKgVWm8E7nce/998i//9q/y4EMPysDAoIq/H8u/f+ELsm/fvsDF0QMh+atf/0p27NgR2Dieevop+e3vfhfsTQ3oNfOLO26f1Ps5GvBcxtvqB80B7TFbWHDCDzWPmzZtCvYIIYQQQgiZXWCdvvGAienuv/9+ueKyy+Wm171eXnTNNfLmm99os5Q/8OCDgaujJ5PJytPPPGsti2F27tolm45wrbvxAtH51FNPS2/f7Okyebjnk0wmbVZjaI7Z1MW25K+VYHtBsK9zn3zwHz/Ifs6EEEIIIWRW8upXv1qamg6/BhyWC3jk0Ufl+A3rpbys3OwwkcjKFSuktaXFtrtUHD751JO63yp3/fpX8pPb/k92qWBbrP77WafRaofujzXVNbYPsXXPPfdI/0C/pJIpuePOO2SjihjMfo5zEbaHHn5YHn70EenY1yE7d+6SivJySafTdi66nX7v+9+330w2Iw0N9VJSXGKtd7/81V02w+8dd94p9953r6zQsKJcjlY9tFY++OBDJlzramvtenC3bft22afX2b+/UxoXNZpfu3bvkh/95Mfy05//TJ5++hm7fkVFRW7m4MJwYEwf7hnXRvfzB1UYL1+2XGpraqxnwsOPPKzx9JS0tbba+YcC7n/yk58EeweC8MNNb2+vvP0db9ewVQRHZpYF1+IHMNicEELI5IPxD62aaaK2k9P2k4UOvgEUMv02IeMF61+Oh3RZWqqqKuW7//M/8tjjj+caNrCUUHht4oGBARv/V19XL5defIns2btXvv+D/zVxBNBqh9Y7j2/hC9uNB1z/Rz/+iYnRc845W84+60x56KGHzA7HcL3fP/aYfPs737F8YsP6DWb/39/9jgq53XLVFVfK6aedJj+//Rfmx8HYsnWrfO0//1OSiaRcdskl0tjYIN/6729bHAAfDlz7vHPPMfP000/J/3z/e3YsDATar+++W36l5rhjjw1sD83hnk9XV5f09fXNOs2xIIUfIYSQqQEZ6vbt261Wl2O7yEIHYm/t2rVcy5NMmKqqqmDr0ERKI/LiF10rq1auMiH3wY98WL717f+y1rAwSJvPOetsOe3UU9XtSrnyssulvaND9u7ZG7g4OBCQ555zrrUGnnzSyXLRhRea3YknnCBrVq+WxU2L5eorr7RlW557/nnZtn2bvOTF18m6Y9bKseuOlRdefY1s3rLZWgpBZmRETjrxRLnw/AtMaCGv2NveLiefeJK1tsHupXr+4sVNUllZqaLtXGvNPFvDf8YLzjA/7vjlnXKc+n3ZpZfKyhUrzS/c3z33/sbyH4Rj46aNct2LXyzHrDnGzIuueaH09vap6N1jfgBc+9Hf/14eeuRhuU7jEdcbD+N9PrMNCj9CyFHDmmwSBgPZC2tUCVmI4Dt47LHHrFsZK0LIVIGKBYixd7/zFrnxhldIaUmpfPHLX7aWNQ/c1NXVBXsiiWTCRGNmkt/L7Tu22/uOrqHf+9//NYOuneiSGh4fWFebDwta7Za0tqnb71vXTUwYgy6b1VXVgYvRQNh1d3XJ6tWrRpU/lrS12TFMAoNwNC1aJFWVeYGG+3/1jTdaq6fn0d8/aoL57DPPGhU/8xUKP0LIUYHBy+jTTwgh5EA4vIQcCR0dHcHW4UGlAgy62jc3N8sLr7nGWr9+ffevTQhNN+VlZbJs2TI1S82sXr1arrj8clmkQmws0B0ax1/+0pfZ9i9uv10+9el/znXbHIuiomIzYVAeKdE48GK2uLjksBXTGLe4XMP6m3t/I719vYHt4ZnI85lNUPgRsoBAAoiMYbzrAh0O+IfMBrXak9HqhxrJyQobIYQQMld5/vnng61D89TTT8s/f/Yzsq+zM7BxeTO6IvYPDEyo4iHcUwM5ejY78Z4bEH0QZCuWr7CunjBr1xwjq1eusmNjgXIExsNh4pWLL7xIbr7pDXLhBRfKvfdhDbzBwFUetFQWlxTL3r2ju6l27NsnkHyojMa19u/fP+p8tERibGD4Pi+/9DK5+sqrrOzx29/+zsIyHsb7fGYbLGERsoBAZrB8+XJJJBKTItSQQCIhRReO8SaWh2Lp0qUSiUSCPUIIIWRh8sADDwRbhwataJHSUvn5L35uE7gACJ6777lbFjU2Wn4/Hmpra+S5554zAYb8HLNbbg+t2VesZQaUG7YGwsmLJ8yuubd9r81eOTIyIm1tS6Svv08eeeRh8wfmvvvvk3//0hdtVs2xwKyjX/rKrTaZiz8Hk6OURkpVkOl19R8mhdm9e7ddFy17x6xeI3f96i5p72g3PxDu2++8Q9paWqVMhR/C0dPbI/fee2/Oz9/o9v/99DYrt3gg+DBe8cwzzpTfPfiA7N6TH/93KMb7fGYbRRoRk9u5d5azacsmfSnagr2FCT7cBfbYSYAXe/gN13jNFvhuEkIIIW4B9y9/+cvB3qHZo2Llu9//3qjF1bGcA9b2Q+sXlkL4r//+tlx37Ytt3Bvo6u6Sr//nN+TKK64wO4yL+89vfsMmWYGwgmhEy11LS7OcpaIIoOslxuFBLL3i+htGnYdZQs895xxzCwH5ne/9T27hclTovvwlL7UlIHDdL+l9XXzRxbJ61So7DjCu73++r37rNbH8Q0LFGCatwYQxKBdg1k0s94CWvNe8+tW2xMTPVOximYZYNCYDgwN2z1defkVuNtPCcKRTqZyfheGAaP3Rj39sohUT0xwOLLexeZzrF27cvFFamw+/RMR0QOG3wMDUuehr/fTTT1ttCiGEkIUBKlZQIILBuB8YVrQQMnt573vfKxdeeGGwd2jwLaPVayQzIlEVQrEjmEkWfvT09lrr3sF6BqHSGCIp3DsH50Fcwc6f4/0CqXEu7wO/0XKojsc8xy89ga6eHnTlHFTRBzsv+MIcSTgOx09/+lN5//vfH+wdntkk/NjVc4GBWpozzjjD1nchhBCycEChrK2tTS699FLr8o1afULI7OVLX/rSuHvnQNCgcr8sXXZEog/AD7SKHWodVpQjC4dkwC3G6IfP8X7BHMyvQuA3WigPdg7EXVj0Adwr7nks0QeOJByHAs8Dz2WuQuG3wEBNyhe/+EVpb3d9ogkhhCwMUKgqLy+3Xh9Yq2oyCkGEkKkDXQk/+tGPBntkNoDnMd4unrMRCr8FBmoqMBGHH9iKjB+FAUIIIfMbdMXCmJdvfOMb8uSTT46a4IAQMjv5/ve/L5///OeDPTKT4DngecxlWOJf4GC9lOOPP95+CSGEzF9Q8YdJIJ566in7xTgdQsjs5ytf+Yp85CMfGXe3TzK5IN4R/3gOcx1O7kKs1W+BvQaEEEIIIXMG9M5auXKlvOxlL5MLLrggsCVTDSZywZi+o+neyVk9ZxAKP0IIIYQQMpeA8GttbZVNmzbJ4sWL5dxzz7UeW0uWLLHF2jls5+hBy15HR4ctzo51+m6//fZJGc9H4TeDUPgRQgghhJC5BsQdu3vOPbicAyGEEEIIIYcAQoezz+ah6CNHC4UfIYRMIqWlpcEWIYSQowFdGjn5HCGTB4UfIYRMEqidXrduHWuoZwjEe9gQQuY2XV1dbOUiZBKh8COEkEkCBZSHH36Ys+TOABB68XhcKioqbJHySCQSHCGEzFU6Ozsp/AiZRCj8CCFkEmEhZeYoKyuTSy65RC677DKpqalhqx8hcxxWohEyuVD4EUIImRdEo1FZu3atnH322ZJIJAJbQgghhAAKP0IIIXMetAzs379f/uu//ktuvfVW6e/vD44QQgghBFD4TQPoboQuSKiBZtcjQgiZGjARxGOPPSb333+/7Nq1i93ECCFkgYLyNsvcB0LhNw1gpr/zzjtPTjzxRL6EhBAyRUDoDQ8P5wwhhJCFCSb7qqqqCvaIh8JvGkBh5Pe//71s3749sCGEEEIIIYRMBUNDQ+zyPwYUftMAZvl79tln5bnnnuOMf4QQQsgcgb10Jk4sFrOJlhh3ZCZBr4/e3t5gj3go/KYJtPpxvAkhhBAyN0BXsWQyGeyR8YChLccff7xcf/31XEuTkFkIhR8hhBBCSAg/MURJSUlgQ8YDKriff/55ueeee1jZTcgshMKPEEIIISQERAvGB2GmWDJ+EG+YUffJJ5+0MVaEkNkFhR8hhBBCSAEQMWy1mjiMN0JmLxR+hBBCCCGEEDLPofAjhBBCCCGEkHkOhR8hhBBCCCGEzHMo/AghhBBCCCFknkPhRwghhBBCCCHzHAo/QgghhMwasAg4IYSQyYepKyGEEEJswfJIJGK/MwWuv2LFCiktLQ1sCCGETBYUfoQQQgiRkpISaW5untEWNyz6jcW/h4eHAxtCCCGTRVF2ga2yuWnLJmlraQv2CCFkakHrCczRJLXhc4+mNcafm8lk7NeDgn74GpORLRxJOP05/vqTed9j+Tkejua6wF8PogrbMN7PwudwMMYKA/zD+d7/8D1OBH+OF3vwZ7zhOhjej7HCPVHCfoTDiu2JhBPnhO8N2/DjSOKMTA3+mRAy39i4eaO0NrcGezMLhR8hhEwhLS0t8vrXv15OOeUUK3z6AvahQOH0ueeek3//93+XBx98cFTrBwpHTU1N8qY3vUlOPPHEcXWJQzIPP5955hn5/Oc/b3560um0fOMb38gVpj/wgQ/IHXfccVQFMIiS448/Xl772tfKsmXLbH88jIyMyD333CNf+cpX7P59GBYtWiQf/OAHJRqN2v5EwH0//PDD8vWvf102btxo1xgvqVRKLrvsMnnJS14iFRUV43p2YP/+/fLd735XfvCDH8i+ffvsPm644QZ5zWteY8cRpu9///vy6U9/2vYPR1lZmbztbW+T8847z/bh36c+9Sn50Y9+JMlkUl74whfKi170InuW4wHX7+zslG9/+9vyve99T/r7+y1uEb7rrrsucHVkIGyPP/64vOtd7zK/Xv3qVx/Rc4M/MIij2267zcKGe/Ti7ZOf/KT88Ic/DFwfnqVLl8o//MM/SGVlpe3j/fqbv/kb2b59u/kJcD0y/eC7wvcF/PdCyHxiNgk/fGALCo18pCg0NDQ0U2q0MJldv3599sknn8yq2AhSoImhBfKsFp6zWjAy/2COO+64bHt7e+Bi4gwMDGRf9rKXmV8Ipxa4cuHTArUdw/UK72e8RkVeVoVIVsWP+XckPPLII9kTTjghF46VK1dme3p6gqNHxqZNm7LHHHPMAeE9mFERlVXRkVXRHfgwMXDeF7/4xWx1dbXFdV1dXfbXv/612SNehoaGsirkDhnXOAZz44032rsAcJ6K42w8Hje/v/a1rx1xGMEXvvCFbGlpqfmn4vqIn5kH59911112z3/0R3+U7evrC45MHPh10003ZROJRPajH/1oYOvsN2/ebO+If48PZRBP3/rWt7KDg4OBD9nsAw88kF2xYoW9ryeffHJ21apVR/Xe0xy5wTO45pprsm9729v4DGjmpYH2mC1wjN8Mo5nWuGuRCSFzB7QW3XLLLdbSgO9c09vgyPiAe7SUodWvvr7e0gktnMtnPvOZXO34kYDWl7/6q7+ysVxTAcKI1hjcP5jIfcMtjAo0azFCS9dYeHeHI+wGraSf+MQncq07h+PUU0+1llrE+3ivFwbnvfSlL5VzzjnHnmNHR4f88R//sWzZssX8gp2KLrvXQ+UBKkrkYx/7mE16gvNU8Mi1115rrcCXXnqpXHHFFbkwjpewW7SkXX755bZ9qLiZ6P0fjPH6A3cwCNNY4fLPEy3KBws37NEKqgLU7hFxXgiuUVVVZa3KZGZQIS8///nP5T//8z8n7T0jhIwNu3rOMLFYzApxu3fvZoJHyDxiyZIl8s1vftMK7gATVjz11FO2fShQWK2pqZHjjjtOEomE2V188cXys5/9zAq5t99+uyxevFgGBwfl2WefNXO4tAN+omALP9E1dMeOHXLjjTean+Xl5dLe3p4TD9dff71861vfssLYkXDaaafJr3/9a7smwvib3/zGuhWOh+XLl8uqVassLI888ogV1iGUVq5cKQ888IB1awS/+tWvTEiNB8QVup3ifhAexG1vb29w9OB89KMflXe84x0Wlr1798r9999vE48cCi9ATj/9dOtSiHP/5V/+Rd7+9rfbuRDFb37zm+V973ufxTvs8Dxvvvlm64Za+BzXrFljXUYRJzi2c+dOeeMb3yj/+7//a3797d/+rQlk3Ft3d7f88pe/HFc+gnxnw4YNUldXZ+cijKikeNWrXmWiciw/IOTPPvtsE0/oLovnivemEJz7xBNPyHve8x5597vfbWFEWAcGBuy5jSfuAeISfqGrJ7oew593vvOdwVEH/ER3Vdjv2rUrsM0DsQzx/nd/93dSXV2dez4A3Z3Rhffpp5/OCULExXjijxBCJgK7es4gs62rp2Y41sVmrGM0NDRz16iIse5knve+971ZFR3jMpdccol1TUQXTJgrrrjCukChq+K2bdvMPy3oZ7VwPeb5Yxl0pVIBZudqITl75ZVXWje5ye7qqWLN/ALoknrGGWeMGZ6xzJ/+6Z/mwvL4449nm5ubzc9wV0+EEV0kxzq/0NTW1tr9+PNgqqqqDghzoUG8oAsk3AMVOdm2trYxrzGWQVdH3AfOv/XWW7MqtHJ+4/rf+MY3rMsmjqsQyv7zP/+z2eO6/voq1LM//vGPc+8A7l/FT1YFmLnB76c+9SkLH/x56KGH7H7HCk+hWb16dfa2226z8+A37hXXhJ9juYc59dRTc88G3TfxTo7lDgbvFPzD++m7eu7Zs8e6Zo7l/lAG3TxV8I/q6omurb7LLL6Dj33sY5aX+vcW14a56qqrstu3b8/dZ7hLrO/q6Z8LjTOIt2g0ar9jHaehoZm4mU1dPSn8aGhoaKbAFAq/W265ZdyFKRSczzzzzOwFF1xgBuPDUKhds2ZNTvh1dXVl3/zmN495/lgGAsyPDZxK4QdB4Nm9e3d23bp1Y7oby7z1rW/NheVQwg9jJwvPHcvg/i666CI7z3Mkwu/OO+/MlpWVjel2LHPSSSdlL7zwQnt2a9eutTF04eOLFy/OPvPMM+Y3roHxkG94wxuykUjEjkOAQehgXB+OQyT+6Ec/MjHo36FC4XffffeN+/2CEN2wYYOFD+E89thjx3QXNhgD5+MDYu6ss84a0503CEtY+OGdW7Zs2ZhuD2cKx/g9//zz2S1bttg23heIv3e+850m/uAe7y9E5o4dO3JiDwL79ttvt21A4Te2QdzhfTiaNICGhma04Rg/QghZYGgBNdg6POgaedddd1lXTBh0BddCd3D0yND0PtgiR4IKmWDr8KBb6E9/+lN7dr///e8PWJNOxbu8/OUvFxWz9lwwlhHj+FSs2BjMF7/4xdZFEV0ycV3MPPlnf/Zn9jvWc5zos0UXSXR1RPgQTnSrnUtg5kfMFuq7+6oItllfMQMrujKje+9Xv/pVaWhosO62mLX04x//uM2CSg4N0hm8D0eb3hBCZicUfoQQMkWEC+QY87d+/fpxGYzFW716tU06MRHBsVBAnEx1vISFOsbjrV27dsxnNZY59thjbfKcgy1jgLD/7ne/s0l2IEoAxnN+5zvfkYsuukje//7326QkeH8g0v78z/981BIcnvD7BfGI92as8Ixl1q1bZxOkQChNxzuG8XYYqzhWWAoNJkSC+4OB8GK84F/8xV/Y0hmIBwg8LHGBCW/wu2LFCrPHOEosnYEJh8Y7vpAQQuYtmjAuKNjVk4aGZjoMuuX97Gc/y3WPQ3c9dFccr8HYpG9+85s2Hsv7eTRdPV/wghdMe1dPjOtCd8KWlpZxGS3IH7arJ7jhhhuyxx9/vHVXPJSBm7e//e3BWQ6/vEJhuAsNliLwYcEvugoWPqODmX379tm4QCzFcagx3Oh2+pWvfCW3VAPAOEx/XbwzKlisa2ZhmGGH+AovUTDeMMId3oW77747+6IXveiArqhjmaPt6olzcd3xhPEnP/mJdW/2fhV29VQRbP5jDOBHPvIR6+oJEG979+61awDEDZbQwDeEdxrdrT3s6klDQzNdhmP8ZhAKPxoamukwmCDhXe96l4kAFOCBLziPB7jF+CSMS0LBFwXduSb8UPD+/e9/b+PPxmM2bsxnjocSfhjf9fTTT4/L7Ny5087BvXV0dNhzKQzzWGbJkiV2PuIG50702eG8Z5991gToweIT9piwB/fu/ffnwvziF784qFCF3SmnnJJbJxJmIvh7wnp44xmHebTCD/jzDwfuu76+PufXwYQfTGNjY/Y73/lOLg78fWEb7wnEP+IZbin8aGgOb/CtIJ3EmGNsj+WGZmKGY/wImQDoioRuP5oABTaEzH7Qxezzn/+8jd3qDbqYTeQdhluYM844w6ben4vgu8U6dSeddNK4TGvr+Ka7xhguLP0wHoM1EIHmdzb1P57LeMA4PKxxpwLBxjsdybPD/aiQHnP9OAB/scQHlirAkhHAn/v888/LH/7hH9p4T4S9ENghbHCDpUImEj7gr4NlPm644YbAdmqZaBgPB+IAS1xgiQx0hcU+roFfdAFF3D/88MMcr0bIBCguLrYu51hGCNtkfsEnSmY9KDhiIH94vAwSo4MVpgiZDaDwiUL73/zN39hYKowRw7gq/B7KYHzYa1/7WluXzL/nGOs3F0GBG0ILk5uMx8DteArpGPcGg3X5vMFYuUJRNzIyYu56enrk//7v/+S9732vPZfxAD8xwc4LXvACW0dwPM8ObjBGDeP3AJ4dxN+hBA/uG2PQvvjFL+bGFaKi4AMf+IA8+uijh5wUCPf7wx/+MDcmdKwwjWXOPfdcuffee3NCCUJ6qsFELJh85XDxiOOY2Ga86zTiHrAu5ZVXXmlrPiI+8bzf8pa32DjAQ8UfmXnwjeD7wgQ9ZHaANBhrcaLyicw/KPzIrAeZuq/N9WCyBSzIS+YuKHBiYWe06M5XfOtDX1+fPP744/LYY4/Z76EMZoGEQeF1roP7/sIXviAf/vCHx2Vuu+224MxD86EPfcgWHEdrlzdYLPzOO+8cJf4wG+pf//VfyxVXXGGzaCItGS94djAQEigAjefZwQ1mRIRoGa/ABCho4d69SGlvbx9zNtCDgfOefvrpMcM0lkE4JxIXkwHuBWE8XDziOOJ7vPfuQUXJ9ddfbwVWvEvf+973giNkNoN3/5lnnuHEO7MIpF3PPvusfYusOJl/UPiRWQ8Kb/fdd5/VwHswnTfspxMUAtECg19y9KCmF11JUNs7H+MUlRNXX321tVbfeOON1pqB+0SmeigD/Ls214Hw+8QnPmFLEYzHoOXrcCCOvvWtb8lnP/vZA8zNN98sd999d66wgsohTOkPMeZnfxwvZ555Zu7ZXXLJJdbjIPycDmXARN5pnIMwh8/x/hwMhOf000+3MMKgxSschkMZFLbxO90UhuNg5kjCh/hDSytayz/zmc/Mi4qThcCRPm8ytfhvkcw/KPwIKQCFr4qKChsbFO5Oipap0047zewnUqgjY4NMZePGjSYO5iM1NTU2DT+mlv/nf/5nGzPhBd3hzMFaQgvfO7yfY51faOAOXamwDQ6VqReeOxEzXd/FWOHH/qZNm+RP/uRPbNwcCpMYY/i6173Oug5iuYSJhO9Vr3pV7tm95z3vsWcy1j2PZfyzO1Q8Hy24N4xhQ/iwVAHetfG+DzgX9+PjY7qeG8I33jB6492PB3TrxRqK010pSAghcwUKP0IKQCEI43L+4A/+YFThG4UPjDesrKwMbMjRgBp6tMSgsD5VheOZBu8PBBfWZEOXQ3Rh27x58yEN4gOTkPhJSYDvvojubz6uUHDHpCBwDzOWX95AYH/961+3td4ARFHheDgPxA7cj+XPoQwmGMFYs5kC8YL4Qe8AtB6iuyW+ZbS8/tEf/ZG1LkNEjBd0PfPPDhPsYLzdWPc9ljn55JNzz2kqKzZwfwgfwonF38fzLsCgZezss88OfHGCaapB6+vtt98+7nfL3wsmnpmIMJ2vaQkhhEwKmkguKLicgzNaAMqquMkmk8kxjy90o4Vqm+Y+EomMske8qQAcZUdDM5ZRkZX9whe+YEsyHCkqjm1dsoaGBnvvMK39HXfckVse4kjBdPhtbW0WzvByDkeDCpysCp5Ryzns3r17XEsFePPWt741F5bHD7Kcg4rW7Pr16w84N2zwnWLqfqyP5+NfRYQtrTCW+7HM+eefP2p9vYmCcCLMWDYD4RnrGmFz0UUX5dbkQ1hVbI7pzhu8Dy9/+ctt3b+jQUVf9pprrhnzGmEzGcs5TBRc76abbjrocg5jXfdgBu65nAMNDc1MGC7nQGYctLZs3759Wmp65xqoXcYMgZiRsbBVBC0l+t0Ee4QcnO7ubhvfVjg+dTzgHUPrFVo+3v72t9vEFQDvJSY1wSQYE/12vZ9odXzf+95nfk8m/rvAb3j7aAi39IT9PRz4TtEFEuP+fNxj5sovf/nLo2YHPhT33HOPfO5zn7OJVuDfRIB7jEP+6le/av6MJ9zhex0P8PNnP/uZfOMb37BrTTSuEUbcG8KImUHHw0SuAbcTDVMYfz7ixcfN0fgH/PlH6w8hhMxVijQBXFAp4KYtm6StpS3YI4SQqQPdg7GWHCZ5aWtrG3fhHsky1nVDwf7Xv/51brISAD8xIQ78bGlpmZCfGPv005/+1MQoRCDsMPbtH//xHwNXRw4qSSB00e3wTW96k4ULE2x8/OMfH/cMklhm4LrrrrNthBXiDeKkrq7Oxu5hbBrArJ5bt249bAHed/MMd89GN1B04zzcuQg/xvpibOapp54qsVhs3HENsYnulJipE6L9cNcC6EaOeMPzhZDD8g6YWe9QIDy1tbXWjRXrIPr4ORwIDyoRfvvb38qPf/xjm/jmcOIWk+RgHCGuiXcHzwazMR6KCy+80CadGWu86nhAOL/5zW/a0hNXXXWVvR8Az/6DH/zguOLVg3Dj/Be/+MW2j3UaIez37Nlj+4QQMlVs3LxRWpvHt07tVEPhRwghUwwKnWhpGq9wQLKMwrUvjBcm0/AHBgX9ifoZFpEA50PUTAYQPD5cANeEIBxvixkEghcJOAfnwg/4GY4/XGcsP3Eu3IUXzIddeGwfWkoL4/NQjOXH4fBhB+O9Fvw/knjzcYJzIRrHC94DvA9gPGHEdcLvCcJX+C4VEn6eR4p/ZxE/3i/Ei2/JnQjh8ITfL0IImUoo/GYQCj9CCJmfQJiglQ+tOCzQE0IImQ3MJuHHMX6EEELmBWjNQxdRij5CCCHkQCj8CCGEEEIIIURB13aMV5+sYRCzCQo/QgghhBBCCFEwFvi8886T9evXT2js9FyAwo+Qw4CaH3z4mFxgviUAhBBCCCEkDyaUeuihh2wG4fkGS7GEHAbMlldfXy9NTU1SU1Nz1LPUEUIIIXMJVHqy4pMsFDBOfMuWLbbe9XhmV55L8Csm5DAgs1u9erW8+93vlrPPPntC0/ITQgghcxnkdxs2bJAzzjiD4o8sCCD8vJlv8Asm5DDgw8e6YGjpY60nIXODmaycwYQAWPydvQPIfAHrKZaVlS2YSk9W7pL5CtfxI+QwQOhVVlbaDE8A08X39/fbNiFk9oFCG4TXvn37ApvpZdGiRXLllVfKt7/9bWlvbw9sCZm7IB/Ed4Vub/O92Ih7xXqgnZ2d8/5eyfTAdfwImUMgo+vo6LD+3jBYK4zMTZLJpDQ3N7M2d56D55tOp4O96QcFxttuu40VRGTegHwQE17MdyGEtAMGrZuEzEco/AgZB8jswobMPZCZDw4Oyq5duwIbMl/BN7pt27Zgb/rp6+uTjRs32i8hZG4BkYvZHFlBSOYjFH6EkAUBxADGqUD8UbzPb/B8Z3ImNlzfG0LI3MF/t0g/ZjINIWSqoPAjsw5MiICZMwkhhBBCCCGTA4UfmVWga0UikbCxWIQQMh/x44gIIYSQ6YTCj8wq0MWip6dH9u/fH9gQQsj8orW11ZZ8IIQQQqYTCj8y62DfekLIfGbz5s2cHZiQGQbLNsTjcRtawhZ4slCg8COEEEKmEVRszdeJX9iNlcwFIPqqq6vl9NNPl3Xr1tnwEr63ZCFA4UcIIYSQowYF56ampmDv4GACL7S0oLtrSUlJYEuOFgqX8QPhV1lZKeeee64cc8wx9j4y/shCgMKPEEIIIZMCFq0/VAEax6qqquTMM8+Uk08+2QrfLHAfHYg/iOnm5mbG5ThBq3tHR4f8+Mc/loceesjW3OTyKxMHAhrvHpk7UPgRQiYEChZI7FnAIISEQcF57969hxyjjbQDMzdfffXVcuONN0oqlTI7cuQg3kdGRmT37t0UL+PEC78HHnhAnnzySauwYNxNDJQB0EW2sbGR5YE5BFNbQsiEQCFt6dKlkk6nAxtCCBkfKHCjdeVnP/uZGW9Hjg6IFogXMn7w3iHOBgcH+Q4eAXjnMAv71q1bKZrnEEX6sBbU09q0ZZO0tbQFe4SQI8HX7jGxJ4RMBN9jADMpAhS4UfBmWkIIma9s3LxRWptbg72ZhS1+hJAJg0IaC2qEkImCdAPdEtHSAoNlLZiWEDI7QMUMl7eY31D4EUIIIWRaYeURIbML3xq/ZMmSKRN+mMkXY3wpLGcOCj9CCCFTBjN4QgiZ/fjW+GeffXbKxjz6yZ3IzEHhRwghZMrAOm1cq40QQuYGw8PDwdbkg+7dmE2Vrf0zB4UfIYSQKQGtfbW1tezaQwghhF28ZwEUfoQQQqYEZPA7d+60Kb+Z2RNCCJkOUNHIysaxofAjhBAyZbCGlxBCyHQBwVdaWiqRSITibwwo/OYxWGB72bJlwR4hhBBCCCHzF1Q0YnhBVVVVYEPCUPjNY9C9atOmTcEeIYSMH9SUYgY2QgghZK6AvGv//v2ye/fuwIaEYa4+j0Gtx1TOzkQImZ8g40ylUlJfX8+uMoQQQuYMfmgBlqTgMIMDofA7CnyNOAtG8ws8Tz5TspBBZokeA7t27WLGSQghhMwTKPyOAgwevfDCC2XJkiUUCvMErDe2evVqrjtGFjwQfFO1iC8hhBBCph8Kv6MEE6iUlZUFe2SuMzIyIk899dRRdZH1lQCsDCCEEEIIIbMFCr+jAOLgu9/9rjz66KOBDZkPQPwdKRB7jY2NnE1qFoFnQhFOCCGEkIUOhd9R4LtCQShwHAzx7NmzR7q6uvhOzAKwjk91dbUJ8Wg0GtgSQgghhCw8KPwImUQg9oaGho6q1ZBMDmjlg+A799xzzVRUVLDlj5B5DMZmc3w2mSiYpK+mpobL15AFAd9yQqaAhdTahzGu5eXlsy7ThMhDmDAON5lMskBIyDwG33tdXZ1964RMFOTZ7KVDFgIUfoSQIwaFrRNPPFFe85rXWLfK2QS6YXd0dMhtt90mP//5z2Xfvn3M2AmZp+Db3rlzp3R3dwc2hIwP5BXt7e3MH8iCoEhf9AX1pm/asknaWtqCPULI0YAWNSz0jfFznZ2dRzUb6lThWyKR1DFjJ4QQQhY2KBdMZ5lg4+aN0trcGuzNLGzxI4QcMagpxUQ2e/funZWiDyCMMBR9hBBCyMIGPZUw6RsqrRciFH6EEEIIIYSQeQ8qgTH0o6+vL7BZWFD4EUIIIYQQQhYE6KG0UGdfp/AjhBBCCCGEkHkOhR8hhBBCCCGEzHMo/AghhCxoMNgfhhBCCJnPUPgRQghZ0GA5kiVLlnDxb0IIIfMaCj9CCCELmkQiIdddd51N8U0IIYTMV7iAOyGEkAVNSUmJtfphpjcYrvlICCFksuAC7oQQsoDg+LHZDab1xppOFH2EEELmMxR+hBAyhUD0VVVVSSwWowCc5VD0EUIImc8sSOGHwldFRYWUlZUFNoQQMnUMDQ1JJpOhsCCEEELIjLFgW/x6enpkYGAg2COEkKkBYq+rq8vEHyGEEELITLEghR8KYhjLMTg4GNgQQgghhJCJgImRli1bxm7shMwROMaPEEJmAcXFxVaIgmEhihAyF0AX9u3btwd7hJDZDoUfIYTMMBB6lZWVsnr1aqs9T6VSFH+EkFkPelBhRlyOXyZkbkDhR6YVFmYJORC09kHs3XjjjfKqV73KRCC/FUIIIYRMJhR+ZNrAAsnLly+X0tLSwIYQAlBbjrXktm3bJvv27aPoI4QQQsikU6QFjgXVPr9pyyZpa2kL9sh0gwItu4QQciBY5y+RSNg3gomnent7+a0QQgghc5yNmzdKa3NrsDezsMWPTCssyBIyNlheprOz01r8KPrmJhDt6XTaejccKXV1ddLW1ibl5eXS3NxsXYAJIYSQyYDCjxBCZgkQe96QuQdE2j/8wz/IBRdcYOM2j4SbbrpJPvGJT8jJJ58sX//61+Wcc84JjsxO/PhUdk8mhJDZD7t6EkIIIZNAbW2tPPPMM/L3f//38rWvfc1a7x577DFrwfVjnCGQMAV+U1NTcJYDi/w/+OCDcv7558uSJUvk2WeflS984Qvyuc99Tu644w7ZvXu3+b1q1Sqprq4OzhLZu3evPPHEEzI0NGQzwra0tJg9rvPkk0/K5s2bbX+qgPBrbGy0Kf1ZYUEIIQcym7p6UvgRQgghk4AXfmj127Vrl7z2ta+VV7ziFbJlyxbrAvpP//RPtk4jJvF585vfPGqiK4zr/MAHPmDuzj77bPnkJz8pn/nMZ6SiokKGh4flBz/4gQnAP//zP5eysjITdsi++/v75R3veIc8+uijctttt+XGiUJc/vEf/7F8/vOfD64wdeCecD0KP0IIORCO8SOEEELmKRBe8XjcxulBFAGIIkzgk0wmrfUPx6655hq56qqr5Oqrr5aOjg4599xzzY3vOgkxBRF55ZVXyvvf/35Zt26drZl23XXXybXXXiuve93rZOvWrXbeWWedZdd561vfan7C7x/96EdmN9VgRlqKPkIImf1Q+BFCCCETAKLMm/ESdutF3a9+9Su566677Lenpyc4mgfdKNFd8+6775bHH3/cBFZNTY28613vkne/+93ytre9Lde1E2CCoPvvv9/8/PWvfy07duwIjpCZZqLvCyGETAUUfoQQQsg4QeF90aJF8qY3vcnG2xVysJavcMG/cNsT3gZ+ghiIRIDj6Pb53HPPyfPPP29j+775zW/KnXfeadcN+4tzIBTJzBOJRKyFFwbbhBAyU1D4EUIIIeMEAgtj+dDqhtk3P/vZz+bMhz/8Yeviiclc0CUTk55gohcc+9jHPiannnqqjcmDIIOo+/SnP23HMJZv8eLFdsxfA613mLDl5ptvNjcYE4hzIOzQFRRdRr1B91B/Hpld4HlB8J1xxhly5pln2phNL84JIWS6ofAjZAZAxo9CnK/RJ4TMHTCBy7e+9S1r+cP4Om8g7H7xi1/YsV/+8pfW5fKEE06wY6effrrNzHnrrbfmunViqQZM5ILfjRs3mnBsb2+3cXvo2vmf//mfJgjhZu3atfLVr35Vfv/738tpp51mQuIFL3iBGcwCun//fmsFhFgkswek9RDmS5culRUrVtg2hR8hZKbgrJ6ETDPI9NEq0NDQYPuY/Q+tA6ytJ2Rh8Bd/8Rfyl3/5l9Zyx9kw5z9olUXrL8C4S6b3hCwsOKsnIZPMXKpBRVjR3eeSSy6Riy++WCorK1kDTMgCAgV/tOyRhQGe96ZNm8xQ9BEy9WA2ZSyNQw6Ewo/MaSCY8HH7KdPnCpigAS196PqF9bsIIQuHH/7whzY5DFv7FgZ4xkjzYfi8CZlaUC5EmRAV7ORA2NWTzGkwRq6urs5qz+fS2Bas44VuXqC7u5vjcgghhBBCJgkIwNkicdjVk5BJAjXmaDVDTepcAq18+/btM0PRRwghZCZBIZlDDsh8gq3rY0PhR+Y8c7W7FMLMhIkQMpuhGFgYoAdKa2srnzch8xwKP0IIIWQWMNsK3VhsHDNSzmUxgLE+FDOHB0MOMPkMKyMJOTqQ3iDtnK3LdVH4EUIIITMMWltm2yRVCA/GI89V4YSCV1tb25yb/GumoOgj5OhBulNfX2/ibzZC4UcIIYTMMFdeeeWsE1j9/f3S0dFh3ennIhAyWAx/ZGQksCGEkKkF6Q3W65yt8zdQ+BFCCCEzDLpUkskFwm9gYIAtWYSQaQXib7ZWmFH4EUIIIYQQEgJdhGdrd725Dno3cOztzEDhR2YMfviEEEIImY3EYjGpqalhOWUKgKjGODgy/VD4kRmjtLRUqqurgz1CCCGEkNlBb2+v7Ny5k12FpwB0g0Q3bDL9UPiRGQOJKRYyJ4SQ2QBr9gmZOPF4XFauXCmLFi0a9Q2hcnfVqlWybNmyOTuzKkXf1ADht2/fvmCPTCcUfmTGGB4etrWDCCFkpkG3LhRQKyoqAhtCyHhAd8jPfvaz8trXvtbEngcTFn3hC1+Q97///YENIWSmKcousOqMTVs2SVtLW7BHCCFjU1ZWdtCuyF1dXTbN/cGST9R6Y/0z4LuzpNNpefnLXy6/+c1v5OGHHza74447zgpLn/zkJ+X55583OzIz4Hm/5CUvkfvvv18effTRaV8C4N3vfrd84hOfmLVTgBNyMBYvXiz/8R//Ibfddpt84AMfyL3D5eXlZoe07fWvf7285S1vkdNPP93WOUPa+dOf/tTcnHrqqeYewP6pp56Sj33sY/Ka17xGTjvttOCIO7Zr1y75y7/8S2tJfMUrXiF///d/b0t2IM2F/w0NDXLrrbfKW9/6Vlm6dGlwpkhnZ6eF7fHHHw9sRoPzIVpn82yMZO6ycfNGaW1uDfZmFrb4zSPYTYnMR/Bez8S7fcEFF8h9990nv/71r+Wuu+6SX/3qV2aw/fa3v92EHGq0wwYzwPnwJhIJaz3yxyAi3/Oe98iZZ54pqVTKjjc2Nsq1115rBSfvDt2mUDDi9zy9oPfB1772NXniiSdY8CNkEkFahtb0P/mTPzFhhnQSBt0/YSC4vB3S1Ve96lVy+eWXmyA8//zzzR5ukD6i8uyNb3yjdSvFMd9Cj2sce+yxJixvvPFGM95PtObj2Jve9CZzOxZIc5Ee+wo7QuYrFH7zhMrKSitIEjLfgBCqqqoK9qYPXwBAa9wf//Efm2iDwfb3v/99ufrqq+Vf/uVf5HOf+1zOoMUGNdHo+vSnf/qn8tGPflT+7d/+zQwKJCi8oBb7X//1X80vALfvfe97c3586lOfkvPOO2/OjomZq6A1AQuWc903QiYXfE9oUe/p6ZG/+qu/MvH2yle+Ur74xS9a6x5a2VHJBvPAAw+YCIMABJs3b5YbbrhBrr/+ernppptsshWIPhCuHMM1sA+DijXg/YT50Y9+JF/96lfNfixQ2YOWQ044QuY7FH7zBEySgjFzhMw30G2or68v2JteUAhAQeSXv/ylGbT2/fjHP7aCCgoXTU1NOYNWu5e+9KXyR3/0R3LZZZdZ16YVK1aYfXNzswlYABEL97W1tbYPgYdacO8HRN+73vWuGRG7hBBypIxVYRK2gyhD5QoE4P79+01socfDzTffLNdcc40ZpJ3hSmycj9Z4nAMTbo0vvJ7f/+EPf2iCEd09YdAFFK19EJthsRgG58LvQj8JmW9Q+M0TMO0wx4aQ+QjGXMyU8IMY++53vyvPPPOMmccee8xa8sDdd99trXNoEYRBa9+ePXusNhrdOrdt22bdjS688ELrNorxLKic+dCHPiQXX3yxiTuAGuw3v/nNOXff+ta3bNwLuxwRQuYS6NFQaNB6dyjg5v/+7//kkksukRe84AXWxXPTpk05AVYo1ML78LvwegBlIbQsosINBr0w0GV/7dq1dpyQhQyF3zyCNVVkPjKT7zWmm4ZQ+8M//EMzEGv//d//bccwsQDGhH3kIx8x80//9E/S2tqaCy9+IVq9QW0yCi2whwAMt9DjmHfH75gQMpdAxTMqxt7xjndYRVZ7e7sZTOqCCVZ++9vfWrqGFjukcR4INEx0hW7zOH/37t1WubZkyRJLE9GTCeeExZ7vjg336A56xx132LVQ6YYeF88++6xd89Of/rTZwSAcGFuNazF9JQsdzupJCCFjgEIEZpb7gz/4g9xMcF64oaDxzne+07oPYfyJP/bxj39cnnzySZvJDrN1XnfddVYQAWgJ/MUvfiFf+tKXTDyisISaaEyDjjEvGIcC/uEf/sEKKfAXY07I+ED8owUgXLCcS3BWTzJXwXfX0tJiPRb82DwPxBzGRKMXw6WXXmpd5dEbwoNu7ujtgLHOHqSx6FoPPzE28Otf/7oJQXSXx8y76MaJ2ZExbhqteL5VEd1H0bMCFXZnn322dbX3YBZmdAHdu3dvYEPI9DGbZvWk8COEkDF42cteZiJt+/btB3Q1xXThW7ZssVplFEIAhAcKKhB3Ywk/jOn75je/aYURTC2OcYJf+cpXKPwmCczch8JjuFA5l6DwI4SQ+QmF3wxC4UcIGQ9tbW22htRYSSS6GT399NNy8sknj6qpBlhnaseOHdZdCeNKUAsNMIkLuoIef/zxNhYFrYa///3v5cQTT7Taa9SMAxyHnxhDiG5OZHxAeCNe56pwovAjhJD5CYXfDELhRwgZDxBq6F40Fr7LJwy2Pd4+bDeWH+EJD7x77y587GDXJ/MPCj9CCJmfcAF3QgiZ5fiJVsYyEGT4BWPZ49ebsQgf9+494WOEEEKmlvr6+lEVboTMZ/imEzKJoOUGBplIuNUH+GOF9oQQQgjJg5k5/ULsUw0q2Zgvk4UChR8hk0gkErFJQa644ooD1mHDuC3MFHnssceydpEQQggZA4iwU045RSorKwObqQVLPszV2YAJmSgsfRIyiUD4YZzOv/7rv5rIw2QTEHn4xQyQsL/yyitNFPpj3mBMGQwyPb8dPgb7sPtCAzcA7rxb74+3Cx/zxjOW3XwG8YAa5YVyv2Tug3eWkIUA02VCpgZ+WYRMIiiYYR2jqqoq+X//7//JC17wAhNe73//++VFL3qRJJNJE32oyfz2t79ts0N68+CDD9o6RxUVFfLBD35Qnnjiidzskf/yL/9ighGzP2Lfn/PUU0+Zv1jz6MMf/rCFAWPGsD4clgdAy+Pq1avl5z//ee6cRx99VG6++WZb+BatjwAiFOvVYb0kjHdYKGCJBdw7IbMdVFIkEolgjxBCyNGwUCvSKPwImQK+8IUvSFdXl3zoQx+Sd73rXfKOd7xDvva1r8nDDz9sxy+++GK57LLL5N577zVRBgNRCMGHBW1vvPFGE3iwx7pwWDMOYg0L2ELk+XNwDAvSLl68eNSyAhAzzc3Ntvgt1pNbtmyZ3HPPPeb+zjvvlIGBAWlqarIWSoAEEIIT1/Yth/MdCOSNGzfK4OBgYDN5IP593BJytLClj5Dxg++F38zsAWUKVHijjHG4fBHPDW7hbipbfREmLK+0ECt+KfzInAIf61zoAoK13N7+9rdb6x9a/r7zne/I3/zN3+Smaocgw72gBQ8tbzA7d+40YYeEDwuGQzTedNNNZv75n//ZFqj+4Q9/KG9605ty9m94wxtyC3+PBfxCS8Ejjzwi73znO+2cN7/5zdaaSKYOPKt169YFe4QcHaikwJqOSBcIIYcGPWqQBpPpAeUMVC6jQrvQXHDBBdaLCJP1/OM//qP9HgqUgV7/+tdbxfhUijKkqShzLcTZsyn8yJwCrWKFC2bPRpCYQJC9973vlf/5n/+xVj8s5F1YC/nyl788J+JwDAt6I0HCNn7DBoxl748diiM5hxw5qLFcvnz5Ac+bkKOB3y0hh6e/v5+TtUwz11xzjXz5y1+WW2+9NWf8/uc//3mpq6uTq6666rBDSSD80OPpwgsvnNLeRyij4T2h8CNkloNab3RtnAugC+H//u//mqhDzVIYFOCQMX384x+X973vfWb+8i//0lr5POFCnhd8jY2NcsIJJ8iJJ56YM9XV1XYMgtjbHXPMMVZbdijhga4Ua9asMffHH3+8df0khBBC5jJoGfe9a8j0gJ5FKPNcd911cskll5hBq92//du/yXnnnXdACyzKRn//939v2yinoNvl3XffbXMWYP8Vr3iFDU+5//77rYvo3/3d39k25kL43e9+Z0NW4HYqxeF8hcKPzClQOzOba2ggwDB+ztc2IvOBWPUiDgnj8PCwje2D/Wc/+1n57ne/a62C6A6KSVy8H+H77O3ttUTvhS98ofz0pz+1cX4wSPxOO+00szvnnHNsH+ZLX/qSnffb3/7Wrodw+DAAtD7i+rge/Ln99tttLGDYDSGEEELI4UDZAeUbTDj3+OOPm3nsscdkx44dJuQKK6Ex6VxbW1uw51r6MNkcKrIByigYg//cc8+ZO8yTgHIR7GBQCX7LLbdYSyKZGEX6sBZUSW/Tlk3S1pJ/2QiZTNCKhpk8t27daglWWLxhRj4kdp2dnbJ582brCojJVDxIGJFwYtbNtWvX2gycu3fvDo6KlJeX2/no7uo/W5zz5JNPmp9ouQuPf0QYNm3S910TTVwbCTK6NgC0BqJVcMOGDbaN89ANA7ORvvKVr5Rt27aZO3JkIB4xtgEzt1JMk/Hw7ne/25aCYUsFWeggX8MwCFRiIh8jsxs8rz/7sz+zNOxnP/uZCTQPyiwY/4f1jVEhff3111tlM8o3aNFDyx7OX7lypbXkYU6Ea6+91irH4Sdab9HLCZXjcItzkadizoSLLrrI/MXkd7OdjZs3Smtza7A3s7DFj5BJBK1ryKyeffbZAwr8SAwfeughef75561FEILNT+ziDbo6YDZQJIhYVDYMasAwbhCtc949tlGjBkF31113jfILYUB4kMBicpdwYozrL1q0yCZ6Qa0ZJn45+eSTZfv27TlxSAghJA8KqDCEkANBt0t0y0TFJwwm2YFwx1AW9DDyFeGoaEb5qLCMFN7HdwZ3Y31v/AaPDgo/QiYRn5iNlaj5bqoHOx62H+s4OJid9zeM9yNsPNiGIMSC8p/61Kfkk5/8pE1Eg9o2CExCCCGjwSzN4V4ahJA8qKx+y1veYsNGYF73utfZHAef+cxnrMyBSc+WLFlighD7EIno3gmDFj8IPT9MBmvsoufTcccdZ0IPvalwrnfP7/Ao0MhfUGzcvBGlXxqaBW80Mc2WlJTkjCa6Y7qjmbipqqrKXnfddRbHYx2noSk07373u7NauBnzGM3sMD7NHOsYzeQZxPP111+fXbx48ZjHaWaXQdnhz/7sz7JPPPFEVkXdAcfxPFtaWrLbt2/P7tu3L/uyl70s+41vfCPb09OTbW9vN9PZ2ZkdGBjInnPOOdlPf/rTdqyjoyO7a9eurAq+7JYtW+xc7767uzv7X//1X9mysrIDrjcbDbTHbIFj/AghZJLhGD8yUTjGjxCHCgWO8ZtGEN9Hm09hhnDMzPmLX/zC5iooBN1AV6xYYevbYqI6rHWMJRvQCujB8BdMCoOWdQw9wbwG6M2EGUCx/h9aANEqCDB0BUNjVATOiTx2No3xo/AjhJBJhsKPTBQKP0IcFH7TB4QXlmLo6OgIbMhUwMldCCGEEEIIITOKn3SFLAwo/AiZQ6AmlBBCCCHkaEG3TCwHRRYOFH5kWoBeKTRk4lx66aXWjZAQQgghZC6DsX9+3B6ZHhjbZFJAS5Qz+JCLA1NkprS0WE2JGdj7bWefdwfjRaE3ZDTxeJyJJCGEEELmPKjIrq6uDvbIdMAS5AyBwjvWMplLhfi8uHMLa6KmprS0NGciEWfywg77EfuFW+8+vF1own6E3eN64esvVBbyvRMyW0EalUwmLb0ihBAyPhYvXizLly8P9sh0QOE3Q2Cmv7KysmBvdgOtUVzsW+XCLXajzVhi7mACb/wm7L9vSXSthAgTIYTMNBB9V1xxhRViWDlDCCFktkLhN0NA+G3ZsmVWzqbkWtUg9ly3zdHCrmRUq15YjHk3YQPxVmg3XuP999fMtwTieq4VEF1F8TuXWk4JIfMLTJDw8MMPS39/f2BDCCGEzD5YWp5BZsv6Xr6GGr/5LpxOtDmxle+y6YWc3w6bsewP5nY8xp+LX2/Cx33YvBv/SxFICJkqxmrRw2LCWHwYixIv1HUbp6qls66uThoaGoI9QshU4Cr8F/ZQmoUCS8hEyapo8qJqtMgK//rWt0I3OQHmW+QCN9g3wRjY503gNnye3z7AuHPctfLbYTPaLi9cmYARQiYTpEmxWCzYGw0E30IWfbFYRKor01JXUy6VFSlJJeOa/iMdDhzJkaXHe/fuNUMImTqQti1ZssQmkCPzGwq/BYwftweRNHoMH0y+pa0Y9qXqTjPxEszCacbZOeP2bYZOO1eNunW/of2cCezCx9WM9jPvd+4c/XX7cJ8Xh/kww7jrejs3FhAFk+CmCSHkCEF6k06ngz3iqa5MyStffI782dsuk7/+w8vlvW+/Ut5582Vy7WUny/o1rVJTVabpcIm6RJEDCbKdNi4wHGJ4eDjYI4RMBfjGNm/ebL0XyPyGwm8BgtrZfAuZM2GhF7bLi6sD7bw9fsNdQf122G48Bu7HOudQ1w7b+/2x7CFsYdgKSAg5UlAomuzWJ6RJ5eXl1qWxsbFR06m5lS0jXV23fLGsbauQksE+GdjXKcV9XVITH5Szj2+U177kVHn9DRfKpedvkPq6cilFWsyix7Ti81ZCDgZ6K4yMjMzKeSfI5MLUdwGRH7+XF0Thbb9f+Fta4M5vw3ihFrYvdOPtCo0/VuiHz6S8Cbv17g5mFz4W3vb7iAMUtCgACSETZSq6c2INqw996EPy+te/Xn7yk5/I+vXr55T4Q1gbG2qkaKhf+nv7pLunX/Z3dknXXjW7O2Soc580lWfk8jOXyh++4VK5/IITpCI9dndZMjWg+95cmUWczBwLtav6QoPCb4GAcgSM7/7ou3V6cWQCKaL7pejSWZwzrrslxFPeuG6U+dk9/T7claA7pppivU7YlEbVbYEpdGPnWpic8X7jOoXXKgxjeBtdU9GryMLu782EH/x1907dNz9AxcCqVaskGo0GNoTMLVasWGFLQaDFb82aNfLa1752bhXANKgD/f0yPDwkQwODMrh/QPo7B6Sno1c69nbL3j0dsnf7buna1S6JkW654rxV8v/ec62cfuJqiRZpXlGkeYEmyLoVeEgmm66uLmlvbw/2CCELGaa08xwIHCd2nADyIijcCubswgKp0N3Bzw3vmyAbte+Mb7kb69h4Tfj6fvtgdj4cYbuxDNyw5W9ug3EJzz77rAwNDQU2hMwt9u3bZ7OBopsVupI+8cQTwZG5AbqGbdvZrr8ldg/4Fvv6+mxpi8E+Nd29KgI7pWPnHmnf0i7tm7ZLcXeXvPHlp8ufvONaWdpaJZFYiWSsNMIiCSGETCVMZecpvjtjScmBogldcw7s9pkXWHk7f16+26U/Fnabsw8d9+79Mbg92H7YPvybv37+mmOZQjf+PG98986x7OEev2RugpYRiD92USFzleeee07+9E//VG699VZ5//vfL1/5yleCI3ODjH57u9q7padvGDu57xGzn6bSKUmVlUlSf9GjY6C/T/bt6ZDdW3bJro3PSH3ZsLz99ZfLtZeeKk21FVogQUUcK+MImUugPIVJrw424zGZXbDEOw9BIxYG3PtZLsNCx7o7olulN8G+zZxZ0FKW29fjxeoOxp2nx+E+qsfQPRN22Nfj7hycH/jt7SIqvErR/RLdTdXovv1ad8y8O+vyGRi3zEPgf3CN3Dbc4jy7HgSfu64zXgzCBPeGc8193uCYm81U99Ww8Y8QMt1g8ffbbrtNbr75Zvm7v/s76e7unnMVGfu6emV3R7+lp9nssKatRRKNRySWikuiXMVfVVrK6yqkXMVdPJ2QwaEhad/ZJzs2bpX+9m1y1gnN8ubXXShnnLZSYpGYpsWuN4YTgoSQqQLfGcZ/osx0pGCoxSWXXCKrV682/8jshsJvnpFv2YKYGS2EYCCWYOfFjhNATiDl3efPc27VwJ0Jr2A75M6Jr/xv2PixeSgI5EwE4/bgH64Pu4Lz9BzzK3c9Z4djfjv8aya4v/A9uHDjN7jnINxu392vjwdvzzSLEDLdhFuu52LrdW/fgDy1aY9kiqNWeSdFWSnR9D0ai0oiEZdkeVLKKtNSVlMpVfXVUt1QLeWppGT6h2Xv1p2yZ/NWKSvulxteeIq85XUXS319SiVfqWSYIBMypaDMWFNTY79HKtrQvfu+++6T3bt3BzZkNkPhN4/wog/rJTkBFNSajurW6Vr+3LYz4XO8O2fn3LnJVfLdOA9mxnLj/TyY8W4Kz/P2B3MTvlbY3cFM2B8zofuFyccR9vlZEELIeBkazshjz+6QrgHNM0pUsKl41WKkFKOCL14qyVRcUir+0jVJqWgok6qmCqltrZW6xfWSLiuTno4u2f7MJunevlGOaY7In99ynZy4voVpMSFTDMboPv/880c1ZALnbtq0SbZv3z4nK64WGkxV5wlhEePEixduo+3cdkgA5ewK9gOxZ/s5984/LO+AbXMHA7vQdcJ2OROMITzAHOAW9vl9P6MnjL9+7jrqFtu54zimpljtXHgPNP66o+19658ziDcYQgiZHaAmvrA2fja1hpXYOL8tOzokEotKkRb+MpkRtc9aT4tIzHX7TJYnJF2VloraSkkvqpSq5noVgE3S0LJIorGk7NreJdue2y2yb5fcfOO5cv2Lz5eK8pS4hoix4oAQQshEYOl2HuCESmiphlJnsKQBljbwSxz4bpU5ARcyJnrQ9dIb9asY/qDGFudF3Lg8P0YvonaqtfS8rIo3tVODfdjDTi+Rsy/Va9v4Pw1kRK/jDfbNPnBXUozzMsFv3t+c8dfXsLh7cMaF1f3mun5CCKopvEcnhr1IxH0F51sc6jbiQf1GPOpuUOAgC50j7QJDiIkVfX+sK5X9g02wVVSifzXtydnk/9l53hShG7ra6q+3y7ubBRSpyMtk5NcPPC/D0bjmAzEZHhiSESwGjeCjwg3dPq3lLyVl1eVSpeKvsqFCqlsqpWZJnTQuWyS1jVUy2N8rOzfulI5Nm+X8E+rknW++Wo5b02rjiIo0UXZxQAgh5EhgCjrHyYuVvCnWjNELnLCxY4F94TmF7sJ2EEnePuwmvB02zl63VVB5cXYwt969/x3LFLoN24d/D2by5+bdFxpv7+Mz/4vC1iwpXJEZAe/CkiVL7B0hZKKYTLPeTxAtKvSQPktWoiUi1fFiaSiPyeKqpCytTcuK+jJZ0VAuy9UsrauQtpoyWVyRlIZUVCr0hDgmowpEoDFbkia9v4z+2bm3Ux5+Zq9EkpUyNDQsw4Mq/kYyFl70HInGYhKLxwUzQJfE9X7KYlJZUyH1TbXS0NIgjUsXqQBskkQ6Ifv2tMvWpzZKbaxHbn7lhXLlJSdLuQpHtC6KYBiDXZkQQsgEKMousA65m7ZskraWtmBvbuNFixMpaM1zY/pQIeq7L3o7uHHGucO2ZcbB+bBHNUDenTN2ruazRVpysW0UOvTa/hgMCP+6bXVf7F4tvGJ6pdw52IdB33KAgpB/DcO/hQYFC4DzspmSvL3u5w3snBtzp4UOrC3lj3n7vJ3bHhl2x7ANP80ucDMy4vZnA9dee63ccccdsnfv3sCGTDV4b9HagNkX8T6Mh6qqKrngggvk29/+tr1PZOGCtC9WlJHqdFxqy+NSVxmXmrKEpOMRiah9SdGIGhVHmma7VBRoWpstsfcNb4+lQcURGcgUyb7eIdm9r1t27x+Q3V190tkPcTXT6ZMPeYlUJEvkLS89X0a6d0g0HZXqxiqprKuWchV4mN0T3xPW+RvuHZaMps/o7o91/DAL6MgwFhvvkf27u6RzZ4eadr3nIaltqpaKugZ5akevfPk/fia7d/fqJYdMcJL5B8oJL3/5y+XOO++UrVu3BrZkPrJhwwaJx+Nyzz33BDbzk42bN0prc2uwN7NQ+M1RnGALiT8VZ17EhX/ddl7gWeFCE1V3zAk+szc3Wds2oxk53Ll91FIjMQ4MxKP+Q8Fk2ETksJQWj0hExefiRbWydFmbtLYuk6ZF1dJQXy/lFWUSS6QlnkpLFqo0Wyz9ff2W+Xd2dsqu3btl27adsmXzVnnyyadkx45dJsRGINSyKGhDzOkv/utvFoWh7GgBaQUk28Z5RTk7b29Cbhjnum1/zOzV4Cvw9lbIGvbbowXgTEPhNzeg8FsIIF1UwabPF1VbWU0cLX3UPbTKJTSdbKmvkiWNSWmqSUm6dFAiMoyUNTjfVXC5irI8SHNB+L3x286tOw5UNkpHvxYqdvfLs9vaZWtHjwxp2jiCayDNtNNwDsI4vkqLowXd7k9dvVQuPLFFhvr32Syedc01UolxfdWVMlI0LF1Y929/lwwPqNJTzVpUquIvGbWZP1NlKRlRMdvZvl/ad+6V9i1d0tPZLum6cqlvWySZaKN86BP/Kdu27pYBFY64R+RYmqIHISBzHQq/hQOF3/RD4TcHyQu6gwu/8Hah8HNiDt0vnaDz+8Ulmfy2FlyK9SC2kQijVU590X09RwVeKlUsZelSqWtIyyknHyvr1i2VlqZqSWnmLVq8KZIk3i4tsKDQARPTnxLVfGipQ9HH+QlBlS0qDdzhWsXS1zsgW7Zslccff0buvvte2bVrj/T09EpvT7+JN8wYh7Wi8OrCmB/Bb1j4wc6JukDsqXBDDXPYzos6Oy/YHtZrQPgVunHbM/u5UPjNDSj8Fgi5tLFYopoel0eKpLE6JasXlUttZUISpZqmQuypO7wHlhbndZvZj4W39784t/A9QtqslrmKMFSotauO2qIi8OnN7bKje1B6Bof06uYs+DP1FBdHJBkpluuvPEkqSvskmYhJfXOt1C6qkwoVwhnNZzp27ZNuFXbdKv6GBlyFHMaURxNRKa8qk4qacs1L0lZBuH9Xu7RvUwG4s9Mm8aptrZPypiXytW/dLnfc87TmC5oXoC9tdigIAZnr4L2n8FsYUPhNPxR+cwxk9l7Y2UQugaDzws8bs8u5zW8Xm9hz58Ee5QrnXosuJUF3TrhFYUa33T6Oq7uIyOKmBjlm1SI5/vjlsmJFgzQsqlGBqIUbFWJBEUWNbmXi+hPVLT1JVNgVqZDSIhAMBKC5Uaw8YgNgUBpy4tIdQw1usQotkb17OuWpp56T3/7uYXnqiedk29adMjDYZwUhGCfcnNDD2xxu8csLOz0O4RcIvLC92w7Zo8UvEIjeXX7btQzOFBR+cwMKv/kPKq+QYqWipSb22mqT0lyTkMp4VlMxdOFUN/rssXYqWgQhzKDPfDp7KHzaOxZ4n3AIxzPqL9q5iiCc1H5EMKFKRIZHSmVP94g8v2OfPLenR3Z19Uv/MCTg1INY0UxBVrRUy1Wnr5JotleqGqpV/NVJVVOtRFMR2be7UzpUzO3r6JSezl4Z7nfdqLH8g00AU1kmNXU1Ul1XJdFYsezf3yftW/bKnm17VCj2S6X6V9HUKA883i7f+/49sn13h97z7OiOT44evNsUfgsDCr/pp+SvlWB7QdC5v1M+9tGPBXtzC99y50Wbm40Sgi0vBvNiz01mYqJP3Tn37ri3d8IRM24Gfnj/1U1RRAWiCr6S4lJJJ5Oy9pilcsMNF8uLXniunH/2Glm+tEbKy9R90bAWONDdCSFEEQS1rui7o7+wRFcoFI+sS5QrFKArFIo0MJB7cF+kwrFY/ULRRayO2pni4hFJpxLS0rpITjjhODnhxPWyatVy6e/vl859+02wuUKS+hcYeGzX0AtiX2/LXc8O5t3Yn7BdAfDDfg846ATmTHDMMcfIxo0brZssmb0kEglZunSpPPbYY4ENmbvg+3cVU5Bw6K6OHhFo1TpmcbWceUyjrF9SJq2VEUmWjkhpkaZnmp7aDJSoMUOtnKYhmFkZuy69wjbSxdCvmpLgF2bUPw2Ct9fd0DmaiQfpHPaxgf2IpqXpeEYW1cRlSV1S6spjMjCYld6BEVsU3aXF6t7ua3ITM6Sb+NfbNyTV5SmpVSGXVdFZmohLPFmqwi4pw0ND0t3dI92d3dKzr9d+e3v6pK97QHr2d0u3ml4VqwPdfXavyepKSVUnJRaLyfCgSMfudhns7ZGlbbWy/rjV8vzmHdK+r9/F0yTfD5l+8C4fe+yxtjZcV1dXYEvmI42NjTbvxHwX+Le86xapKK8I9mYWCr85AhLCnJDTjNCJPNdah4/Giz2379zl7CD8YJcTfm5yF7iB6HNunYiE6MM5RSURiWnB5vgNa+QP3vYqufrKF8jqVY1SqQUILNmAMoMVHDCOxEoRKuy0sCFZCDfYjWgBCSJw0MIuWczG5ooaOJ5V4wQZ/qEVEucNSra4X391G/6auxF1B/Gov3rd8rKUtLY0ycmnniynn36KdOxrlz179gYCEBPZoECEa+i+/rUCFK6DHT2GDVdAwn5+G6HI47btmBIWeYHVjLXiUPjNDSj85hMQRy5VyOpmVIUcZt+85KRmWd+alsayYUlFMxIpQQ+HrKY5SGewJI0Xds5YUqN/vEEaDHx6jl4WOAf7hQbnwo3bRprtem7AuJA5v/2MzjgBPTU0eZdEpEiqy0plaWOV1JaXmajqGkJ6i+vj3KlJyzBGe19nr6xa3izZwX0SLUlKNFFiwq80UiI9EH4alp59PdLfM6T5U6lE45o3aV40MpRRAdgr+zs6pK+rW4YGB/WbSkqV3kO8DMMJRPbv7dJz90tNZVzOOfdU2a3utmxuxxPQo8g/yFwF7zKF38KAwm/6ofCbI/jF1JGpWyHBTH57tH2BnbX4jeEmKJDkj7njuNaSlkXynne9TV5xw1XSUB+TuBZsMFalWAasvJAvcGgBQoVZ1sZXDOo2WvpQqIAZ0kxYhZ+13sX0F4JQzzGRiIw5KHCYX7DTYlNG/TfRN6L7GBsDEYjzse8MhGA0poWZ6nI5+6zTZe2x62Tj8xs1g+iGb+aPN+F9CD/oNW+vW8Fvfssf87rO3ONf7pw8MyH+KPzmBhR+8wV895ouavqkSY5UxiNywfEtcsaqaqmPaKqG9LOoVE3Exj4jrbVTgjQH6SoMtsP73g7k0t/AzdjGpU3egLA/MGE/3W9+u1TT1GTxgNSkS2RNqxa0InHZ39klQxnXPjdV9PZnZGgkI0tb6iXT2yuReMwmcUmXJ2Wwd0h6u3qkV8Xh0MCIxJMRSVSoOExVyfb2jGze0S19I6XS25eRrr09MtCjaV5pRmoaaqWiskpKIB5VNO7bvVMimi9ccPFJkkqUydPPbJZhFZ25RJzMOfDOUvgtDCj8ph8KvzmALxhY4cBa5pxA84LOG9fSB6P2uW01WPg8sIcbTJ9ta/Nh7J75h/1iiUai0rSoUV71qlfKW954ozQvrtXCiBvjhsIPEuOs9GuqrALPhB0yVog5GCfK3LZaq9HiiNq5/HekqEcFG+xK7bB3h5Y/JwJLdCeibqJBho1rBN1GrRURYwTRiqdubV9FIbqYFmelrr5WLrjoPKmvq5UtW7ZIf/+gE2V6cVwL4baCUPCLTbu4C4ntO5fYwf9QAcr+evIFCXdc42OaCxcUfnMDCr/5gqYG+q2Xx0plRUudXHlSk7SWFUm0WNMj1XiqSzTpwiyeGMunAlALMEhjrXcB0qugBQ7phUu7kf7k7fDr3AWiUH+xXWgsXdJfc+/tArxfueOK33fO8Fus4cV1sxLVtLO5vEQaG6qlq3dAegaGBTppKkB3+/aOblncsFhFmabnI1kpVYGXKotLLJqQ3u5e6d3fK4N9AxJLlki8olye3dIr37n9Edm4u0ee3toum7Z3IgOR4f4+6evsluG+YUlXpKSyoUq/s7iem5U9O/fLUHeHrFvbIsuWL1Pxt1X6LB8IAjKpuLR/YkzU/cIG7y6F38KAwm/6ofCb5bgWOd/Ns7DVbuxtE3NBF87SCOz1QZtIxHg+94vWPhOAJv6KrPvNOeecI296w2vlpA1rNFNGVgXxhJwTXS7R+obumVrSyaJVzokx17oHtyXqBoUOtKrpmZrP2fk4BmGHLpzWcucKORB6aEOEK8ud1VhBRe2KiyJqjWt6gQlhiF+4gWBUkWnlH3QBhXBU3/S+li9bKieeeIIMDA3Lzl27ZWhI3QVhANiGWxRG4BdsLCjADgTbcBds2YYZdW+WuSOK82c6tR+F39yAwm9ug5QIaRkqxxZXJeTctU1ywtKUJEs0HdT0sgjpLNJQiDi4VndIv2wcnqbRES3ImIiDX/gN7PPb7jdv7KJ6Sd1Wg19vLC2Fg8CEzwNuspf8PnD7+V/zG+HEzMq6DX1YFs9Ia32lxCMx6eoZkIFhny5OHnpF5ByybccuOWbZEika7neVjLGYlFVVyGBmUHr295n4KymJqvBLyIOP75FNO9BlE3lAVvpHMrK9vUt2d6qQyxTLiKZ9vZ2dGsdRmzSmXEVgkQxJx+4O6e3qldbFtbL22BWybfte2duOisojvC8XgfofTxj34u7H/YPiB/A3yMe8sR/nCuSfzeTG7XwFcdXU1CQvfOELbSK1Z555xt5xMj+h8Jt+KPxmMU7k5QVdTtjB3oSgG693sGNmp9vI5P0xmFLUTGMfbvR4XV2NvPlNb5Srr7xMGhpq1A2yLCfSnOBBoQYTr3Srlet26UQfWuRc5gZcVucyvmBLgVCDQEOhB9sQjegOCjGHVj7Yq59B5uwySL0ejHmAZRUGNaxO+OWvj/PVXz/GUO2K9besLKmZ/jHS1toiTz/1pPT2YsygOrHMFxl0gHme3w8fM+8s9LYxGpSaCqDwI4VQ+M1dLCXQ9ADLMxyzuELOW1cvLRUZ3df0CRVlmoYiPTGRp8anrWYXpLGw82mzTx788fDvWKbwmPez0ITdwPhrFP6GTd5O/dA0M6npcGNFVBqq0tLRNSDdWFcvcDcpBH4NDmalvbNHVrXVSWawT0oiUUmkE5JMx6Wvp88md0F3z0Q6Jh37h+SZLeFZi4slo+lutx7f2d4jezsHJFYSkcHOfSoMhqWyrkrKF1VIRKLSua9D9rfvlbqahJx22nq9px7Zuq1d/TiCRNryBI1/23T5EeReMlYqlYmIVKbiUluZsoX5K1MqZOOlEou4dwEzQ7vzNY9TP/APQpYcnrKyMvnYxz4mN9xwg1xyySUm/B5//PHgKJlvUPhNP1zOYZaCzBmFBjfzpstMwiIP25oX5bdVrPlj1rpngg/naIZVnDF77GPyAAg/bIv6vW7dWnn7294iLYsa1Q0urNmTFgZKhtFCB3Hnal0zRe2a+e4KsrHglcGPU0khvBBzosy12qnQy6AAgIwQ6HYxlniIqx9oWkzqr8tk7X82oT+omYY/gzKS3a+/A2oHAelCkLEsGLXqEdvOqsHSEfjNFEdlZCgqHXt75CMf+YwVvlFziDc9tyyDbYf2Ndh+G2v4jQwPWxdXZ4e1/YZte3gov0SEd2/r/unvdMDlHOYGXM5h7oJCOtLJs9Y1ywmLYxKPYHkGTWNKB/U3YmkzDBrk8hO45IUYtvHMLb3VRBULuw8OajqmaYR3cyj8ce/Hodz7dwu/MK5bft4ewM4fB/ardqhCK1KBgnUAoVPaB6Lyyyd2yePbOiYtPYNssvxCbwGzS599wmo5aVmZVFUmpHFVkzS01MneHR3yzINPy46Ne6S6IS1dI+Xy2W/cGQoDlgQatpQf2QhEazpaKieuapbVLUlpbK2WFetapaKmQvaoYNz6zHbp7RmQhtZaqW5uke/+4LfyvR//VoaGhkbFy+EoLSqRdKxEFtdVSmtdmTTpb31VmQm/ElQCaFhc/qx5l+7Y88aj0vy1ezAju9u7Zcv2Tnl+e7uaXbJHwwQmEoaFyKJFi+Tee++1Vj+8+7feequ85jWvYbzNU7icw/TDFr9ZihNyhS16EHS+2ycKFaEaYLV3XTyxredj3InmQujGie5KTvBhXF9C3WvxJRqR884+Q971jrdJY12D1Vzb8gd67SLrytmjGxBtgXAr6tYsvFePIZMLEmBzDHGIjN0bdwgb2MVC6/pX/Q7c2SHdxvg83cVqfWity0JgqkVJFq19OK4mg4ISOpD6SVkQLudHVu9THaiAUzdqh/DjOjDq2kRxMhWTc84+R/Z37ZfnN23Vsg6OBwUvXB9CUv3Hr7tzd74LZu5GCtCD5kBN0Ppnl9b96ciX2OI3N2CL39xCUwX9W2qNNMlIqVy6oVk2NGk6iUozTYuLS5HG4FsP0lukz/qLtMSnwUGdlBlblgHnmbsiiaqfEVTCBU5yrYU4N9hGQgL/zE81NtmL9zJ0LRSAYbxbkDsP4Qj2QdgdjC88Z2Cvv+hWCmEK54nSEWmujcnIYJHs3a+pss3SjAo2c6nmSBI4Dav9hdbMSsf+HlncVC3RwWGJaH4UTaRUBJbL4FC/dLbvk2FN4itUFD63rUv292BiMKB5geKvjnsYGB6RTbv2SUf3kD6jYhncu0eKY1FZ1LZIUsmkDPQNyO5tOzXr6peTTl4hVTV18vizO0RPk2IVuv5R4cbxixlVsfB8XJ9RQ1lcTlmzTC47ZalcdMpyOXG5CstFKWmsiko6rvEUzUgsApNVIxLVvDYRLZZ4pEh/1ehveaxIFlcnZe3SOjnjuGa58sxj5KRjV0htRZmm3QMyOIweNPosM3iueEbIVy04Cx6Udc4880xpbm42sf5P//RP8sgjjwRHyXyDLX7TD4XfLASJvxN2QSud/iLT9uLP26FQkROGpXmRmBeG+FV3eq4/BmGYSEbk0svOl9e85uVSXhFVfyC+UDMb1Ayr2CvCJC4QZeiSaUIHAg5LMxRk/oX7IVw3TL0ZdaJFEtgEB9wfVwixg+7XskKr11U7VzDJwg+1t4JMFrOEohCATNO5R22yDzf2ca7VMCv4RYa+dt0xdv/PP7/J1o+CV2HMbwufwxUFfPjccb/tsf3AKn/sQHeTDYXf7AbvCgyE37Jly6yL0lS/E2QS0GeGSrKaeEzOXF0ndXFNa4ZUhagYcOmopruWlrr0N2ws/XBJhu2b++CYB+8A0qBIxPmFxMOlpXlBhzCYXwqEHtJt/z7lUphgP3fdwM7/Hsz44+HfPC7dgn1cD2ER+qyKmfZ9QzKccRV3cJNL8I6CIVVeXV1D0tpcIdn+PomqWEtWplQARqS/t1/a93RITJ9BNFkmz23cJSNBC+ZYIOXf3z0s21UADktcRjraJTMyIDWLKlXolauDEdmzdY+MdA3LqjWLpG1Jozz93Hbp6enTXELzGYsHjMeMSF1ZVNa2VMr5JyyRFxy3WJbVR6QyWSSxYn1uWY1DzWvN6DkQaTjVPwMfn9g3AR9sm5aDQUj1tzqledHSarlAhehpx66W8mhEBgaGTcSODOt9Wq8XphVoHUevFqSdn/3sZ+UHP/iB2TMdnZ9Q+E0/FH6zEN+98wBjE7QUtgL6Y67Lp3cH8YfMB/u5MX26H9cM9mUve5G85GVXSSqJXKlXskUjmv3FLKOEcML6e0XWmoW2M2RsyCN1y1rvYEKEhF9hwmwZnhVs0A1TM1och5AMjtqYP9+6B8EGv4oC4QdjGazLZJ1wxPpNuAamC8DELZgeJmi18wIV2+bG7RfrvaG2ffny5XrvKXnyyadkaChYW1BdeiA5PWPlL+F7y20f4E5DdIiCymRA4Te7wTeGjOwNb3iDnHbaafLEE09Ie3v7Ad8GmV1A0NWlY3Lesc1SlxyUEk2TsloQz4xoeogWIqtMc13qkXZY2qoGv2ZMGLptEwPwMzjm014A8YC1U6NRdNWHX1h71KVD9hv47f2wX5jgfJCzC0zYLkzumgXHwvuFx0CppqWNVWlJaD6yc1+/DI9oXFj6ePTvMFJnzCSK+15cn5aRgQGJxiNSXpvWI3psb5embb1S31gnW3d0yr5upHMHvy6O9A+NyLbd+6WzKyNDg0MyMtgvFVVlUreoQXV7RDp275FezfeXtTbJuvXLZMvmDunc12vr1LbUpOSklYvk9LWNckxbhVTEiyVaNGyDBvSpuVZdNYhKH1cw/j3wxhO2t23rEqqxh20ISNhrFleTLpXj1zXJqeuXSktdlWA4QWdXvwwi/2BaIfv375cHHnhAnnvuOUs7mX7OXyj8ph8Kv1mGKyi4woIXcShQ+LEE4W6eJSponODTLCpwj/PdbJ3oKgR36qYYwg+tEDF51ateJlddfZEkYsiQ0KrXr2JlyAo+yJQwe6doxleMTMr+qb3+y2b79S/G2aHrDwoB6HLkRRoSZYg3/MJAdMFeM0TkiZYxYkyf+mMCDWIN9uo2yDMh4iAsbQwHLOA3jsPebFw4ivReijAuUMNTbF1R3XXQTdQLPrsO/uX811BHorJ0yVKprKyUBx98REb0Qq7GHSAu3C+6gAYnBT+w0//eqTKW8IPVdGRQFH6zG3xD//iP/yi33HKLrF+/XmpqauTnP/+59Pe7SYbI7MKlZCJV8ahccfJSaa1CZZEbs2tpH9ISTRLQIoMyeTSKFkCoADxrPddEAdxpWqtprrXS4UwoBfhtx/CL9AbHzdq2XQugawU053os10U0dI6dp8dzrUmBnW3D6EE7Hfaa/uFcHEZKhOTIhcG5xy/SKB8+4MJsl9c006W4xSp8a8ojkojGZbuKpEHrJj8ZaZubq3N3R4/U1lRLOoJ4HpJ4ukwqa6tkUEXbvh3tkoqXSpXuP71pj6iWC+HuI48LE1oG93b3y47d3TLUr3mRCspYWVQaly6SWCwm3Xu7pX3vPmmoTcrpZ5wkfXv2yOqmCjl5ebUsqUloODTu1S/EJPJNzH6Ka7kWXsQ34g75hIv7sPHxawbn4HkE8eu6BqPHjv5aHoXj+pSQ92gcVyQjsnRRpWxYs1hWLl8kHbv2yd6uPn0OyOfgx2TEOSGzFwq/6Sef+pMZJ5yJ+MzDCgFm/P6BBjWSo8SiZjTIsLANEQg3qGF+6cuulUsvO1cipVqCyULEDWrmMqgZ3YAWBro0i0FXSs1lTbz4DCdXJFCD85Ah4rVBZobruGt5Nyh4WKugiris1ZrDQExivB4EX9i/MM7/bKZbMlksxA7jl3PQYzis18lmMLlCUq9Zrv6iBRBCD62QcIeWQEwkg66qELO4F/XDZh/VgkAsI5dcfLbcdNNrrLCFsPg4szjWYCEeIbRRM28ZPuLXnkewP+rZ5DN8fxwCmyxcUKg+++yzrbAZjUZl1apVkkwmg6NktoFkJa5i7oVnLJfmClRrZSQRi0p5OqnpqCYd+jnj+8b4tMGBIensRIsU0k58986BJU3qDgIKaW947J9PG8K/rheDSzN11yrusB5dOqUCJK1Gf7EfiURy6Qr8xq8txxNcwwtApDjmf4Fx13FuQD48uHZwTuCPa70MzkU4ca3irByzOCnHr1wkcUTGZKHfyMDQkPzklw9L51BM9uxUsbNlpz2M1mWtUlVfLfs79snylmpZ2VavJyBPsbvEyWrGBtlWR8+w/OrhbfKjXz8n9/zyKdn86HNS21ghbce1STRRJJsef1a6tz8hJ6yokTVNaUkhL8wMOd9R2QlPgktobFkFAFp889fFr98ejcWz/sc56PkRPJmcMV+wiV/9h3GWEKx4HJXJEjlBRehf3PxCedMLz5P6FPK2wDEhhEwik5iak6PFZ8wQIvjNZcxq8gLFbftuRX7fMh3vh2ba3j3sS0uL5eJLzpcrrrxA4jHUaPeru34TfTZuLtOnGZUTfmqpvhRkOIHfY2JCUK8Dg6rxzIBlpCa4bJIYZ7KZXjU4hhresTNOUKwiDi2LWRV/WQ2TQARiohnp0bPQRVOvYblnXO+zUjejel09B0tE4JqWiePag5Id0fsU3GefntevArdPCzMDcukl58h1L77aCubheA7H71jbhfuuC1D+PLMzv+xWyAIEz/8jH/mIde/cs2ePfPe73+UMrLMUFMzTkWK5/JRlsjg9IKVFmEE4qyKoSMVgqdRUVUgs4rpiwoBspkj6egdk//4eGR5GZVZwLOQmnw64NMGnp7AblX4E5/heAkinbfKuCNwh3S61CgTvjz/HU2iH7XBa5ERj/jowft//At9TwdmPdhsvGZaTWtKyvrnKRKc/ZzLo1ST7uz9/SHpH0rJ72141uyRdUS6tK9skEo9Kd8duedGlJ0uqzOdvh0tYM3ofI9I/nJHHNnbIj+94Su785dPy4ANPu8mW2pr1fmLSuWWPRIcHBZoPYs/Peurv2d+j5YS6aePMdQP24fv37guBPfzLWO+RPOHz/bYZvVKRhjuqeVayaK9cdHKj/NkbrpCTVzZIrDSftxNCyGTAIuosAul7OGMOb7vf8LbP2F3mgZYqZMzezh1HIaNYNmw4Vl760hdJIonOLCqIYCCMTJxhshN0D0IGhO6WaLVTaxOAMGiFU3cGlk3IF2Qcum3iD5kdWtZUhJl4Q+tesJ0zEH2jM0OHvxYyQAhI+AZ3feqnij/Zr0f2qw3EX78e1LBbEFAjXqb+RnB1NSiIofVvWEOJMLht13KI+1ZBWTQgkdIRueaay+SMM0+XCMRfsVvewptw/FtcojA1RoHKj/EJPxtvyMLlK1/5ipx++um2nAPWoxoYGAiOkJkln24htYurqDt9XYusqtb0T4XWkJXvkY5p2qXfM8RXlYq/srKUtcq5b90ZiL6uri7p6em11kDfgod0QL0YlRY4M1rsYdtEWmAQtJHguvrHZl3GJCf4xQQoEIH5cYTeD/fr/UO4wwIm3IrnWwj9tndjRq+fH0MIN8G5uCcsaVDcJ6eurJSWugrrimqBnQSQxu/p7Je7fvuMdHVnZPuWbbJ37x5pbFkki1ubpK+nR4qHO+XFV5/vBHhw3sHR/E5T+RLEowqpHT398oN7npFf3fmMPP3bp2TL0xslMzAoxVmMXccSRfjrch600o1k0Dslb5f7qz9Z6+p68BAgPgsx8WethR7vxuWx7lkgxIpaaKhlRJ9XJjsgzZUj8sYXnyqXn3OClKfiegT/DhUCQggZHyyhzhKccIDJFxpGZc6FRjPl8DlaHtBf1Far0QKLK2gUSdPiOrnp5huluiapmWK/+gmhh/WM0EIGoYYMpUL9q5fijJ6jiqoYGZaKNLfEQr8aiC/dl7huQ2ShGwrWVsLrA6PZEVri9BxTbZY9jWXwg+OW1eUxpXegcWehNhoCFesKdul2t5o+Dc2ghhGFtIS6qlDnaf2N6T7Cgwx8SO8D94nCkBN/1iUU967ir7yyVF5+/dWyZGmrFJeOrlVHoWdUzbkvcFnhzxe01Gg8o4Zeo9rte/fB+WThgYLe8PCwPPXUUzYFeW9vr75/+j6TWYEVoCGs9Btd11wpxzUnpBQzbaLngBbubQkFK4xr2qIJUFFJVpKpqFRUpCSmAgxprCu4I3Uqlv7+Qdm/v9u6f+ZB9718+u0mhUF6AHHm0w+XRhRpuuIMxFepFvrdYuVZDWMRWv2ipRJPxm2xc/xGYpFgZlCkOTAYr6fh1PTSp00mXtTorkTUb/2vZrT48+kUjJ7khF9wHHFg48P1F8n7iIY9HR2RC9fVSaOGw4ncowdCB5PnPLVptzy+pUs6dvfJ7ue3y2B/vzStapKq2hrZu323rF9aJiceu9RiHE/w4Kh4s7+af9lusVTGEtLSUC9pja+YxQ9uF35A4I048af7yEuwluGw5heaY9izd/kffvWYeYj7Pvj1zV9zH5jAPg/ORd7mlpOIaLzCxqF+47ln9NmgIlW3K2JZefFpLfLqy0+Rllrk0eoG74W6zp83n9G7tDgNDCFkUpicFJwcFfm0LV8omIhxIiV0nmYO2I/FSuUP/uCN0tZSp5k4xqWoQbdHtIChdlO3iorK1W21biMrCoOE1okut4RCiCzEnxeAyCbRNRPZOCZdKbVMC/aTC/zHBDPo9tmpv916L912H1gEPotF4CVt91OkAtUyUbT8qfjLjfvTe7HurYgHjYOW5lp5o4risjRaDkNxafEZxKVmzvntvBsX53m7/FjAYD94loSQ2QFSBGR5WK+toSwmp6+slbLIsETU2otz+4aD7xjbsMZvVAUX1pdLl6UkEkUakf++Ifb7evukc1+Xin5NVW1iEHdeWPRjPzjFwDHY+TQjbAqPI71B13R0WUym4hqOhIYJk3vlz/Fu3XXctWH88bDxbgrPgSm8tj9eGxuRs49dLJUqRr27owL5hAqv7oFB+dVDz8r+7rjs3dwh2zftsFbOtpWtVuG2a/PzcsX5x0nLospxX1dDLW11cXnji06V01ZUS1T9iWqemI7HrGLGA//yfroWOr9wfPgY4sMm/Bnl3lG47xnTPjgfM20jXv0zgvGE7UqLRuT0JWm56apTZFlTlb7Deg5EeeB2PuHjNv8+6i/u1CpzYadCGSbooUMIOTL49cwSfGKH31EGiV8uMSw4dhjzspe/RNasXaHnBWPtVPCYyaIrZEbFYFz9r9UMJiWZ4nCNNUCmpZmPiqb87JcBaNkzMYgF1IfVQEzBDVoBMesnKDhnErAQYbIY63qKlsgOtYTRfT3oZhnVe5JKvf+0WqBrKsSeG/cHAWjdP3G+hhmzgh6zZpm87KXX5OLM4toyHc1yAnGXj39n742vYXfbBx6HIYTMDpAioRUnrunW+ccvkZqEJhtakMxqQRKF+vC3nv+egyxSzysuyUgqlZDq6iqprCy39CH8jWNK/n37OqW/f2iUX86fQn/z6UN4v9B4AeD3cT7GAmI2UMzSnE6nTAyiK6h1Bw1dA7/AdzfEZDE+zGE3/te2/a/ahe1hUFpoKS+Sk1Y2at5hXh4l8AStaiWyvzcj373zAekpScue53ZKx/Z9Ur2oSlrWNEvP7m7J9u2USy86ySozx8PKxip5y0vPl2WL4iqy9F6y+vz0DcDSPhg36SdgAbjPQvyxMHgOXhQeKbiSy1dGXxN+j0VRpkhGikqluTYqr710vaxeXK33oc8nOD5fwDNAvNQ01svKY9bISaefJmddcL6cd+klctGVV8p5l1wqp515lqw/6WRZunKVzQRZVlbm3ktCyITgcg6zAJ8R+IzbdR/UhNAG+6O219X4Wu2uHrM1pXS7FFNQYx9ug5Yp565Ujlm7Um5+4yslFkWiqiIJrV0qfEqspU9FXhESzQbdRrcmtASq39ZdUzMgdBuyjAhdPHGehsf+6iEE2PJEiMJutehV/92+FKNGFAULJMbIII8ye7ILuvA4r1AY0b+6j4zcGYg+hBXjB3F93B8KLjHdL9Nt18UTTrIQgnCq8YTQi4YVXWdWr1klDzzwkOzZ3WH+22B+3KSKTCuY2Lmww4b+YCvIqH1+7dz4bWw4c7AM/Ujhcg6zBbzj7v3Gl4EvBO+SGX2/sE5ZcVFEbTELLb5N/MIxXjB7iXGiww7gC8O3M7nvC8mDaC7VP6eubJDjmuOaxiHNwLMSGcIYLjw3dL+z54ddCB6kOe4J4zmWqh3GUkNApJMpewsywxhPjG9dfVM3g4PDMjg0KPF4VNNiXBf+Bf6YcX5j21oX8eR1X0o0XUPXTU3PsWvpHC6AtAjbwT7c27lwpNfVJN9a/7Asjx3FBUI4d87Ot1rpH9v36VP4HKSNeEVxRGPD0k4zuq8SWZIqOPd2Dcm+XqS17vwjwzISBX6MSK/G2+49HbKqdZEM9HdJoiwtNSp0Bvt6Zc/m3bK4uU4GhjOyfUenjGQ0nyu4OmyKNMJXLqqV1169XhZVawapYtyJPNw7ntGIPsMSGRgYlGG1DKfP7pm4uIDR2NZngQfo3gPragk7vCP2TL0Z/TwxTtP7Yf7oNSxv13Px7vhJcrwBcAOxaYJTI99voz9NFhOiaf6TihVJa1OtPLdtt3T1uHzOxSEqXI/mOUwDPp6wjbjUOIzGkpJOV8jqtcfJaWefLaefd76sO+54aVm6TOoam6SiqkZSZZUST6QlEo1JIpWU8rJyqaqsksqGRVLftFgaF6kATGtZRr+7oaHhIBZmeVyQUXA5h+mHwm+GQcKPTMUEW2BM9PltzVD8L7q9QPTl7DTDN3vsq/HCsbq6Ut7ylptkcVO1XgEtfL61a1CzCSyzkNLMp0aTx5gaJ26Qs1uiHAChmLExgehiiSwrDBLYATM2tm8U2EdXmkkQfockn2G68KAVUAs+Ns5Qj6FQh7AXJTWIEHjIxh2a3eofl4n7zHvFyjVy96/vtTE7YeA9zswVELAfbOesdMPsQscAtjHxw2RC4TcbwBuEdwjvuooBFXglJWkVAzUSjy2SVKJFylLLpaJspRZUVujvMhUJS7Tg1iSxSJ1+p5X67cb0q0KBTf3IvTPwb3LfF5IH33lzZVIuOL5Jkppe2KQmQeF7JPhO8+mxS1f9WGlsm1t1k0uP1T4ej+kzj9oi50gnvR8otA8MDug2WudcV3J3LXcetkHeXvf1dPtRO+DtvRtv57ui+n1vrEVPwwtx494j2Dt32A6nRVhGIJ+O5e8dJgwEn/2q/bCloSpiilX8xZOyfU+PCjH4j3MK84GJ4a5aLN29Q9I/XCQNZUn1sk8L/2mpaqiXjo4O6dvXLatXL5dnn9srnd3o8YH7DFEUldbqhNx41QnSVJsw0YfQ4b5dWuzuGeMKkV8ODg4JllSwU/X+XDy7bRi49fYW58E2TsH74d3p/9D22AbvjG7pNp6vv5Y7hut4ExZ+APWNueO6jfUGlzXWyzPb90tXH+IAKVBBPMxC3FuCmy+VVKpcFrctkVPPOVdOO/dcWbPmGH3OVZp+YqI1J6rdd6fbiG89V+9e9923YXGGuLN3sVhiKgqr9PzaujpJJpL6TEcCsR+8vPMOjccgRucDFH7TD4XfDIOELCzwnDnQzratBTDvRq1yx32LH8aBnHfemXL++adrggjRhtY8CD8IGpiYir56TTJTuo1aQwgkJJDIJF1CYpmMYAkEtKa5BDufxMAtxv316gFfwHDYFlrg9Lhmbfo7lQmT89tlnrhPtP4hg0ROiUKYMyZnsRiunRHUzOvf/D3ht1iS6XIZGBiRJ554Op/pWjwAlzkb+uO37fgoY9bGaDe2OSlQ+M0C9MVBY3FJaUxFXrNUVB8nNbUnSE3NKVJVc4JUVa+TdPkqfaeWSSzdKrFUq8TTbVKmArCsYpWUmzlG0mVLJJms1+83bYWUTAaTD+EC7v0jk0s6UiIXHt8ijQlNn1CBhi9f00wYFDiBS09s09nrDgrqsPSFf2fn0l/d1EJLsQrAOM7IpR3Bg5ShoSFr/UPBBmmzK/Tn/QB+GzMp+238ho13Z8b2QvuBATgXM5Ba7xBN9xAOlxaNdqcb9oNjsPPp1Sg3ihd+5s5SQwgYkWSsVLoHMrKjs9dSVHUBZ0dBPjx7Orv1u0hLWURTb43P6kW1UpZKye5tOyVSMizLVq6Q3z36pOo6PScIN6hKR+V1LzxNVjRhjLeGSgWeyxOcv174iX5n+MWzxOys8AH37OI9HwfhuLD8dpQdhIh/Tgeeg2PeYB95tB6xCEUeBVFjdnosHDZ7fwLhh33MJurfKQgaTFqWihZLS2O1PLtlr/QMopIV79HRxv/UghiLqChbs/54a9lbf8qpUtu4SEpUtKGHEiZAKlFRqBFiv36yISyJgSVWNPLxX60sss1DPFv7gnTb4kjt0SpYWVkhqbSmqXru0MDoitz5AdIq3LneuDG7n/3hmC3CD98qwmFpxBRA4TeDzCbhh/TLumkG4s1nFKOFn7fTfXOXz1AwdgE1l2aHzL44KvV1tXLTTTfob0qTBSf6sLSBa/mLqptWvTAKKfpyB2P9kHwgU0ItmtkX9ao9JlJx9i7DdxlUUcmQ7nWqwfIMSHghsHBY3dnsmRBX7swpBSUSb1DtaQmhuypEoM1aagu3o2AzYpmG/cEp5hAbqE3U0Oovag5rauvloYd+L/v27c99/K5Qo/6hMG4Zr+smaofdH3Nr7tUgs3GL1rvMyB2DT0cPCgmrV6+WLVu2SH8/uu9OkseTgnvqVnzGu4B3Ca0NahC/1vIA+8Cl+6f2uu/+wjjyWzOLhcPuQ/9r8IuzaFHXe0xqAaO5TKqObZZUU4OUpY/VQk2zlEbrtXQTk0xJSkZKkzKiQiMTKZVMacSZSFR/Y5ItTajwSEokWi0xPS+dXiJVKgqj0UoZHOiUzAi+IVwWf/FeW0hCv7MP9zzdJ4Yomy1BdcFAWloix+gzO645JYniYclgdmJNP/GeomtexIQS3CO9cIV1b/CN+0K6dclUkP7ikEuPkS6XmvhDOjE8jHHRdpr+lgjG/g0PDasZ0WeMGYQhDPQYunXimtiGX7pj/ut5JjI1NN7g2nCLbY///u1YEC7448NdrIUYNxOxptJIi6xs7M7HXzO6P1Y6Eraz1E/3YeNNqaa5VWUReXZ7l/Si0H2gF0cM0s3d+7qktrZOIkN9EtO0urZ5kd3H9k1bpEbztrLqenn8qW16D3phzfcS+izf8KLTZe3yShvOUDTsWjhd11bnZ85A7OkxxCUKeiO6jwfiWpnyzz1scHuodNWTdF931B1iBBUGqHSFnZ/wp9Ag3PZ89D6wjwduyyUFxxF5XuDB4GL4xTPArt82N8GxtGbhNZVV8uTmPdI3jNDBzDJwq4gXNQ2tq+TKF79U1hx/glTV1Wtaqd+BlXHU6HGrrNA4wrdg56klqpVROrG8QyMe3TnRTRd+WpYPg2hE/OnL7eOpWIUjvsXy8kopL6uQnm635ubsBTeCnBO/Wp5Tg47B2JLihEQT1ZpHNEhlVatUVy+Tyrrlut0mFVUtkko16L1WalkQs5uraNH3Bd64UorHR9bsZLYIP/SYWLx4sezfny//TSYUfjPIbBN+fn0oL/7MoBAS2Pmawfyx/LYJP2ybG00s9MU9/7wz5IILz1C/IfhQ2wUBhBY61Kih62da9yF3kBCqINIjPlmwGmc9J5Pp10QWKYjHfQQQUJlsr26hC5NZBckJjsM9RCC2g4PThr8Dj2YWyJhtPCPuCWHyH7LbNtfIjDUGkNsgc0mmyqSnd0Aee+xJKzAAnO+SUP1riQG6Urlt7Pptfzx8DBTuHykoIBx33HHyF3/xF3LxxRfLL3/5S1tHbLaA+ERRKmutDPr+ag4U04JtRaxUKhMRqUpGpToVl6pUzH4r9bc8VmzTzUMso4DjfIHBcznKCJsE7B3RPwiNlTSiWYm2lUnlSYukZFlUhit7JZvqlkhqoxSneyQT1e9Cbz8b0XcHNYclWjrTX2+y+q3qh4oSpO5rXOH90+2ikpgerpBkfLHU1a7R7zgpff0Yx4RWXUTMzMdFGF+gtUQAhbJgGz/5EpkalOi8uxm6BReSYqnSd/AFaxdLTQLdw/T71+fgC+RmNIwofGAbqYO39/fqDdwhzXX7eovqBvsQDEiD0fUT24ODSENduoJ9FEqRpqDCBufZwuw5oYAo8v7b23YAdhz/4NjvB9tIX0A4vMCWhNBtC5/+Zq1grEVpu17oOoF7uPV++V+489tO/GnsmPsRjS9UKcZl856uSX68RaI6WXbv6pAVrUtkqLtdosmINDY3SF/foOzctENO2rBOtu7cIzv2dqsILZErzjlWzj/JTWRWhPvUz8aluxBPQfgDYYCWQLPT/xg+URopNWHuZ2YeywDcO56xBs/Zq3vYmUjXZ1w4ti9s3LNRT2xft+2zQRdjV0mYDysCXtji58Lv991vRio0TR0qjsnG7R2Whs42tFQiRdGonHLOOXLVi14qVSrkS7Ekir6PVm6x7wbxgm9E3UIEWvy6HNtlCaFngl391Wi24wY28E7rt4T3ExUcsNNNcxvT69fU1ur7NKzvDsouuTNnGZZ76i/yhYQkK5pl8dJTZNma06Vl+QlS13isVNSslHTlUkmmG7Ws0ihpmHSzlKeXSGXFMqmpWqbCsEVikQq9/xIZHO43f4OYnLXMFuGHbw6iz77BKYDCbwaZaeHnM2ck3q6wkC+AYBvHwsIvnEDa+D5NGJ0dWvxGu0mXJeUd77hZ0uWoPUILn2aCmjVnNPEsKa5C8UdTQ5cQZGymy0AABWSKMFYOyz3gWBh3ThZr4EmvHst/GM4dMimcM1MJjGUJbtNw24hLa/Wzrp/uHjQa7Rf7udpEFFYtJy6Vqqo6eeB3j2gCgDUDg0xWjc+IMxn37MwEdoUGhAsesPL2R0pNTY188pOflMsvv9xa/TZs2CC33nprcHTmiWhcRzXzTei7u7gyLm31ldJaVyEN5TEVeqVSFlVhXZKRpB5PqO5JR4qlPF4i1frO1laWS01ZQlIRfW9RM6uRF7Qjzyx4LfDYMIFSVUSqT1oskWMqZVDFAwp7WAYgqu/WUEmvjET3SEl6lxSXPSFFqS2SKcaal/VBC1+JM2j9U6GX1e82A6MFHYhBW7arVN+lYj1WlJBEskkziGYZGRqSoSEsX4KWa4Dv+ujeo0kBaZQGAx2oI/oVaahRHWKh0xTMtvGZYaFsxJ/qrBkLtRYTBWvSrWsqU5OQeCnSXSxHgMJ3XtyhtSGXBusvCtuwtwK9/nqD5+63kQaHj9nkK/rOYOmHRCKeWzZAj+Tc6KYMDAypAOzTwk7E1hD0YYCx6wfbYQPCaQjOAeHjSKPC55hoC9zg/iJauEIYR0bQ1dGdA8LPJpd+Wbp14HaY4kyxvqcJeX7bPunB6veTCHKm/sGM7G7vkmXNzTLUu18LvQmpWVQvnR3tsnf7Fjn1pOPk8We2SVtdmVx/8XGatoxomDScI04sOaNpiYorvQHbtnTc/6pTxIflpWiRR2VfEHeF8WviRNM3CGdU1sIuh14HfuBdwXkHnuvscYo/jvcI7wIY0fcE4w6BxbVuIny2H9wHyIU/eB4lmudWppOyu6NX9nShy+3sAfdcVlklF1/9QjnxzLNV8MU1cQjKKz4OLE40fpAm6vtoreN6rzbeFvaWJ7v4y4O7dO85QPoCwTeMh6kROgxRH3x3QK9g16moqNDyUomtq+rjdvaA8ltMovE6qW9eK6tPOF+aVpwsqaqlUhqv0XwhrU70fjXvhHHrfuo+FDDiULfdPlLktKY/FVJW1igVZfVaZkxpHqLvjMYZenjNJvAuYGbW008/3cZoPv/889Y1fiYZK52bLCj8ZpCZFH5IgMrLyy3RQqEAmYXLMJyxRNGM24adtQjCjdlrIoZCKNzDTSijQZeeiy46T84771T1H5OuwKDFDwlnuaYRKX2rMcWnZhpo7cNMlzY2Dri/WLoBC6X77p8ObOFjwLINKvqKw33m1W8kKHrMln0I7KYbV8zEdWGQmWgRFBkDMo2Q6MO9Yxuhdv9xHoqriCMkmiWSSlXIrl0d8tRTz7gMV3NhlxYg3vSvFZiCzNjsYYeMOLyNYyGBqLs+8z5SkEDecMMN0tbWZvvt7e3yuc99zranD9w7TP4v/sU0M6pW4ba0sUpWNJZLowq9VARicETzKzeNuhmLOv2DjBdRZBEzogJqWKKqDlKxUqkpT0tE33O3OD8qKHIX8z/TAK7k7q04VizRtmpJntgomRr9bouGLA9GhQIEDsa5Fmciamp0s1nDvEhvLKXfSVKFXYUKvLSaqIwg09ZvFi1NruVPPbFf7GtkFeu3iddRv+WiYkzSUS7lqRaN25T0WvdPVLggMnyETFds5K+Fv5gVM6obCX2OKS2YJfShxvUXi6jgN6HH3T7SqRKJ6i+MfY7miwd7+ALdXU0VKDymVIidvrpe6hKaFiB+1c637vj00wqgwbYvnFoIC9zAHs9AvVCjx/BM7eZgpwZu9Hyk28lkUvf1zbf0AIJT3QfXgd3AwIAMDg6oezfGCbXeiBPzDu4KTC6caszPAOz7X5usBPtwA78QXDvojBsnrtex9CkoANvpeT/8r/fKvXMOl57hftTvDETyoGQicdm0q1uPql3gz6Sgge/q6ZWevkFprErLyFCflNeUS1VDhezYulNUPcuxq1bJhjVN0lym4gFjZDVs1jKpCYcPq4knFQQItqXDajDDp11CbxD/EPd4ZhAOds9q/FJKZvTZWS8StYc/7rnre2HHEUN4vmE7mPz57lhwPTNuGzhxpwJ1GD1qXNzCP7MPwp+7l1EmYxVu6WSZPL11r814ioA7X2cO3FdVbb1c+dKXyup1x0mJvh/Wwo5yjMaDN/YNqtGDmhzinnEykkRNE10EOWP2uC8XL5Ax9mzg2OJBxTNEMTxA9AVjOIMzc6TSKesC2tXdY/E9syB0qEDQtDJZJ00t62Xp8RdJXet6KU3U6qGERkupe88s3rR8oump/tG4gT0mjEIPBbVDzZraw1gaZGUaPZZNSzJRLWXpWtWLmgeN9Gs8Qfz5mCmMoekF78CHP/xh+du//Vu57LLLZOfOnfLAAw/Ys5uPUPjNIDPd4ucTbdS6etHnRZ4VOCyBdIUH29aMOn8MBQ3ULiIjcQUrfywRj8ott7xVBYImJtbFE7Nu4tOuVHdlemHN7FE9hmQTNT8QfbnE0dkXo4un/qJL5yggfor69Rx0HSjA1gcMd/GcrsREr4cWBYlo2GCQKB5oim1tP8gOFMqQ2COcQM9FIgo/kGCqO5t2X01dXaP87Gd3ytAQ4sF1xbHTcMmgwGQG+iV4njjot51RK9gWbB8p6Ca2Z88eaW5uls2bN8v73vc+eeaZZ4Kj0wXiEiAu9f1TU1+RkGNbamRFQ5lUJUskhiU9UEjS10B/4NR+kRnpm6peuFp12OtbrA4Qn95oXGnGFFNnaP1LaIEd8TxoBR9k8/76U4cVJgKKE1p4X1svJWsqZCStX4hVmqDQATGLNygjpbi/TEoiI5dKduQMva96FUbtUhJ9RjKobS1ulpGc8FO/9ZvP6i+6eWZQkESrHyLIogIFaf1OtTCNd7EIrX+JOklrQWCov1OGh/erI/cO4Z3121OKPisEDwXMMk1n0houTU0kpvsQvkhSivXZIDQIjw8RYrFEn6c+QRN+EIQxDXNEPYOBO1dMndq7QDy2Vcfl+CWVEinRtM0KT3g/nUH6aQVwv60GXegjKgLQo8J963qPgTsU6nVTDSyDsON0vSdLR3BQf/EP6TKWdLDun+qnFbrsUrhrdyIK9ZhJGGkN3EeiKNDBL7hz1yw0dmbwW4i9S/rfnoQ+nAzGu5kV/iAdxC+WFUDeoWFC6x/sQoT9zqdZ/teB543uhcNaCE3Fi1X49VsLXXDlSUIL8+pbe5eKSk2n0SugaHhIahvrpLyqQnZt2iFLFlfIqmWL9PvQQi1ae/TiuH44bYbYg7HjSEs0CYKgMlFl965GT4Koj2n8u+eEI/n4t49Aj/v4wznIfzHmTF9/swvOUGc4z+Xb7lk6E97W//YLXPgQXqTzCKPbdveBY4hX7y5/T0VqhjVe0ppO9g+XyuZd7RpfCMHMoHdl91TT0Kii7xXSsnylir6ovtcaD0FZx43rc9suTvCr5yJu1CCOnIWLH8SBfVPmv/ubQYTrAdu37xMRhm0XL1hbOKvCHmmTezYw+kefSTyZlISabn2n0NI6E1g86W9xUVRqFq+RFcddILXLjpdIqkqzAP3+c5X9SGjUbbBt8aDxhwp/n8faO6QGv9jUCHT7uALyqwzeybgko1WSTlbBgQwMonXY3budP0Pg2p/5zGekurradX3XsH/zm9+0ss58ZDYJP/dFkWkBCTZqeWH8B+cTQG+A37Zj+i/sxm+H7cD6DeukoQFLNAzpdTB4PSqlRdVaOCvXC7vHDPsMuoDmhF3w0aOLp83GifGA4WNIXfVYkYpICDzdzqGFX1tCATnUNGMZH8JXHNWwxTQsWrTMGUyRnyerdoI1/WxCG1ejbvel94pZFK3104oXEMoYCzkojU21snbtKj1HM48xCl+Ie4t/ZFJK4fEwhftHCsYG/ehHP5KXvvSlZm677bbgyPThijYqdvR1iuuftW21cvqqellWUypV0RFJRrJSokoIBWfNuzSOUAuOOMSZKHS7rraad6m7fFzhedrsh4MoALuuHhF9PqnSjNSlSqSpLKXbGt/qi3t+UweuUKzPvThRJOmTmiVzTI30l+HKuA/n5oBHqu/IcFFaX8NeKY78UkriP9OMervVshZFtYCBVy+q4k8LaMNqRjD9f/Dr7YZVILh9NdG0DEfjMpIYkaFEVmJla6Vl8RWSSq7QawXid4q/Oyu46q9+YVKuhY6aklKp0FJUSguhKHCisDWCklXwPBA/wH8D2Mf5qIaCiei5SbVbpPe6orxMlpYlpQwvUnDeVBHTd279klqJF+M7zz84H85CYOfH2Zlwi8Vt0D/AewoDwueH7T3mT5BOYI29qqpyaWislWQqnjsXxp+LPKG9fZ/s3rXX1gG0SiikMSG3Yxm48dcrDAPAceseGOznztXvMoLu1xoe3J+392DbX9/vh924GUj1W1e/0+pueaPmM5aOTj5Del8PPLVLHn26XXZu7ZQdz+2Uxro6WX7cMmsJL9W8qDSJtF9TJw2P3W8QrxYn/lfBsQEt8A+pgBxWUezdu3PUH/28ylJJiekGzvH3WwiOoYAajleAbqVjFVx9mApxdqPt4XZYwwiD7YOFweXGIyoEhuTUlXVSm9TnGHrHpxukGRXVDXLNK18t9cuXaLEDXdc1z1Ux41q1XWX2RAxaYv023kcYvw2h7lpq88af4/PmsUC3zyVLl9osu9OPfqe4D03jV68/U1ad/EJJN6zRIkqFlGh4MAayJKrxFZhS/EZKNV9xxm+7X33e6Cqu92vHcf8w3g0EpBoIR1SORyKNUl+9QRY3HSeREggQpBkz976An/zkJ/aeY5ZylG/mq+ibbbDFb4YYlYCFEjbb1gJRzk4/2tHbWpDCNhI9b6/bb3zz61SwVOunjNk41Y0WRFHTg6KXXk2/cWQu+lGhC6hlNHCFf5opohunCp5iOwY0MUBLmYk7CEm09nnBiIIGzkLXT0wg4/12fjozdSCjxP0WFZe7mj+7nM84fTjCqDAEEHAqJ1zHMx8nuBfcJ1pD4SjYL45o5lArt99+l13PZ9i2rW5ydqhdVJM7Fhhk1vAwbOfN0YBEsaenx8zR+nVEBI+6LBKVk1ctljWNcRu3h06PWpTSQg8c6fuIWLJHo471F4VEPDOLA0SxYtFtz8EVdGwcTgDuDN1c0H1HT5Nq9axSxUK/FtYGNZOYujt3oSqKF0n5SUtloKVMMmhh14IXgo3JgjD7owbY9nGfaPXKjCRkMNsnpdn7tBD6qMRLtEhWrKZEhaAWsIdLVkhGM2A3vg8tfHqmtfRpoRz7qM3Va6BGF11cUaAeiG2XfbG7ZTD6pB4flFhJuQq/tPT2bZHhIYzDxcg61xIwJei3Edd4r9VwpvUdL7F3GmMvtcCr4UWDV6k+zFEh0Ojzs1tisgw8XbwNiCstWks8WiLV6bh+gUNSpv5WxFP6TIelfwrf5fJ4qZyzpkEFICq1kG4gfpGGukJkobHngOeqz8W5Q3qMgqsTAtYFVO9Tf/QP3pd8euwL6PjVPduGvR7WX3dNrDOWSGD5Do1LK+S4bwMGhTBfCMIagFEU+oJweAMOtV0Yk/4YotgLWjsneHI4jK7FKCyH0yj/688H5r93Y8c17PqDGT4xlvXZ3d0y6BKBSaVI37Ph7Ijsbu+RmspKzYb6JBoZkROOX6ffWka2bdkqi1oXS09Ht4XNBJmF0d2HtZJZWu3El2sZRPiD+0d8qMHjdBOmQayjwrDUnofFAd4be97OvXXnxLZ642eHtWdtz9EJRuTP+PUGAfLusOvs1BbhC8JqRqMQYYXBbJT4NXfWuhW4UQNb9JDAbNqx7JAUp+rksc27NL2d/GcwHuLplFx9wyulcelKvXe804hD3K+KMn31wnHh7x2//h0H+W6y+eP2Gxjct+3rL952mNGtovpNIe70GWMSHxQRCoEf8RiWtSq2CdK8n9OBxoZE49Wy9vQrpWrJmfrMEnr/KvjQ0QPpgMaFpSeBQZ4Ag/fKtfrpDSFO9L+lMRZXtmtxlbsXizd7qfAfFrqHCYw0vosbpDxVIX39e2V4ZIxeXNME0hyIvZ///Ofy7//+7/LDH/7QKn/nK2zxW+DgA/XdPnwmYF0v0ToCg318tEjYNGcZbfIJo3NXLIsW1cvyZc2aGGrin9EETTCRC8b0oaYaKa5+/JpN4MMv0UzUGSQFmljakgeYCQ2iD0U1K9Go0YKrpRgQfDimFzP/cFQLvpoJlai/CLcD51iApgy9e40fFbPZlAbNdWFyYCNsgIYnixpH3cfU7VjI3VoHYRJqUlrIrlC7Gs1sVEQWYSp2tAjqfWlmuv7Y1VJVpcc1ThDX4cwB++4Xz85v55+Le6Zu2x2DQQHP7c8t9P4Rp/q/RHPRinhUzlq3SJZVa0akBSwUqiIqByJaeIxqRhWzrsga+5bBlEqkJGIzd5YUZ1Q0ZSSqcRbRZwPRUIzJgoqGrVDnY9fiTX/xNkGmx+A2holjRqQhHZWyGAoRLjwojE02xSoUEsc2SW9rVAZLVczqd4CCJL4erP2mN6a/7j0B9k6W7JFY9Hf6um3U+4nIwLBm3tkuiWceVWG3X4ZjKoujMRmJYEmHUjURyep9ZGL6a0s+6BcV0eNR/UqjxTKi99sf3Sa9sWelO75Lusoel/bqO6Sn5XdSvSEhpWkVIYXdsScFvLf6rPSeKjS+a/WdjZkgx3fuxHypmog+L6QBaC33qYWeaV0+EVeYQAFPJqH3hAlF8GzRxTKOAoy+L/aENf3QO5Zq3URqhbGD7skfPfDFmRI5vqVa3z8sdI2WEydUYHyyhe/avlnd9gbfq7fHOSUa17EIxlKhgIYJUiAC9R3IopCGtAUx5uLN+Z0XGe4XV3IgfY/GslLfUCGLmjBNe1r9dGkMvhkUkjEjX3/fsOzYvlfa93apiHbx4sJz6DSnVI8jDAiLxx/3YQJoiUH3ePyW6jcbUZNKRKQ8ndBffW4qZlCxEcafa9eyLsn6Puu3PVw8IjWJYWmsTOg7ghicXCzv0velUwXxz+57UvZ2R2Xrs9tkcH+/tK1eJpW1Kdn+zHPS2NakLydCjZY/PQvxr8aHG9hz1V1v/C0ijvSPxkdwn3p+OlEs1eUpTdP0/bRn6+Nf49idpmkXxJnPA1G9odfT5wh7tCzqW6f76p/GL5YdtIoTXBTXC7BgBOEsDCvcwXdUeGE9O/gPf/BbpOHBUIURNXhax7aUSGuV5vtT8AwODqp2RKKJpJxy/uXSsmKtvoP6XQhm74RY0TQTUavvC4wblzbauG7twbdk75Y7zwy2vZ2mIX48rI1/K9VroFJGv0n3XUJEqj16/qi/GX2Hx8I/6+qaOjO49pRi8aHh128tlqqVtaddIRXNGyQW0/SkWMslUc0Holr+0P0izRMkqveCro/xpJmiWEKy+quRrEWZuH52cfs1UxpTo+eoyarxLXy4P4yrROsfjKucQKUE4nRE46xS6utPlli8xsIXpHwW3OkCvXvQk+kXv/iF3H333VybeBqZzhSCHIzge7MEKfgd2yDTGW2n6aEct/4Y/YBRGNVkGMJIi8yjQcapBTjL6ULovmUlKMghcyoA4/owy6e1FObAOegSiexoOhMK3C9a65CoHRjWUWihrAhGs2uM2bOEXTNJFDUzageTlTI91qSmQd3VqhBp1AJejSbQZepeC3EanaedfoKmicOW8YSNi3dkRu7X2+Wfifus/L7fnpsgrrXwq3+TiYSctaZeFpdp5qH3E1EVgAKiGY0LGBTgUTsJsYfac1/B4Wp1EWcoOKpRD/0xFHB89GDbx6lvhRgYydgi2BAbNemYlKlYsoqLw7wGEwUTJ0VbK2VkWXWu0OCWSkFmibCalb319h4GW5aMonIkk5SBzAbpGTlBhrTgozEmmdJGFXNxNfruaQYP0ed/s5rBj9g2uneKDMS6pD/RqaKvSwaLcb8xiet7GS9aq2JwhwzF9kpxRZ80riyzXgGTDe4kqnFcpfdeBaEGG00X8Mx8q2fO6CFEUak+BBiVr2qvv/pMXDGiyDJ216qlfuv5GD/lUIGonvarEEGhGStQleGdQQAmAffGFkuiJCNLmyptX0Nq7yyw7xU3oIS/T29cTOTx9ngPksmYGSxlYE5Dx8PbMHnx51qgvL1/vzGupa6uWgtgtSoAVdDbM0W66gzOQYvEjh07bG1R1wU0n9Z4f+x+gn3/C3C/8MPhvivbUrtwePDPnwuD+0zot+7GGwb2Ib+9u7BBa25zVUKiQbxOFe3dg/LDOx+SqBagt298Tnr39cjqNatF4iWyZesmqavVNNy+XcS7i0Pg7zm8DxD2MGF7vVOJalpTVZE2k9I8FuOPS1TUhcE5thC8j2oF5+P6wzaDat5fgO3C5RfC4Qi71b3g1/X4sNZM9bcQjD+OqPWJa5r0Gw6fP/Wg50LL0uVy4imnWpqN98elmfn3E3PpYHkR9HSwZRtCxyyuQ7/+XGvlCgz8HXUsdA200GIbbtDKiooUdHMMx+lY4JympiZ716eSYlRS6zOJxKvlmJMulYqWY6U4qqJO03/XndN18YzE4roPE1OxBlEL0abHIRAh4Myt7/6pxn41XnTbr9mJykkzgeiG+DMBqHaIKw/KRIlotTTUHi+xCLppg6l9b1Kp1KgwkJmDT2EGQIIUNqglxQfh970bZ5e3LzTqSiKaMZ1w4nES1UQEXTEzWQi10c3lqGN04i0s4AAyR7T4ISMp+OiLMAAYU8nDHkW5PDb7J/xC9eg0YfHgWzAPCcKE2j/UxAfuszjH1V9ntCCbFSxuX6/HU7qNafcD91nMTaiCUAvsqDU85+xzRz0XF+cIS7AfbHsK3XjC9nMODTZCntbM6Nw1dVq4iwvWQYtolHqxZ0ZfEdg7o7GtBRGUAZHhoSCD+3ctGmqvBTNEB56pbyHwZR0f38Cf1z+ErlnwXzOP4hGpL1fxF1elVPDKHg24bml5Qor1HgdTeiELoyu8IXAIn7X8wSAwFsbAqOCTDNbHHJLh4n4ZLtogvSNLZKB4ifQm10l/rFzFHVr6nNAbwa9m1jBZ3YcAHFbR11l6v7THfiI9sa36Xa+UZPGJ6p8WHou7tPBQq1+hhqO0X6KNA1K1LJGLp8kC5eUKjYdyFCL1WgktTMT0/vD14xjEX86oPZ6ce85oFYPUwleGY1oQ01+Ezz9DfHW+ex2+xz4V8x29fRaX6D1QlrFpqOw5HC16ZXuv6spTUhF3aRtaRpBeISzOHPhdg7HsPGZXlNFCmKYQSTdpCwgLDODP9feCY/buBAV27xbuUAESi0ekqrpS6uprpLwiZZVO7ltx+QLc7+/skT2726WjvVMFtRvd5cPpTdjOztP9fBjy1wVw4/dH27tzYNAdDuOgbD/wvxB/PVSlLda0IY58aArR10wG+oc03qIy3Dckm5/ZaF3C12w4RsXXoHTu75DKqvLcfRc+G+D3Ee5CwsfQoqYfvG5jwqmsVKRiUlWWkDJ99hAN4fNxnomy4Hz84ji6IdpyDUgzQuA4wubTF48/34Nd2IX99QLQv0/AhJ+qq6X1Uakp0/RomkCLOCZMOf+yKyVRhh40+fcWxuIR8aAvurV+Ir3Xd7vQXdhtbrvgWPgXaxaj8sbyEN33QtCf4yvsDgfe75bWVjtnqsBrlI2kZdUJl0hVywkqTBMSRcURRBxEHX5NxOl7pabUxJ9+d2pnY/gCcQeRB5FoAjDYd2P71I0ZLcf4bbXXSHBG4wlhQNx5fCtrIloji+ow5i8dHM+7mUzgNyZx8c+QzCxT97aTg+I/MPz6jyD8O9refgxs6mdjv/iLsRnVNTXStKhBC17Degy1i+hu4go7EILZoh4p1swLrSWojbdDaLHDQuyZXrVHywIO4FVwDtAldCTbb345nGCEuyIVlsgQ3b+pBZmZ1ZUVxTVUanQfIcpndwHW7Q0ZPGIHGYIWWzVRs26eFg8uLjA5TVEGtU61ejN+7B8KUT5icO/6GySKzc1tUl2lbhU8D2S6RZi1Uv3CLxJTy8TMuE8p/OxA4f5cQ+/aunCeuqJBllRFNMPSgn3QmudqWpER4x71/q0wrRmvvjc4zyaQ0ONY2w/dM0s1jtAVzVqPdB/vkwkGNT6GfJedcAEoioxcf83oZRLquLm6TFJaANcrmxu7/hGAUECqoIwQ2dAo/RX67HFp/WPdEjUcmeyAhlEzU5yggqVoWN+toSoZHmmWoeyp0l9yhfQXnS/9pSfLQMkK6Y23SF/iUumM67F4k8ZDXAOu769m4iMa5pFoiQyrGdEMGuP+MqURPW+/DBZhfM6Abm/UjLtM4qWnSDJ2nF4brRhV9k5bpYbGR21bRlLVEQvXkd67gXdT/2vxQWpQuNV7j+ITQCvryJAWMvR6zmHOoC0zZs8Ez12/HnwX+ovJe/CdFelXq3dnz1cfs4Yb7wMmwCmxKinMHdzZg6UM8H3jntSlXjemBp2r0Z3UXenIcIWcjLTVq4jStAzvCMaZYvyk7yZn365S+K2Gcd8u3mkfRryX6r8lQFgXr8i6R8Zj+s5b39HgO9BjmH0Z8WFxEuAL7SBcaMd18D3EbBKYMmlqqrdJV5z4g58ajxrfGJvW3d0jO3fulc59PTI8BH/gg14H35DdN9y7+7Dno+8w1jHEHeBd1k9SQzf6PhEn6JqYjxd4Cv/029d3FF0/Y/ruohXfP1Mv/s3odlbvszpVIhUaF6N9n2Q0nle31Uvp0IB09g5Jf/egbHl6syS0oLvhlLXS09tlS65Ey2KSsc9Cw6a3E05PQPhZ+224gD4bxjqAeNb6DzFhY8lx0/Y/KzH9JipUACItwruN2XnxbuGNx3KGbuF8pBfuu8Tar5kRXAMmeJ/UjKi/di2zD94te8eQj48Or0PdISxq0AN7ZFhDaI8Kaa6617ysTONhTVOFvi/oHYN/ePJTB6LlxBecI7VNrZYu+ZYm6+KJGChGC6Aaa+WzN9LFrW7DjCDe1C26x9ps5vBD7ay1T3+xjXffBAP81l+8z6hshJ+qcszYbLZ63Ak/d06JlgNw/thx6d57nJeuKJfK2hp3M5MG/NJwBM+77ZizpHbpBsnGNEyl+mzQZbMU3TY1DYfIQwufisDieN6U4DcWM4FYpM8VXTrdUkBqrKZV4zMwTuwF+3oceTPi2xoVLK928auxrzfuyoMu/y2WRKxBGuvXangxDMYCP+ngGWCB9uHhg73bZDo5ihIDORo0PcoTJHDeWCIXOLCCtCVmITskKLadlYaGOqvhdGIMCSzGWfguVT7rQgHW2WCq+JFMt+YdKvzELeLugH/6UZooxAQxej31D+NYNDXVbQgrN2PotKEZGvr9u9c0HGEFIDNEiBFONaPc2jG9R4hCtOiVlOk+OsN4NwdPhKIxFX8tiy3eRz0bzSBy23gOZvDj7MHoZ+jPt905BSZWWNZYKcvq0dKXsVa3uGZeKPQ4wQaDogsyEdghP9I3B5mNxkFurcngPXYZu3+ng3hU4zP8MH4f3Xf0xbNtRDSuVaolntqKpHUzhN0hHuMhsYkQIFZaKiTbUq2vSUxGtHQ8rPc3WKrfimaGGM+VHdLMEp9SBt1Pa7Xwcq7e9dUykD1Thcx66YucK/2pl8hw/XUy2Hyq7G+6XPbXvUiFXrlko5rNxvT70Qwci7irYrBM24xm1sjMS0uXSlXixVIZv1Lfr7QMR56R3uLfSO/IoyosfyPDJc9phg4BgPjUvD+SkcUrtDCgD0JtNWCj4248ICYBlqQoU3/T6pcVENQOzxGROjyo4i941tayp3GTVCGQTGJSAi1YqCs8dzwGdx5C494FezS6bb/6vPZ1dUtX/6B09w1ogVcjU+3dd+jCAdJaGsPEL7i+nX4E2PuhprneDaR395n3zW1NzHf/DReeBquoFt6wYDtaAN0rixfFnePTAfe+u23fCpVr8Qnc4ly4QeVHXV2NzQKKLvwo37rj5rmW2zLS2blfduzYKT09WJBa7RCdGjb4693h167pty1t1G013h1+c+HSbbRQufPdjWITx9Eygi5xmLjHJi2xo3CTtXGcMb33inRc6qswltodnQrQo2D9uhVWeMX6fgNDWenYs1+ee3qjpKtSsubY1bJ3d7tNooDeMAif5YJBXPv4PjguTuAO5wHdNTuAuOjv65fenm5JpfL36mIC9UJ+0p48FrdmD4E+Om4Q524CF5wdPqZXd5csAG6Ca6qDoWDyFxTjUTGK9LmloVrS6JM6yr+pIZpMy9kXXKyCw72niB8fRGzbvu7kQw1U7On94pbdGD89ru7w/aA7IN4nnAd770fO6DuM43ZOcHzUkAuY0HnjAe6bW1osPZs83LUzmr+U1y2T5cecpgIOXfRjrjVP8wAzek2bPAotfjDWkpc3vlun/UbR9dOdZ+siesGHcCMvwT17O40jjH2EELSWUCTiSNvVzn0P7r2xdEDLRelkg1RWNlqYp4rDf3tkuhjfl0EmDZ9gwYT3C7eBS7jyqb8vPOfca0m0qanRxodki/zyBDh28McK8ebW6YMp/BBxrjPWcgaDLpBajMoEojAcvqnEEqQiFWha0A5sgt8DsVp5q9nUQrSr5g2B8OJc3Eul/pbpniZ+Y91G7t7cOUhP165dafcMU5iR5J4DjgXPxu97937bm7mEhliqkzHZ0KoFiWjGWu/QxROL4qOAgda63Pi+4FjuNzAowCMevPE1sj5+YFDQxXgiZFCY1Qu1gig84Td3XhB3eJKWkWUGJalCqDwRPbp4tfDFJbFimfRFRyRb2iel+lnEB6skNlgrJSpEirL6HmbbtKCyTjPyU7S0c6ZI8kTJVqyWkoY1Elu8XCJNKyVTryZZowEslpGStAyUVKl4jMtgVEWkZtbDmuGPRKIypBk5Wv+GNRIzpVoojOh9RVRgljTp/bVJLFYvnUP3SV/RvSoAn1PBuFMjs0czcRTS8X7hNyvxiiGpasB3glg5+PdxMHAGWoCSGn/VGpbYMAS8Gn3vtejgDN5rtUUrHL7EiAYA57nCLUQenjHef+cX9s2tnmfjPfVDQ0sTxiWhINs3mNHC+sFrfXH9hHqdtKseIXrNchWnKQx6Uvy75sE+Lo9ff8xvu31n59Kg0aEIuwsbnIMlSlKaFif0mwn76bf9PXt7v28F9yB+/DEYTP7Q0FAv9fV1JrpMaKtf3uCc9r3tJgD7VEyjXOX9wvlw43EVYg6IDRwH/lp+G2Hy53s7GH9NfKsQf4lkXKKxiHVTLdV32VrxM0PSXFtu78NUUVtVLpVl6r+Gc2ikSLp7hyUWTcve7fvkuUc2Sk1dtSxZtUR27dpuYyfxTFBZ6e8Lv94Af392j8hHgm24DQs4H2cw6bK0xkFCulX8FaKHzW+cq67NvbN3cQt7f+0wPmwABfOxgJvwPQD4Dj+HVFTibccMn7VlpVKbcpW/etf2O9ngfvA+vOD8C93kI5ru+/jx9xx+/w4gq9+Xpq0jmubgXnwLFc7F+wUTXmbEG7Ra4R3076PZhfJe/+0Wnnc4Ipo+19TUjsvtuEAarT/RRLWsPOFCGY5puUPT1VyrKO4BAg6tdJpR5oSg5oM23k9FsBeD1h1UTV4cqqhDTwz4YUbPN2GncYpfjQP0dvJiz7WGIlF3+5ZYByDu3bqHCamtXCGxyMFnnUT609raGuyRuQzeTTIDIIHxiVU4qfEJT/jXJ2Rhh9hHLWzT4gZXs4nZOW32TRhsawZj4g64xD+fWQQteaOurKgdOnK5sXE4x2dA+MV+OBOB3eHMeMmf4zI93DO6qiCMiCOEs9A/H3a1t3tBsRR2Bfek57szURuf1l/cmyaKZhdGr+MvgV8VyKVa0F62bIllSiD8TNw2CgPYh62dhI1g3+HPAe68YGccIJS5kKLgZudrIq921m0ShU3vZ9jgj/0eDXgGRbKysVway1Er6a6JljlcFwtcm9G4wbTY1g1MDQomCBAyY4gGnIN8Rn+csWPmxN5rKzDjXP3FYtI4MKwFGYg+8yvAv7vA1uBCl5GRIanQQnZUz0dGe0RoGJPJZr2/ao3XUikdrpJEx1JJ7ThGUntPlOSQijpZI+n41VKevl7SFS+TWPoyiZQvk+LyahlJVMlQrFwFGgo/KvhiWmgsVaVXgrF7WqiJ6vunGXVWBV9W4wuCzy3tgK6PWnjVoGNyFylJqNHvVcXKSKZXCwNd+koPapxqHGTjev9xu0frJaYKC61/+Eyrm/QZuDLeEWApgVRowSOqhWOXIqi/ajRYeaNxDxGX1MJIXC8Gu2FMu632URRWvDt1gxTEiT4NvhZIouq3dfPVsMNnLMbvpvx3LyiuFQZHEA6MwsXkMuYK7wt+xwnOqk4lJG5NtDgzuBb80T/+m/TvFH7D36nH2fnw4ddtF7r1fjprjSt9vkksFB20kFkrmRbQrMJCHfl0H4QL824bhfrgoPoFP9ESUt9QK7W11SYq0SqrUWzfDLqRDQ9lZe+eDhsDiJnx3LeT71bqUL/sHDynwEYvZHGgBguR4/n5e/PH7HgADuWMeoJ8x81IimeG7zordRUaPlxA/08ezjMNnbQuqpIkhvfqs8VbOjA0In0DQ5KIxmXv5n2yeeNWaWprlIbFdRonu6WhsV5KYnrTWfXDjGuVA7iz/N2NBvGAYzYuFdsWn+59wr+EPpOqinL9HvD+u+/Fg/OwRuCgpmc4w31R7h688AtFqwG7/LG8+3D8e8ayQ7jwuHEsrWlOfSXGqTs/Jh/nb7qiUo476VQTFu7dQTruYsK/R4W470RzMHtHnMG7ikeCWHRdXeEG6VrUyji570bPsxk99TSXd4wWeGPZwYyPIqmrq9P3+YgT0wLwvZVI/eK1kqhabL09ijSxLULCiPzOjH5z+v7oTbmPMjDWBRWb6sbG9amxVj81+dZAfe9Q7sP3p2mLdfdUf2xWU/ir56q2DsSfusMv4gbiGk2zIbJFrsGgOFshlWWt6szHgQYiBN6tzs7OYO/owbPBs8XMxjU1NdLY2Cj19fU2FhAtv0gzx//8yEQIp1dkBrAXuyCB8tv4xb/cdsgeoGDR1NSgW5Zq6n8tOGTdIuRu/b1ggXVr4cNxFKzVzk4f69EjC9MMtahPDaZAx6LmKiSDWalwXj7LgSeFBn7qxxqY8QNfnXEZHhIejCSCf/6KsB8LdYNJX2x69bB7h90P+q4Xl+sv3MGnzIE6wc7FNXAAGXCfJoCDUlVVKekyLYba5Uc/A2y6XZzjCknB4Ukg8Nyuo3JcM71F6bic1FYtlxy3SC4/frFcur5Jzl3TKMe31ElTedLGXaEI5uJvdOI+UXDpZLRE1i2vlpiKEYg7dN/EuCbb1gwKA9Sxrh0MCnuY+KR/AIv9a3RrWKyrp/qD7lluLJ/ahwyu4caR4qm7Wl9MWz4UFMx8C4eLa3Ws6J4WqlQc6f6gFvqi6ndaw+mewcQpzsakEi13fQkpGYpIsr1a4vtqJTLUIMnIKomVrNL7bdFwNOr3UCMjJWUq8iJq9H5L0Eqn3wxqVZGxIqMqgcArVXelkkE3JstoNdPXIKIxOqtxpRGi4deLI+PWAsGwPq5MrFf6hu6X7oHvSH/mQXWv73OxftvFdRoR6iceLTJsxBtEn5rSSFaSVcWSSE/kW8uDrz2tYU/ie8D7q88IMYk4dmPGnMGzRgEXAttadzXurdIB5+gzt6CpsYoBPZbUe6ouS6rBRBMxqVNTmcZMmOhmBHA1nOG2RqHvOWqrkYIk9BfvjwYCf+zw+CiSqpQWjrBphUh4gXvJv0fBj32zviDtj3ny7t07Gn7H/DG8n+F94P3EMdwzCq9eAMJ4tweeo1cKhB+M+qrH8f7DZCSeiGgBqVJq66q0YKT+6KWdHwgDZlEdlo6O/bJ37z7p7uoZJSKd/5oPaDxgnJwH9mal2xB/Y3W5BnCnf/WY7al7t+/s8DTxrZZKZapYUvo9aqj0mDdHi/MjqnG5pKHa0p0RvSbSdqQXXb291oociUVlx+ZdsmfbXlmycolU1FdIe8deqanHGFl7Gyw+3Jm6cZCg+eeCu4NIxC8cI6nK2PSUtmffQ5XmDeVJFfYWBw64RwwP6QloiUPuizGAAP7mBZ7zGfh9iH8IOIhMVIBZ19FcGPL4c3P+6LUwthBjBtEjo7mu3NJlF5pJRm8Fb8CSVeukWMsguDWXnrt4gykkfAyHnXHvk0ogvW9Nz4e1hIJWQP1m0XUVLzha/TD7LX5dZaI732PXCvbd9oECcHygO3NcUmkMBRnvOYeiRKLxCmlconEUS2nYnSgrKtF0yfIJDR/yN91GKx5a+qx1z341ndQIhQAc0eeK8bdWWaHnoBsnRJ56FrT2uX2bvVOfNwSzzZpq/ufjwxILyz8QN+5b8KgLdYZW/lJJJ5s0v0fPKMSBf6MdeDcnS/ghTWxra5NzzjlHzj//fDn33HPlrLPOkjPOOENOPfVUOfnkk2XDhg0mBikAJ5/RT5ZMC+4lzidK+PGJlDfhAkWYsBvM5IlaYBtgrom/JXaaYLjMACJPEwvL5OEHMg+M30OmgwlNkB0VZArZITVdajD+D8cty8KBAqfY1/BhvFNRxIyglihYJy9rBsJtvGhhL6jpKylCwcgnTIfKtBAuvd+gBe9gWDcH0YSsCDOdHdzdKFTwYnZUCGWM3UHtUzjeYcIUHgubcAbkzfhA0aJU/6ng0wLfFacslpecvUQuXJuW9a0RWVFfJCtqS2VtY0ROW5aSi49rlsuObZXWirgWmJFtHumnjfBpBqvv0JqmaqlKqLjSjCWqzxctOGhtQE1/VAt3tq8Gv/rfWv0SKOQm3HT36I5o+U3wLltc4B8ynyAe0HrnWyaQwMMeY4hQUPM1vf4Ytn1XHl/w0SKDlMc1HME1Jko8UqMCSr8hZJIjpTKsmV9fww7pWrxR+it2ykB0QK/bou9R3EQbDFrrMvgNzEh4W/1Bix668KClb0TD7Q3W7EP/1xEN6ggyZ6zLFIV4jGomPyiDg49p4f1evaNBLTYcrwLqCknGXqli4TLN6OtRltD71PMQJyhoFmckkhyS8nqNT1NIEwOVzxB+EY1L9dUmf8JaZeiyCaHuDd5E/+7as9TzINixj+eA4EC0YwIQzHpYU5GySoOUxgda3ir1fcAEQXhC8LswpEiZvEFBx61XhvDpe6Xh0Y9Rj4wXvD9F1urR1+vWhcI756/q78Nsc9u4H1foDtv537Gw+9bfQvfe+HcewC32vfiw70Dd+HfYnwN8ODx2neAYfuFHPB6V6mqsw1Wr31q+q7Odp+ny0OCI7N/fLTt37FYB2IvhcDjb3MA/f91wOArtvQHePhwOb+yY/mbQuqrpDl7DuopkcDWc7849GpCEF2uBuUzfo+oK9NrI3wfel94B9AAokv6Bfr1+iWx9fpuK33ZZfdxKSWh62N/VJ1W15fb9oIrD4/0Adm/5QwcAV7lrajz7Z4Q4Kk8lrfUPXdvVgdl74M6/V2FsoXElHIYw3t6uBwEYiMWwP/68Qr9RUVtXpvkAPvCpQK+L2SVXrluv+TzKAJixU9O7wnAEIHww/n0LGw/uBcu/9A32q4gfsu9f7z53HsRfUvNiTKxjE0cF76bzI+RnwUMMX+NwII+pqHAzkx4tSKOT1S2Sql6sgdD71pcY/toyE5Y/ONGGjBOtfk7wxaQklpDSWFJiqTKJqQiNptKaxmv5Q90O6TvQPzSo78KQ5asYfoPeH9YyiPQVcaLb3vj4Brl70l9sH+weI6VJSSUw4zkqEw98L48WXBetexdffLEJvpUrV8qiRYusla+8vFzKysqksrLS3DQ0NNjxNWvWWCMHmTzc10OmnbG+u8KP0fbH/j4N9EtPpZHJukIIMgfLkLSwZsY+XBQG4A+SUs1s0PqXE4ThD1sLHEWY9EULS+Y+8CPnz+iAuFpoFXcQfRB/WQhADYn6mzNh7w+K+mvNGSjQotVO/bOum4cDnrvzCl9jnyGCbBaT3VSoa3Vn93J4MljM3rrODlshq7wctYDjY6wE9WCJ7KHAGRhZedLKKrnlZSvlvDXD0lLVJenyjCaCIyqwsKi0ijKNrljJiJSX9qroG5RL1lfL+qVVao/nO3FcxqkZkT7fdW0N1t0OhbloyfD/Z+8/4DVLzvpO/HnTzff2vZ17Zrp7sjQzykJIJpgsgkz0Hz42XrR4WTbYn+VjWBswrL3YXrMEGdhlCUYEIUAYEGCLqAAoZ81Io9Hkns59u28Ob47/3/epU+977u3buXs6nd97n3vOqapTuZ56nqo6VVZSp+vLTtRZ0YFxTx1EGUPpmxgbtpnpSVf6WAIWz1OKShzw5WlOScfET/6TR9RflrMMJSO86XzjPhLvUc/xyzpt392TGajLwfjkDmtJiOmOS8Aarllres6a4/PqlIdsdeiIlQvHrTdUVZZIgFNGcGZVX/mDJFwx2+eKn64+84c7dwtJIIqUvE8nzgf+DL9AnuXtOpVVfyMSIO+08aHXqM4ekEB9UHZfbaP5f6BaflD5xogubS+0eZaHzuylTC49/SOK34j86St8yltG1FGiaVGRFGsXysjzNjOyTQaQNrYlf5YwOzkipV9tv8DsEu1ahIw7XFIeq3w3xxJfJNL2iUVHLJBjlJvmyo6ulwrq4thwGDQol8XT9NsSst8M0phOGvf4E936fQKcOb89D9L21FtGulkG6jMY5HNC+BuJ58jLyVeu0c6hjJET5017du92AQl/eY/BM0qNGZROp+fn/52WAri+Xu77B7jy3WXfTyGGFRWNtPtovhXwgdlij5fKbfeM+GUSj6uDnt25/4DvpDk5zjm1IU6AYBrNti0srVur27Z6rSHWnbOTz53ytL/qS17lY369fNsmURpT6Q0Y+LUZ5A3KwFnQK+QHbSHkEd8ZFm3HzLQfgSGDxGFAzMsIbJnRS+dnzOdzIZZNCO/8bmmvk8M5G4UXXSZfPB/wcdvMdpuc3qn8ZydTV9ESm41I16+LAbNcDSk2TZVluqy48x2ih0u+uVTa1w33erjUMNOIbfNKUSwUbf89L1OkJxJ+rbYp80h5lmTSd6p++Rl7XMUjiwlxn+M6PGJ5KYQjY6M2NjHumyjRztrthtpvx5rNhvhx8ukD9YK0U+aizbwlDrY6zpVFkr+mxnfrvQvnQfT3YoFbzk38pm/6Jv9WkAF1+Bb5zRVCwY8UeeXMzIzdf//9rhBeSngZzo2rxZkzXCQ2N5Zwv/k5wO+9LYd3NlOpMKyOcMyFNmbJCrlxFag6RilOvslJolBF//l+z3rDsiuKSZxd9OHbvkRBSoQ2yJm6K3jqQfPDYs6jEkhLEnRxRxzxnyvu9X5CHipcDmdiSgMKnWDXUBZH9dqo/JWfHNsgoTEe28CrGyC7APweTdJzdsfsW/Dr2lYe9XIT1hUzY3dK9xE/IsXIOemZ3RtzEmrza8oLngtSQnI26eciJe8nSJdDfIbJRvh3WD69EcKJ7tJ+nAWG8ZjtlNthMfuve80ee/NXTtm20TUbk6I3ruROlMJsxpgobqTCTouuCCj8EZXJK+4cs1cf2G2jRaUbRcGDjuGfHyHnur40j00Rw+yShEjFjWNBlEN+0DZJZZlVtd60BpuCSMhAESsoveggvuOnxy0Qy7OYOUQoV+1ENFWMulJQC1IK1OkpDdyPYC9BYit4J6ZfiVkP31lUTzIbVhp38uHPRYO8UDh5dfIjHHisjroqFVfl3x6qqX5O2Fj7QdvRe4PSkbe6HdYrK6rvEogRBEkQGYAyy3bivhSzZG115nzH59/6yT7OEPYpPyRzqfOyb7EZk9Lc6TYkAEqxVB6PjUrRHh6T0FBWXjyjsv6EyvxRKw4tSri609rNr7V295UKU8q12rovG1J9GZtUuYzRsZMScug8Za1wlNtO03I2RFvRNSfF3ts9dTYvpZoylHPK3xUK2dWbdVHDmi6wqgy9rHtOHNw9LcVfzUXVR+mi6svvWr0qJU4Kn+qOfHFWoRYuJa8TFDzuZQZR80Ls8UTQeyXxiiCCnKfdpMCbE0MlX/4bR8IrZZWpb/okn6nP3OmShOIItT4hCde4g1dxdcKRMHh/cHWBS4jXNB8ICD6z2iIsb+tJsFEcJ8ZceeM57pYc/YvXKOhHv4FKRPaEQRvr2Mhowe64c5ft3hOWgIbgk9xU/eDV9bWqnTm9Ymurqm/topdHDj7MhmCyjwpjGNAb5FNEfI5xAtEdVBB/1X/VhY5tn1CYCjfnwxob/bkcKCdsZWnBB5bG+RRWccgrPOoTXRCotZp2er5hS6tNqzTUtlptO/rkYVtfXLOXv/YRxrJsQnkzNKE2qrrgS+KcCEDpcT4d0hXhG9boSj12Z+44gfd1YVCD7GBQA562Y3JC6Z9wHkm8+U++tloda8kfcsSXfSqf2+KbKOch70Pepss5PkczLh6WR1OpT9mlQWzzpZ7t2Dbmm1NddSj+O3busyH1iwz2stqIWfqQS1tjq7huyM8IKcSwoB67lfJNpe55ppxzfO+stsI3bBNSGkakGPDtMWVEbcOdrJN4hNzfKn8GICMD8QbFwKYqJfl7xSiO29Sue1wUUkUisYo//YXuRfBAwkMBZFm/K4IogCiD4g1+nIP4GDyMFTA9KUdQXorQ8Pi0DY0ywMoOu6yEUYrhHyh/age9tup/p+2fRDCA5queQiap2qkcRF3dI2uF9KegeA4NbVP/sz3k9zlA2TFDx1LMLctxE+CJzOy98Y1fa9u2TUrZS1YMKW/CQPGAgl1YIh+UQXZNHtb7e3wQ/mLCy3B+eBeR4frivNX4PJZ8h1zy75vkrDelwmRHNbZFYFc59XT+rhiChEwEehoMdoW8hAO+e6M3TMM5ZbjdCI59aKpvhMEEweDCkEdJh0rYmxGDobu4JiCe3Unx3LjsiHDOE2+PK0IQgn8QwgCjUWNSrkFM9+b0X+g5IphvbReAECVhV0rE6+4dtW97/bDtnKjY6HBLiqCJulKSun29wwVGfmS1vKWT47ueksrr4b3D9rI7Z/zYA1+Cc75gN4COtGf7d0/r3bbHGaYdKc7esdmBu8ZexOg192lCaUoLkn1zV0bDPR0XI5741laHxa6e50I/DiI6Brb1RgmU/Oa7OF4qSoVJG8pNSThSm1metNHl3VaUUFzq6trbafnOPhsvvlaCTddW2u+zZvezSvCqSyHM3Cky6kiVsQmhhGLGzJXPgOjeZwAx1yPtgNkBdt/NSSLoqKwRAHI9ddTtZ1QFH7PJQs2mS4dtxN5n48N/YTPD77Btwx+wfEvu2gesXflKa5a/UQrYqyREsgW58m+oZ1PbJRh4OwsCz7lANaBFomijpCkFLpcgWPlsn+wRoBCrKT++2xsZYhZPzzLnGaEWzjEk9yjqw0r7iDps/IqzGMqN/pU7lin5WWfygwEZFD1VA/knxVESUBDYNoJnBDq2eXJPLhJsKDM1KaFQcaWuUmcaybenAyhMxcPvdI33gPuo3KSx2V1ENEsLmdHtZorgnnhRjxn5DjMNgR9vFlaJC/kKnS3IDsLm+8EdO2dstx8EL+VDAhT8n/qGHxAzoPPz87aysq48kbl/bBrCONvvgLQ591A6fza/NjUmAdXr4tUBYnm1vC5/h30AKY103Fg2XlM5r1caVqt3rdXs2fNPvWCdWscefNmD6sEatntmm41Pwiti/FLlmZRPLCvK53zYXKYeF/GKUQnt0xJuh8XX3Nr7FmZpklmZxC0U2svZ+Xs+YH++8gJ59WG7piddubja4Hu1md27JZQzyBziEOOzOU7ni+P57MgXBpkarYbzDv+uW9kIdVG49S47QQ+z263aDemEr0G+eoBn0i638TOSSHC3synAZ5/obK8Q2/fcrfjxbZ98T+oJfUXsw7yv6EOOZI/C6t/+ofw5ldQ38n144GH9+oY/4hvs9Dk0Oqb4jkoW5KgqcUo2FROvps3wjSjlwqCEl00SGiAXtoZc5Yo2NbFL7wTZcivgX+QlFwM2cPn6r/96X0pLHsP3Im+OMgVpw1/izH1Mc3TDe2z+wmxghitDuvZleBHgDXczZJY2P9d9GpiPjqhzL6LYsPk5i/KkCYqxqak40YjZ5IUNX1wBlCnKgjfuPg0QWMNGM+CzZTJmsxgUwIsD8VAD7YmJsnxzA0IH4cv+9LsU6LWLAI4QXKd0qzgQxAWD0Tu5phhmTdeB0ALDSTMa8j1NaZyvI4vY9MoGMLKs/7ZvIm/f9RXjdtfMmo2P1I3JrOFhCeolZsU66gwoKQmCLIdJBBjyMTBKOkUJv1ILXnHHqO2ZGnah2rPkIkEXdHDPjG+cEsqIeAf/QWTSPEcz0n5WnpwzrWFMFrhzxa3ty6YSP4LVORBGmOkcmPEbQmtRFBCyYlwuFqXipDpKDnouSOFTh7Syw4qtcRvq7lKe0WlL0MzdY2PFl6lZDUtQPqrOdFb3Sr/CJlxfzqk4+xJQ3TO7hWxBx+5LQBW/GF8/bkX2PkKbb6joimohi5arvN96tU9YvntKHlYVNstYywq/YUN6Hhp5Qmk9LbuOhKDtEoheZuW1N1q9yozkhOWH2ja9k9ldZaTK/zwZL7+Jr4SmfNdnOlGsgqKXKH3RLCEqU7fVcjeYoyAyyj4sAZy8ZwbYZ4HJj24QNLwOxChw1TNnroVNGyjfnJTaEf/2b2a0ZON820K84zsJFJSHN+xpungMS/EbHZZC6oL3oN6ml6im62m897rHPX+6BrcD99GdbpLn8BjRtxfifXwvbQfic2xDCDWjEuJQAlHgMEvzE+7JWwTisGnLwC7tP3VraLho0xL6d0oJnJmZEu+QEKksiO/gR7Vat+XlVVtaWknOAtxacAfRPFIMq/9OkkcAu0mVKYpHYpJcLx9wC9r69in6uQFv3oyO+DZKQqUmBbDesVpVPKVudviZw2onHbv/4fut3q1JeJxWXg+E+5geEO/Px0tiHkRKI8yidrzuzUxPJUd74G+Id1p5j9fNZpFA2v9BLgfgZlAngmLv5iJmgGYm+F7+0trOxQBFY3LHTgUSBuxifPluMcY7jWgW4xtpK7cR2PEtJasLGq2mVRt1lWnLmm3MoHYymCQegYI0JKVHec4MV8tnu+gfyRuFE4qkTzw7wQv7FNJAfo9JmTxf+V8Mduy5R/xuMLAeipF/g3oTBkaTe4WHAhs2ahFPEBVK6tOGkplA2UNynfQ58gqeSzzzam+cD1hSXSuyTFR9fiEckYSC5Zu5KKtZaRXTee78x2HexkZmVIc2TQxsAvWunRrMOBdIHxu3sCSdb/XgdZ4WmSNLxLyO9+mB4ZjuSMwAovxhl+HycfW5QoaLwoa2kjykK3P/XlaxEfBLoygBJ58Tk2J5p/77EkrvYOBuCGt1K6iBB2UvmHNHR+pMwxn3cCDCy6mXzKFMbET4gFth5Nn/j1E+VZtI5wT+iRnnh8TEOEqBw26ZORtVPFFSZSfGEpZg4py4R0WGWJJWKAW5DdlCOiTEGbuOKs6bhIGuC5GEMaGweEF5cAHmZF0UVGY1axLAg3uW0BYLYVexdNmkGV3aHGx+PhvntkfwRoz+8pdN28N3tW18tCkhUDk2UrPRIUY4peyU1Gkq7c1mS4qI4isBvuAbK0ioVrr5bod1/yiFQ8WWvfzu7Spd8uMC6Y+QU76X2zM5IoVINY6ZHAn4iOyraxVbWV9Wp9uQcMXMqJzjRu/AlPv1NJK8C6HqXnVzIAxK0VOnwTvYqSsi+p6vdFSA6EZKA7cu4CTDv12VEZ+tlvSPjUqC+nIBeNz04zsKdZQ9aRcsmRxuTckUhU9tSnHxZceqq0OF+2xi9E02OvkNlh+5X/mi9qB0u8In6pKOJC1EJl+SuTpx3PhsHgMKRXWQ0b387ahNjfJNbe2j1qt8UK8d9njxvqtHqusUKzV9zE7Z3u0ftImxZ2yksCDFa0nuxqzYmXZljyMfRibDSK8v+UmEzK0QlveE4xLQmXMKQTKG7uUPJDs/qF1xiMS3JNQ6hFepycrnnn8b6IqjvxcUdzbZYOlvKDK4DJtFmepj1yoIYIobaVMttdEifils5fuYlLRJCTgkfwM8fpQo+ZiYXRCKl+JXKnQkdKtsPd4IECoP1ZW64tdsIqzEwLhuDjiA99JCUmz3A9fhDnebgdt+O0js0899vzbYKd9VKCxtGh8fdaJaMWAQlQPId3xs831PGCzZDPyibfFNLt+A79y1w3bt3mkcug8vpBzCGWrioBKm19WuOQpidaXsSxKJWogeccI/7slJ1K580vSIS3AXhOiQXiC9z+vEObL10iG/Kb8Jn6kbpDfmYbwWWKrf5SxQvvVrWrvRtjWlrV5r24lnT4qfjtmDr3rAlmurtuOOnVZUvWMQhIGZ6AdAToavxvSkEcpp64Rh7q0Le3kHJ9shxW+K9akywp5wqE+0a5QW1cT+7p8KMbThxB3gEhQTHkJa+yQjlabiL/+wg//LD8qIvnV8WHE9Nyu4bKCITE5Oe7jp+EgnE19T/Uie04hu0thsFu/7Zkq3qr3XcZTKhvq8cq1uDT+0XuZJvsCl2PxneGhMfHpK7V+8hHbBe+QQzCOMbjl5nnm+uZOEGDClbudsRPUk9E2XBuW2Fz17H4xtv8M6HAhL5+i8Bgvxv7wSBGMXCMOXXIpfseyf/oIG77t+0n94fUrMxaQRlXj2pIh0S2Z5feHB+xsVOI8oT9G/8BmG8shn8EIbDq/zHxCfSIABZpZUXnoebAZxY+OWhx56yAe0kKUo37jDMUogblD6IOzZG4Dsh0JagtIH8bx37269u1Emy3BpuPKSzXDNcFbF3vQYOnKARWzECeCIznBCYx9QBHZpEuAsuN9yin+T24tG+j0YU8KE8sxOovhxTZF/0UM8Ams6NxL7LSTCoORVZHta4ZQVqrNLOVcc0pQGy2E5xsJnRzf6CUPfjHSHdbVAJ4Vo8zVfOmlTExV1YnzMrnKWIjE01PLZPoRplscNs6umGLuXqupJrCpx6RjLxljisVMKwdTo+UfuNkDJwm/JnkLwlB0buQvnWMlUgbG7ZLp+wrQHz1zViUoaKVdqLtS4UJLYw8Cje+KOIARxYDXmFwJ5D+EPAjGEz0PqRAad2YVAZ0PnQbx4LFgpP2mlzqRVekesN/x5G+l+wKabH7FCd0mu+a5uhxW7I64MKfCElPdoTt7JKj1SJt0caZhzvBhi9uygjAY1qdRbsvbSf7Xa0sdUXzkImryNttyF+05Haeqt2MzUp+zuvX9pDxz8U3vlw39sL7n3z2x47AtqsoiQqifj1HEGTghbdC6QPco7n2FL6vAgVJCYqV0FCklDSeTKUjvcS+Ryd2kgQDdbHCMzsFPqrc6zl30wJ6YIRKEZMmvYtvGhvE2Uwojupgg5Bjl3IeSSEWWVrwQIZrwQ8wg1CA4ce9CySgUl5+xBrs2ISYnKH3XtUhHfBek2cz7gjrbMEilGyXlO+8OFe9ISl0fTdkjjZmDGDtDbt29zoYlvbNigybOUMpBftO1qtSoFcNGWlpY9b4JSmThyCkhSksTBHxwxfr450Hmq4OWA8hw5zxK8kC8hjtTDcrVmTfGfptKxvlq2tdWqvfDcCzY9OWOveu0rba28Yjt2zxiHz4NBMuLdwORiy2wzGISDxsXExwNDdbTbbVfcPXuTvCXvMD83tohDYoQ3lDF+kPZQKAwUXgLfvwSgmPgmNgqDfI/lzgwb6Rrk3NnAXaQ0Nptx7zPbULzXlfZXrdXUfiu+fNtn9MRrFTTRUVmFDVqgrdrCxSAOPl46iD/8Z9RGx8b1RNyCTYRS0a8X3r7kINQAUeLW8yGxgzq0Rfo4pdGLPHEHcBsoMUhZppx5HWYVClfnjbRR+oCzEN6CKw8Pj/v9leLBBx/sK3gQPB6lj3yG4oY62JEWyg1e5v26Eow57tjkJS4V3bNnd+J7hsvBVWbPGa4E3uA3QxW/b64LjSAChruhdfcBh0BoU2OSKhG+kgnkHm4JRCspYlK8wiYv53J3NSChz4e61Hn02KSFjTUiEecr67BQ9Jj56NmqGOa88qktATQZ6XIpn2q/qerna+q4VsQcLywMXivAmPeMF+zlB2u2bbRpE2MSiId7NlLqGp9yKvY+uxVmz3ouUDA7wy90koNlP9SZUqFo0yMd27t9XO8kgVwIcse2/L1OU2GEOoBfMGIYNDtrMSIH88UcQnmDMcdnZhM476paq1ur3bX1qq56Zh4p7R+IAk8cEMAuDeo7bkhX2i52Dun2QBwuTkFQ/im8Qp6ZbnKVulGyYmHKJlr7dde0YuMvbNv6b9nkyq/Y9oVfsp3lP7GJ5idVRmvWyjO7pnRA6kSV2z56T/n5bKCUyE67qTxseWgxjvwnBZ6M6nHrrH1Eebwmi+BuKxQLDUlaYUOm4dy8TY8+aZNDz9iumc/Ynn2H5CLU47wU0zBgQyghvK2ADTNoQwy+pNz246grhHAQiWV2uKUO6dZfoby4VZJ172/6e5RRvV73+44U0KoUkxUJ4SgSJBuntEHqA0uUmOVo6h0EVuJ1Lp4WwrgYwPcU35RQs20bO+tR/5AOg4LEt5EoTBx4vrlupRHDxc+I2L4oyLRwiZvoDvvoJ5dYh/vvJtgcLv5FimAUnG3OaXMgvhPD45k2RP3f3CY2QJKjit0mp8YlOO2SIjglAUxtJuUer+u1lp8FCNWqbB+PeYgPYW3lfzSPcYvt+2oBv2P604jhAe7jMxupLJfZyTTns5rl9botz6/boScP2fSOSXv4FS+Vm4bt2Ll9Q17zNmUUy4lwI10M8KvvNrnm1f9Mjw9vyBP4o8/ctlQn4I0KizBR5GO4WyGmD3Afnze+IzOVdamkuPjU0NUFm41w0Pnm8KHYluI9uFDeRfcQ/RjveVth8KxvH8oklgv28Jm1tTUrlytS8KmnvBfcUFdoMwyaDPL94vKCQc3LBe1kZHgqeQLEPd7qXnFzKEt8hZbi60S6yC8GBMQrO6oHXZRo1Q9mL9nspsPAAHzT8yPkSfrqeePBJPYe9oCw908UcOP/zwH3RH188coVP8r+rrvu6rcxeBQD01wpI2QK7uFxKISYRbv0knfivr6+7mWMn9PTM+5fhsvDgONleFFxAV7ooMLTCPuM05nFoMmybClYiXHoGpZ0wmzpqXXxznojSYzbFDj3hIPCwz3iV/qdy4dHISEYiS9Zke+B1InnRxQkI4fMvEjp8+WgXFFQUf5iHIgXV8wiKR2kT+QKrh8tgdA9cB++TSy6YiJRSkI2/3kvpB8WTFy463XKih+7K7IkD1vFUVfyu9NFiRyA8jhXZ5Yun0sFQsr9BydsapilnRLOi5RJQ7w+dGphlBilitkLRtaJpeLpSp/iCOMXKRLeObNjILt87p5mYd/W8d0K9A058iFRJl2p1Pucz0enGHaiC+nkGspYzJm8ohPy56Q/03tt3dQafOMV/AkzQ21XBlrqzEKJET8UDcqT8OWS4tN9o90KH6rLb8qSOLCxiwv3svcZT/1C/07I+HU+eADyB0Ux+MGMXyE/bsPNl9r29kttvLFgpVxZxms22n7cphZ+2yaO/7JNrf6VDXfmgjcCSqPXExHKH9pRF4Uvib9XEzp4Udc3D/I3rKi6JpcyL8gcR2nEZ9xSX6WkdBrWzukdCXTsStjpla2Ur0nC3W25zqS1yrp2WfItPxkaPgc8nxWeD62cFaxsReRneE7IL8pX7pXQYEQ+D9B/TwQHqquurqt8K00GXQISr9xNudaUQtiwNfGw1XrbVhsdKYlBoIttC3ZGjSEk6sjFwt93om7QFtjsZVx1hrykRlILB0obyh/LpuOMdkA6fcQnUoDXe1EURC+M8H50n6Z+epNrRIwfYNadFR6cK4qz8D0VfoU4429IB7MgA+Ebcvg1xAHCD/zavn1GNC0hedyG2E1Qjd+jIeecB7i8suoK4Pp6yCN4gfMD2RNfiDBo06GNhvR4O76YbLlIECcGpJh59jouUIoRMZ39q+w45qEixbXbLVhdda0u5W9lbtWef/pZP//24AP7rZVr2vTOabVz+eXp8dc9jX5en/zDR4z7FB0liPkQgOtA/Tv9o21MT7HZ2ODdju/qKWWvibKHCfWj59+oES7Cr3z2MBMHGxDfCRQQy4JfkPHPfu+KQRr05/WP+kw+KR1cybMWSoqcYU893VhXiU+gaBbJ3TnJnjTgNwO41GfqnBNh4SfuA5F/lfWyrUkxKFcqTnW1g7aUJ+o0O0GOjY+6QhGy//x54huvpAaOLh6htIZH+MRE9T9Jh6cVGYM0UT7KhtCGZMeVvBN16ecU725TRDtu1qUAii/5IGKSD6obnOMX8yn4qXeV46qx8k9XlvvLLJcoiQ5dnYfHK+96rIjdRpIDT3+pEFeUXT6GhlDgwuwwRHzbKLBCKI8waIxyzqAHVxRArpHCgDAz5R1X8qvVmhRF+KAXZobLwOXU7gxXG1tUYGcK5wH2Tbathrn4GgCuNGo1eHZjdFdbFW9U7ABum/KsIv9Qeph5EBMSA4nbXcvQXV4OQlMPRBxR0Ho2qhC2SX6cEe8Zk9Abw0kUuh7fEDILOKG4SRHUvXV5RimUmX+dBIWZQpaHIh67Iuizm6MehlNuu4x36UqaxWxyYoo+ZQaTJK94B0YpgZrlfAjm8isK8sQbYaYpgcc5zxa4UDmdjXO7V1dhu7aL8RXrYpZdMcC879ZVayDE8D0fh7jCHMUwfSSXPJUyq/qDQFEqIhyydIKNIgr+DWipWLIxtow/T7ibgUuUO9Lu33epp2Lr8Xan6VcZuXCJOYA5N9iuXJ2X/mQeBEBFzrONPIoj2fjNtxp15SlXBETfnZPdy5QDPNPvclSADMJH/OrEuEahEiEYv8MuaSx5RYETCMxD4MlNzoEkN+SeoQDyHX/M/enaWLtqQznOcpQ98c+rsy3UbKx3xEYW3mnDS++WeU01h/oT4unh0ga7dMqh/XkYyiOEFTKNjVVA3tatVTnsm1H4d3DBgz7IJwYbSC/l0CWfvBOnntN5IijgUtf2pLyetF5TwmvfHw/5HAhu2BI/KojKyn7ZcA0uMExIQKnF3oucFzYBI8oGNzXFd6VSs3UJ3mzGQPkE34GuCqOtS6UlZUX1pqGHuipOmzjhIrkC7iBy+lIQYxhEMXEW1ZnJiXGbkPLkS8GVh26vOFPnqM/MINTrnI9FiAMfNtIAuIrCZzrOaQTz8C5tNc2TPc9F0Y/z+RNCQxlgxHzMlTZm3uP7IAwOIRhuFIwhnwnxOkR+hMGVCJYETk5N2MzMNpvZvs1GxwZCFT4za8+S7dXVNVuRIsiS0Kjkka4Qs0CYeXz0sDG3rgy0S84IZJk7UQvhbQwhnXfBJm9lKXzVhuKq9lKR8lpeqdrqmXU78vwR/+5x/713WkNteceeHS7rD/IlpMs3CCE9mMgS642hbkaIWZ/wUP1Pt1ewYSmXfeUPa1wozkSbb7ZD9JVSWXNGKgKwh5V4Fd8ZANtA3vaS9IcycFMe3OxqgmAY4CNfaCtR6aPcaedsusJ3eFGZuxBFxc/dJ355G4TJuZvwHM1x42aKSKDwzCBirVG3al28Z33N1lRXuZYr697G2a0ztvdYv7dCyLFgf25XZ8Pfg6dLYfcVTWpvxI8BS9IpQy8Pn+FVfJnBcyWWAV3arRS8rvrYjtIQSApgS/wI5c9nAHEfiHc75LHnl2QbFGQnwgjUVzzJu8Q8DhBjTv2QDb2Ik7P6mC96LZ8/99LqiwWyAXnQcYVVcVfY5D9XyHmJ0oIZM4FB0QvlwzUohSiI8E3qeGgrcVVJhsvDoBfK8KIgMuc0IgOL2OBGdTvabzAXEFLYAj8Nb9TnAV4M/FFzz0nhy1fV6fEe5oGcyW4K70rQ8901t0mg3yvaLZpRmCzBQnkbkn2Y0vcEs9zUdykNSh47FwYlELNAbBJjOQlxec4SksIIw+3WROyGqPSYGEOvIQGXJYsS4lFuSWuO72GQmln8uSrzWTHSU7LjOyuAiDlgKAhRjabeF2IZxE5nM2Lnu5UdCHbJw1ZQGloSgsUffdS0JoFlcblhc3NNq5ZR9CmXIKTS+fkrKiu2bZ+YGrex8REbHmE3LylHyhIEQ+LkAtpFMkmEQqqQghCxFElxQqljdq7JhhLcw7TDck0YM991MbJeToj4eR4QdlIffXRPPxTAOCsRmTv+cB8FVmb0cB9nH/xd3cD8OTvQZwDljhnE6A+k3PEUXCyCa7FA9XglNnrRczF33Iaan7RSt4KoKSGMZaB5a9uQtXPDNtyatanF99t05fM21l21XEdxUzx8doMOPVmag8KYp+NVHvLsSl+HHFCYzUVrVZ/TDZsT8b4MU/BOWmYIBYxy9qFwyFYf7OFRP9qFSfFrN0v+Dm36/HmQvItffufeej77DZfE/whcenny59cQj4EPIU4utLkdimvo2CPh/8D12Yjvuf9XCPIv7U2sH6pqah9DNj0TzpHCLNpTDyHqU7lctUpFgpcUnrgJzPniFeMd6310m74HafOI6AYin2IbiM8RPMf4AtoES6HisinsI3gPYSrke8KT+OmK/8DNNr2DW0bo+QaQDWG2TXNWGNoQ76gcdYEXkDfLy2u2ul5RW2SFxEYxIubD1QQtB34G+jPSSZo2hxXNIlUkXDKwwK6ybGSztlKzpTMrNvvCrO2/6w675/4Dtl5dsZld4YDoSBH4Ad9B2WF2/nwpk1MH7xPP6JfXL70/Aq+W0q6Y9d1xzzWWdygLKa3l8oY6FQl7rmmkzWLMUTbk7VUHoYSBhEFdjfGKz1HIj3aR/H1dsfO0J+bpd+M9FNtD+j66SdttIJnDN+lr2i0pos2u1ap1mSezqJ4p4tFJm8e/DeBxs9nFQu95WerqfEjxYaYuB29MFDVXyHjGDv5OOtSuUACZpWwnSz2htpScoBjqXdq07CB/D3Pcyg3+eV/jpDjAj9N5Qlgep43lkEbaHqurUXfoF6gL8CMolhlX5ID4fTJhkm+xTCKi+1BmQZHkPg4kZ7g8bOTYGW4oeMU+T92mIbGkYcDqLwZ4GD1VRxpbN98H9ZhxSygYJnQVUKxI7l2RAL2kWtdE1hYxGsR3fnyDJsUOhc539kTQSMINDpNHOsZgzkxgJOuOy7ggZem0mPtzEr6fFWP8ghjop8Ug/k7M8yNikJ8WfVaM5HEJdE/qnefEN58TUzmiLGDpHv6SF6mwhVZLysx6VAoHSDOdS2NA53bbKeTs2GzNyvUZWy2XrFpFGRKjy/P92Zg6MN6lo1L09S8sSSHOPTFRZitq/n0OnR2rDRkBxV2lyqY1FxdHsXzvNOnYxXN1r6uorc4E5Y/BhsB0YeqBgTMjKifuhv4nCN5hh87IzBm1K1fKzujHxsZtcmLCR7Sxc6UhYe7eQfHT+8x6sZwzCrkIUj6arXiyHAoFkFS10ZS5KhKxOl8I7j9LZrhXOyhwBlKvJYXvGRvKP2ldr6MsymQGWPmcV0dVyFtNgnCv/YLlnv85Kxz7PVU7KX9EiDQov7miyPnSnZAZXqtCtGp6lhrZbVhRYee6fCfDd0sbywahj3xwhX2THXkVy5IjIcgzBgPaTeLqpv7/Qtjo60Zg5+EntEERlPdbv4upcispAAR1j5viGsvnfGBUHPdXA1FYiIj5RfzCzpl5n+GiTm0Ok2fqKmlGAVxZXtkggJ8L0Y5wcQtFeB7KPl43+xOfoxvejULSZrdpEFfaD+mII+tpDPxT3qbqRTpuZ0N+eB7lfFaRcwFnZqalMEtgVlgKUU5CudZqdT8OAqrrnrAi4D1XGyOjLHUNW+1vld4NwCqxZnZyTcofSitm66tVKy9XbXF2yY4dOWL33HfQ7nngHqvUy57WLeuhjPCHdMGfgtnZdWcDzvIGXsC32SM2Jhq4D3yNcnEzeV8urzufhRdjFkJMwr1IMHh4LRAUK1YbwRsGfAJFkzQ4KWxmZkI/Mqj30S33uOM+vhPvSaeveEjcBvuwTD4+RztvJwortpe0PyG3yGP60fDtMeR2qfhsBvbK9OTp0gDvZjZuQ754H6p4yTzM2nE/UOR85k+EAtdpiHQNCmC4h3AbZvkSP/S+h0NcPYxoJr9Jn8xiGjfcp2hrJDVN9qH/uTJQhyMoI54h8oV2THsmLOxiGcaNe2LZUK+CghgGm6Pyd+40ZLgQMsXvRcbmRhfuB8+xskc3ct1/ZzPRKVQknPh3bn4cAd+4qcGeNYVAMeMv5/CxDA3hVG58mafMUfp4R9RjFsJnxqICdpXQ5VCBlkRshc9IpAvArsbon5hsnlk71pQjCKN4JkopyqHsu/m60lxWdGtKyah18jNSlLZbV9QrTuv9O604dK/cSgn0ZXpNK5QaYi4SsAtS3HLszHhGYc8qzJOKz3Fdl33JW17Ct29l760BwYYbKCelpm3ra8oP3W8GZUU5AK6x7AAbnETi3ejufCiog3h2tmKza0Wr1kpWrhYUftcPx66JIbIhBp1Iq1UQY8xZta7OTMVUlZu6Ogxm43ptlaEIdzDS9VrPTs0r31BeLgpd35CjorBYgtdodX25HgIPih1bXjdlxnd7bJuOskVesYSEekVRxtlbnvkuh23UEbrYKrutcvW4qGzZWUwPui8q1KDs0Bm44sPyX9nx6c2IaLQUZgwRylmWGYVzXpfeQy2yapt8RoEIYZ8THj/iE3Zx5VtQvnrr5VRX8hXFUJ2t6iPtqK0EtRSfVm9YaVdgnTF1tj0b6py24fayj7BaV+2oWbNiW3VOAkpexHd+YQmO6ojyxvNH6c+hkau+dfMTuspc9RPlkhnBfLfg5dZV/ipwPSs82oHix/efXRKa1EvAkjGeevXdEhh050uVce/WW0KxUZr5cpSHkEvkfUd+kw/McJFOJdE7V7aAIed9np3y0h+zlMyesCNnW+95vuApaXUfKaeCFXUb6gPlFMPaumQo281tRK/IfYizj3lcJJodlRl5Rf4LHr4TT+Sd8k1ligA+OjykJG32XPVHr7PjI2dhITSurq67gsP5d9T7+J3rwN+AaAaoz2fx88R+M++AyG8X/FPAHcJQpOgfCG7xg2XhbIgQlKE+KQ8g6o8v0U69q5pH8TvxfiS9pneoa+GZDZ6G1fampSizGczUtvGw+67aB0dxUGe64hPlcstWVyoSrJvWrKss9XoILfy/EqhGex3jcPapyRGbnBg2JiLT5UZ6N4IaFeom7asj3tBSmjipFZcVlWO10rDTx1bs0PNH7N4H99vd99xh9V7FxqdGlbfwoVAegQJf4h4FMHzLLJ+o4CmwSuGcIL/wQ+9tGy/azNSIlZJl65QDPTP8HKZGnMNqA/VBCPTidbRJb2oiDz0p583wGMi80ZLf4emqgnrYqKyqjCUf6D6XkCKpuhCUGmbXGkpUw+sd/VEw9x0qo5uE4jduPljWU9tSu/UN2VReYVBQ7kSD5YLcozwEdyx9RAFihoyZMF8KqnCIjzIiRWR1zJMBvwntaIA239RF3uH/Lx70PK1GRfGRHAX7J18UX5QvL0Di2q4mpP5H1G3VpNzpGeUGJU99ea+mfomjcVCSpGR35KYnsnZd/qkPUZ/TgzqQ8gVF3POEukJfTfqDrKWa4+HTb8mBKORNf2VKisKO6PAiFHOFd4VoS244c2Y+9AdF9akKHzMUuTCwEe4h7iOfAwM3oawpptgeUQ43l1uGiwetIMN1QGQ6gXn7bR8b7VKWyW00o2GwqxWQaCRC8ONhU4NwJU7k141I+x/a0bVqTApbQYmNOw2g8HyGkaq4tZDgAr6/ixuJoXkURJbmoSQyU8MyN9bv77V84T6xOb7vk78p7y7MI3CPI8KIJGGjVrf1MjN+IZ82lMcmwIjS9vF+8/VcYAa0Lon8Y0+17fRizpZWcrYu5a/aLKmsmdGUItiRciBhLs9GNvQlKGU+aqj3eVbZw9/byjMUwcVG0c644nr+sCMQl9oSnFcq6nxyEjr1mit+6ihQPBFCuG9L2PNloCibCpe0x9E4F1LEu1Ei4u5vmMP0I7PGLJ0fGEezONKIEkhnEWcGiRt/uKFzYObGN3yQG9JNe7g4hIrR7jBL0XIFVP2cSHHv7bBWfkhVQfmgPG6rTLi2EpJqx4EaqmO6NmZtvLlquVbFhQ3/cE1X7n15p0gBOIUP89WRohDaDitOPKAAla4eI6Jy56/KXSpPAI/RPOTcABJnbWi4ap3yAd99MaSL9zf6sRnYctAxHoaz+/Bb+Z5XOHrmrL8h2Y0qf0clyHJQOzNA6H3+fhLHeKVMKaP4jYaXk4A9ChbfYuL0/LHaGkl1OSvt50YQlKn/5x/sQLjpKs5S/kZD/ern/abAqIPsOscyMeoYM4DsMIcSyFl4/lqK56brOHWeusp9mjCP99FtIH/sY7PbNEVzwiP+xC/ukoc5aYz2APdOKC2p97cikFz6iGcMsisoy0GZNWV5OUon4XfEN6qVts0trbvScrXgSpHiul6pq2gKNj4yKgVw1IZKmwpK6Mc/FXnu4El1lA75AG9CcS+vV6wtAXvh6IIdfe6k7b/nbtt31x4ltGMT21D+zvYfBO8DD4p5eMlQ8xtSW5mWIj06TP8XyyjMXvUh4xgWFIVliLDT6Nc7EYM5fHftgzJXGShYlbWylJYQp0j9+iVyBY0+Q24ZNDzb/ux34z1p2+p+s1n/iuIT7RJz/DtX+V0ItPHLKlOBgcdGU/KCK1coeUEpheJMX1zWiRLsxAyfwmw3GwnVk+fBjB/P/ZnBhHzZJ4o1fhKGrh4Oz2kzN0+3+VBvBs9bpDWnuial9EpBGTz77LPOMykX+ARhksfM6sXlnpsp2vENIETZ4ldUIJeXl7eOd4aLwtXjzhkuGlTYDXXWnwcdLtjqXi4G97qybGF+ft4Zfc83iaDDGLzXR7J80z84TkMNKc0c3e9UuFcXqmq+aQtLO5Ow+mCEh7HYrRmNb0Gsv7DkjgPnWSYD84KYaRLz0hUBoZffJrN9InaSSneMmzuBzemkKTCiG66MkkOVSlUCggQZBMnknY1x3/o5mp1tl9xsAdLQkfLx5x9ckfA0aivlolXqJau1pHS08mLEzLZJEZGwicCJrsHoPMJQjD9Cb63RcmpIKXtutmxrrUHcLwTPJeXBmaWK/KcjlYInRo3SxyYPQQFE8aOjRiAJ8QAwdu+MEzu9rvQGZZh6Rh7C1N0NHZT8dSJT9EenABidxJ7naBaj7517Eg7LCksSRtk8pKk4eCcWnF0AuMopPVV1kC3dKdW8q7zsdg7KrwOqOVHx45Q5KXn5kjVQ/HguDVtniB1Aj1nh0FttZu5DNtY4IT+q6mDVBuVXmFFXuiEUQJWLdZQW8rQ7avnRlyiEbepfmZcIgnrshL3OQI7Enw3tFGK0tmsj4wtKAwK3BDFvR+k6vwXkj4rEh4gKRZQ6dm9jg528jajcmdUbVntjwlUlYx0JAFzD8l38DmUW4hjiQWfMMR/DI8M2PDTs9qxGiO6Iu7sXLrYeAlw66d2LfQ9XzEj77LhyNoa/FcgvaESKH4rr4PufgM1xpy4idER3DHpU2MRmreqbFVE3Pa4piiAvYp2PdtxHAsF8YAal/QCYRX82+weII2lh+Scm0S6my59VH+O7aYpuoYDBcyDVmmQTCTaX4vs/loOi/E1OcR1W+GZlNlOBfwpb5/ylgfpKfJdXKnoST9D/0ZGSbZsa87TG+A7iTcwHz1xoz+zyCV/EQ2ak4KNrlYo1qx1bPLZop44dtwP33Gm79u20VrfuZ4adq+5EEC8oHfbFgBl+eENeeTk+NpQo6yGu+LXZz1gPI6XL7GzIrXKpUm1cVQU8AoVkbWXFlYmY/kjEKf2MItaUAB8V1rQdFN1vZZc2Tyt30XxAG9/nXrkYInsZQNHYOl8vApJLUPxaDQYVUfrCLGTPFTQUNaWZK0obSh/xjgpgqyGqJ1eR6iobezlhr+cOqw0SZRC/okJJ/0I40SwqfITlYSd5EyjwG+rUBr7g5I+yVLm1aG9Xjrm5OZudnfVZOnYepswBcUEeiEtw00oe9QUz3HOFr4U2EHYvZuAtw+Xj6nOFDBeJwLzD3aDh+XO/EYoQGoXI5NNUa1TtxIlTakENFwIpzDDevrGz6vhyMkYVk5FF/OpKyerV9SgmmYt+qlNk6uOymWaIQaBNVUsKTc9nHMckNEyqEUsoI1zc+eHpiKJoCrxHPFBkBbkhPQXjez4JM70JvRFnCAPhB36FcLdZYehhyxdeIeFjhxU6hbBkTv47o0u9B1gJxbd10R8PX+58mY3ivLRUFsNiBynFFeUvlf8UTShCBEyYEvf4tTH/QXznfEAQYKfHQ6eb9pHnirbWHLWKsqHWHLa6FL66L1eSwAKfl1e+bbMEsHxJ+VPKO3FQFyOtKGyrjVF79uh8EMLOH3QKIZ7HF8SA21IyVa989LaNYKtOR0yZuogyyC6MLJ8KS/4UJxHKYU0CYk11sqn61VWd4h2WBTFzVW8yi9kRta0shu5Fw0yTRDNfNuWkP6ULJs/SsVqt6XmNm1i7hpmFEYWFiDn5pQ4/SaTntd+dC5SP4tNaV5xWXYDJs+SzM6x826vad5/ep67JlepBs8DJfsp75SMbvLRlV1fFaVYrNrz4MSudeKtNHP4NG6sdUXxUl30zoaoVpXDnWbapTjonBdM1ZBKssFuFPZYfeZkSMyVlX8Ir33K2RyzX3KG0Todln8zuostRv/Qe8fGP92M681JaijUJ3Kel+J0MTdftCGNr+LtKR0MX2oW8kKyi8lFHz1sQc6sFnCnTvY7LjGhQ57ze0RbkUDqrC9SUa6vBsiUEFKVfL3n79rbMbCrtU4Kt7i8JBCJyMS4RUC6MsENok7xXGwBp3jm4xwZuGWoU3rNjJssYEcJBdB9ygBe4Ko/kGEEEhZccQ9Csikc0pfD4BkiNtp8dx/e2jboEU9WBrjKLZZeUZ1gmSnkOiGDCsrZBXNNEPuIm7X5wH/zzeuJudaf4+UymCpI2qP9ujn0Mw9ul+x/jgf1GNwzK8KaT4h/cEUaIFzNUAIUPJWxyakphsjzfja8aEFzPLNJeFROlt6BgR/JFm5kYsR1SAMc56FS1NAxOhHoT0hZiT+74ctF6z1ZqVdV/BrREagira2VX3OeOLduZE0t2zwP32547tttKY8nGpsc87V7/RPhTSClTLowq332AzOtbUucZOfF7wFsboah4jeJfUX5MclQOj0lZQiQ1wvPcs11+RjoHVHL6n7czaxKyt1jlc6Voq8xXl+etKvmD4wbCUkRd1fahuPSzoz6AJZlNua8gyKudeJ6rA6PutfXsM1coR5H0LEPnJRBLGNk8zJcq41bkyo4yx99FEUJJakvJFfWkcOVaCj+Vd5sR6sVG6qgMYM3sqomiitmlI5RRry1esD6vjArKV5iFU3oUZ1+WmihirqRJ8WHXTohjHDpO6hdRHLlypIPfK30piu91eZc8iX4nJM8H98gJPLPjtJ7pJxRynzZC+aGMaHc4ezWRwa4A5CPK3Uc/+nFbUztj5m9w+H7gHZQldQF3KH7Yh/MZy+4OfjxQ/Hp28uRJf+fyyigDODf3yHBNsbHObl2Bqdjnq9o0lpOnTnnjSGNzN+Pf//Hdm63IzzV1DOvqeKT4nefg6MsD3JaOBgqNuo+8wpdw2ctJ2YQReSypfuruWKbZG5XwzXdPPCfkIAdo8CVdxiVUjLowuhEK198J3wd2e9t1vceKQ1L+1AF7p+2znoSXzp3Ygca4ROIZga5jTz/9zJZMxp8To2gPndPtRYCQSctas2fvfWzRDs2NWKvGCGLTGKhuSmmSDuGEEMbsIMJMECr5kFqdCZ2B4tDIjdlHDp22suxJTjrVF4aEo0rNFiUksYQSxRHhBvEpEgqmzwKKqopcnVFIJdPzO8lHRcMVQZZZUWaF4pCnBQYfZlBJA6HlXViMyzgCo1c4qXylrnOls2Cmb2Q4HIhMzqKALJUvdXQSv1hOsqDqKAGmWVH1rFFFRQdVg1XPUF5Un/hurpsvWUfUVPqqShczjD0phNTkQvOklZY+bEOHftWmFz9tUxIs81LaO1ZVBgQhiAP32eUzL80przzhGIbSxJfZ0PbvsdzUP7be6JssP/Edlhv9TusUvtTqvT0hmp5CQWmMAw8RPLMjb7UxpzrBCOjA7vxQ/ZDTqsrWBR4vY5nKb18GqB/p6pPs8DmSku5KP8Ip4H9QIhQd1Qtm//bvv8stgp+8FRDeuHggjCGcXGwbAg3Vx6oUMNISseX7MsKYc8D8kbiqzjGjx7JVlk1GgQMWshm4x55loOF8PZYbs2stdVxCsPyi3nJPnYdPMwMSwzn7Gu63ouhuK9CWyH8o7Y74MPPnm9gkz1AaxI/3MOe1+G70z79nE50r7IhQNxW2fssVtVWFyP3VgdIvWimrrkuhjoBPDElZHx8dte3T22z3zhmbGBuhtcoWd9TedByIk9qu2l+5WpMSEngTSVtbrVhLCvvpI6ft5NFTdv8jL7M7D9yhtlW28W2jkTmfF+Q9y+6p7zHUkOfJw7kg93yzyOd+cJxglJRpoiRdCoJgn7eFFZYcJoZXE+q/lxfnrV5e9/qDghDrC8rY5tk98gVCgfM2kLLz+pV+loLUt9c13vMebQiK/pPX7l7PreTKc9h9VdEUwTsuhpKEeVttKYwrxdrKacVfPECK1oaZPsqTq8IJs3xJvP1ZpGtb/MuXdkrB86sUW+x9sxcRyqRvaJM8ux/EWXV5EJZSpXwLCmaIA/kYy+LcUKb5rCWfECHHXR2wMu2xxx6zlZUVV+rShIKHwsdMHldm8zBjpo92EHhTuC4tLWWzfVcBF8HOMlwb0OGcTTRKru5ik90G0o/xx1kpfmtr6YZAw93Y0+TEqHtdGjKbnDB71RJFZhfgAoG/ttH8UsBsmh+m7scxhFHzPjiLrzcpYqkmgoEYFUcrROVTSkzOpKDmFVdm/1hW5IyH9JLSIQn80+rH9H5qxDUgpBlltmPs0HlaJAW3OyLBdqfMUSzxI+aLYioBvj/7l4yg+iit36N0FsRYu/bss8/5G+R5umwi0s/xPrqNxPOA3MmWoET1T9Sx48tNe9cn5u3ZpWmrNUat3siLGLHmg/mcIf+oL1AnFUZQXcFiJFHxX1Nef+L5RZtdS0YuXSCLaT8/6BKoW031nM/NlY0JK+bZmP0MSh33KGzKTSk+nBvBtyR8xA+5oogiKjdh5FCCuOwlh3scQWTkCGAYQWEWJCG5iYpgNOOdOMuCYA5cUOiGQ8LLl9RHEQJCoBQEZso6Sme9bM3qkrWqy1avbFPHd6/qDRu88N0fX9MpnaI6yp8UWJZ/NpTOtvKl3Z2wguIysfqklL+ft/zxX7dRvv1rq04xQ6cE5pSRXPPMLupa6FRUN8bk937F5QErlF4nvx6Wn/cpXX/P8kNvUph3yy7Udd8cwBHKMc7ytKrTtnCG5TFsyBTdnAd6B3e0unU5D61PYaisOuIJrugpZzzNCYXyzvdn/NryA2WdsqY8JiaUfl2JGYf1onCdmp11fxDAgpJInkMXD/yjWJuX+B5niK03JBwpz6KwA2I9inUK8yi0Ov9L0JaQBGFGelAwPH2pd7nHjDoJAa4oWdRP7vHf66j8IpwQXhBeMYdiPKK/8TlSdAdFM9xEBLPNzxvdEM8RKaYxnum0AtwSx/guFBHjFOO6mTaEpQu3p1fojwK3HcTiCsBMoy7L6zX/zg94mKKiqKD6Bg2pXm+fHLWd05NSxMOxNiGewX0/nnm+Cc5budZQ/FXf1R65rq2h/HVd+Tv2wgl7yUP32l0H9/qyT1fsWY0ANmZfH+QrG0KheDArBtfdjBiPdHxo2yw6meSQ8VBEfXvyN5ZN2rfNfqQhU6uJJ67WaD3niOwVoWuV1VVrSGiPSltsM+n7NMU6zFEFUYHbym3azDcU45q00YHClyiQPKP84bfM3U/lEzyH3IL/9HS/mQYrSwYU87Iu5QMl8kqxsHBU3XiYtewrY+qwg8IHyQxyc+5l1lD6pfS5G9LCTKZ/71d3hTAuCY1Koi//ZLAXP3RtN5p+H5Z46soKE5E/ky/UIaVxq/YfyTMo17FqbUm5d+X5EEHYTz31lD399NPKmwX/Rg8lDkVwVXWJK2bh2+lwth+IcSVuuDkleTfaZbh8JGwmw4sFKnBogINntbDBfXKN9zjcYM6VX2J+en7OFleWZUpnTYNIRgfVXtydnnNSiCTWiVBo8AFLFT3UB2ZsxBFnbIDcujCZxGULhG8Vhp2YuTNmF/37Og5TZxleIEm98qUuWtW9hGJ2DmWpqdUUDYl2LEf1Jam44YrSIuaGPWZS9oLiERjBRhAHrmJwnVXRk7p9XPzred99jp1C4WdxiRrugz8SzPnhryuTImZ5uBexU+bJk6c9nyPT9GU46lnC0jsFyp8L4YG2QjQ/h3UfcVxX4oO/88Jc3f7046ftM4e7tlwxq/p3flI8xI9RmuJW2c7fFa9uYchO14tS+hbsyAKKhUdOPkKXAtUa5dXhMytWbQblqwXJv6b8C/dS9OiECFv5Rp0hHwky1m+Uv6Y6pJq0VK7EOeSvaiPuFGe+syGfWWrFCK6/J2fyQv7xTVVYhhfP9GM5HkQcGd1t6v251YricfFpDP4RX87CXFJ9WbcC4SW7rHWUz+3mS2V+h+IhR8RH7/Wk5DLz1yZdSqhS6T9qa9vrUsMmG2dsdPFzNtRYtJyUj5wE/bw63kBSJlhqI2LmL9eWcttRGqXImyuJct+pS/iTkNkdUX1H5ZGdKNZ7yqLbUTx039Z1dXGnLaue+HI+Mu8CwAXEGYhrqjgN/FVZo6wMD4/4wdGUoZ+RmCbSSx2j/iutcZawNEzbkj2+0ggRepW2hk+JUsbkE/kXrjK6KJBawiEHmJW8FFAVFteaLhDGGUd2oY1X0sKSM7a755k6iWBJvQWex16Hleuyy4uHhGtchRBAHUorf7jHH4QV8pOljyiNPEeBNs7gxJmLGC7v6k+ArxCHEI+IMBsYCPdpwiwi+BPiQXgANyAdH+cxMvciS0omuCOv4YUhHp7zuuGKPf7ifxh4SMWP9/kuSErafFm8O1kCejVA2MR4tVyz+VUpa94nET8X7d0N8FYiM5Wm7dk+YxOqz95jyHnII9ySluCjisLKdQnXekRh8A1kmAlsdqT8zUr5O2kH7zlg++7cpTbQsrFJzowNvrgXYBB8gPLWQ0nKgO+k0+7TguwAeNq1knjctglmZ4Md9Z/YQtRV2mFMRT94mW30C7ucz7o2xWSjX1cThN2oV21u9pgrJa12UpdFPgvl9ZxroLZ4YKRWp2kNua/rvtps+H1U6CBX9hK/4kxW9Bd3kVB+mJlr4idX9R+8n64PDh4vguBhLFteL0uZVbldKZpV+dNkMy+1NKWRXT5DfiRKnuKNYheUQdmrD/Tlm32SG6UJ6rqd0uYKoviF3vclnrr25DfLSAmDZapB0ZS5+hjnLfA7rlR20uV1ZSN5nU6I+tXuNqxcnU/srx6IxzPPPGtPPvmUzUrdOmUAAJYWSURBVM8vSJFblbK34tfV1TVf4sksX8h/Bnrp++HNXZudPW2HDx/11RQZrhxRws/womPAsL35JQw8dOTh3km/DWY8x3u10mU1mmMnT3kDV6uXeZpQnvjeiGWeatUSzJPQRFuA2TpRXsItM15OcIPzgs0xUCpxlyhPzkW4R0APlMdfBA51oOJ0QTCAerp3ZQ8Fj+8OJQD7Dp1SHp1Y4kn3Lfh3SOrMNsUJgaPjHytJcOXbKfzoSBnunlBeSXFz/0MnKkd+zzXGl5k/V+gwI488nwr2zLOHbG2dHT0HCApfoNALUw5BiKJM3I2u6TLjHrowQtm4t1xVwKdX6vbez5+xd316zR4/JSWnztEOQ1I+hqWEDEvXnrB6cZudbk3YB55dsg8+edqOrVTFvINQNCjpc5T5OUC8K+pw+NYPYQ5Fz7/rkzARN3dh2SYCNEoc3pN8V0T1EARsOhGZYa78YnOFlph6UCJkKDtXmuXAv0tU54SxE3a6YedODpVGXgoykyxFfG+IAd/ardd5j87i4oAA/MpXvsJ2796lcqnayuoLEg6bLiBSjfLtovXqd1mr+qXy9y7Lu7BMjVANUcddUJx90xbCVH0u8qw6yNLQemHS2uP3+3EJpVZVip3cO6nudgeKH5kTFD3u1SbUWSOJEodCXp1353nVxjOeEV51yC6F6cuY9Ot0C9ZYv8fOHJ2waoUl3DiKII/OBTI3XGryr6wrLRCBqynFm1lZ8h/f0hTWoaHsUXZ6nfTrPb4FdAdqc0qRDz1VGhJy8AO3lG90IrpY4JYuvqUbL/ZLAGHNLVd9Rpa6FqjraQtpRNkiXgj/HIXC0mPqnwQrz2zqcZhhQEELZuJdKl9A2qM99xD+4W7wHNo8CiH1zZdbqhKRJ4TD+1zxPz7TdnywJklx9AsKORIorfxtDm/gPiCmyZcFCyh+/i2j2hTLJPEybItPG0qnA9dRRRJS/gb7EFYEd3Jhy7WO1Z0hwAWuDqhngM1Kjp1Z9wEojkZRikO4iiAUA1SW25oESZbtDUn5C99/h3zrO3Jf81KOFF8Ecr0fyqbj5552VfHmjs7bqWOzdvDug7Z3/x5br63a+DYpf/5NcvQluapsg0I9MAMMPrDE0b9NTBDzbUP+KQHwmCE//iYszXVzj2cg55vplqQXuEv7DWiHs4tl49D5vturCI+P4n700LPW5js/KR0cgcBsdl/Bc8UGBSdQUHYSBY56rzxHaaur/jN7B7lSJ/O0cufvyI1f9d7ALih83PvmMbonTptTG8vjQkSqGEhcX1v1+ytFt123lYWjVsoNqYDEL8gP6pnii6Lnn2RgRtpc+YuktrjhOZAyK1H89IyS5/kbCaUy3MdlnX1S/xJJDTdJ60aQ2j4x29dYUb2tXI1sOAu0yZOSVz/3ucf9WlVb8+XR4j+RfwUwKNyxxcUlVxRPnDjpvDLD1UHhJ4Tk/rbAqhr2L/z8LyRP1w9hBiNZLkSHoec4cgxh59eUebjnXe6DGUpKSdcv/qJXqkMXS/alk2rkKFSc06dnRDI64rCwa1NrTnECOh7CVQiKEwobHVkQdrbiAt5I45JM71x5J7oH3CeEIohCpviiBIYloeSBBOEkfgjS2PssIQwTxY/ZQ5Q/mYp96l3iliiCEdjLwP3zfvGU7ljW6lK87vETPxSHvv88K76+6QSj9grHvyMsKTb4V7Lf+70/tmPHTvWVOhiTz3RwhWDo6tgBz0FwC0TWYBfug9AUyJ1fBMg30smMUtdWGm07Nl+3505U7JnZNTu62rFnz9Ts88eW7PHDC/b0yWVbrCB0kRUEctEBnRvyoq7OZvu2SRtmDMDT7v2H8kH2qiu1ujob5ehQUXFV4jwfdFVW6D4RWFSlEAOZ2UOwdAFJxFEPgHzi3Th7EjBwB4HYDnCH+6YCWaiypAnV5eKBIP5VX/VVvqxkcX5O8Srb1MxexXSbt6tQ30akXO9U9Shbd+ikzBQjhZdX+oqQOtKSBEm+J8qr/qtGWacwbrbz26yy/R/o3e2qz8o0H+BQ7Eg37pUvfOunROuepZ8SP7mXUEDdLRZG5N+I/F+Q/WEr5moiwlF4amPDygvlgjVWXmazz91vZ46t2ur6UcU31MNLAeVGXRlVfhZUVr6JD1F180Ak3L91FIVZMzIilA3fwA0zoy67htJQVV0pM3tLR663lZxkNjSU38UAl5QldaamdMOxLuF1h/MsxfHBu3bYSCFsIQ4QLtJ1CsKOOst9cMOyO6WdOqw0xfYd3UU/ImK9xSjtbwT3uOF96l1Jihc5g78xXgju8Q3cQvG9zQj2wS7ax/vYjtJmkVzRlVWw533SQXsqKnxyGTPsQx5AEX0//N3Uc+ImPOuqxyOLbXvuNAMRbnVVoBzln4czpDx7xYN32JiuLQYCFWaMrw9+CrhTofh3xygWgRcFPky+xpnbWFYoZ5zXWGCGQa/CA1AyRoaHrLImxUYlds/9B/V+1z+tmN4+LSEbtZGY6Sf30a+zKOnnFavQz4tCfoX8G1xDvCnDouLOzBAKUpjxiP1IcMd5a+n3I0I4LHXO2eeOLNlcmRU1Ieyri+Bno9aw3XvusNEJNsDxSDn/IE4eL+occRTxrZmbqzDSZr5MUekkv12hw0zkA4gyg7CDyIe+O5Ur9z5wgsIju5j+y0WZ5YdzzHRdOSgr4r591z2qW+O6J82Ug+eUF0k4VsUdb8wrlCDyJcmrcCi7+k74s/yE2CAmbBoT8oh8ZTaQyu4byni+qu6rX2HzF+dbhLslBjZ8grO0+oLydUVPoT1dbVAPKEOWdp4+fdqXenJsFt/4sYs65uwCevjwYf82kEGBdD2/WfGDP/SDtm2KXeevP6KUleFFRuiIA/OmQ3WmGJ9hAP37aB4YQ7QPboL9U0895yMnDtd82IOwIQGm5RQaMALMhRoP9mICCKxOCMAoaFtXE+/YJCSHbx9ws5m18BzNsBfhr8RYH6L1XlbUk9gMueKoeHoalF7/z0ydrnlGeySEd6GNG3nku3XpeCfF4B5XXopyC/JD6fYNXSSMswQ1xg8FtB9XnolLNAtEeuv1lj322OfEbM8uk1hWoSPebBYomgEuwdwfLxIIgzBrxamrPFaW+PdsEtLWml07uVi2U8tVW6pK4JbezZKivJTwgoiDs0P6rgx4s1xr+5LPhhRP73zVofiH5SKUPpYToRDQYfc7ZzcLM4MogfhTFWNnlJcZBxCF3lCHwgAIyzrTiPmeBr7RiRVL1LuirUi4CbtHXnx66Uje8Y532JNPPqlAUCIrtrjwjO6rPgPHcktmAAvddSllOSupjfGRIjN3QyqDIZUBZkWVvyt+XKm/hT22PvoKtbwZG+msKu0IphI2EwrLO1W/1UHn1fGp91OhSuGT4JLTPW6KBXb4xN0+tYkRxTZUGvKIvGhzpEdlp80//8VWW9pty6uK92UofYAltxVl7xrlRT6QhyoXQvTZOsqOcHVtKe1elnISlOOcz4YvlytWU7wX6bAlCFaVNnnn7zAk5FznEqpidMpSY5+vuIR3+9A762q/6/XQBqmTUXiGogDJFfu0IpBWBKmTgOc4I3EuxDYPDdp9MAOEFUesmf1DaY7+y6H7DcV3iB/3myndb2w035jWtHmkaM59BAOQIyOjngfE2u2Td4lD9Ldv5+/GQglKDHEKgzxmJ+aW/f1rhWOzS1apeWwUdjBLg/gAeOC20TGbGh61ISlPYKuqFHzK2Xq56ooiAxvhe2Pxvor6mlbO5o+fsWMSQu974G677yX32Or6io2r/KgjaWwRHUd0Rt7FPD2nY4F+ZXxs1I+qCbk6ALwPXrsZQVmifFX3ay1bKquuKlwl5+pDbdO9VTqefPyz1qzXVXeDIubkdZkZqNSMn/hcmKVCaZMZhJ2uzLTF+t+QXyz3g/ADM77j40r7oR0yw9dsBsKcdMf+5LIhP+bPzHl+X50sy1mtumhLi0e9vywVh126cEWNOEOeD3pO8oN8C5T0tckzV2YJw+yg8jmVd/6toPzvfy/Ie8m7UUnk2Y8XuiB6agPrymM+Hbq8PuVSEHkM3+4dP37cnn/+kNOxY8dtcXHRyza25wxXF1fYWjJcDkJlDp2r3/NHxxmJZ5EvLRLnDiO8wWzwPu9IaFEnsbi0Yp/87OclLI35++GYBsbamQkR+Q6eNOTNLA23hJFQtEcZ6wMzBBTsidRAaADMBPT8GzqZo2yl7QkzEu/KH4kZujKzhjs6QGYM8DcQh5i7n95bwoTDaDizJ3nioffC2UQxHMKXsMbsphTDXKciJyW5GZMVB70zwjItez1LAaSD6OURSPPKL0iie2HYfSPcruLTk7uPffhRq1eVnkS5S1MUhqKAFAlsdeU2jtJfCvSmfuSdmHjyhGdhuR/h60r8/CmwagiB291eBeD/kYV1m620rSHhv9VhNFy1SsS91zeRdDwX+GUse5aBtvy4hkpdyqo0U7a6Z6bKyyup0xEog0HpI85JvRAQrNLClT+r7FhWKe/s6ELNaoxweqovPr1RAENgUBerNHassnrCOtUTUsjqVlQiCup0fCf0thTMRs+GJGQMS0ApSbHOdxq6yp3yptQbVa0ccYWb+t2VYlZqV6zVVZokuOSVZ5FYJppTB60eTWFIeVXci3p2M7XlIWa5JQgU2AhGYXiSfDmpyrmldPvh/VJ2Fx6yWmWHzc8+Lq/YtCm2hUuDHx+i66LiUlHb60oJYP6SsoylEL+dHOUAcykqUxMTVhoZtrrMm2ovbSnfS2vrQVjuojRRjij3BauLKPUN7OQCiDWXXUepx9T3S203zKy2VVeem11XtuaUBoRllJ+k7SpWqJXhmfqEUk041DGlQRwnfk9VKJVcQYPSwiXvRHMX5BOE9r4xvml7F2RVDwAzgBDADfUR4ZYr8SFPI4X2Eng0/qfbRfQ/bY6Zki1DlYcPttHu8CsoCJgpm+ROz2q/eaXTVP5t1TdmIPER8mXdigv5F5IV/Se89LVjayq0hXWENXdy1UCJeb7qfrFSs8cPzftsX6ET8iJSOk8oY1aTjA7z3VzRRpW8Akff+CDlADwxuMa37dVa29aqDFCRB6q57YLV6nzzK+XvyIIdfuaIHbz3gN17/36rNldtZAJPFbY88eKJFKH4pONE/pIW6iPLNgd9b/olPSpPmR0cVztjYImW0FHcvSeUW+pmMynz6H+bshN/aMj81ErXVqvwD+WJ59pVBlH3S9eW50/ZmRMnfVOSdpO8ErU5iw7FDcUsUFDuUOTYlCUh8VSOYQgKXOJO7YOZzobcVlEApeSh7LX5FrMRjjZoi1ruP9+Dsag+lP+lI6QCWmeX0mq5b3KlYPiYIxHmZ5+WErviyl8xF5Q/vsvjKAYG+/wbPd2HjVyUTqU1pjMc7QDJXvnHUk7yrScz/y4QP5RXfD9Ov0E/Eo6GwF/1X021AYiO2dvpoK2kwQxyng2UujWrlFFU169OJlwk0nE6VxwzXF0MerIMLyrOVdnTROd9IbP4/Nd/+UHv0NkUJa18YXdZQFrLI3rVxTPOPdKdBh2Bf2uVhO/HDUjJ65oUsJwUsNyECGWM5U50WBs7vAAJQszQ+WzjpurpAkz4XjAgpK0rgTlf4lusl1uu9Grdv1yvPmK5wiMye5XlMC++RGZ3KS6Kg7pT38FTVw9DnW9O4bFzKERH/9d//b5+Hl8MBcHxbALp+5sNirnVml178uiqrdfzVpdwVG10RYMZFFIWBEQJIAiqurLxC0s7UQDbdE4SmguFcB4Pih51NY7WgrR8tBnpfGSXzJbK6OhyzZbZKvSKEQLu9lZtbvFxdbIr3nH6BiyqB1YfE5XUFKTGSMgoquMtdZuqhWyLMma5sderun6JnDxk3cLL5GbIFbd8S4Kp8qCg9OdFuYaUQHXWeXXMRfnPjB/POVFB+YMQW+wofxRusTOrPP2CEswhyapbdNwKjQGOXnfUaot7bG35WVuuPEHM3e5yQfmyIOxkl7MX2TxI5ah8JshI+D8yNGJjI+O6y1tZwrEvedY9yzpRHHxzIblkMCTS5dR5FLa6eA8bCG0WiC8NPTsxv2q1bkmCjOqo2iezUihRKEQQdY+6STyjAocZdRGBGvNYP7EPAxSB0oog7jy6fiWcwJOjHYhmEGHiL/f4xQwgV7eTOcpfbBuxjUGEGf2AMIv+QGCj/SAuXEF8ju+B8D8MwKCI+uBY8k4MI74XzeO7MZ+gpfWeVRjEuIZAX/rEo8+q9TGwlxgmiPFwcoNgxhLOidFRKYFqx15LQ7wDBnWMt5qdlq3XaqrjErLllIGLqtquiszmT87b4WeP2J477rT99x4UP6xYaYxv4gfLMc+FtAKIu3QdiEjf48YHBobpkza3g1AG6bLnTVogqz8OnVpQOnST2F1LwJueffwxq6+t+gYrLSku/u2deB51OFKs01wjheeN7vxd/OEqQulrSAnyI410H9/lnvQ7NmfPJYJw2S3yaiLIN10rrx23lTPPqEOsWVeiWV5yBtRVH+Ezd+oj44zf4MD2dp/Y5AUz3+iFe8U17AgaZgZVEfwzi5Ghgu8M62f3oUyKqGOxTsZ6ErHhnl+OjXYWrVxZuOZ1JsP1R6b4XSfQtmJjPC/pR+OF0uabn1944QV75hkJiz68jkJzheiy/DL4c/GjhriD0YgUj1xOgmJuWooa5+pNiSbEYPjYnrgjPDZEmz/Y5V0YOv6kw9U9UzCRHIHjs5W3n1XY2ya/ZxTmQcsX7pH1Qd1zDMS4mOJ2me2TgDounxiPY/YxKH3uT6Js8i3gCy+csOPHT4W8VTxifqfLwa/nUPawA/E53t+MYDSQGZTlesM+c3TZ5mtNKQjqoKUoxPTRAaMwREJx8C3TJWiTaoQeCAGJa8xHOiY63SDADNylEc1i/rVVPieXqrawzoY9IZ+vHMz0dqzWmLW19ael+FXQZBn3sHx9WsrbXisp+KLSXeg0fdavqKDztt3ahddbc+TrrTP+HdYaeZ0iKIWAWTsppXknKXaRpPRBKH+u+KmjZ+aPjV9US33JsnXOSOD8a8sVPqY6zTJW0o4grnxrTVr59MusvGR2avbvlIcseUYsvDw2rtLjn8pXCpzSM6tyrss3Wh9CbySprRJyG8ZZiUvrZZkFxRAh3MnfQexEAZRACrnHIZxLQVOvValTl5mmAOWJ/Fgq121utemTpp029VRx5b6D0Jy0YbmL16hYYe/1TfWOmRfsqaNcAXZpCmbBLiKax/ob6zV5Hv2LhB1Cfjxvj3dpGwi4uIV4Zvkb12i2MfzBFYr26Xin34l+uF1iBlCS4kxkbHdp9/gX3Ua7QGanl2pWZTfXa4qeHTuzZIdPrnmd24wYNyLEL6KQz/mmKRyZEMtiK/AGEyi1RtdW1td99o96XVa+dzp5Wzm5ZMeeP2Y79u2yex64x5bLK75sF6U55s9mEF4MM51n/fx0m4B+/BOMDIfjQdKITqIfAdT5rq3VO+KPFU/7Rp+uFXJWW1u2Y4eeC0swpaA0xSu4p75GZS2ttKUpKHYDQukL/vAs++gm8cvdiHduyKcrSCj5x3ebxGVz3l8RJMO4KKb+4syJz1mjckYKGwfei5tKtmL1Szj4XoRihzKna1T0NpMrfa4Yqh7qnTZXmZEvFZRuXYuq42MjQzYsJTBsPHb+tthPL32MOP/C4mHx7mowy3BLI1P8rhvoCIJQQQM8Fw2kKz0jSPMtTkK8G9/nm6vf/6P/JqFsWG7DTJZ/vO+btFDMW9HGDjDsVMhV5lKu2CJenokSBoFCydLMcyDHMjiWluo9BOm8lLx8Z0rmQ0HZk+f41BPjcx85VF7Us3CwfM/osNqKN5abAXMSQ4NpisJyMqCOM2SlKbkKEz6GMEMe1KxTe1YC86Oix9SjP23FXkXx4Xw2xUV5k8srbr5UFRqSslK0d/3Zu62mzsvLQF75ckr5q/8yo8x07+Y8RxqURbpM02V0M4I0h3RzgHLDnplVJ6P8K/qyWGWp7FqSpql/4UBddrFDoFVtYRmt3EheUrVRfVSHhD90suRJVASh9OwJ95F8ZkVhldhJT/fHym07uapyZWRTflw58ANhjbKq28ryM1avHpFC1pCSJsWsOaE6d4+NjE7Z8FjXRkc76lzNhofvUHoeUec7LMViWPVmpzJj3IqtvN7pWElCS6lRl+IoZQ8FTx01s3453aMYKqMULCSxsk2dVrrp/NufUTq/oLRx3IneUf7l1Z4LjW1Wn325rRy9144e+bReVZvxcqF04kDI5UE11Ov4mrJhTvHo0rYULlUWoVfF6Tu8+nEeUpg6KhexItmxVJY5FGYi1S5cgOCZBpm3ISmUWw1B0ZbSRCL9e8OCFEy9HUqV/4rAZSCkp2cNpenpWSmqeuZbTecV2Mlr0hbbJ9eoIFHfyHPXbKX1ygslRfVU5tziJtZXzkKFCop3UfW7UNS1pLo6pLpbUE6ICsrKNOEunvNHmHGmAxA2SgQKIPaEFQVSVlKwcyI7cPJeJN9gKlYlEcttw3J/VjWQ5hDnsCKB5zCIkOZjoZEqj3RBeUBo5Dw5hEh21AXhe2baKv2OG4SSpt7KvNzM2ZFlCbb4dS2hOlVRBP7b+z+ruAwp7qSVfpH0hbBDfpEPoY/zuOsdcR8bKxVsx7iEY/GTUFNDngRiMJAay9mdOWu0CrawXLFyTbxG9Ydvmjm3c/nMsh1/9pDtvWO3PfLah2126biVxqS8j4TwGFTAPx+QUTxCRccu8BkPS2VDy2WQhKWNDEiE/j2UWQSbOk1LWR3TfVFln1M68kofV5Ibd4ItisnWC3l78siyVcVHrnEppKB6qLicPvK8rc6ekOJWtxZHPLDskzPoGjVr1av+3GxUN1CjXkncJd+uodSp3+U8urbyuqNnljw2RVW5rdfVltsMhomHKoGRNubYxYMavL60auWFpcTk6sHroH4qHbXvNTv03MektK1at85MX93rbZGVULRvpVMarZS+kOZuijrIIbjxJZwi3efqrCARz1A/4sc+6Nqo1Gx9edXWF9eVd10bH520qW0T6rfUtxTgWdR/5VTSzlna6XmnsmNJ9MLS81KyF0P1zHDLA26U4ToAxhCFjnh/PgrutjYP90X7/BPP26HDR9XP0DNfDmChtHxJEByuLqYVni+StaozQ4Dzfg5hjm8N83wnx2ikOsKE8jnO+FOnnVS/nm9iISbI1WfeguJ6drg8EycE3aiUnituMlcackWUSXb4ZPMb3gMIthJoXIkNHb26Tsk/BXv+0BF7+qlnglBFvpK/SR5vLjOEibPMEkqbKSACvelB17Fa79hTJ1ZsvVOUEKQ89mkhKXxcJPA48Ywwozwg6cV8wQmBGmE0ziZEQuCNiAJvyDe9rqtqlNVUL44u1ezMojpP/L1GaHXKdnr+E1arHVXHWhGpDpf3qPo8bBNjBZsYH1FnOql4vVZ2r5HSNjb4lkIakm/SkhDn9jGbl2/rXs8Fvh10UufLjCLf8jWYPeRedaW9plr9vFIr4cZntUmnBNjGXVaefb2tnXyJnTj2Oas1aOPXgnX3bF1xOcWyT4WLUkcUfGc5CZfI9JBkh/DMVTwpfHMayorfRpyrfQ6AwsiC8hrS71XG4dlF1Z1RP+6F79CII22bAQrqUbiXAEXcE/LBBtVD7uOmGRB1NSh8od5y74pi8qw/vTNo9/ifrssgmkc38TnOfhAO/g4PD4cZQHmKeVPCnZyJwmAh5PFSmvr3CZHn+BvuY5gh7THseN1sxjtp/0JcpCgpPrr1NKIMxvM0iSNHJqy1i37Aunz0MK8Vov/PvnDKXji9bt0iaYx8/XwYxGtoqGhT42M2NlxSeqi5aRrUV9gbvH+9UrGVtXVfzl5HIZGz5YVVe/7J523Xtp32mte92tar6+prxMuk9HPOYKvbEk+M8drcBjbmEUoreU0ZbAZm1AGWfG6ub4Crv9et23qjZM+dXFT4m8O79qCOHn3hkC/5bNWl+EkxiTN3Axos4UwTs1U+o8d74rfNhFjiGTd6oY2eK48uC/KmoXI9M3tS5Xkx9efywYBJpXrCjh37mJTaZSlrau9lpbGi+ku61DfEIyvOpmDvs4IJsYupH9/Acs4NdoGHsDsm5+Ktr3OWL5tJjdnoaJiVpg7RvqXxKWbUnY7a7dOq4ydCZC+CX2e4+ZEd53Cdwcfmmxl6NIvPfZJ53B4aCh1xuGefeIksVl5bstd/0cuNI5oGHUyaWZ6bceKNHwQt8RMKzMFtEoo4tx8oUJabknI3pTfCN0GuXOX4kohOmiUQurKc071BuJG7PEtwWOoUFUJZ+tB7RBK+4gTzl3gi94yqkm8hrwZAWWDUdklenJbfCG1kFu6IX7KsM09Y4czAXm5UTNPsv/63v7bHP/eFvmDohHCbCETdzkDwYrvleB+PcoidUzzqIdrdCiCLUThq6oxWyjUrDknokxJXZBZA9oyfhxIL/8nzYqFoBV0p0bCdeZjJg+iIotLHzEm4pstRfir/1ls5O7ZYtXm2Vr9aHf+WIH4KsyNho7pg46NDVspNKznD6qBHrTTcsGKpbI3VR6wuRdBaLF9meabqoIQ3/4heZT44pkE54vciXdGO/b5/xQ01cFjvql7lX7Bm4XOKg8JRRIrdSRuu7rPW8S+zzuKkhJRPqUN/SvWR7wvJh6ubF+6jwlUz8GGVXkF8SQXns0Me4kbCLJQ774X3ycOIGMOzYpk4oazhWlU9u8rgsyJnub4iUF93To7b7u1S5oikEHim26aeU6RfrJ9hB9PgBrCiwK8yxyjWZepxgVk/XaOAFUEdTiP6FQG/iBR5CNfoL+ZsmBRnd4g3Zn0k6Ypm0a9I+BWsNroDA/twTZO/HwtLCPnDO17i/gef5HzOTx5asRPLqpfw5+D82oA4kH7x8OW1NXvFAwdtRH2JmpLHJ/Jfuhi/ptJF/MlTVitw7xtK6Vku8NHTFvsS3PUobOo/dvrF3TS5L4mvsaSxtlaxXft328zMjM3PzakOSCGWQulKH/6pbEK+ifIhPngTvjkd5Dvf8hL3CMwCgj0RYWYw1IOQxr6/olauZB98YtZOrdYU5sb69mKBpYacD5kvDjlv4KxeBk44aoBZQXaXDDtPdnQf7HxgBaXFFSDspcwkG5pwpl9b5qSVfMin5AGVUnJ36cA/FM7Zo8esKoU91OdrCcqqJ8W2rPQ1pIhNSEpSHrEJTrdJZRCRF/Q9qiPUDdq6yI9s0JVKE+7lyK/MEjMTrWtLdspP8pm6EEG2wTN8JQ6zwJ6P1HGVjcJExivXj9niyiH1KddW+c1wYx3nkCl+1xmxo0lTWvHjPlzz6lymXaiAGbpb77d0dTc06ryVyxV78IG7be8eCaxIld5NJXABwXsjHtwo2NHoIRhHU2ZiRikmGxCfeR+3iV9nQeFJUM6zkQtn8LkR3UBZpHgTjj/rwlJLVxR5Kip6fGOHwMTzQHCKz2EJqpigux9XGCh9KA48DxDccSdm2K3KX/IBAY4wWGZa0mPYyAWxGyGip7gePnza/svv/4mVfaQsCmDqkCEx5MCMuefKiHgQKPpXdcphQ4XQWQ9oc17enEDgCmK++ZI/ln421OmgAA4X1TGrjrK0WBe/Z3lcQVfORfM6DDEGoLqlKivBKhnskL++TFDeI4YVZM/urg0pAnzLd2SxbGv1lotn1x6hvXS6FatVl6xUHLOhIss9p6zblIo2VrbqygPWbtwVmgg7myriKHiqFDLjGu65shlNJFUUNUkIxQ+lr22FnhSF3pC1i2esOfWoFcfPePUuNWassPyAFc+8yrrljp0+8WFbWX1SXvINBgFfy7xAkFQZK120VNoky4JccHAzROEQA5bExfuYdxHpJz9Eu/+Ys44S2dRbDfnHkBAKJy0++HP1wG6NzDbcvXfSxkoKgzrqrOXskLwukvlElD/4MHVYxHs+UOFLOoMZV8wiFaQlh2uwj+b4Sd5FCmGE8LZCdB/5B2Hz3B+MUt0h+i6vcnUKflM2DFQ5Ej8wTx5T9wP/g3kw82vi1r3vm2Ma7uN7Ybkh3//m7QNPn7GG+F94+9oDVYxNhvbtmLF921ktQkRD/OJKDI+r2lp8Jl8jxX6VcxWZwfQ0KS0ySvpT+gvxI569j87b2OiojXCMjOqyXPj3kMxildfXbNeunTaza9rOSPmzds7Gx8etJaFetUUeJH2U/oim9wf86cozcePGZ8/hFQo0DDZS1lJqvR9iGTL8lfEjDkCXIC+/w5Ldno3s3GMf+Owhq8JfZCMfX3Qwq7y6vGyNWs13JCUN4Tw5+kpm7ILi10bJ4/s2XZmxYtYrHGMQFD13J7/IFqAke35zDU+UjSy9sBKjSIPLlvCsVh6dOHrUymvLek7ayjWH4qyw6o0Vpa1tI0NTMimqfFHglAcqX3U63kcoQ3QNRFwx68ksKsusvY+KHvmpl+W3giA/zgkcJBnqPLtl69Xjtrz2vLxP77OQuMlw1ZEpftcRN57iFzog2qwLy7o5l+Lno2YwhOQ9GfnV7/mpc2LL5Fqtai9/xUtteER++A9mmGIKfhsYQdjKIRIMhKWZdCoDc0Zxgx9pf5Ce6NDSjCKExmwb3zSEJafMHUiZdC6e+OJexHuZS5H02Lgkrc5C5GF62ggnuA0iJqPwnKHE8tCQR2eDd3ijpLtpufFH94sZyR4KH8oey0ql8KH0NZp5+53f/kN7+qnnlMeho+0rfsqGcIXRBqFn4KZr9957r62trUsICB+dR0UwUuzAbi2o5qh4a/W6rVRqfpZbaWjUBWVGZr1OerEp8Yx0U7e8fIHsVUXYhSy4Ta4qNsSWpurOYqVtxxfWbaHctDoFoHdeHBBOCKvTbVi1vqx4dW20OGO55h4JXQ0bGs5LuJmQM7ljubA6ZZ/Z07MrgKHCODELGBU/vikKil9Q/thFYihf8vfbwy9Yd+yolTojNl7fZ6X5l9jw4j1WXz1jx45+yCqVQwqODW1epHxQmahIJYyafyvXprD0R5JpoRFwntjqN0M1oW+HLW+xDE1NzeryqC7Dlp6jbwNfry44imD3tnGbGQ+Cc1TMqKMudG+C8xQo3qevijtvQP5NtIyDUuEGONnwDhTDwx0ET8A8Pke35wP29AV+PlpqgCl53eG8JomPC93UwQTBbXAc4xDDj8oD1uFdyj76v/GdSP6ehPNmrmSPHV615+cu/1iRy0PXl16urdfswbv3GicreFyJV3JF0EZJ9gE7Pcfy8LzWn/et8gkFjmWrfJcevk1ncEAFDU/Sj2f0AxQTXmWVA3wOP71CtXsuV2zfvcP27t9jp2dPW6PSsJnpGc8rDww/5D4ciyF/ZYzi5ylJlYUrfDz3zbkmdgwmCV6XZNfmm0CeiwV78GUP2H0ve6l96jN8piC/3ebFRYxjvVbx7/pGJyc876mvnAMalTqf3UuUPV/GKLOg6IV8CKBkwv9I6SeF5CZeIGnocZPJACg8ypwjh563ytqal/WLB9JFOSp/Gmt+Xt7YqPqU3ojreT5AQXwoY8o9kuIbZ06dlG90vNxTf7wGX1RRh3zziqdedmX9kOiI8t6H3XCQ4RojU/yuI240xQ9GFxQ9KCgykZelOyoIt/z6ZhKo+/c9BBkYWd7m5lfs3vvutv137XLVbKNAont/hnCPIjlo+H1FUMoYC7Egt1fYoZsRM4J/uF+JfwkQIPIs2ZRChdugMOKPmFRw4eSv+rupK4akw++Du+SlAdAWcpMy5sDhkO6tgTnKH7OJeXW2K6rp7FeoPGJZnSuNUvry7DAKDdlTTx6233n7HySdUFDoQkfGfbwGZhuVPjpkrsvLyz6rkH4nEma3LpRe/W8pf1bqbZtfXvMZwFyJbcjHZIfwJAeUVZHZVgRMKXYSBMiW4QKDAxKgmOnVO3UJMmdW63ZkbtXmJdDVJFB1fPnf9clDRva7vZqUrlMSuOdscmSHmsVu67VUj9qqP2o6zNixjDMs72zrPih2heTqm7ZgJ8q1m8k3f8oj5VOpW7ISS475BpDZgeqwDZ2524ZP32dDa2O2Nv9ZO3b8b63ZOqm8ZADlXPX92oGcbytYFDVmADluoYvgiQZEe0yaqTdVuYM39ElG7KnSldLYFm+rS7CryUfO3/alpP6OHIS7awJ85yzCnOrdwV1jNgQLSfgG/DbOytFuadcRuMEsIPBZv1MaBnxH3Fh+A8yicXwvmAV/YljA+YjMLoXgJcD9UObGTV8w5xpBi4zvqPIO7pUTXCNfCmYhrsltuNcVhSaYB4ru472nH94nx4vNUXvPo0eseZ343Eq57t8v3bNnWt1G4N0e3+QK71a0FdcQ76jwUx4QSh9lqlsrDRVVV0K65IJ//TIMK2rMGmqr9WbbWg3Cwm1PfgzpXrLF4opN75y2e15yt82dmbfySsW2b9/mCk9EiJPqGZu4JHm6FeFOgfbTkbZjOKWkvqzabPieMfnhovhk3V7ykrtscttO+/wTh/Qc4ns9QBwZEKxX6zYh5Y8ZTHh/tIsUkTSbS0Sob/jj9TGFc/nHEtIXnn/WquU1vXd96mtA2xr1dVuvLNgEO8Lm+JRAeaJ6Emfx+qS64koes+m0MSpnKu8uCZLppPLZ6YVnFfZRecNMH/3r9asrtxMyxe864kZT/EDoWOI1kCuCEq4wjwph+EYq2ge7+OzLUfLq3NSQO92CBMbD9iVveKVNcHJt0mn10Vf86JBip4RgICbDToKy928TvIuBYK5B6dE/MXExKHcH83TV0uE7iMbNWeTev6dLEBZ0JeERX38PFo3wyMwbbmXuG67AjKA06IjHdZXSRvxI/JbAHJJ7xYNUForEXc/qbEOcCC/s4mlS/Mrllv3kf/hZW10NSzwD0fmyRIVrStmDMSdu4syeH0nQfyfaBffpDu6WhMohdOpKt/6v15s2v1K1uaU1PwsLRZBNc9qqkx2VbZPvDeQQaqiOrVRbUvaqdnh+zU4srtuy3mHGjxoTCFynPKRNcVEZcmjwyvpzeh6yYm9GnfCINyOWQJJw/8ZP5Aqe6kx8Dt/+qS2oruQYzVXC/dBdPY/kpRzznZ/ypFiTv+VtNro2bM3acTtx4kO2sPyo6hBHNhBIrNcvcl4oSHgAEiZqEcszUeCaSjRfAqPgtZQJHfEr7JPs8KGeqvgD7mviK+zW6V/5Ul90jekJJX3t0sRKCL7VakhQv2PbkG0bZfBHgAelaKg05EoBOEsw1Qs8+wxPKq7uj/5jD68IsxYKM+HN0UUaUfGIyl/A2e42w93ypytL3FEAI6/BzK3dP/g4OeoGHtvNbngOfibPXBO//OD65D669XfliI1k5FJmPKsddwr28acX7fBqQ8bYXR+cnl+1+w7ssZkxdhwlvsQ/xNPjSvz1S5e3k34ofCyhJF3evypfWVLnZcIfg1Yy93auqzoT1WRd5S8DCpxV2lbdGmYWUE6WF5ZtZGLEDj5wwNbW1mx5ccln/pR7Sd9BfMgu3YvwE6VUDkI8EyIdwaH+kjREhRweMsRxOQpwase03XHvAVs8s2r1+po9+PDdtlbt2PGT8x7W9QRHM1QqFRsdH1O2IYdQz8+OE+Vw6cAf6nq8x/vgD/+9LQdLr9uV9XU7eviwL0OVgZtfD8QYEtdut2ar6ydcbhodHlO8ZLs5e3gWkTTeDe9fCoIHYfXKnJ2R0tdsz8mI2nr98uF2RKb4XUfciIof2DjjlyhcrvgFJhHNXRlEnNGVJs03bsEt3VFwRwe2Xq4rrWv2utc+bLmSOj3c8nPmoo7Nd+1s6Zn3sIcJ4COKGbN0myADeevkMRDjINzw/QJMhG9ZhvWseymg7oH86RN+IymLfAmov8e3GWJ4ngZdUm4g4osCyeCoSUj22USM+OeMK7y1NXFR2nDryiJKozof2aF05l3pG1JnmbPf+PX/Yp/77JN9ZY3z5/jmLK30nU/xi+bp5/iud9S3PDamUan2rf/LzZYtVhp2Zq1qsysVO71Stvl1KYVrnK9W82MZFsoNW5OyyIzBQE5J+3c98y+GTYoY4a9bpXraapU5PVe9buVZTqy64lVakhjtKcz+6SoBzWcApejlJEzmOQewJfOW2XB+JNhJ6cu32aZ71Rrrz9v84sftzOmPql6eVN1hm5V053y98oJwB2Fzh2jMrB2bstRUxwfXrnKG3PG9SY3DWnx276yoBz/5XUu4/wq8ofJotHq2f9eUjedVlvBSpP4EzsHyBf8mlQ1dYrulLXPPI5wDBYBr4KO6d/4y4KDUYch3MHZfRXIS3BEVKRgJn28zE8QgGX7hzv3cmlhN4R7JnceFuid/An8K8XNBHzt+/k4w4xr5EbbRDPj7evCBK12JX+Rh3FOvw4AfigdugoKL21PrBfvAUyeVDlKeePgiIuRIwc/aO31m2R66Z58NF8mfMBuHfO+7ntLHKT9csUt+g0FU+aGs93KXf/4dne45OoPy6+o5vsPPS1UOe1QElEIpGEOlkpXrVX9mrcvq0rKVRofsjrvvtJZ428KZeZucGdW7Bd9oQ1nn5HnML8nrmO+kKjwr/91tKBfSw7ESvKMeyYoKd3r/Lttz7x1eHsvH56UQmj3yygfs+KlFW1is+HvXD+KaTSkckrkKpYKNjpSsVFCekRBSgSygfESWuHTwDu0ovjtIJ2c2DovUZVutVbelM3M2d/KUykJc6joOUGwEBaty77atWpu3mpT2oupSnvzwehoQ6uil5A9vym+Xn5BbqlZvztvy6mFbLZ9Qe+CYIPIfyvBiIlP8riNuzBk//++NPAojocFD6fsBBUfBzgUJNfa4/BEfuJ6cPWXT22bsvnv367njnZ8rZRLJuhxx4Pv3wQhRzCBm6cQw8D7VYbjMEQITEZYUNhQnCb1hgxa+5mFEz0PG8VmI8XbiJ0+dYED0bs648d+de4cV3GLOVtacZJRmgFuHE5C2Q7AijiPqEPg2MCiAEsmlnAzb+9//CfvjP/lza0lJiR1vaWjY9u27w0cr2R4Zs60Uv2Ae7UJH3XfnzxlzjXBBBlKW+NVLdlDHbnyEOkU7anfWrVqdtXp51pr1WSWITVpY5qk2iLCmOoCSh2IXFL5APtPX7tmQhP0inX5Lyl71qK0sPW4L8x+3paXHrFo5prxBbbo56w6zv84vztc8rxMqjZxNTpZs11Teil1m/EP9C3wmgPu8hH1mDOCrfaFbBMRiHbiLZtwD6nPffcIf3G9ZR7fpdyC+fwLRfDOif2mkn+PgIKsOIk+K70BpHhSfo5t475RyH+2dEj7mdvr5eY1SPsqtkn3kyTN2Zi0MTmwd+2sLcp3hT+rcWrVhy0sVu/fAjA356pSgWEXejGvyyfvKJO8DDcoi2IXltPSiHE3jXSb2hNV/V+8kXRHHXIyOFf24jWZT7vXOsPqPtZVVGyoUbd/Bfd5tnTw2a2NjozYyOiJ3DXdHnhI//E7ns+d1LAcR8GeSkZjVe0P2yadPs6Gwzeyasp27tltD/s6fWbBxxedlL3vInnjqqFVq4iXXo3BSII3VtTVrqj8dHy7ZkPIH/u9Q3ILEciUggYNEligf8eTFxSU7feK4FPFF/6Yw7ebGAfnQtXa7auX6nNUby6p3Ta9jBdUf8obdjnMci+UIAz+OJAvDhcF81Q1WY0mua7XLtl45ZSvrx22tctwabXYvRdajPt2I+XDrI1P8riNu1Bk/FK6zOyU6I+xCpxQVuz6lnuOGGoHwMCyte+7Zw/bS+++z3btReuikxQB9JoxQGRUCkYNg5zeySjOHsCzSD8xlSaave/GIySVf1TPbpx7oEkemQjzV0Xk8eMBPtwx54QwKPxlHRdl0qwQbHjYhZcd5feFGxpiPKJpKj/x96umj9uu/8bu2tFxWZxqWXkFDQyP2pjf9A3vuueesXC73O2EXIqToxY55oPSF+zDrN1D8cAdiuWQA6aW8A6H0xgflFwY5vINVR9vuVK3RWLSalLW19Rdsff2w1aUIdtuL1lPH221xTpM63PaqdVorUhJPW6txwqrrz9n8wmdtfu4ztrz8OSl7HJ67IMGu7iPgLHcOwtDNlD+hnt/I6IrXrK1Ubf/e7TZSCiP/Mc4bYk57TXgrCmBcAkq7xh3tepDWQTuHj/Uhs8gnfMMQGHkCzKMfhULgT9EsTby7lflG9zyFeMJ72hJwMY/vRgR+FNIQ7eK9byai5/R7ffuE3/mztCnOEexJ2zh0umqPHpcwz6z1xpS/iKAM4CeKl+7nKjVrVDp28M6daqUof0l6RLglvyOF/lRlIi8oymBGPmLPIfss6SxYy9NH/5p+X+71Ku9z4H690QxKmQybKutas+k7gK4trciN2Z0P3GnFkSE78cIxKZUFm5qaska94UtKY96SgfGex1g2UfFzc8pQz7XciP3NE6ftE8/OWUHlMzmUs90HdtjktimrrVZtbX7Jduwct4df+wr7yMee6A8uXE8wY92oN/18ubW1shX5DnyIgWPKcNA2Lg9kPqT/yp/K2oodO/yCLS4tWcsV34H9jQnkPspdCmCnob5gzZXAcm3Omu01yV6cQSx+5bOB1NWwb0LeB/Elb1jTOH+20Vz18/iWVo+4slerL0oBZNYXpRe3sR6Q3zdyftyauJEUv5waxW1VA46dOGYH9x9Mnm4s0Hkz2lgshk4pPOuabBvOMpTohms+2VY8PA+ElKK7C/5B+/fvsB//se+2A/vG1eZZwqIiZxSJjjzHkjW+0QidYB8MdTJy2uObFDZDQfiRG5l3+6NPmEgh6yPtwWbAdGSPfyiL7l+oenSwEXk/Wy+BwmLL6lx+Ug+jikswPhvpcEMYEfGga++wSZPsEXROzy/YW97y/9pTTz2VCEthZNIVN+UFo20cHBs66NAJ4w4Fj6vfyzxusR7swvvhfhBZOvp9+/bZM888k5hkuHWRFmIQGePAA7WdgZeI6y+M3W4QB/DfAztG7Mse2G4TU0M2OlS0EgJUviTek6yaQCkQ34jKQRT4QaeJEAWfknlybh9AoM/rNr7D8t/4bljGr5pQKvXdR//yhcAn6IbZzp+z2uAhzFhRf2L37GNtCeA3INgFnsY9xOYjzP4BltDFOKSXckZyxWKTWaAQBvdc432rW7ThTtXO1Iftzx49abOrfH9644Cy5dzQr3nl3fZVr7hLSlFNeSGhmOLFPinHdDnJILyLHWbJUk/SLC5vlSrnFDIwWZS98oYzYSlPNqTq+8fmMCiLmKHQUx+Ktn1mSm/VbO9du2z/y+6z9dlFe+LTT9rw+LDt2bHLTh6ftVYzzKD6Jw1JXqd3jvZyc5lfZdFpS9Eu2IeeWrT3Pvq8n104NTlkX/2q/fb6Lzpoj7zh1bZ46qQd+/xR9dFm9zz8UvvMc4v2S7/2Z64e5Dkr9AbiO8yW7t6zx0Z27nJFm3pnSh95CuKS0Ag2Aovg22n9D/VV+d9uNWxtbtGW5+et2UJRurXgA99clTdhJpA86klRZCdxZvliPgX+lOHGw9HjR+3AXQeSp+uLbMbvBkLsSOB7/Xsx8Nh5b7bjIW2HcBE8Cp1PNFsvr9uZ2RV7+GUHbXyUs/WSb+rcuZirOp3QNaaBBzCT4D+zHP6S23Doujo5F2rdp4TOh8Co3b8N76DcDd4NggeCRhJej104me3zrtvdnI20OfeptIREhjS4Xc5W1sv2q7/6a/bYY5/rd7bp2Tu23G5ygKwEqDBqHJbkELf0we4+y+f24TmYBXvvxBLgz+LiYvKU4dZHrI8ILnTEkaI5SFWQDC8amOlfr7dteGzCJtmepskWNeJl4pPilhuLSKDNg8BLw0wQA2sIWt7WZY+du0vejbfx3biDYOQNgRcl9uKxmPmzzH3gzgf/OA8zCLr+jpziPhIYPPtjcJcoIPgD7+LgZudH2CcO/Tl5F3CNZpGfAa5ptyyfq3aH7RPPL9sLc6s3kAoRANdn0O7M8rqX1c5t4yrZlswoj9BHOlHMyb3++bsDu/BM/iFg8/0eSn23i4CtFPsr9ImpPplZ+pQ/OOKKEj8i5aa6Wrb2Wt2m79ppO3fvttOz87a+tm53SQis1RsuvFNAMZ99Zi+59/NN2w1XdGqdgn30uSX7gBQ7/OZzhXZT/ZVorNi20dG83XnXHjdfm1+1RrlsL3/kAauovh89uuTfciqHPJ43Aqhbq6urtjK3YOtLK9Zt8EUwGcHAB/VW7YWZW+U7s81h10vO/VN+qU9ld87lhXk7c+qEzZ86ZRXlqa/c8dp+qwEZDQWPfGkam7Vw+DvPoUxJ862Y7lsH2VLP64gbWfHzztU7jnBNE+CywaxvznO4Ah+1TpgAZvLN5ufFJFcr9oqX3WfDw8yqwUhgGJGiYoUQE/xzBVLmnH0XDkrHTfLcdz94zy/nBPGJ7gUPo6gr2/ynGVaaiZGOcbkblZsYx62QDjgVhoAgFPMFAWCtXLG3vf337IMf+khfENtMKH5BqQuK3Fb34TkISWdTOj1KiXe4GW4fxPoL0nUzmmf14fog8AU4yWqlbjOTEzZWCLvycqYY7RSFQX99BN4ayJ/1NooDikGOowBkBl/ABr7pm7DIEK4b231U/OANLswn14Bgx7P/uCZ28NiggEgZTJTA9PsDCn67vf8P8S7mwzEVgScFe7Dx3QFFf8Oy0PRzuLaUtqfOtO3Tz5/xg/dvNNBb8b/V7tgJ9Xem/mX39m3qxqQKyapfliq//n1CINgNzApySF/Kof0c9eC7PCsv2FV1s+IX3w/ZktQF5WNTSllpZMTq63WrV2o2vXPKdu/dZavLa3Z6bs527dmp8s1bq855dmFwMSp+Xm66cjboWqdkn3hu0T78+SNWaSDsE1Cof+Vay0ZGhmxMCtP0tkmb3rPdv2lbPL1onVbNXv7qh+yklKu5hTUv2xsOKh9m7CrldVtdWnJaXxatLItW/Lq2vCzzBVtZXLClhTlbmDvt3+5VK2WlkXOCWeyrfPMcuRUR6mgADIrnaHarpvnWQqb4XUecS/GDadPpczirM9/Awa8LFJXQoUSigdPR8Oub0/HQ9EPjj51ZeEBxjOyAdeFhydDJE4u2ML9kL3/lA0pn8M9Y/+0zfoyuwVDiDBvLO9kNk9k9ZgnDZi6+octZjCciPke7FKG4sZyUd5MjFdgDzZW+OJsI9f2Wc1cIicMYeqJM0+GmSebRbz2zvJP8IROwxZyR05W1qv3Gb7zN/vbv3i9hr+0dbJjpo4NNdsiD2up0+fi+r+SF0f2NSp/y6yzFL/h3HavODYdBfQ10++HFTfPtmceXAtQDli12rdrq2K7JUSsW2IhHbbrNQdMsk2TmLSzRjfm5sT+Ax4T+gt0gC4mbqDBhH3bAhD8kwqic6NbvfQaD9Xu61x22TjA5Z3lOekHvw6N8EkpmxIUwQV9JkHmMG1fC8+/yuIqn+wyW3uN80ug2Uozv4D6kIVDiH/Hrck5czk6u9+wDj5+wsngnR5zceAgZxX+Wd55cXLdytWF7t08ZpxqxBRlHe4QsSfIyKTvAbexHY7m74sc7opJkgxazTd4ZhSWhwW0YMIjvhXdD/pCXDeXXyNikWa1h65I/JreN294Dd1i1VrPZ47M2OTFhkzsmrcJRA2wQI/+7PWYqKbCurbdH7L2PHrOPP3XcKnV245Yb953/KmW5W1mr2Z6pGcv36jZ9x3Yb3yZls96wpVPLNjyet5c+cq89feiM5B82dQPEkbp0o5Wj0oaCzZJnBmQaDWtFknLIAA1LXsO3j8Q9xH+Q47cqQn0MiOm+tVN8qyFT/K4jzjfjNzMzY9/xHd/hB3KzBOF6gX6DzmNzZxIIu9D5g2gelL2EOfg91/4j/70TOjY7Z0eOnLTXvfphGx5SJ5JnqZPg3/Kh9CWKn380j/DDldHmOOMXPY60mflstg/UVYR6KJU2pUeOcEChw5zROjnZCuwYmmcXTimd8kYpDeab4UpfKjxX/LjyBjOUOVteWbNf//W32Qc/+CH/Bi8obwhggXTrz27mil+475u5+8EMYVrxQ0AKbsLzzYZ+HboGwF8GU/bv3281CTbkfYZrB3iGL/O7IQXzGwdkT7WpNtvJ274JlnqyjIrlkRyz0PElksUSKx1wHdrGIEt5DtyITT98Rq4oPqn7oEQFHgCfhifwc76h97GH3+EXm3ug9uEt7qRKuHkgmScP/XuBK2UMBT4U+A/k4Upp4N4HqvSM75EXMtg14E+DuG684lcIh3tTHNkNcLUxZO957JgtVnmVuOLzjQvKpq0+bX61ZnOLa7Zn9y6bUJczxFLApF8lD8mXCMzCjF9y37/KLTO8ei4Wh6wuJcSPIMLc/QjLd/0+5rd7qD+0TGUUG8CMTI750mJmtIqqc/fcfw9dlR0/ftxnEQ/cfcDWysvWUr30IynUry2sl+yd73/cnjg+52egnivPW928rayWbefMiJUKHdt71z717yWrrddsZXHRdu/YZgcOHrTPPf6C/OcN4ngjl2CGDLcWbiTFD06VIUG1WrXHHnvMr33mfR1Ah+sd9yZFw88kSu7THbY/u4IyWCoS34tu4n2jlbdPf+qY/dTPvN1Ozzf0DkcbSMHLTanjmlS6UfpQ+KgaabpSSOnLcySD/O8Rxqi6HcyYWUS5DISS1lEn1utxQLbi5DOPl9JBhY46otXu2tLyqv3qr73VPvCBD/qyrphnMR/Tz27mI/KRBvkXqf/eBneBbiaQTwit27Zts507d9rICLO7V7fe796929797nfbs88+ax/72MfswIED17Vt3eo4KOHuW7/1W21iYiIxyXAuqBnbc/Pr9sISh8uPWMt5p9pxhyV6bVtZXrNKpSZ3tGvqLINngY86X03zVv04o3pouGCloaCU9XlNWzy9I76mK99jtVpsAMW7emaDqBY8RWEyw5EMSvl7aZ6UmEUCKJtskBEVfcw3XsX/CM8V3OA++kc4XNPu09T3Q8rHertoH/j8STtTVjwIGHOPwQ0MH01kM5SuPbdQsT/6wBP2zELDmoXA4zbzIJ79jNwt7ACK7lAh7+cElnRNu0m/k74GRTCA/F5QfaKP6zR6dviJF+z0sVN23wN32yOvfsjW15bt2AuH7P6X3m8zd8xYS33jU8dr9lvv+rg9fWrVWh1icG5QF0+uVOypIyt28oUFm5OiuH3XDttz9y4r5Io2d2zWHto/Yd/0da8zVVF6ybPimCFDhtsD2YxfCs6cFxZc8aPTu56InUmkgVnSqaiTIo7x2ZUjd4YB6pOeSQLvYCzgvuD2bZtdWLfnnjlp996732Zmpq3A4eiu8DGzJzeeft7EvS6O5HkDzpVP0S0dCzN7HL7uPY5TiEkym8hy0x4WhD0iQWbclcS8oSiiDAqejujnuYiLriKiT3pPzJ62t/zcz9tnPvNZV44RaILww30QcLiXUWIu4SZRogc0ELiifXxO+3G968ylgnozPj5ur371q+1Lv/RLfQOatTW+A7l6Yt03f/M325vf/GYPBzp27Jh9+tOfTmwzXG3EjT3m5uZ8g6IXA4EvJe3vJgKiNEc8nF5r2J5t221yLG95Ds13XiS+pebMrFyTb4jEb4NigIrnzCVwnCTtoeWzLBNhmgEVvq8Tf4h8QX+4D3wJQqkKAntYOYDCJUXMr7JIfAwIZpG/xPv4zCYwlDlEKISLHc04XPUMj5L2h6DvPAyzxA7EZ7z0uIjYZbTSztnHn16xZ6U8seFGnt0n/Y0bvbxVVpRHEtuKyvG5o8tWbbVt38y4laQES3/r11uvw8nz1iQfqQPKPw5Ob0p5Vy7phVAn0u7S70W/HSrnnOpDaXjISt2SLZ1ZsrbydNfeXbZtxzZbPL1gp08u2MyuGVsq5+wP3/c5O7VaUyj0kUmffg54vVRcVtfrtmt60kq5pk3tGLfpnTPWlqK5slgWP6jaK1/3sJ2cXbLZMys2s139vurMi8UnMmS4nZEt9byOuNDmLrEzvf6gs4BCfLwj4UfvJMEkfMOGXXIv0DF5X8R7bkanVJBzdep6cqIDYZlKL2/z6gw+94VDNj6xzfbt22+lAu/Jrah/bhEeuxAU/HNyQ/4F28F9miRW+feBLNMcUngoenxlgR0uWoH8DECWl7LcalLEUlC+KWQWkvBwG37hmIYQh55/J8izSO7CtyzY4S5ntXrTPv6Jz9gv/uJ/thcOHXFhBgpKXlDYOl2+fcEsCEnRzUbFLlBfCWwHP4LbaBeebzZQvswY3HvvvU4cN8EyZ9J0tcBRFih/XFk+/Zu/+Zv2wgsvJLYZrjZYTnvq1KkXTZjbsWOHfcu3fIs99NBDPnBQqdxYW/yfD95i9Y9vpE4tl2375IRNjw+LR6L8wavgW0E5azaYjVO7kEHgjbwNLwvieOg2GIyDU/mizXCsjvhSUOb0rhzFb//kQVD63C7wno4v7xOPUftzpSIh7INSdjbRVoOiR5sNCgibhXDFXoE7RbdQsAvKXqBE2cMM927GLpIl+9ShZXvi1Iq1UBaTGN0cCDHtx1eJ40y+4wtlOzK7rjwasfGxYRsqodBTikFhD0s4yT+UPMo5UmKm+xJHd6ir4Xs/vovffIbu4D68h+8hCh0penpDylYYICjY2sq6FLO2zeyetul9u21ufs2efPwZ65YK9sBL77fVat1WVla9j7pw7vfkf8/qra5tHy3ZaLFnM3fusZExKarVhq0uLltRfe4XveE19oVnjorXr/vuoPRrGTJkuLbIFL/riAspfjcaYmcSl2TQgWMGuKTv+9CDuvHkFovQ2fuz/w/AqLzetS88ccQWlubs4D0HbHR0XLINo4u4hIKqFt93uNATca7OCOECZU8KnR/+Ln9ccUNRw68gaOTyUvL45o8loFL+gmIXw06D55AHjpgeXRG0oj1+Liws2X/5g3faH7zzT2xhftE7toGQMxCC0rtyBoUwKHe+jXRiPrBP7Da8E90jEt2cIP4oexxWPz8/bw221CYTrxJQBp544gm7//777cd+7Mfs/e9/fzbCfI1xNcvvfKDtveUtb7F//a//tf2Df/AP/PlTn/rUTVm+CMxnVhs2NTZi01MjPjsGa/NdOtl8SqCttFsdazXDt1bxuAUQ8zxe0SH8Kr7NrAp543xD9rjgPvJU3nFynpiYKciwZB97N+nzmb77FA3M/dbviV/sNzxs0bneIW1+z2CYFJSKePXHn1mxz59A6ZO589fE85sc642uHTq9ZMfOrKpsh2zb9IzKiF5EfYmyi3Ih3yge7tOEOUobRzyQJ23lG1kzcHP2O4C8Dco11LWin98oyhVtdb2qfmpZKpnZxJ7dqosdO3NqzoZ7LXv5K++23Tv22rETc65oUlbnA/7X6y3V43EbKbRsVErfjju2e5zrq3UrL67bxGTeHnj4IfvM5573pcwZbnzEdkx9CnUzGdjJcNMgU/yuI242xS827s0diWODAhbgDELm/EBwHgQGf9/vEqhzx/umOpTDh+fssceetL17dtme3eoIndHgevDGIPx0uGfHIaLHAfB6n5k+zptR1ydTUToNvaIizY6hkFy7ckjYIR0D8E5gfiB9TEN0j/L25JNP28/9wv9rn/rMo1ap1qzrmxMwS7dRmQuKXhCmsNug+DGDl9xHu/67qXei2c3Mf4k/B9UzG3e1lT7QbrdVtw7bI488Yr/0S7/kYWS4+UHb45uxX/u1X/NZv9HRUa9Lf/7nf27lctw58CZCruSzH7MrFZseHbdd28elBFVFbEaU5lcMLvVc+as3auK3IR/cSuaRfOit/xy+pYV49hm9vl1ob+Gqt1D0UBD8SvsMbtiVc8DvBmGl78l//AhXzINd6BP0rohn2iRIu8MNz4qZVW3UPvjEGXvqzJrc3nqzQSh4rV7b1qoNOzS7bJ8/NGtdKYBTU5M2VlLZKZ+CoB3u0wS4oiiy5JNdoFH+Bm6CfZpiOanr0H3oM4pDI7baKNqHPnfSPvmFEypfs/LSiq/A2HPfPrWnSVs4M2/VM4t2373T9qovepnNzq7a8uqF2xbh1Kt12zs5aqV8yyYlbG7bMWnsWru8tGz1ct327NtuIxNT9vSzhJ3N+N3o4JttBth+8Rd/0esIn0vE9pvh5kCm+F1H3GyKH4jLTOhEfDmKm4V7rvE5dDL+ZP49in4se/TlJi6w4BYhIChXEhd0VaelH++trlXso5/4tJ1erNiD999vhSG5RVhxxQqlzC/un0JwIiz3E/96LM9k2SYbsoRlnuG7vtiB4hxP2BK7q1v5oYAlqojCDnoeRdy4O3/wuOGK4VgUvuBQVh5m3lpSzFbLVfutt/2u/ee3/pYtLC67wMJxDHyngqAVllixtFMpFr/kCt8MCp/EHa68g9vELJCEri2WdwYKgtnNjig4Xivg99d93dfZe97znmsazu0C2hJKRBBOrx9oA2wm8/KXv9wHD/7gD/7A3vve9/YVi5sLCFFS6NTejyzUbVTK3IGdk1YoDYlfsH184HjOiyDu1fbZBKZRb6lMOGvPXYjEG+Qa1gBR4yH4VtgdMihnod2FfIz34TlwZmYHw7JPfM1LwcCcMu/ILgyk4Y648R68Er9A4E8MTiHUh/YNn2dAj+/b4Kxsmc+LnBPXlh+WL9p6M2d/+/gpe3Yubmpz6yHkbigb+o5yo2XPHJ+3Tz513E4vN600OmYTo/RfLMksWMn7naT/Ivul9FGGxVzRhgtFrwP0Lb5M1J2oPLzfC/lMudCxoUNXW0U7eqZu7/vYC/bHf/1J+8yzp+3wbNkPWd++bcJqiyvWK3Zt7/5dtnPXjJUrNZs9fNymSzn7e1/8UisWRu3kXNnrJMmgTN3/FKgt1UbbhkYmbXtB1/GiTe2ZtpHhIevVurZ4Zpkk2AMP3Gmz86t2en49yZHwP8ONhy/5ki/xQbZ9+/bZ13zN19jv//7v+2qaDDcPbiTFT3J36DJuFxw7ccwO7j+YPN08YFSZbzcgBD6WmqDPxZHkYFbs23GNZvRB0Z13WIk7vk3Qpf8+9yh1KJTT28fs2771q+3L3/CI7dg55jvVoYvR723sIMJoN8AUwWSgEF6oaiVCihTGXG6baEL9Y+zENnVm/ojCGvyko0W5W1xYto9/8pP2p//1XTY/tyBBRy6SUVUIxS/e+856rsAFpQ4BK87qMTMYZ/GCwjeY7WOkNPqBUDuwu1D6MkSwJPCHf/iHPQ8zXBlow/fdd59/y8dGVNcTzPSxi+j09LT93u/9ns/23fRdCrN44mEP75uyL75/u02NSMjutK3eZDAp8CXKAITBt8AzS6WCjY+P2NAQ3ysP3EWCx8b3QOAlga+4YpZyE65yBCk7MYNPgwLfYMOsE8Tsxo+Y91yjvyDMHG40J3yW5ba78ksK4vH1vH34ydM2uyoz+HiveUEOfmtBeYyyJ8V6cmLU7t2zze7bv9sO7J22yeGCjQ7nbXg4598Fhj409Kf1dsGWV9fU16jc1N+QZypWV9Rb7Z5VWj0pWCv2zNEFO6P+ig1YZCx3KnuVA+VMqAf37rCvesODtm+sY7sObrd999zpHe6RZ4/YiedPKtwRm7ljl82ud+1df/WYnZpf811iVSnl16CkQg3L267JIXvTG+623fvG7P5XvsT27d1tS7MLduK5k7ayumr77t1vjcKM/dyv/ldbmK8qNiw2zXAj4k1vepO9853v9Nk+eP7f//t/3x599NHENsPNgKPHj9qBuw4kT9cXmeJ3kyB0/EHxQwDYSvGL9+E5CAp0UOqN+ub448ogV75rkB+8GykIMXInGYPNCe66c9q+7EtfZX/v9a+ygwd26N2OupSB0JGWDNhVLChnXBOJZUtgjn1w67uW+cHxbOySKJKh9xrAvWKGLyhlR44ft099+jP24Q9/zI4fO+GjrtRkX4rJJgkSbpz0Ilfe2aj4BcUt3vuMn5ttUv5cIRy4GxDCk8csw0UgU/yuLqLgfyPk5913320PPvigz+jeGlDeipcVpWDdMT0i5W+37d8GP835GZ/tdjh2wTdykTsnVwAlxIvXcn7ayEjJz6+M5QS/hQKPDcwtXBnAaif+BYYS7eOKjrR7iNmatJuIdF1IK3iBMAtuBmZB+VtvFuwLJyv26AvztlxlwxI8iP9CnG4XhL4NNUrpdiVQ5SmFflqK4LaxYZueGrdpKffjIwUbGi6qjFkRU7CG+p9ytW4t9TH1Rsvv1ypVW621bL1S811AWRaqEvQfA5weBkRQCqkgsx0z4/a1r37A7to7ZLv2TEj522Nj26bszMkzdvSZI1Zdr9jU9hkrTEzbpx4/ZZ9+9AVbXF2X8j4o++C/4qf6+w+/5hGbHqrZwZfeZ/c9csAKUlrnDs3b7Asnfb+2ffffY08eK9uv/+Z7rNbOvr2+UbFr1y77yZ/8SXv9619vf/M3f2M//uM/ft0H/TJcGjLF7zriZlX8gHf6rvgx+ydFrqjnRGHLyzzO9AUlLyhw3OddwQvm8b7vToID9yyhzBd6vkQUYcLdoP1JmEGQ2bljyu65b7d93dd9mb3sJXfZ+BjLOTuyZ6moqhDrZlD88kPWzbEzXskK3dSH4y6fUNUgvcEsX35St+zgiaCFA4UnYSqC2UO6ynDPOYsNPw/uPe95rx06dNjm5uZ9xJoaTDVGqKH/o4P1JZsyi4qcEwocCp3ugznPQZHbMPsnd1wRitxN3z0zfuH+Nms2V4xM8bt1cespfpEHwQ9zNiUl7pGDu+yVd03ZRKFpRfG9pvhUqy0ewSygqjTKH2zMlTW9mct3rCTFb3xs3IpSHMRO3T9nc3IxUNywgB/CW+A56VkX3DG4x9EQrM7ArfzQPbw7+IGfEH7wThgc4z5cA59yPqZnSCzQCoo/u5nOVXv2oWeW7dCpJasr/MSTBMH/2wuDNIcSSp704CWrBy8F3aJzU+wobbgJs6rh3X42skwmuacvC34Glc89TSE8qb6pb/3SV9xnDx8Ys+3bx2zf3Xtt+o7tUiTX7fgzR23uyIKVbNjG90zZaj1nH/z4c/bkC3PW7ITBg+gPAwT/v69+rY0XTtuu3Xvtnkfutrvuu8PWllZt9rlTtnhi0SZmJmzXPQ/YO//qUXvPhz7rM9rsPprhxgJtn2X1X//1X+8zf0tLS1lfepPhRlL8sm/8bjqkOwu6j/i8kQmk+29c9BUVOiIuieDBUzDhfzIaHB/5pz9mt8qVup04sWCf/MQX7G/e/wk/B2hsYtp27NjlThnpduGHXTw5okFKHMc0sGsaJFVKdtgXJCgxEj4h83GRFEh/j1k/dTrekypuIv9Oppu3Q8+/YO/6sz+3t771N+09732fHT58xFbZBluCiit0iWIWlTMEm6DcBfOovDFan3brZ1ul34v3/l6iLCbmg+ugc89w8XjjG9/o339leXfrgWWebPBy6NChxOTWQqPdtdNLFTu9WPazz4ZKRRvKta1YzFlpmAEsvhULQnfkn1Rz+FOj0RSf4XB3VjK4jduBvvtEQfMBOPG9MOAU+Dnm3Ee38B/dJANYDEChcAx4HM+BovtE+VMYuV7bcnJLF1C1tj15qmnvffSMHVtcCzNGuMtwQZBLEEVBtjHQGPuFaHf56PkB/yfOLFonV7LJ8VGrrSxIievZ5PYZ27Vvp9e5cnnNVmeXbKTUsUdecrftv+NOW5ybt0pN5W1F9aM9mx4r2Ze/7h7rNMvWaXRsaEzK4rYJm5wel1nbGpWOra2UfYnyK1/zsH3uiSO2ts7mWy4xeGwy3Bigbo2MjNju3bvtySef9AHvDDcXsm/8riNu5hm/CASEsFwzjPz69wbSmzCHfCaP2b3EXX8GT8QkXtpd+soodd9O0oybSRAJhBuUuYJ13Z7DfNs2OTVkr3jZg/aaVz9sDz10j4TACRvy2UbCGk5mEEMYKHHheAeObShZpyeFkE1nJIy4UiXhhO9N1tfL9oUvPGGPPfY5+9znn7DlpSW5l1KYCDFRKIpCTVowCp0wSzrDrBx2UFDo9CyBKZpjFomOO1wx172ENvcv5SbYe9AZLhHZjN+ti1tvxm8zGIhiNULPxgs9e+Se3faKA5M2JaGbWRUXknVt1jvJCgQGwRKe6rxT1qKJyVEJb8nuxRhsAu4jWq2w/DMiuoePsizdg4x+M8vIvezhocF84D98C+UTja/WKdpatWQf+MJxe/70in/VheKZ4UYChaq+1jr20MHd9sY3vMSG8zXbs3+3L/2cnJq0ufkzdvqpeZudPaY+rW1j27bZ2NROO7lQtaMnFlXeeXv4vt02UWjYyqKUyHbPdh3cZfsfPGgH7r3TqlL4Zl+Ys9kjp1XvenbHPftsvjJmP/1L77RKnVqR1YkbDXv37vVv+/7iL/7ipjovNUNAttTzOuJWUPwAQgIKHYKAUzG9hHOgbEHRnStuyfd+7ja6kznXXCFsGhCVNZY5+RJQFyQIk2eXNEw+q2PKWzvX8W8BfflR0Wzb9Ljt3L7N9uzabnv37bVdO3f64d0TUyWFw0zfsDoldjjr2nq5LqrY4tySOrBZW1hYsLmFZVtZWXGhh6WeKGRRoEHw8nOwdO9bnvv9QLkL97gZfMvn5qKgtMmub47bcyh+6iRdWJJ/wX7wfobLQ6b43bq4HRS/nLiRcyLpZnC+nWND9tqD03bHjnGbHC1YMdcOrsQiOLKETT38QbyI5fVoaswMlkp5GxsbFc+EF8s7/nkQ8BZCwQz3DGyFb/Cch+GX4Hyaj7OIjxuhRBIzeDTvq305vxbfdlvxOtk12jlbrHbsiaMr9tSRNVtnhlIu2IxEHA6PMtwo8OKnbFRCqie7p0bsG77sYds+3rMdu6ds7/49tuOOHV7PZo/O2akjs1Lu1vROz8bGR21oaNhKeq/XaVq93rXq+pp/Az+zb8b23n2HHbj/LtXBEVs4tWBnjszb0sl5m94xalN37rN3vf+I/c2HPusDDxluLGSK382NTPG7jrhVFD/gSluixPm5QsmmLcgSg01gghluwv3gvWge/AhCDc9pcjcFZAkEjOBepn4fCWx+jgKJIwkTO67hLLxgh1CDkBKrYfqarpqurMlPzFwQ6qpjS9y4XULhOXEPpWbugrIXlLiBWaLUSfaJz30zv/Ic3Ga4fFys4nfHHXf4QfKt1u27wxztlN3barXaBfPrRsCtr/htjSExxl0Syh/cO2kHdk3YtBTAUr4jJbBjHAjfbLSt2VL5bZqF48rOnyOjJRsucuSN+FgO7ua2fXcRaX4E34JR44b74DK86+/5TJE/sKeXtcRvT6427fmT63Zods2WKy3jgPYBZ81wI4MPIDqqZ9PjQ/blr7jX7rtzymam8rbnzt22Y/9u5xN873Xm2BmbO3XGqmtV78vy+aKxWUxP9caXG6syTO+Ytl137bY7Du7Tdaetr5Vt/viizR2etfp6w/bcvcfapUn7ld99nx1h1jCrJDcUMsXv5saNpPglw40ZbkakBQIUFEaHeWY2LNpFMwhhOt6nzbnne5SNz4HSbtNmW7nbSISPwiRqc+BxToKQWb3W9dHH+E5UwNKU9pM4+/Mm881uo/nm+/QV2ipf0nbpPMVNnBXM8OJgfX3d8/52Bwf2Zrix0RTvOrVStQ8/O2d//uhJ++BTi3ZitWeVdtEF7dJYwUYnWY3BMvfAV5wvih/Wag1bXSnb6nrFGuK9bP2fHpiKxDM8Mg7ilUolv8fM3Tpxfh8DV1IE4Vm61mpt+8KZmr3rE8ftz0SffmHRFqripRLmo7qY4caH614q29Vyy/7uU4fsY58/ZUvlnB1/9owde+YFW5HSt23XNnvg1ffbA6980A7ce8CmZ6Z907dWs5kofXyLOuSzh9QpztxktnBsfMzGp8Ztavs2SYI9W5pftvGhhr3xK19jw0MsSc6QIcOtiEzxu8kxEBRSikyirKC4bKXgnMtss/v+PYJJ6n4r9/EeRS0Q9yhPLFeCmqJGQpvdBuUufR+pH4/kfquwN5oP7NN2aTdbmUMxL7kGdzxnw54vJlD8KIPbGaSfWU/qYYYbF2FhpllbxbRcbdrjp1bsv33qiP3Rx4/ZY4ebtlQdVQ87YWNjErDHx/szeRRrGPDqWrVWt+WVVatUa867Iv+JlOZX0QzEFRQ8sqyUlXnQoWWz9z25bG//yEn7y8dm7ZkzTVutie/JIQe1s2WWLwnJcFOgG+b8pJd1rNpq2meeO2nv+runrJobtjNHl+zY08dt8YXT1m327J777rV7X3mfHXhkv91x/z7bsX+7bds7adPbZ2xi25SVRoe93lCX6GfZcGhsYtSVv8ltE1ZfX7PyQtle/cgddvDgnf36miFDhlsLWQ9wCyAIBOwiFxQV/0ZNxLd0LPtoSwGLZsENAgVK0IBcycFdivzMqqbsuLbwhzDMGs2uCxntDt/qBep08/1rIHVXPSlgXSlyTtwjgERSHCDikvKj2yv4fbzGcPwa4yAinaSFHdBiXANxj5kEJoh0JRSFqChAhXSFK8/RnvzgjC7JZhkyvOiIszkZbmxQTuEnfiLBnMG3mnjH6fWG/e3TZ+z3P/CMvfMjR+3DzyzbsbJ42th26wyNWDPXtkavK5KyJlWs2crZ+poUxaVVnwmM/NgPixdPhAIPE+8SdcQAaw2F1SnZYjNvTy/U7L0oex88bn/4icP2maOLtlitW0PCfbfH7n/qBKhTSWzlcUhAhpsAoaxYnOubn6mPOjK3ZL/yJx9TnSra4mLFjkoZPPHcMTt15oSNTI7a3fffY3e/9KDtv++g3XFgv+24c9qmd03a5PSYDY8P+Qy01y2hNFa00kTJhqZGrDg0ZmtLZWuuLtv3fvvrbbg0YnzTz6cdGTJkuHWQfeN3C4EROkb0wuYucUOXjd/s8b3eWWZO4d3oR7z6vWSP/s5xCUU3VJ94D8V4+DV/MQKG/EC4ScEFqhSlzRCIw30I258lFEVzrhvvB2YbSeYoyRKkotuoFKJUYpbh6iHb3OXWxe36jd/5IX6IwAxf9GvXRoo52zY+attHh2x8KG+jULFnRfHPsIty2/kzSzrHRoZ9uV7kTQx+1UXlRse/01tar9lytWHlesMabXgVuyMzB9kOwWe4ZRH73dGREXvdQ3fZq+6ZtvFSwaZ2j9n2fTuk5G238W2j3sdVKxWrr9V8aSf1KF8o2vDYiE1sGxdNWKvRstW5VVuZW7HFU4u2LsVv284p23PPXfbf3vu0vfvvHpPCyTzx9RssiPIEuJ375ewbv5sb2eYu1xG3suIHYJJBiTu/4oe7zfbw18H9QLk7n+IXw0xTQE/vBCF/YLYFVPt6vfDNij+mrpHiMx3XwDyl+KmD8wPbE3uuAwru02Z9ZU99Gc/cYxYUP9x7kBmuIjLF79ZFpvidCwlPFEOBpfgmLr7IRrzTN3yRkqdHFL+iGHMJPitDPcI9rat7djD21QriVS3xJ65dNs1K8Sh89XB077sfZ7gtwKZopULe7rtjh33ZK++1mfGejYyZTe/ZbtM7Z2zbjikbGR9RveAb+6YfNcJRRwUpiUOjQzY0MmStWssqSxVbW1i3pflFW5ldVfXM2a79O620bdp+6hf+0k4v8d319VH8kFH43pnBEOKPwnO79iGZ4ndzI9vcJcM1Q1BigsITlgcNljA6sdQzWRLKUkmWOgYK9iwzCmdIhXtfdoR7lkTiJnnf3SfLLJ0w83fjeywtzTm1W+Ea79vJfaspYcaXj+I+vN/3W9ewbDOE60tOk3DCNYaP2ySeSfxjugPFdOKO98gX4hbzJxyYyz39Sab0ZciQ4eoABU18xVWznpQy+AsDTW0Wh1pH9w3xn4r47VqjYYu1hs1X6zZXrtt8uWYL61Vb1P1KrWnlZktu9Q6L/vDDfQ1EOD6QlTGvaw4UbJSQhx9+2L7t277NhfH0IOiLCtWDpvq7Z47P2Z++//P21Kmq1RpFO3N4zk4/P2tnjp62xdML1qi1rVgatqlplnxO29TMpI2MSiH06tn1IyrzQzkbGh6y0mhRfW3dysurVupU7Wu/4lXJUk++NURcfHHTSV4/9NBD9k/+yT+x173udb6LaYYMGa4MmeJ3iwJFZqAEcY0UFayEEnPMovI0MBt88xbMUJx0xa2ElbCBS7IZC8oiChr37hd2QREM7lJKYfo+oX44CQ38D/7FOPXjnDZLaIO7SJi5OfmQ5EXfXTpvEMgywSlDhgxXDxfmKMEF/6Pb9P0AW5sOcCH7DFcD9BEvf/nLfdblHe94h33kIx/xGanrofiF0g4K/0K5bu/76JP2vo+9YA2btOX5ZZt9/qQtHjrtRz0snV629eWy1cs1azfUr9aa1qw2rNNs++Aq8Wd2bXi4RCKtXq370RCPvPSA3blvRuHEWbYXN51R0f6Gb/gGP+qHOGbIkOHKkCl+tzDopFDAWBoRFLJNm5voPm2++X5gNthtM20HbfRn446cF6LoB/fR//SuntF+4H+grdyej3g/Hc/NfmYKX4YMGTJkuBBQQl772tfaXXfd5bNPLHN+1atedf37kByb/XTs8cOz9ofv/bTNNUZtvZ632ZPzNn/0jC0cm7OlEwu2cmbZVudXrLZSsdp6zeoVlL+OfycflT+ODGnW2taQ/Wiuaq995d0yQ1QkjS+eyEh86OOPHz9uP/qjP2qPPvpo1ldnyHAVkCl+twF8aWNqxis9y9ZXgvw4CNlHu+S62W1Uls6m6DY892faNtGGd3yWcKPbDfYJRQUvhC93ydXv4zVJX9o8pncQ943uUAYzZMiQIUOGiwH9yGc/+1k7cuSIn4f35JNP2tNPP53YXj/kunw3yjeeeTu1VLN3/s1n7LMvLFjZhm19pWrzJ+dsDiXw1Lxv5LI2v2qV5YpVy3Wr1xrWaoT+tZeTX8W8+s+uNapN6zaq9vADd9nMtnCuKN8LvlhAySNOKH5PPfWUPfPMM1ar1RLbDBkyXC4yxe82AQNlfPcXj3OIyk9UilyB8uWXMk9dw3dxwW1cehnf3UiJAsc7/t45KNqLtlb8Am0dBubJvYeBmyR+7l8wc/Lv+LjGd0LHhr/ZBi4ZMmTIkOFSgTLyxBNP2A/8wA/Y7/zO79ib3/xmm5ubu+4zUeF7T35swtK2aq1pH3vskP3Vh5+3o6s9a0kBXFtat8WTC7YgBXD5zIqtLqxbWcpfZb3mx4i0Wg3rdNu+eRAbEnEOb7PWst1Tw3Zgz7Tlc3zt9+IPljJAy+Av/Xc2WJshw5UjU/xuI9A5wThRggYzaIP7uBwymqft0+7OZ44f0R+Y9VbLMeP78Zp2E/2JZpHhR7dpd+nnaJZ2m76PiiNxy5aLZMiQIUOGywEzfcz6ffSjH/WZqBsNzPy54iYd6ejsmv3Zh560v/nMEWvmJ63XGbKVhbLNzS5K+Vuy9cVVqy2XrcGRD9WmtRtSHNuD2bZmsyW/Wv6tX7GI2pf1nRky3OzIFL/bFGklb6Acna08bWWWVsa4Tytu8Tmapd+B+BD++7//++0nfuInbGZmpm+/1bvx/a3M4nXzfZoG7sMsX4YMGTJkyHArg6NAela0Xk7XXMsatZZ99vkFe9uff9JeWGrZyPZ91s11bW1l0Vbml2xtadWqq2WrrlfltuE7aEf9jmMc2s2q3XNgl5WK2cYqGTLcCsgUv9sYTHxJ/5NyhGIUvgX0JZ7JEsmBcqhrW3Z+jAJLKMM9xPE+6ec0bTbP54r2T7/3++xHf+THdf1+e+cf/Ve9z/cEwc/NFP2A0uG4WUrBg6KSF0hukrSQrpt5go+twsfGxpKnDBkyZMiQ4XxgySeblrG6Rf2m7rvdhq1UavbOv/2s/Zd3f8rKvUkbntptudKIVetNK6+XrbnWtEalYa1mzb/zyxU4G1LKo/rbyfGiDWWKX4YMtwQyxS+DY7MiFZWpeN3qPv0MpWfltiKwa9cu/Vdnoh5pz549Vijk+zN6F3o/HebZcUHZS1/51uHWAGdFZciQIUOGDFeCXidnR04s29v/28ftPZ8+YUvNYRvbtsOmJidsaHTYhkpDNjY8YSO6Lw0VpQCy2wu7fZZ8l81MZHxxQF5v27bN2GE1Q4arjawVZ+gjfgMYlKqNSl2agv3GJZ9p83NRpVKxP/zDP7Qnn/yC74r20z/907a+vt633/z++fwNiiJXnqPCR/zDYca3CiiPw4cPJ08ZMmTIkCHD5YFNYDrqHyuNtn32mWP2J3/zqL37Y8/ZsfWSFaZ22NjO7TYyM2KjkyM2PDZiheGC5Yt59d0166p/ZdA2w4uDbC+CDNcKmeKXYUvAc+Lyz7hsEuUqLAVFEUPZYuevgdLFNSqOXAdLRQM1m0372Mc+Zj/6oz9i/+Jf/ID9yq/8kszDOYNbuQ/+BX8JLxz6PogHdpFuZSaZdQAZMmTIcHXA8vkwe3U7Qp16QvS3y2tVe+zZE/aH7/mU/fa7PmGffn7OyrkRG5qatqGJKRsenbJ2bsw+8ekXrCFlMbyb4VqDPn9tbc0HuDNkuNrIFL8MFwRMCAoKXlT6BkpaUAQHM3GDGbmzl25Wq1VbWlqyM2fO+AxgNN/K/dkzegOFMMYpQ4YMGTJkuFiwfO7gwYPJ0+0M+k/mAM0q9YadmK/ZX/7d0/YLv/kBe8tb321vf9dj9vb/+pi95df/yv7yg49bvR3cZ8iQ4eZGpvhluGSgcKVn51DS4nWgpDErF5W4qLANKJpHNwO7MJu3UdHLjmHIkCFDhgxXDgYYZ2dnk6cMffQaUgJb1uq1baHctSeen7XPPn3cTi/WrN3LJyriACjQU1NTt/HsaYYMNycyxS/DVUGYgePK8tCouIVlooPnQNLhUu6im0Bx2Sb2GTJkyPBiIhNib33Qv/DZQYaN8OMfdKUF5HpdJ5Z2cs332CwN2tg+hoaGkrsMGTLcLMgUvwwvClDkIgVkAlaGDBluLIyOjtrw8HCmAN7CCAOL2cjiWUDR87zRJfm5sX6Dg9sH+cbM6cLCQpaXGTLcZMgUvwwZMmTIkEEoFArZFuoZMmTIkOGWRab4ZciQIUOGDAIbTkEZMmTIkCHDrYhM8cuQIUOGDBmEuIlUtnzt+qNYLNqePXuSpwwZMmTIcDWQKX4ZMmTIkCFDhhsO2exrhgwZMlxdZIpfhgwZMmTIkOGGAsf8lMvl5ClDhgwZMlwNZIrfNUC2I1yGDBkyZMiQIUOGDC8+kMPz+fx55XHsbkd5PVP8rjJ27dqVnW2TIUOGDBkyZMiQIcN1AErfwYMHz6nYYb5//34/wud2Q6b4XWXU63XrdDjoNEOGGxMwRChDhgwZMmTIkOFWAxt0LS8vJ09nA/szZ85Yo9FITG4fZNLfVQbfJGSKX4YbFYxyjY2N2eTk5G25xCFDhgwZMmTIcOsC2YYdmldXV8+7QzNK3+0or2eK31VGthV4hhsdMLtms5nV0wwZMmTIkCHDLYUo22Ty+NbIFL8MGW4jwARbrZbVarXEJEOGDBkyZMiQIcPtgEzxy5AhQ4YMGTJkyJAhQ4ZbHJnilyFDhgwZMmTIkCFDhgy3ODLFL0OGDNcc2Tr7qwc+XM825smQIUOGDBkyXCoyxS9DhgzXHJ///OeTuwxXgkKhYHv37rWZmZnEJEOGDBkyZMiQ4eKQKX4ZMmS45vj93/993145w5WB8xe/9mu/1r74i784m/nLkCFDhgy3Ba5VXxf70dupL80UvwwZLgII3JmQfflgJ9EMV452u21//Md/bB/5yEcSk+sPlvFmZ5dmyJAhQ4ZrAWSviYkJGxkZSUyuHvDzwIEDydPtgUzxS3C7afwZLg379u2zUqmUPGXIcH2AklWtVm19fd3vr/e3k/DMlZUVO3z4cMY/M2TIkCHDNQErhq52H4N/DErPzc0lJrcHMsUvwf79+zPBJcM5MT8/f9vMWtEO4gxnpDTOZZ7h9gOK59ramh05cuS6K6EZMmTIcKuC1R4M+t2On0zEAc+rff4w/pKv9Xr9tuq/MsUvwerqanKXIcPZaDabtwVjQOEbHR21H/3RH7Uf+IEfsGKxmNgMsH37dvuf/qf/yf6H/+F/2NI+w+0F2kX2/WaGDBkyXDsgo77//e+3RqORmNxeuJby1+2k9IFM8UtAo8qElwy3O2gDjKqxe+S//bf/1r7iK74isQlglu/1r3+9/bt/9+98uSFgCSwKYJp4H/PNdjyjXGI/NDTUnzXkmrbf/A7uoWyWMcONjMnJSdu5c2fylCFDhgxXB6w4KpfLmZya4YqRKX4ZMmTYAEa/fv7nf96WlpZ85i99dAD3mD366KP2oQ99yP77//6/tzNnztjy8rITAyif/exn7f7777d//+//vSuHfAMW7b/whS/YV3/1V9v3fu/3utuDBw8mPpu97W1vc/s777zTPvCBD/TfIR6nTp2y//l//p9dKcxw9cEs7/j4uCvXaZDfY2Njbp8p3RcGKwMqlUrylCFDhgwZMtxYyKSoDBkynAXW0//Ij/yIPfjgg/Zt3/ZtPjuHEvBd3/Vddu+999qv/uqv+gfR//Jf/kubnZ21f/2v/7XTT/7kT9oDDzxgX/7lX+7usfu//q//y5VFZglRKjmOgJ20mMmLwDzO6nFUAX782q/9mr/7H//jf/QlLnfccYcrIBmuLignyvq3f/u3Pe9juaDoUf6/8Ru/YT/zMz9jw8PDbp7h3GAZ1tX+DiVDhgwZ4MfZ4FuGq4FM8cuQIcNZQBF7z3veY5/5zGfsf/wf/0dXuu666y77V//qX9kHP/hBn5FjyQkKIcTMHcQmSbzLEk3ATB0KxS/90i+5AnHy5MnzztrRscXlLC95yUvsFa94hT3yyCM+i/K3f/u3mVB9jfDwww/bN3/zN9vP/uzP2n333ecK+I4dO/z5H/7Df+jlwBJGZmrT9D3f8z2uHKIsvuxlL7P/7r/77/p2X/d1X+fvvOlNb+qbMUOMOUsiM2TIkOFWAn0kn0ewaiUqaVynp6ft7//9v+889XLAoNt3f/d32z/+x//4mhxpkOH2Qqb4XSQQVjcvg8pwaYABxu+1MlxdoGjFjuZywfvRD5Q3lK23vOUttnv3bu9wWLrJWTo/9VM/5Ts54oZ2wSwcwj+0d+9ee/e7321Hjx51fy4nTp/61KfsrW99q++2RXgoCcwgstST5wxXH5QTS28p6//n//l/fAMflvu+5jWvseeee87dYPef/tN/cvNIv/ALv+CKPYrhL//yL/u70Y7y+qf/9J/6zG36HZb0vvGNb7zi+pohQ4YMNwrgZyh98Dco/a0vg2kMfLJa5nKA3PQN3/AN9k3f9E3ZyosMV4xM8btI0NgQbDNcPmBeCHxf9EVflCl/VxHkJbMt55tJuxhMTU3Z3Xff3fcHxe6xxx6zv/iLv/Clmih/CPGf//zn3Q5wcPfp06ftne98pxOHi0MnTpxw+3MBpQ4/mGX6R//oH7nfjJZi/vKXv9zb2t/8zd+4n3/yJ3/iM4V8gxZnEjNcfXAWH0t1X/nKV/rS2m/5lm+x//yf/7PP7iLUYI/gQh2J9OM//uNuhmDDbO93fMd39Gd/v+/7vs/uueceO3bsmM/e4p6Zxe///u93vzJkuBUAX9qzZ4+vfMhwe4PZOOoCA5U//dM/7XUD0G/t2rXL5Uhm/t71rnfZRz/6UfvYxz7m38qzkRqzgv/m3/wbN4t2H/7wh+0d73iHnyMMD+YzCVbiYE8/+ad/+qf2JV/yJf1BNFZT4P61r32t98P4Ef1jpQ5L+pHDvuZrvsb++q//2u0+8pGPOPGpBt9zZ7j1kSl+Fwm+3Xj66aeTpwyXA5QEBD427Mhw9UC+ooxd6W5f8Ty2tD8srfz1X/91n/WBWPoXlT6AYsAyUMwj0eExU8SMYXq3XK6EwfeDdELUhR/7sR/zWSNmglAgfvd3f9eVxpe+9KVuF/1DsaAT5P0M1waUD8ICs3aU6e///u972cTyQ3FjJvfZZ5+1J5980glFEaEjCh4s06WMIO4ZFOB7TTbtof587nOf8+82o+KfIcPNDja8YjAjW42QIYIB0m/8xm+0f/bP/tmGpZmspPjf//f/3Qe/MWewgOWf/+Jf/AsfvIVXMvAW7bh++7d/u/3QD/2Qv8+gbPy8Ajv6WQZsIy+lLvI+q2Re9apX2YEDB9wtCicrNn7iJ37CHnroIV/Jg+IY7ai7/9v/9r+5Epnh1kem+F0kEH4yQeXKgILy1FNPueDIfYarB/LzSusn72/2g2fK7Du/8zt9qQnCfBo/93M/58tb2KkzEqOOf/mXf+md3//6v/6vvqsnQBHkbECURZSAv/f3/p6PPMb38AelAIUQP6I5br7yK7/SlRAUhgzXBpQ1W4b/4i/+om+o88M//MP+HOsEQgdCwtvf/nb7P//P/9OJ2dhozzUqgIBnRqSpB7zzO7/zO+6eJVDf+q3fesUz1Bky3AhgcIM2k+3mmiHyP75p/7M/+zNf7o4CyCwb4MosILN8zLAxA0cfymBonB2kPr3uda/zWTuui4uLrhzCT5ntoy9EccQ8zW9B5MGRJ8N78Qfi+2oG5PALxfB973ufh89qHgbwUAKJw2Y/M9x6yHreDC8qIkPKcPMAZYuZQJZbbi4/BkSef/75/gwQxOzOwsKCH/PADBFb3AP8OX78uHdsKKp0XCiVvMP10KFD/QGW+fn5vh2EHbPuWf259kC5RxiJ5zSS5xDmlCHCCMIHxNJNBIWthAUUu6//+q93hZ5vP1kCxZVlT/V6PXGVIcPNDdoEAvXterB2hrPBShm+iWclDkrVq1/96sQmgKWgrGaBz/7gD/6g95HwxNi/pfu5C/V5m/nvudynzfk8BN5M+BBLTNmBO9s87fZApvhlyJDhgqDTiJTG+czSFLHZLH3d6j6NrcwyXB08/vjj9ulPf7q/rDMq4CjozNDzrSeCwf/xf/wfLqCwbAhCGWQJLoMCfEfC0t4I3uX7UAYN+L4F94wo823JH/7hH/bDypDhZkfGmzKkAW+LxxwxmwffTIMZP5ZvsryS5aBsgsUAJ0ApiztkQ+n9EFiSybfwLOFkAA07eGt0G2cGLwTiBx8mfOif//N/7qtz6AeyunwbQIV8W+Ho8aPU6oyuI732ta/tveY1r9nSLqOMMnrxKZ/PO13ILpfL9SRsbCDsMI/Xrd7f7H6zm4wyuplo3759vTe/+c29kZGRLe0zuv0I3vd93/d9vXK53JMS1jd/1ate1VtYWOitrKz0vvEbv7H3tre9rddqtXrNZnMDvfGNb+z99m//dq/dbvcajYabce10Or0f+ZEf6f27f/fv+m4xf93rXtd77rnn+m6her3ek1LpMhZ2/+bf/Jt+3N7whjf0pIz2vuqrvqonpa//TqTTp0/3vuVbvmVLHv5i0ejoaO8lL3nJlnY3O6F73CjI8U+Rum1w7MQxO7j/YPKU4XqA9eZUu0cffTQxyZAhQ4YMGW4OsMsi3yEzc50tW84ApDD55ixsuMJKB1ZDIOcUCgWXeZilY1UE7vhGL+6gyTNgwzOWhbLz+b/8l/+yvw8CS+7f+973+mqJ17/+9b6BC+/wDSHnBXKUDmEQFsuOWZ3B5xRS8HxHZTbUwj1L7dm8hTiAL/uyL+t/e4g933N/8pOf9Heul1pAPEgL6bjVIMXPDtx1IHm6vsgUvwwvOjLFL0OGDBky3KzIFL8M1wKcicr3f/fff3+2FP4Ww42k+GXf+GXIkCFDhgybEEef+ZYmn+1AmiEFZmH4JvZWnJnIcH0Aj/nUpz5l7373u533ZMhwrZDN+GV40ZHN+GXIkOFGB+dksZSKbc6XlpZ8p9q4/CrD7Q0Ec4h+7DYToTJcI6D4jY6O+kATAwvZjN+thWzGL0OGDBlucTBbxIG9dOQZbj7w/Qvf1LAzH0uvslH4DBEoewjmmdKX4WqB+sRZkOyMnCl9Ga4lMsUvgyOOYGbIkOHqIVsKdvMCoZ6zJjmXMjujLUOGDBky3ArIFL8MPjPx0pe+1Hd9ypS/DBmuDlgWyMHOmfJ3c4LDjD/+8Y/bb/7mb9rzzz+fjcLfImA3RXZITNPw8PB5+z6W4U1OTvpB3NPT04lphgwZMtx8yBS/DN7hvfzlL/eDQV8MZAJUhgwZbnRExZ1v+7LlVzc/UN6+8zu/037v937P6R3veEeffvmXf9nuueeeLVe+xOe7777b3v72t/uW/QBz/ISim/j+ZgLRXXyO2MosQ4YMGa4Vss1dMninwygogg1bU1/rKkFYhMGIeoYMGTJkyHCtsXfvXnv/+9/vCtihQ4f8Gvu6N7zhDfarv/qr9iu/8iv+PSd2EcvLy/bkk0/aQw89ZB/60Ifsx37sx3z5L+edMVtIf8bZaPSfrJ5hO/65uTl77rnn7N5777X9+/d7H8tAAubMLvLtbwTvvfDCC3b06NFscCFDhlsU2Tl+1xGZ4pchQ4YMGTLcXmDG7iMf+Yj94i/+ov3cz/3cBiXr27/92+3EiRP2qle9yn72Z392w4ZMKG3/4T/8B/vbv/1bP2Sb9xCb8AfF7uGHH3alEDMURg7P/qM/+iP73d/9XfvjP/7jvpLHd6K/9Vu/5Qduf+mXfqn7E2f7UAg5uPvpp5++5gOvGTJkePGRKX7XEZnilyFDhgwZMtxe4ND1D3/4w75hDzN4adFndnbW/r//7//z7/hQzJi5w56jPL7ne77HZ+t++qd/2v7yL//SfuiHfsg+//nP28mTJ+1nfuZn3P1mxQ+F7wMf+ID91E/9lP2rf/Wv3H8UPej//r//b3fDDCP+ojz+x//4H+17v/d7fUYSswwZMtxayI5zyJAhQ4YMGTJkeJGAwsdMH2cy3nHHHX5GY6R//s//uf0v/8v/4jN+KGrQD//wD7uSx/fvzMoBlDKWeTJzyNLMC42b8znDY4895u5ZDsryUN45fPiwP2P++OOP+2wgYaRnITNkyJDhWiBT/DJcERgZpePkw/g0MbqKHSOoLLHhPnaeXPkugpHObdu22c6dO/07CL59SGPHjh124MCNMUKSIUOGDBluXtC/PPHEE/Zv/+2/tTe/+c0+k8cV4js++iz6HJRClnEyM8eyz89+9rOJDwHM6tGHxf4sKmtpswwZMmS4UZEpfhmuCD/4gz9on/zkJ330MhKjmHwE/13f9V3+oftf/dVfeYeaBsdH4AZ7RlV575u/+ZsT2wBGXP/gD/4gecqQIUOGDBkuD2zEwuYtP//zP+9KHUs3WYoJ8R0eG5s1m01f3vkN3/AN9i3f8i32pje9yQ4eDJ+GVKtVP9T/R3/0R/1bve/+7u/2GUAUxbe97W1uxpVwOIg7UwIzZMhwIyJT/DJcEf7ZP/tndvz4cXvLW97Sp//0n/6Td5J8MD8zM9M/HzC9LIYOFPORkRGbmJjw0da3vvWtfk5S3FFtamrKZwOzDjRDhgwZMlwJ2EDl137t17yv+cqv/Er7iq/4iv9/e/cCHlV1rnH8E3IPCQmSQAATNHJHBQ3YJjSHlniKSkFaORW0qC1ttS2CitRi1eKtHryh1lKUUwU01pZjImqlPUhRxFoBAStECAgJBnMhIeRCLpPgybfYE0IIkmT2TOby//nsh9l7JgNmJbP3u9da32retKiKLumwdu1ac0Ny7Nix5qZkamqqhIeHmyU9dF6gfv2QIUPM1+iIlcWLF8v+/fslPT3dHBs3bpzpVXzmmWdM+NO5fQ6Ho/ncp0FR36u8vNzs63ENmwcPHjTDQjnXAXA3irvAJXrS27Rpk8ybN886cnzIiwY2nVORkpIiS5cuNZPfi4qKmp/XE6v2DF5zzTXmpKknYh3+qcNxtLrZrl27zMkzIyNDBg8efMa5FAAAnI6ed3TTc0nr84mzmItubb3G+bXOxxrgnF+jnK9vuQyEU+v30tfopu+hx1u+N3P8TqXfm5bfP8AXUdwFfkMnumtoW716dfOWnZ1thtPopPj2nsi011An1+vd0WXLlpm1lJwnQwAAXKHhQc9HbYUIDWHO59p6jfO4bvpa5fyalq937rfcWr+XHmtoaGg+3vK9cTJnDYG2AjWAzuG3CS6ZM2eO3HvvvbJixQqzLV++XFauXGnmTOik+dYFW1TrE6HSYx999JHceOONptDLwoULJT4+vs3XAgAA/6ZhuKqqiusAwEYEP7hEg5rO59MqaE899ZTZdD0kXeNIQ5/esVPO4SzOrS364a7rLC1YsMAM8dSNXj8AgCs4j/gmvSbQ+ZAEP8A+BD+4RId56gR3nRyv8/J2794tOTk5Zg6fzunTye2VlZVmHuCePXtk7969ZsvKyjKBUcto6109HTajJ2f9Uxe/1SCpH/YMfwEAdJbegNS55ro0EAEQQKCjuAtcohXOZs2aZQqzOOmPlC6Sq+WtNfhpdU+tjqYnXd00zOmfmzdvllWrVskVV1xhisHoMFGthKZ0mOcNN9xg3leHfXLHDwDQUVo5Wm9QFhYWmsXSuZkIwNO8qbgLwQ8AAPglvcnonHKgI0q4iQjA06jqCQAA4GYa9LSKZstKmvAeDL8FPIvgh04JCQkxi7Pzoe1eQUFB5nvN9xkA4G90DmbLqSIA3Ivgh07j7umpNKBpWLOLrmc4e/ZsE/4ABC79bHFeJDuHLgK+Tn+W7TxnAvhqBD90ii60TpnlU+nF2dChQ60915WUlMiGDRv4PgMBTouUaDEtLZQVFxdH+INf0OreWvkbgGcQ/NApBJG26fdFl7Wwi1ZH1aUw6uvrrSMAAo3eUNJe/3PPPVfS0tLMMPtu3Th9w/fpOZPrCcBzOHMANtITmPaG2oWTIgD9DKitrZWdO3fKX//6VzMSQCtUAgDQEQQ/AAC8XF1dnezbt0+2b99uRgKwHh0AoKMIfgC8hg5p0w3AqXRJAh32TegD/JMO4Q4ODmYOL9yG4AfAa+hJLykpSXr27GkdAQAgMGjgGzt2rAwePJh5vHALfqoAeA096aWnp0tCQgI9fwCAgKLzeaurq+nVh9uc1fRDFlCVI/I/z5ekc5KsPQB208Cmdyr1o6WjJy/9Wu3t0+FsWuYbAIBA4uzpI/z5j7wDeZI4INHa61r0+AGwlQa+Xr16mbXGOkPXhyT0AQACkQY+Qh/cheAHwHZabr6oqMjaa78AG4AAAIBP0hE6Oj0jLCyMqRk+hOAHAICf0gsyLsoAuIMGP4qx+RaCHwAAfurss8+WyMhIaw8A7KEjdHQ+vo7uYbSO7yD4AQDgp3TObG1trbUHAAhkBD8AAPyULvquGwAABD8AAAB0KZ2LGhQUJFFRUdaRrqP/lujoaFOhGvAnBD8AAAB0KZ0npoFLC4Z4A11IvbKykuJI8CsEPwAAAHQ5h8Nh5qV2NQ2hjY2N5t/TkcIlWuEyIiKCsAivRfADAAAAXKRhUTfAWxH8AAAAABdVVVWZJQ5Y3gDeiuAHuEiHdOgEcCaBA4BnhIWFSUpKiiQkJEi3blzKwHsQ+uDN+LSEz9LApSd83bpyPL1+yB85ckQqKiqsIwAAd9ICIL1792ZxegDogLOaLloD6tZE/uf5knROkrUHX6VBT+/4xsTEmMcavLQCFwDA/+nnfnBwsJlPdezYMXpZ4DeSBg2T0anjZdjosTJw8HDp0z9RomJ6SXBIiPUKdIajvl4qy8ukqCBf9u/eKTlbP5St76+XvNwc6xXuk3cgTxIHJFp7XYvgB5+lQyunTJkiAwYMkFdeeUX27NljLgAAf+Ts3daPbC502885MoDvGQBvFRUTK5NmzJKMqTNk0MhR1lF4Qu4n22RtVqa8kbmsKRgeto7ay5uCH0M94bP0Yi40NFTi4+PNnV/AX+mwtri4OElOTpbExETzc4/2CQkJkYEDB/IZAcDrhEf2kJ8u+K1kby+Um+9eROjrAvo91++9toG2hbaJP6PHDz5Lh3pqr59e2Okwz9LSUnr84JeCgoJkyJAhMmvWLDlw4IA8//zzZq0rerAAwDd9e9pMufnX/y294vtaR+ANyooLZckDv5S//WWFdcR19PghYNlZhKW2tlYKCwslPz9fDh06xEUw/Jb+bNfU1MjevXvl8OHD5veIn3cA8E3zFi2Vu55aTujzQtom2jbaRv6IHj94jA5X69u3r5SUlJh1bgC0jwY97eHWCob6WNeK0iAIAPAdOpfvvudWySXjvmUdgTfb8t46uefHV7s8948ePwQkHYZZXFwsDQ0N1hEA7eHs8dPhzNq7TegDAN+ioe/RzDWEPh+ibaVtpm3nLwh+8Bi9eHU4HMzDAzpJf4cCbJAGAPgF7enTJRrgW7TNtO38BcEPAAAAcBOdL0ZPn+/StvOXOX8EPwAAbKBLzOjyMgDgpNU7J//gJ9YefJW2obalr6O4CwAANtDgFxsba+ZiAoCuCffy+7m2VO8sLa+UrHX/lA3bdkhDQ6NcPCxZpl02ThL7xlmvgLvpUg/TUwdJTXWVdaR9KO4CAF1I18WLiYkxlWYBu+j8ZUIfAKeZc+6yJfT98+NPZebdj8uKN9fJvoIiOVB0SF5b/y+5/p4nZMUb60wQhPtpW2qb+jJ6/AAEHA1+0dHRUlFRQZVZAIDttBJk9vZCCQ4JsY50Tm7+QZn3xB9NuJs9/TvyrTEXSlD3bvJRzl55dGWWFJaWy63XTpEp4y+1vgLu5Kivl6su6tuhJR7o8QOALqRhr6ysjNAHAHCLSTNmuRz6tG/mzfc2S1V1jdz+g6kyMfVic7yuvkFSRgyS386+XnpF95Ds9R/Ikapq8xzcS9tU29ZXEfwCjC7+DAAAAPfJmDrDetR5VTW18um+A5LYL14uGZ4sjY3H5OEXVsms+56SwxVVMrDp+MVDk6W4tNz0/Pm6mtp6E2C9fTCiHW3bVQh+ASgyMtJshEAAAAB7JQ0aJoNGjrL2Oq++vqEpCB2Vnj0iJCQoWOodDVJ2pFKONQWjY8e+NNdxfXrHWK92v7wvimX95n+fsm3d9ZkJpa7K+sc/5d4/ZEptncM64p20bbWNfRHBLwDpB4UWIQiw6Z0AAABuNzp1vPXINZHhoZIQ10sOfFEipUcqrKMn1Dkckpt3UEJCgiQsJNg66j4bt+XIg8v+LEv+8pb8YdWJ7fV3/iWOAJs6YVcbexrBLwBVVVVJTU2Ntdc5WracHkMAAICTDRs91nrkmrDQEPmPi0dKaUWV5DWFv9YKikplV16BjB6aLAPie1tH3WvE+YnywsK58qeH5zdv9/xkuvm3BhK72tjTCH4Bxo5ePg19/fr1kxAXJy0DAAD4m4GDh1uPXPed9DHy2hN3ydcvHGIdOeHc/n1kxf23yp03XC3du3ftJX15ZbUsy/q77D3whXVEpOTwEVn6v2vk86JDUnjosLzw+tuSX1gijyx/Va65c5Hc9+zLZmmK09EeTR3++eP7njZLV/wx+/+kuqbOelbkzQ2bZMPWHWZ9wxt/86R8nLvPHC8uO9L8d9yy6FnZvnuf7aPc7GxjTyL4ocP0l6e4uNjvKiJqoGVdNwAA4Io+/e0r3a/XJj17RJo/W9ORV/pcSHCQdaTrxERFSlxsT3nsxWypqD5qlp/4HxPUaiWhdy850nTszXc3ya+fWWkC6x0zvyuhIcEy95HnzNqErenXP535urz+zofyvYxUuXFyhmzamSt3L3lRqo/Wmtds371fHm/6+7bk7JXv/+c4870oLD0s85983jw/99opkjZqmPxmaaa8+9EOc8wudraxJxH80GEa/Orr66Wx0b8WDNWCN/Hx8dYeAABAx0XF9LIeuZf2iL301jvy6PJXT9rWfrDNPOcOun7gt39+j6T/6M7mLbPp36CuHJci8b16yp///p4JWp8VFJrA5uyNrK13yHVXflOuzkiTS4afL7dfN1XGjBgkr7/7oXm+pW2798mWXXvl/puvk4mpl8j4lAvkoV/MlIrKo/LBJ7usV4kkJcTLXT/6L/Mafax/9/DzzpHbrrtKvnbBkKZA+A2ZeeW35LV3/iW1dfXWV7nOU21sN4IfYNG5j4WFhdYeAABAx7m6fl9LerNdlzjQip6t6fDJVWvfk9VNwanldt9zf5JnXnnTlkqbrV1wfpK8/NAdkvXYXc3b1G9+3TwXFNRdbvre5fLOlk/ksZVZ8ovvXymx0T3Mc0p7BYck9bf2jr8+9aKhJiDqUg4t7c4rkBHnJkq/+BMBS9/rwsEDZUvOHuuISHxsjISHHf9+63voex0sKZMnXsxuDsJalOaLpmMth4m6ys429iSCH2DRD1e7x4ADAOBNdHhgW8MGYR9HvT09Szrc8bEVWfKdOffLlbMXmjX8Dh0+Ud1Te7hWPnDbSSHsxQdvl6EDB8imHblm3p3dgoODpFfPKDk75sTmDF4qKiLcLCqvIU9DWUtaebRHeLi1d1z3bqefYqM/p60LCcZG9Wj6vnx1oB3W9P+vC9w7t0npY2TOjMnSIzLMeoXr7GpjT+M3HwAAIED07t1bRo4cKWFh9l0E42SV5WXWI9c4moKfc2F2Hbr5j00fm+IoLWmQahnC4mJ6SkR4qPWsZ+nNc+1x1J68Sy8YYoq5aHh1KquokoKSUmvvOF0bsGdkxCnzFONio+Xz4kPN8/mU9mDuOXDQLFzfFn0Pfa+opk2Hhjq3tNHDJWXY+RIabN+SF3a1sacR/AAAAAKEVuROTk6W0NCuCQdfJTo62i+KrBUV5FuPXKM9afOun2qCjoap701IlbRRw2VwUn+JCOua9nNYi8iXlp/YdCiqhr6cfZ/LG03B76arL5cbJk8wIXXd5o+trxQzx+6F1WtN8Re187MDkr3+A0m/ZOQpVUlHDTlPapper887157WIaS6fMXXLxxqvepk+h4TLr1I3tq4RXKbAqLS4Z/3/P4ls/agnaO67GpjTyP4AQAABIiioiJZs2aNVFfbPwzQFTqkT4us6Z+th/f5mv27d1qPXNf37Fj51Q+nmSGU6zZ9LDMnfVMW3jTjpOGVnvTvPXkyfcEjMvX2B5u3e/+QaQLgs6+ukcnjL5VBif0kOjKiKQBOlOWr324OYX3OjjHDU797+0Nm+OrPH14ik74xxqxV2JpWCF3Q9P+tIe6K2QvN6xdnvmYqdWpV0NNJvXCYXPa1UfKT+39nvuaKW34jjcca5YdTMmz9ubKzjT3prKb0G1CTmvI/z5ekc5KsvbbFxMSIw+Hwug9FAAAAeLerrr9Zbnv499aePbS364HnXpGEuFhZNPdGEwjboj1cv/rdcikqLZff/fImM/zTG2hP3b1LXpKFN18riX3i5Ghtnem1PFOA1d6+I1XHewg1/GrPZ3toMZzK6hoJDQ06ZV6hHR6/82eSvXyJtffV8g7kSeIA71j+gR6/NuhSBf62Rh0AAHA/LUgRbONcIviere+vtx7ZJ/3iEfLDqy6T/MJDsmj5qyfNfWvpy6b/jh3z7j4dDXuti8Kcjv4+aTVP3dob+pTO99O/wx2hT7mjjT2B4NeGo0ePSl2dfSVfAQBAYNC5c1pABYErLzdHcj/ZZu3ZQ4cpTstIk0njUmTzjlyzKHlBcelJc+108fLlr78tH+ful2HnnWMqa8J+2rbaxr6IoZ4AAAA2cc4jCrDLK7Qy/Wd3yM13L7L27KM9fYtWvGoqfJ7O+eckyEOzZ552OGhX0OqelUdrOjRc01stuX++vPz7R6y9M/OmoZ4EPwAAAMBGUTGxkr290C0LfevSDhu27JBtuz6zjpxw4ZBz5RujRnRZ8Rd/p+v3XXVRX6ksP2wdOTOCXxci+AEAALSf9mLSg9lxP13wW7l29p3WHvzBS08/LEsf+pW11z4UdwEAAIBP0MXeY2NjfX6ZBU9b8eSDUlZcaO3B12lbapv6soAMfkFBQdYjAK7SCwGtYKeVtwBP0Z+7iIgIqicCbqa/a4mJiTJt2jSz+Dvar6a6SpY88EtrD75O21LbtCO8LXME3JVa9+7dzTp9AOyhFwXx8fHcUIHH6UUoPRCAe+kQT130fcOGDdLY2GgdRXv97S8rZPXKZ609+CptQ23LjtLModnDWwRc8NNeCb1zBcAeuriqXhSw9iU8SS9Gjxw5YtZdBeBe+rv26aefEvw66dH5P5Ut762z9uBrtO20DTtDM4c3jYgKuOCnw4JGjBhh7QGwg4Y+DYDuoutiJScne9VdM3Q9ik0AnqG/a84NnXPPj6+WnK0fWnvwFdpm2nadpZnDm6YkBFzwCw0JlZQxKdYeAF+gvTr5+fncbQYA+CQt/z9vxkR6/nyItpW2WUeWbmhNM4dmD28RcMEvPCxc0salWXsAfIHeZXY4HNYeAAC+RwPErdMmMOfPB2gbaVu5EvqUZg7NHt4i4IKfFqDo37+/TLx8onUEbdGCCc4NZ6bfp4SEBDMkEQAA4HR0vtiDt1zPUg9eSNtE26azc/pa0qyhmcObit8FXPBTUZFRMmPGDGsPp6M/qD169CD8tVNZWRm9UgAA4Iy0QuT01EFmQXAHRaq6nLaBtoW2SWeqd7ZFs4ZmDm9y1pcBOlP34BcHZfo10+Xdd9+1jqAlDXs6GVXL0JaUlDChGwAAwA2iYmJl0oxZkjF1hgwaOco6Ck/I/WSbrM3KlDcyl7k8rLOl9PR0eflPL0u/hH7WEe8QsMGvqrpK1q5dK1OvmmodQUsa/PRHw9nbR/ADAABwr6RBw2R06ngZNnqsDBw8XPr0T2wKhr0kmMXzXaI9epXlZVJUkC/7d+801Tq3vr9e8nJzrFfYKys7SzIyMqRHZA/riHcI2OCnSg6VyKJFi+TRRx61jgAAAABdixvvvmveHfNk/vz5Etc7zjriPQJyjp9TbEyszJk7RyZPnmwdAQAAALqW1lk477zzzJQb+A7NFJotNGN4o4AOfvpL1btXb1n81GIZP368dRQA4Ek6n5iKuABwQvfu3WXatGkm/FFkzzdoltBModnCmyp5thTQQz2djtYclaLiIpl7y1xZvXq1dRQA4AnR0dEm/JWWllpHACCwadgLCwszQz3r6uoY8unltKdPQ1+f+D4SER5hHfU+BD9LbW2tHCo7JE8ufpI5fwDgYc6CUvA8Dd2NjY1y7Ngx6wgAoL10Tp8O79SePg3r3ozg10JDQ4McLj8sGzdulCcef4KlHgAAfi8xMVEKCwvNOqRcEgBA++iSDbfedqukpaWZOX3eOryzJYJfG3Sph4qKCnn77bclMzNT1ry1xnoGAAD/EhISYm580uMHAGc28fKJZnH2CRMmmKkK3rZkw1ch+H2F6upqqayulIKCAtn43kbZvGmz7NixQ/Lz86W8vNycKAEAAAD4F+3B06qqOipixIgRkjImRdLGpUn//v0lKjJKIiMjrVf6DoJfO2jAq6mtkbr6OjMURu+K6nwIAAAAAP5Jq6t269btePXpkFAJDwv3iSGdp0PwAwAAAAA/F9Dr+AEAAABAICD4AQAAAICfI/gBAAAAgJ8j+AEAAACAnyP4AQAAAICfI/gBAAAAgJ8j+AEAAACAnyP4AQAAAICfI/gBAAAAgJ8j+AEAAACAnyP4AQAAAICfI/gBAAAAgJ8j+AEAAACAnyP4AQAAAICfI/gBAAAAgJ8j+AEAAACAXxP5fy8xV9BZ1OnyAAAAAElFTkSuQmCC',
    planets: [
      {id:'mercury', he:'כוכב חמה', en:'Mercury', detailHe:'הקרוב ביותר לשמש. שנה קצרה מאוד וימים חמים מאוד.', detailEn:'Closest to the Sun. Very short year and extremely hot days.'},
      {id:'venus', he:'נוגה', en:'Venus', detailHe:'אטמוספרה עבה במיוחד. כוכב הלכת החם ביותר.', detailEn:'Extremely thick atmosphere. The hottest planet.'},
      {id:'earth', he:'כדור הארץ', en:'Earth', detailHe:'היחיד הידוע עם חיים ומים נוזליים בכמות גדולה.', detailEn:'The only known planet with life and abundant liquid water.'},
      {id:'mars', he:'מאדים', en:'Mars', detailHe:'הכוכב האדום. בו נמצא אולימפוס מונס, הר געש עצום.', detailEn:'The red planet. Home to Olympus Mons, a giant volcano.'},
      {id:'jupiter', he:'צדק', en:'Jupiter', detailHe:'הגדול ביותר. ידוע בכתם האדום הגדול שלו.', detailEn:'The largest planet. Famous for its Great Red Spot.'},
      {id:'saturn', he:'שבתאי', en:'Saturn', detailHe:'מפורסם בטבעות הגדולות והבולטות ביותר.', detailEn:'Known for the most prominent ring system.'},
      {id:'uranus', he:'אורנוס', en:'Uranus', detailHe:'נוטה על צידו כמעט לגמרי. כוכב לכת קפוא.', detailEn:'Tilted almost completely on its side. An ice giant.'},
      {id:'neptune', he:'נפטון', en:'Neptune', detailHe:'הרחוק ביותר מהשמש. רוחות מהחזקות במערכת השמש.', detailEn:'Farthest from the Sun. Among the strongest winds in the solar system.'}
    ]
  },
  agesHumanity: [
    {order:1, he:'תקופת האבן', en:'Stone Age', descHe:'כלי אבן, לקטים וציידים. ראשית ההתיישבות והאש.', descEn:'Stone tools, hunter-gatherers. Early settlement and mastery of fire.', detailHe:'כ-3.3 מיליון לפנה"ס עד כ-3300 לפנה"ס · כלי אבן, אש וחקלאות ראשונית.', detailEn:'c. 3.3 million BCE to c. 3300 BCE · stone tools, fire, early farming.'},
    {order:2, he:'תקופת הברונזה', en:'Bronze Age', descHe:'מתכות ראשונות, ערי מדינה וכתב מוקדם.', descEn:'Bronze metallurgy, city-states, and early writing.', detailHe:'כ-3300–1200 לפנה"ס · ברונזה, כתב, ערים ומסחר אזורי.', detailEn:'c. 3300–1200 BCE · bronze, writing, cities, and regional trade.'},
    {order:3, he:'תקופת הברזל', en:'Iron Age', descHe:'כלי ברזל, ממלכות גדולות וצבאות חזקים יותר.', descEn:'Iron tools, larger kingdoms, and stronger armies.', detailHe:'כ-1200–500 לפנה"ס · כלי ברזל, ממלכות, צבאות וטכנולוגיה מתקדמת יותר.', detailEn:'c. 1200–500 BCE · iron tools, kingdoms, armies, and stronger technology.'},
    {order:4, he:'ימי הביניים', en:'Middle Ages', descHe:'פאודליזם, טירות, מסחר וגידול ערים.', descEn:'Feudalism, castles, trade, and growing towns.', detailHe:'כ-500–1500 לספירה · פאודליזם, טירות, אוניברסיטאות ראשונות ומסחר.', detailEn:'c. 500–1500 CE · feudalism, castles, early universities, and trade.'},
    {order:5, he:'הרנסנס', en:'Renaissance', descHe:'תחיית האמנות והמדע. דפוס, גילויים ולמידה מחודשת.', descEn:'Revival of art and science. Printing, discovery, and renewed learning.', detailHe:'כ-1300–1600 · דפוס, אמנות, מדע, חקר העולם והומניזם.', detailEn:'c. 1300–1600 · printing, art, science, exploration, and humanism.'},
    {order:6, he:'המהפכה התעשייתית', en:'Industrial Revolution', descHe:'מכונות, מפעלים, קיטור וייצור המוני.', descEn:'Machines, factories, steam power, and mass production.', detailHe:'כ-1760–1900 · מנוע קיטור, מפעלים, רכבות וייצור המוני.', detailEn:'c. 1760–1900 · steam engines, factories, railways, and mass production.'},
    {order:7, he:'עידן המידע', en:'Information Age', descHe:'מחשבים, אינטרנט, תקשורת דיגיטלית ובינה.', descEn:'Computers, the internet, digital communication, and information systems.', detailHe:'מהמאה ה-20 המאוחרת עד היום · מחשבים, אינטרנט, טלפונים חכמים ובינה דיגיטלית.', detailEn:'Late 20th century to today · computers, the internet, smartphones, and digital intelligence.'}
  ],

  humanBodySet: {
    organFunction: [
      {promptHe:'איזה איבר מזרים דם לכל הגוף?', promptEn:'Which organ pumps blood through the body?', correct:'heart', choices:['heart','lungs','kidneys','stomach']},
      {promptHe:'איזה איבר אחראי בעיקר על נשימה?', promptEn:'Which organ is mainly responsible for breathing?', correct:'lungs', choices:['stomach','lungs','brain','kidneys']},
      {promptHe:'איזה איבר מסנן פסולת מהדם?', promptEn:'Which organ filters waste from the blood?', correct:'kidneys', choices:['kidneys','heart','brain','stomach']},
      {promptHe:'איזה איבר מסייע בעיכול מזון?', promptEn:'Which organ helps digest food?', correct:'stomach', choices:['brain','stomach','lungs','heart']}
    ],
    systemMatch: [
      {promptHe:'מוח', promptEn:'Brain', correct:'nervous', choices:['nervous','digestive','respiratory','skeletal']},
      {promptHe:'קיבה', promptEn:'Stomach', correct:'digestive', choices:['nervous','digestive','circulatory','skeletal']},
      {promptHe:'ריאות', promptEn:'Lungs', correct:'respiratory', choices:['respiratory','digestive','skeletal','nervous']},
      {promptHe:'עצם', promptEn:'Bone', correct:'skeletal', choices:['circulatory','skeletal','digestive','respiratory']}
    ],
    labels: [
      {id:'brain', he:'מוח', en:'Brain', zone:'brain'},
      {id:'heart', he:'לב', en:'Heart', zone:'heart'},
      {id:'lungs', he:'ריאות', en:'Lungs', zone:'lungs'},
      {id:'stomach', he:'קיבה', en:'Stomach', zone:'stomach'},
      {id:'kidneys', he:'כליות', en:'Kidneys', zone:'kidneys'}
    ]
  },

  tenCommandments: [
    {order:1,he:'אנכי ה׳ אלוהיך',en:'I am the Lord your God'},
    {order:2,he:'לא יהיה לך אלוהים אחרים',en:'No other gods'},
    {order:3,he:'לא תשא את שם ה׳ לשווא',en:'Do not take God’s name in vain'},
    {order:4,he:'זכור את יום השבת',en:'Remember the Sabbath'},
    {order:5,he:'כבד את אביך ואת אמך',en:'Honor your father and mother'},
    {order:6,he:'לא תרצח',en:'Do not murder'},
    {order:7,he:'לא תנאף',en:'Do not commit adultery'},
    {order:8,he:'לא תגנוב',en:'Do not steal'},
    {order:9,he:'לא תענה ברעך עד שקר',en:'Do not bear false witness'},
    {order:10,he:'לא תחמוד',en:'Do not covet'}
  ],
  holidaysMonths: [
    {holiday:{he:'ראש השנה',en:'Rosh Hashanah'}, month:{he:'תשרי',en:'Tishrei'}},
    {holiday:{he:'יום כיפור',en:'Yom Kippur'}, month:{he:'תשרי',en:'Tishrei'}},
    {holiday:{he:'סוכות',en:'Sukkot'}, month:{he:'תשרי',en:'Tishrei'}},
    {holiday:{he:'שמחת תורה',en:'Simchat Torah'}, month:{he:'תשרי',en:'Tishrei'}},
    {holiday:{he:'חנוכה',en:'Hanukkah'}, month:{he:'כסלו',en:'Kislev'}},
    {holiday:{he:'ט״ו בשבט',en:'Tu Bishvat'}, month:{he:'שבט',en:'Shevat'}},
    {holiday:{he:'פורים',en:'Purim'}, month:{he:'אדר',en:'Adar'}},
    {holiday:{he:'פסח',en:'Pesach'}, month:{he:'ניסן',en:'Nisan'}},
    {holiday:{he:'יום העצמאות',en:'Yom HaAtzmaut'}, month:{he:'אייר',en:'Iyar'}},
    {holiday:{he:'ל״ג בעומר',en:'Lag BaOmer'}, month:{he:'אייר',en:'Iyar'}},
    {holiday:{he:'שבועות',en:'Shavuot'}, month:{he:'סיון',en:'Sivan'}},
    {holiday:{he:'תשעה באב',en:'Tisha B’Av'}, month:{he:'אב',en:'Av'}}
  ],
  tannaim: [
    {he:'רבי עקיבא',en:'Rabbi Akiva',type:'tanna',quoteHe:'ואהבת לרעך כמוך — זה כלל גדול בתורה.',quoteEn:'Love your neighbor as yourself — this is a fundamental principle of the Torah.'},
    {he:'רבי מאיר',en:'Rabbi Meir',type:'tanna',quoteHe:'אל תסתכל בקנקן, אלא במה שיש בו.',quoteEn:'Do not look at the jug, but rather at what is inside it.'},
    {he:'הלל',en:'Hillel',type:'tanna',quoteHe:'אם אין אני לי, מי לי? וכשאני לעצמי, מה אני? ואם לא עכשיו, אימתי?',quoteEn:'If I am not for myself, who will be for me? And if I am only for myself, what am I? And if not now, when?'},
    {he:'שמאי',en:'Shammai',type:'tanna',quoteHe:'עשה תורתך קבע, אמור מעט ועשה הרבה, והוי מקבל את כל האדם בסבר פנים יפות.',quoteEn:'Make your Torah study a fixed practice, speak little and do much, and receive every person with a pleasant countenance.'},
    {he:'רבן יוחנן בן זכאי',en:'Rabban Yochanan ben Zakkai',type:'tanna',quoteHe:'אם למדת תורה הרבה, אל תחזיק טובה לעצמך — כי לכך נוצרת.',quoteEn:'If you have learned much Torah, do not take credit for yourself — because for this you were created.'},
    {he:'רבי יהודה הנשיא',en:'Rabbi Yehuda HaNasi',type:'tanna',quoteHe:'איזוהי דרך ישרה שיבור לו האדם? כל שהיא תפארת לעושה ותפארת לו מן האדם.',quoteEn:'Which is the right path for a man to choose? Whatever is honorable to himself and brings him honor from others.'},
    {he:'רבי שמעון בר יוחאי',en:'Rabbi Shimon bar Yochai',type:'tanna',quoteHe:'נוח לו לאדם שיפיל עצמו לתוך כבשן האש ואל ילבין פני חברו ברבים.',quoteEn:'It is better for a person to cast himself into a fiery furnace than to shame his fellow in public.'},
    {he:'רבי טרפון',en:'Rabbi Tarfon',type:'tanna',quoteHe:'היום קצר והמלאכה מרובה... לא עליך המלאכה לגמור, ולא אתה בן חורין ליבטל ממנה.',quoteEn:'The day is short and the work is great... It is not your duty to finish the work, but neither are you at liberty to neglect it.'},
    {he:'רבי אליעזר',en:'Rabbi Eliezer',type:'tanna',quoteHe:'יהי כבוד חברך חביב עליך כשלך.',quoteEn:'Let the honor of your fellow be as dear to you as your own.'},
    {he:'רבי יהושע',en:'Rabbi Yehoshua',type:'tanna',quoteHe:'עין הרע, ויצר הרע, ושנאת הבריות, מוציאין את האדם מן העולם.',quoteEn:'The evil eye, the evil inclination, and hatred of fellow creatures put a person out of the world.'},
    {he:'רב',en:'Rav',type:'amora',quoteHe:'לעולם יעסוק אדם בתורה ובמצוות אפילו שלא לשמה, שמתוך שלא לשמה בא לשמה.',quoteEn:'A person should always engage in Torah and Mitzvot even if not for their own sake, for eventually one comes to do them for the right motive.'},
    {he:'שמואל',en:'Shmuel',type:'amora',quoteHe:'דינא דמלכותא דינא.',quoteEn:'The law of the kingdom is the law.'},
    {he:'אביי',en:'Abaye',type:'amora',quoteHe:'לעולם יהיה אדם ערום ביראה, מענה רך משיב חמה.',quoteEn:'A person should always be clever in the fear of Heaven; a soft answer turns away wrath.'},
    {he:'רבא',en:'Rava',type:'amora',quoteHe:'בשעה שמכניסין אדם לדין אומרים לו: קבעת עתים לתורה? נשאת ונתת באמונה?',quoteEn:"When a person is brought for judgment, they are asked: 'Did you set fixed times for Torah study? Did you conduct your business affairs with integrity?'"},
    {he:'רב אשי',en:'Rav Ashi',type:'amora',quoteHe:'כל תלמיד חכם שאינו קשה כברזל אינו תלמיד חכם.',quoteEn:'Any Torah scholar who is not as tough as iron is not a true scholar.'},
    {he:'רבינא',en:'Ravina',type:'amora',quoteHe:'סוף הוראה.',quoteEn:'The end of the era of instruction.'},
    {he:'רב יוסף',en:'Rav Yosef',type:'amora',quoteHe:'סיני ועוקר הרים — סיני עדיף.',quoteEn:"Between a 'Sinai' (vast knowledge) and an 'Uprooter of Mountains' (analytical depth) — the 'Sinai' is preferred."},
    {he:'ריש לקיש',en:'Resh Lakish',type:'amora',quoteHe:'גדולה תשובה, שזדונות נעשות לו כזכויות.',quoteEn:'Great is repentance, for it transforms intentional sins into merits.'},
    {he:'רבי יוחנן',en:'Rabbi Yochanan',type:'amora',quoteHe:'טוב המלבין שיניים לחברו יותר ממאכילו חלב.',quoteEn:'Better is the one who shows a white-toothed smile to his friend than the one who gives him milk to drink.'},
    {he:'רב הונא',en:'Rav Huna',type:'amora',quoteHe:'כל העוסק בתורה בלבד, דומה כמי שאין לו אלוה.',quoteEn:'One who occupies himself only with Torah study (without acts of kindness) is like one who has no God.'}
  ],
  chronology: [
    {order:1,he:'אדם',en:'Adam'},{order:2,he:'נח',en:'Noah'},{order:3,he:'אברהם',en:'Abraham'},{order:4,he:'יצחק',en:'Isaac'},{order:5,he:'יעקב',en:'Jacob'},{order:6,he:'יוסף',en:'Joseph'},{order:7,he:'משה',en:'Moses'},{order:8,he:'יהושע',en:'Joshua'},{order:9,he:'שמואל',en:'Samuel'},{order:10,he:'דוד',en:'David'},{order:11,he:'שלמה',en:'Solomon'},{order:12,he:'ישעיהו',en:'Isaiah'}
  ],

  halacha: {
    stages: [
      {id:'daily', key:'halachaDailyStage', he:'חיי יומיום', en:'Daily Life', items:[
        {he:'אדם צריך להשתדל לומר לפחות 100 ברכות בכל יום.', en:'A person should strive to say at least 100 blessings (Berachot) every single day.', correct:true},
        {he:'מצוות ציצית חלה רק ביום ולא בלילה.', en:'The Mitzvah of Tzitzit only applies during the daytime and not at night.', correct:true},
        {he:'מותר ללבוש בגד שהוא תערובת של צמר ומשי.', en:'You are allowed to wear a garment that is a mix of wool and silk.', correct:true},
        {he:'מצוות מזוזה מחייבת קלף על כל דלת, כולל חדר האמבטיה.', en:'The Mitzvah of Mezuzah requires a parchment on every single door, including the bathroom.', correct:false},
        {he:'יש מצווה לתת צדקה גם אם אינך עשיר.', en:'It is a Mitzvah to give Tzedakah even if you are not wealthy.', correct:true},
        {he:'אם קמת בבוקר ואין מים ליד המיטה, מותר ללכת כל מרחק כדי למצוא כיור לנטילת ידיים.', en:'If you wake up in the morning and there is no water next to your bed, you can walk any distance to find a sink for Netilat Yadayim.', correct:false},
        {he:'יש לומר ברכה לפני שמריחים פרח או תבלין בעל ריח טוב.', en:'You must say a Beracha (blessing) before smelling a beautiful flower or spice.', correct:true},
        {he:'כשנועלים נעליים, השולחן ערוך אומר שיש לנעול קודם את הנעל הימנית.', en:'When putting on shoes, the Shulchan Aruch says you should put on the right shoe first.', correct:true},
        {he:'מותר להיכנס לבית כנסת רק כדי לקצר דרך לרחוב הבא.', en:'You are allowed to enter a Synagogue just to take a shortcut to the next street.', correct:false},
        {he:'אסור לעשות קעקוע.', en:'It is forbidden to get a tattoo.', correct:true}
      ]},
      {id:'shabbat', key:'halachaShabbatStage', he:'שבת', en:'Shabbat', items:[
        {he:'מותר לפתוח מטרייה בשבת אם יורד גשם חזק.', en:'You are allowed to open an umbrella on Shabbat as long as it is raining heavily.', correct:false},
        {he:'מותר לטלטל אבן או מטבע בשבת כל עוד לא מתכוונים להשתמש בהם.', en:'It is permitted to move a stone or a coin on Shabbat as long as you do\'t intend to use it.', correct:false},
        {he:'מותר לבקש מחבר שאינו יהודי להדליק עבורך את האור בשבת אם שכחת.', en:'You may ask a non-Jewish friend to turn on the lights for you on Shabbat if you forgot.', correct:false},
        {he:'יש מצווה לאכול שלוש סעודות בשבת.', en:'It is a Mitzvah to eat three meals on Shabbat (Shalosh Seudot).', correct:true},
        {he:'מותר להכין סלט בשבת באמצעות פומפייה דקה מאוד.', en:'You are allowed to make a salad on Shabbat using a very fine grater.', correct:false},
        {he:'מותר לשחות בבריכה בשבת במקום שאין בו עירוב.', en:'You are allowed to swim in a pool on Shabbat in a place where there is no Eruv.', correct:false},
        {he:'מותר לסחוט לימון ישירות על חתיכת דג בשבת.', en:'It is permitted to squeeze a lemon directly onto a piece of fish on Shabbat.', correct:true},
        {he:'אפשר להשתמש במטלית רטובה כדי לנגב שפיכה מעל השולחן בשבת.', en:'You can use a wet cloth to wipe a spill off a table on Shabbat.', correct:false},
        {he:'מותר לנגן בכלי נגינה כמו גיטרה בשבת.', en:'You are allowed to play a musical instrument like a guitar on Shabbat.', correct:false},
        {he:'יש מצווה להדליק לפחות שני נרות לפני כניסת שבת.', en:'It is a Mitzvah to light at least two candles before Shabbat begins.', correct:true}
      ]},
      {id:'kosher', key:'halachaKosherStage', he:'כשרות', en:'Kosher', items:[
        {he:'יש להמתין 6 שעות אחרי אכילת בשר לפני שאוכלים חלב.', en:'You must wait 6 hours after eating meat before you can eat dairy.', correct:true},
        {he:'אסור לאכול דג ובשר יחד על אותה צלחת.', en:'It is forbidden to eat fish and meat together on the same plate.', correct:true},
        {he:'מותר לאכול "צ\'יזבורגר" אם הגבינה טבעונית (עשויה מסויה).', en:'You are allowed to eat a "Cheeseburger" if the cheese is vegan (made from soy).', correct:true},
        {he:'אם חתיכת לחם נפלה על הרצפה, היא נעשית לא כשרה.', en:'If you drop a piece of bread on the floor, it becomes non-kosher.', correct:false},
        {he:'מותר לאכול תותים בלי לבדוק אותם תחילה מחרקים.', en:'You are allowed to eat strawberries without checking them for bugs first.', correct:false},
        {he:'צריך ליטול ידיים לפני אכילת כל כמות של לחם.', en:'You must wash Netilat Yadayim before eating any amount of bread.', correct:true},
        {he:'אם שכחת לברך וכבר בלעת את האוכל, עליך לברך בכל זאת.', en:'If you forget to say a blessing and already swallowed the food, you should say the blessing anyway.', correct:false},
        {he:'דבש הוא כשר אף על פי שהוא מיוצר בידי חרק (הדבורה) שאינו כשר.', en:'Honey is kosher even though it is produced by an insect (the bee) which is not kosher.', correct:true},
        {he:'צריך לומר ברכה אחרונה אם אכלת כמות מסוימת של אוכל.', en:'You must say a "Final Blessing" (Beracha Achrona) if you ate a certain amount of food.', correct:true},
        {he:'ביצים שיש בהן כתם דם אסורות באכילה.', en:'Eggs that have a blood spot in them are forbidden to be eaten.', correct:true}
      ]},
      {id:'interpersonal', key:'halachaInterpersonalStage', he:'בין אדם לחברו', en:'Interpersonal', items:[
        {he:'יש מצווה חיובית להחזיר אבידה לבעליה.', en:'It is a positive Mitzvah to return a lost object to its owner.', correct:true},
        {he:'אסור לשנות מן האמת אפילו כדי להשכין שלום בין שני חברים.', en:'It is forbidden to tell a lie even to keep the peace between two friends.', correct:false},
        {he:'יש מצווה לעמוד מפני זקן או תלמיד חכם שנכנס לחדר.', en:'It is a Mitzvah to stand up when an elderly person or a Torah scholar enters the room.', correct:true},
        {he:'מותר לתת כינוי לחבר גם אם הוא עלול להביך אותו מעט.', en:'You are allowed to give a nickname to a friend even if it might slightly embarrass them.', correct:false},
        {he:'אסור לשנוא יהודי אחר בלב, גם אם הוא היה לא נחמד אליך.', en:'You are not allowed to "hate" another Jew in your heart, even if they were mean to you.', correct:true},
        {he:'אם רואים אדם בסכנה, אסור לעמוד מן הצד; חייבים לנסות לעזור לו.', en:'If you see someone in danger, you are not allowed to stand by; you must try to help them.', correct:true},
        {he:'יש מצווה לשלם לפועל באותו היום שבו סיים את עבודתו.', en:'It is a Mitzvah to pay a worker on the very same day they finish their job.', correct:true},
        {he:'מותר לומר לשון הרע אם המידע שאתה מוסר הוא 100% אמת.', en:'You are allowed to tell "Lashon Hara" (gossip) if the information you are sharing is 100% true.', correct:false},
        {he:'עליך לאהוב כל יהודי אחר כפי שאתה אוהב את עצמך.', en:'You should love every fellow Jew as much as you love yourself.', correct:true},
        {he:'אסור לנקום במי שסירב להשאיל לך עיפרון.', en:'It is forbidden to take revenge on someone who refused to lend you a pencil.', correct:true}
      ]}
    ]
  },


  continentQuiz: {
    continents: [
      {id:'asia',he:'אסיה',en:'Asia',color:'#c0392b'},
      {id:'europe',he:'אירופה',en:'Europe',color:'#3498db'},
      {id:'africa',he:'אפריקה',en:'Africa',color:'#8e44ad'},
      {id:'northAmerica',he:'אמריקה הצפונית',en:'North America',color:'#f39c12'},
      {id:'southAmerica',he:'אמריקה הדרומית',en:'South America',color:'#27ae60'}
    ],
    countries: [
      {he:'ישראל',en:'Israel',continent:'asia',flag:'🇮🇱'},
      {he:'יפן',en:'Japan',continent:'asia',flag:'🇯🇵'},
      {he:'הודו',en:'India',continent:'asia',flag:'🇮🇳'},
      {he:'גרמניה',en:'Germany',continent:'europe',flag:'🇩🇪'},
      {he:'צרפת',en:'France',continent:'europe',flag:'🇫🇷'},
      {he:'ספרד',en:'Spain',continent:'europe',flag:'🇪🇸'},
      {he:'מצרים',en:'Egypt',continent:'africa',flag:'🇪🇬'},
      {he:'קניה',en:'Kenya',continent:'africa',flag:'🇰🇪'},
      {he:'ניגריה',en:'Nigeria',continent:'africa',flag:'🇳🇬'},
      {he:'קנדה',en:'Canada',continent:'northAmerica',flag:'🇨🇦'},
      {he:'מקסיקו',en:'Mexico',continent:'northAmerica',flag:'🇲🇽'},
      {he:'ארצות הברית',en:'United States',continent:'northAmerica',flag:'🇺🇸'},
      {he:'ברזיל',en:'Brazil',continent:'southAmerica',flag:'🇧🇷'},
      {he:'ארגנטינה',en:'Argentina',continent:'southAmerica',flag:'🇦🇷'},
      {he:'פרו',en:'Peru',continent:'southAmerica',flag:'🇵🇪'},
      {he:'יוון',en:'Greece',continent:'europe',flag:'🇬🇷'},
      {he:'סין',en:'China',continent:'asia',flag:'🇨🇳'},
      {he:'מרוקו',en:'Morocco',continent:'africa',flag:'🇲🇦'},
      {he:'גואטמלה',en:'Guatemala',continent:'northAmerica',flag:'🇬🇹'},
      {he:'צ׳ילה',en:'Chile',continent:'southAmerica',flag:'🇨🇱'},
      {he:'איטליה',en:'Italy',continent:'europe',flag:'🇮🇹'},
      {he:'בריטניה',en:'United Kingdom',continent:'europe',flag:'🇬🇧'},
      {he:'דרום אפריקה',en:'South Africa',continent:'africa',flag:'🇿🇦'},
      {he:'אתיופיה',en:'Ethiopia',continent:'africa',flag:'🇪🇹'},
      {he:'דרום קוריאה',en:'South Korea',continent:'asia',flag:'🇰🇷'},
      {he:'אינדונזיה',en:'Indonesia',continent:'asia',flag:'🇮🇩'},
      {he:'קולומביה',en:'Colombia',continent:'southAmerica',flag:'🇨🇴'}
    ]
  },
  worldCountries: {
    europe:[
      {he:'אלבניה',en:'Albania'},{he:'אנדורה',en:'Andorra'},{he:'אוסטריה',en:'Austria'},{he:'בלארוס',en:'Belarus'},{he:'בלגיה',en:'Belgium'},{he:'בוסניה והרצגובינה',en:'Bosnia and Herzegovina'},{he:'בולגריה',en:'Bulgaria'},{he:'קרואטיה',en:'Croatia'},{he:'קפריסין',en:'Cyprus'},{he:'צכיה',en:'Czech Republic'},{he:'דנמרק',en:'Denmark'},{he:'אסטוניה',en:'Estonia'},{he:'פינלנד',en:'Finland'},{he:'צרפת',en:'France'},{he:'גאורגיה',en:'Georgia'},{he:'גרמניה',en:'Germany'},{he:'יוון',en:'Greece'},{he:'הונגריה',en:'Hungary'},{he:'איסלנד',en:'Iceland'},{he:'אירלנד',en:'Ireland'},{he:'איטליה',en:'Italy'},{he:'קוסובו',en:'Kosovo'},{he:'לטביה',en:'Latvia'},{he:'ליכטנשטיין',en:'Liechtenstein'},{he:'ליטא',en:'Lithuania'},{he:'לוקסמבורג',en:'Luxembourg'},{he:'מלטה',en:'Malta'},{he:'מולדובה',en:'Moldova'},{he:'מונקו',en:'Monaco'},{he:'מונטנגרו',en:'Montenegro'},{he:'הולנד',en:'Netherlands'},{he:'צפון מקדוניה',en:'North Macedonia'},{he:'נורווגיה',en:'Norway'},{he:'פולין',en:'Poland'},{he:'פורטוגל',en:'Portugal'},{he:'רומניה',en:'Romania'},{he:'רוסיה',en:'Russia'},{he:'סן מרינו',en:'San Marino'},{he:'סרביה',en:'Serbia'},{he:'סלובקיה',en:'Slovakia'},{he:'סלובניה',en:'Slovenia'},{he:'ספרד',en:'Spain'},{he:'שוודיה',en:'Sweden'},{he:'שווייץ',en:'Switzerland'},{he:'אוקראינה',en:'Ukraine'},{he:'בריטניה',en:'United Kingdom'},{he:'ותיקן',en:'Vatican City'},{he:'ארמניה',en:'Armenia'},{he:'אזרבייגאן',en:'Azerbaijan'}
    ],
    asia:[
      {he:'אפגניסטן',en:'Afghanistan'},{he:'בחריין',en:'Bahrain'},{he:'בנגלדש',en:'Bangladesh'},{he:'בהוטן',en:'Bhutan'},{he:'ברוניי',en:'Brunei'},{he:'קמבודיה',en:'Cambodia'},{he:'סין',en:'China'},{he:'הודו',en:'India'},{he:'אינדונזיה',en:'Indonesia'},{he:'איראן',en:'Iran'},{he:'עיראק',en:'Iraq'},{he:'ישראל',en:'Israel'},{he:'יפן',en:'Japan'},{he:'ירדן',en:'Jordan'},{he:'קזחסטן',en:'Kazakhstan'},{he:'קוריאה הצפונית',en:'North Korea'},{he:'קוריאה הדרומית',en:'South Korea'},{he:'כווית',en:'Kuwait'},{he:'קירגיזסטן',en:'Kyrgyzstan'},{he:'לאוס',en:'Laos'},{he:'לבנון',en:'Lebanon'},{he:'מלזיה',en:'Malaysia'},{he:'מלדיביים',en:'Maldives'},{he:'מונגוליה',en:'Mongolia'},{he:'מיאנמר',en:'Myanmar'},{he:'נפאל',en:'Nepal'},{he:'עומאן',en:'Oman'},{he:'פקיסטן',en:'Pakistan'},{he:'הפיליפינים',en:'Philippines'},{he:'קטר',en:'Qatar'},{he:'סעודיה',en:'Saudi Arabia'},{he:'סינגפור',en:'Singapore'},{he:'סרי לנקה',en:'Sri Lanka'},{he:'סוריה',en:'Syria'},{he:'טגיקיסטן',en:'Tajikistan'},{he:'תאילנד',en:'Thailand'},{he:'טימור-לסטה',en:'Timor-Leste'},{he:'טורקמניסטן',en:'Turkmenistan'},{he:'איחוד האמירויות',en:'United Arab Emirates'},{he:'אוזבקיסטן',en:'Uzbekistan'},{he:'וייטנאם',en:'Vietnam'},{he:'תימן',en:'Yemen'}
    ],
    africa:[
      {he:'אלגיריה',en:'Algeria'},{he:'אנגולה',en:'Angola'},{he:'בנין',en:'Benin'},{he:'בוטסואנה',en:'Botswana'},{he:'בורקינה פאסו',en:'Burkina Faso'},{he:'בורונדי',en:'Burundi'},{he:'קמרון',en:'Cameroon'},{he:'קאבו ורדה',en:'Cape Verde'},{he:'הרפובליקה המרכז-אפריקאית',en:'Central African Republic'},{he:'צאד',en:'Chad'},{he:'קומורו',en:'Comoros'},{he:'קונגו',en:'Congo'},{he:'גיבוטי',en:'Djibouti'},{he:'מצרים',en:'Egypt'},{he:'גינאה המשוונית',en:'Equatorial Guinea'},{he:'אריתריאה',en:'Eritrea'},{he:'אתיופיה',en:'Ethiopia'},{he:'גאבון',en:'Gabon'},{he:'גמביה',en:'Gambia'},{he:'גאנה',en:'Ghana'},{he:'גינאה',en:'Guinea'},{he:'גינאה-ביסאו',en:'Guinea-Bissau'},{he:'חוף השנהב',en:'Ivory Coast'},{he:'קניה',en:'Kenya'},{he:'לסוטו',en:'Lesotho'},{he:'ליבריה',en:'Liberia'},{he:'לוב',en:'Libya'},{he:'מדגסקר',en:'Madagascar'},{he:'מלאווי',en:'Malawi'},{he:'מאלי',en:'Mali'},{he:'מאוריטניה',en:'Mauritania'},{he:'מאוריציוס',en:'Mauritius'},{he:'מרוקו',en:'Morocco'},{he:'מוזמביק',en:'Mozambique'},{he:'נמיביה',en:'Namibia'},{he:'ניזר',en:'Niger'},{he:'ניגריה',en:'Nigeria'},{he:'רואנדה',en:'Rwanda'},{he:'סאו טומה ופרינסיפה',en:'Sao Tome and Principe'},{he:'סנגל',en:'Senegal'},{he:'סיירה לאונה',en:'Sierra Leone'},{he:'סומליה',en:'Somalia'},{he:'דרום אפריקה',en:'South Africa'},{he:'דרום סודן',en:'South Sudan'},{he:'סודן',en:'Sudan'},{he:'אסוואטיני',en:'Eswatini'},{he:'טנזניה',en:'Tanzania'},{he:'טוגו',en:'Togo'},{he:'תוניסיה',en:'Tunisia'},{he:'אוגנדה',en:'Uganda'},{he:'זמביה',en:'Zambia'},{he:'זימבבואה',en:'Zimbabwe'},{he:'הרפובליקה הדמוקרטית של קונגו',en:'Democratic Republic of the Congo'}
    ],
    northAmerica:[
      {he:'אנטיגואה וברבודה',en:'Antigua and Barbuda'},{he:'בהאמה',en:'Bahamas'},{he:'ברבדוס',en:'Barbados'},{he:'בליז',en:'Belize'},{he:'קנדה',en:'Canada'},{he:'קוסטה ריקה',en:'Costa Rica'},{he:'קובה',en:'Cuba'},{he:'דומיניקה',en:'Dominica'},{he:'הרפובליקה הדומיניקנית',en:'Dominican Republic'},{he:'אל סלבדור',en:'El Salvador'},{he:'גרנדה',en:'Grenada'},{he:'גואטמלה',en:'Guatemala'},{he:'האיטי',en:'Haiti'},{he:'הונדורס',en:'Honduras'},{he:'גמייקה',en:'Jamaica'},{he:'מקסיקו',en:'Mexico'},{he:'ניקרגואה',en:'Nicaragua'},{he:'פנמה',en:'Panama'},{he:'סנט קיטס ונוויס',en:'Saint Kitts and Nevis'},{he:'סנט לוסיה',en:'Saint Lucia'},{he:'סנט וינסנט והגרנדינים',en:'Saint Vincent and the Grenadines'},{he:'טרינידד וטובגו',en:'Trinidad and Tobago'},{he:'ארצות הברית',en:'United States'}
    ],
    southAmerica:[
      {he:'ארגנטינה',en:'Argentina'},{he:'בוליביה',en:'Bolivia'},{he:'ברזיל',en:'Brazil'},{he:'צילה',en:'Chile'},{he:'קולומביה',en:'Colombia'},{he:'אקוודור',en:'Ecuador'},{he:'גיאנה',en:'Guyana'},{he:'פרגוואי',en:'Paraguay'},{he:'פרו',en:'Peru'},{he:'סורינאם',en:'Suriname'},{he:'אורוגוואי',en:'Uruguay'},{he:'ונצואלה',en:'Venezuela'}
    ],
    oceania:[
      {he:'אוסטרליה',en:'Australia'},{he:'פיגי',en:'Fiji'},{he:'קיריבאטי',en:'Kiribati'},{he:'איי מרשל',en:'Marshall Islands'},{he:'מיקרונזיה',en:'Micronesia'},{he:'נאורו',en:'Nauru'},{he:'ניו זילנד',en:'New Zealand'},{he:'פלאו',en:'Palau'},{he:'פפואה גינאה החדשה',en:'Papua New Guinea'},{he:'סמואה',en:'Samoa'},{he:'איי שלמה',en:'Solomon Islands'},{he:'טונגה',en:'Tonga'},{he:'טובאלו',en:'Tuvalu'},{he:'ונואטו',en:'Vanuatu'}
    ]
  },
  worldCapitals:[
    {country:{he:'הרפובליקה הדומיניקנית',en:'Dominican Republic'}, capital:{he:'סנטו דומינגו',en:'Santo Domingo'}},
    {country:{he:'ניגריה',en:'Nigeria'}, capital:{he:'אבוגה',en:'Abuja'}},
    {country:{he:'קטר',en:'Qatar'}, capital:{he:'דוחה',en:'Doha'}},
    {country:{he:'דרום סודן',en:'South Sudan'}, capital:{he:'גובה',en:'Juba'}},
    {country:{he:'הרפובליקה הצכית',en:'Czech Republic'}, capital:{he:'פראג',en:'Prague'}},
    {country:{he:'אסטוניה',en:'Estonia'}, capital:{he:'טלין',en:'Tallinn'}},
    {country:{he:'קמבודיה',en:'Cambodia'}, capital:{he:'פנום פן',en:'Phnom Penh'}},
    {country:{he:'סין',en:'China'}, capital:{he:'בייגינג',en:'Beijing'}},
    {country:{he:'מונגוליה',en:'Mongolia'}, capital:{he:'אולן בטור',en:'Ulaanbaatar'}},
    {country:{he:'ארצות הברית',en:'United States'}, capital:{he:'וושינגטון די סי',en:'Washington D.C.'}},
    {country:{he:'גינאה המשוונית',en:'Equatorial Guinea'}, capital:{he:'מלאבו',en:'Malabo'}},
    {country:{he:'ברזיל',en:'Brazil'}, capital:{he:'ברזיליה',en:'Brasilia'}},
    {country:{he:'אלגיריה',en:'Algeria'}, capital:{he:'אלגיר',en:'Algiers'}},
    {country:{he:'דומיניקה',en:'Dominica'}, capital:{he:'רוסו',en:'Roseau'}},
    {country:{he:'איי מרשל',en:'Marshall Islands'}, capital:{he:'מגורו',en:'Majuro'}},
    {country:{he:'גאורגיה',en:'Georgia'}, capital:{he:'טביליסי',en:'Tbilisi'}},
    {country:{he:'טורקיה',en:'Turkey'}, capital:{he:'אנקרה',en:'Ankara'}},
    {country:{he:'ארמניה',en:'Armenia'}, capital:{he:'ירוואן',en:'Yerevan'}},
    {country:{he:'פולין',en:'Poland'}, capital:{he:'וורשה',en:'Warsaw'}},
    {country:{he:'מקסיקו',en:'Mexico'}, capital:{he:'מקסיקו סיטי',en:'Mexico City'}}
  ],
  officialLanguages:[
    {langs:{he:'דנית',en:'Danish'}, country:{he:'דנמרק',en:'Denmark'}, capital:{he:'קופנהגן',en:'Copenhagen'}},
    {langs:{he:'הולנדית, צרפתית, גרמנית',en:'Dutch, French, German'}, country:{he:'בלגיה',en:'Belgium'}, capital:{he:'בריסל',en:'Brussels'}},
    {langs:{he:'גרמנית, צרפתית, איטלקית, רומנש',en:'German, French, Italian, Romansh'}, country:{he:'שווייץ',en:'Switzerland'}, capital:{he:'ברן',en:'Bern'}},
    {langs:{he:'יוונית, טורקית',en:'Greek, Turkish'}, country:{he:'קפריסין',en:'Cyprus'}, capital:{he:'ניקוסיה',en:'Nicosia'}},
    {langs:{he:'עברית',en:'Hebrew'}, country:{he:'ישראל',en:'Israel'}, capital:{he:'ירושלים',en:'Jerusalem'}},
    {langs:{he:'חמרית',en:'Khmer'}, country:{he:'קמבודיה',en:'Cambodia'}, capital:{he:'פנום פן',en:'Phnom Penh'}},
    {langs:{he:'ערבית, כורדית',en:'Arabic, Kurdish'}, country:{he:'עיראק',en:'Iraq'}, capital:{he:'בגדאד',en:'Baghdad'}},
    {langs:{he:'אנגלית, אפריקאנס, זולו ואחרות',en:'English, Afrikaans, Zulu and others'}, country:{he:'דרום אפריקה',en:'South Africa'}, capital:{he:'פרטוריה',en:'Pretoria'}},
    {langs:{he:'קטלנית',en:'Catalan'}, country:{he:'אנדורה',en:'Andorra'}, capital:{he:'אנדורה לה ולה',en:'Andorra la Vella'}},
    {langs:{he:'סינהלה, טמילית',en:'Sinhala, Tamil'}, country:{he:'סרי לנקה',en:'Sri Lanka'}, capital:{he:'סרי ג׳ייוורדנפורה קוטה',en:'Sri Jayawardenepura Kotte'}},
    {langs:{he:'אנגלית, מאורית',en:'English, Maori'}, country:{he:'ניו זילנד',en:'New Zealand'}, capital:{he:'וולינגטון',en:'Wellington'}},
    {langs:{he:'פשטו, פרסית',en:'Pashto, Persian'}, country:{he:'אפגניסטן',en:'Afghanistan'}, capital:{he:'קאבול',en:'Kabul'}},
    {langs:{he:'טגאלוג, אנגלית',en:'Tagalog, English'}, country:{he:'הפיליפינים',en:'Philippines'}, capital:{he:'מנילה',en:'Manila'}},
    {langs:{he:'הינדי, אנגלית',en:'Hindi, English'}, country:{he:'הודו',en:'India'}, capital:{he:'ניו דלהי',en:'New Delhi'}},
    {langs:{he:'אנגלית, מלאית, סינית, טמילית',en:'English, Malay, Chinese, Tamil'}, country:{he:'סינגפור',en:'Singapore'}, capital:{he:'סינגפור',en:'Singapore'}},
    {langs:{he:'סותו, אנגלית',en:'Sotho, English'}, country:{he:'לסוטו',en:'Lesotho'}, capital:{he:'מזרו',en:'Maseru'}},
    {langs:{he:'איטלקית, לטינית',en:'Italian, Latin'}, country:{he:'ותיקן',en:'Vatican City'}, capital:{he:'קריית הוותיקן',en:'Vatican City'}},
    {langs:{he:'אמהרית',en:'Amharic'}, country:{he:'אתיופיה',en:'Ethiopia'}, capital:{he:'אדיס אבבה',en:'Addis Ababa'}},
    {langs:{he:'אנגלית, אורדו',en:'English, Urdu'}, country:{he:'פקיסטן',en:'Pakistan'}, capital:{he:'איסלאמאבאד',en:'Islamabad'}},
    {langs:{he:'מלגשית, צרפתית',en:'Malagasy, French'}, country:{he:'מדגסקר',en:'Madagascar'}, capital:{he:'אנטננריבו',en:'Antananarivo'}}
  ],
  countryFlags:[
    {country:{he:'ישראל',en:'Israel'}, correct:'🇮🇱', choices:['🇮🇱','🇬🇷','🇫🇮','🇦🇷']},
    {country:{he:'יפן',en:'Japan'}, correct:'🇯🇵', choices:['🇰🇷','🇯🇵','🇧🇩','🇨🇭']},
    {country:{he:'ברזיל',en:'Brazil'}, correct:'🇧🇷', choices:['🇲🇽','🇧🇷','🇵🇹','🇦🇺']},
    {country:{he:'גרמניה',en:'Germany'}, correct:'🇩🇪', choices:['🇧🇪','🇩🇪','🇪🇪','🇱🇹']},
    {country:{he:'צרפת',en:'France'}, correct:'🇫🇷', choices:['🇮🇹','🇷🇴','🇫🇷','🇳🇱']},
    {country:{he:'קנדה',en:'Canada'}, correct:'🇨🇦', choices:['🇨🇦','🇦🇹','🇵🇪','🇩🇰']},
    {country:{he:'מקסיקו',en:'Mexico'}, correct:'🇲🇽', choices:['🇲🇽','🇮🇹','🇭🇺','🇧🇬']},
    {country:{he:'בריטניה',en:'United Kingdom'}, correct:'🇬🇧', choices:['🇬🇧','🇦🇺','🇳🇿','🇺🇸']},
    {country:{he:'איטליה',en:'Italy'}, correct:'🇮🇹', choices:['🇮🇹','🇮🇪','🇲🇽','🇭🇺']},
    {country:{he:'אוקראינה',en:'Ukraine'}, correct:'🇺🇦', choices:['🇺🇦','🇸🇪','🇵🇱','🇷🇴']},
    {country:{he:'שוויץ',en:'Switzerland'}, correct:'🇨🇭', choices:['🇯🇵','🇩🇰','🇨🇭','🇦🇹']},
    {country:{he:'ארצות הברית',en:'United States'}, correct:'🇺🇸', choices:['🇺🇸','🇱🇷','🇬🇧','🇲🇾']}
  ],
  scrambledCountries:[
    {scrambled:{he:'ודוה', en:'NDAII'}, item:{he:'הודו',en:'India'}, aliases:['india']},
    {scrambled:{he:'ליזבר', en:'LIZARB'}, item:{he:'ברזיל',en:'Brazil'}, aliases:['brazil']},
    {scrambled:{he:'פןי', en:'PAJNA'}, item:{he:'יפן',en:'Japan'}, aliases:['japan']},
    {scrambled:{he:'תרצפ', en:'ECNRAF'}, item:{he:'צרפת',en:'France'}, aliases:['france']},
    {scrambled:{he:'נהמירג', en:'MRAGYEN'}, item:{he:'גרמניה',en:'Germany'}, aliases:['germany']},
    {scrambled:{he:'נדהק', en:'AADNCA'}, item:{he:'קנדה',en:'Canada'}, aliases:['canada']},
    {scrambled:{he:'סקימקו', en:'OCIMEX'}, item:{he:'מקסיקו',en:'Mexico'}, aliases:['mexico']},
    {scrambled:{he:'הילטאי', en:'LTYIA'}, item:{he:'איטליה',en:'Italy'}, aliases:['italy']},
    {scrambled:{he:'ריםצמ', en:'TYPGE'}, item:{he:'מצרים',en:'Egypt'}, aliases:['egypt']},
    {scrambled:{he:'שרלאי', en:'RALEIS'}, item:{he:'ישראל',en:'Israel'}, aliases:['israel']},
    {scrambled:{he:'אירוק', en:'AREOK'}, item:{he:'קוריאה',en:'Korea'}, aliases:['korea']},
    {scrambled:{he:'הנריגיה', en:'GAREIIN'}, item:{he:'ניגריה',en:'Nigeria'}, aliases:['nigeria']}
  ],
  fastMultiplication: Array.from({length:20}, (_,i) => {
    const a = [11,5,9,9,5,2,2,7,9,7,9,8,12,6,4,3,11,7,8,12][i];
    const b = [9,4,7,10,11,4,13,3,10,6,10,11,7,12,8,9,12,8,7,6][i];
    return {prompt:`${a} × ${b}`, answer:a*b};
  }),
  fastAddition: Array.from({length:20}, (_,i) => {
    const a = [15,48,121,36,207,18,99,43,75,64,88,123,57,91,240,17,68,135,42,500][i];
    const b = [27,16,39,84,93,72,101,57,25,36,12,77,43,19,60,83,32,65,58,125][i];
    return {prompt:`${a} + ${b}`, answer:a+b};
  }),

  romanMath: Array.from({length:20}, (_,i) => {
    const pairs = [
      ['XV','XXVII',42],['XLVIII','XVI',64],['CXXI','XXXIX',160],['XXXVI','LXXXIV',120],['CCVII','XCIII',300],
      ['XVIII','LXXII',90],['XCIX','CI',200],['XLIII','LVII',100],['LXXV','XXV',100],['LXIV','XXXVI',100],
      ['LXXXVIII','XII',100],['CXXIII','LXXVII',200],['LVII','XLIII',100],['XCI','XIX',110],['CCXL','LX',300],
      ['XVII','LXXXIII',100],['LXVIII','XXXII',100],['CXXXV','LXV',200],['XLII','LVIII',100],['D','CXXV',625]
    ];
    const p = pairs[i];
    return {prompt:`${p[0]} + ${p[1]}`, answer:p[2]};
  }),
  romanNumerals:[
    {roman:'ML',answer:1050},{roman:'L',answer:50},{roman:'CDVII',answer:407},{roman:'MDCCCXCVI',answer:1896},{roman:'XLIX',answer:49},
    {roman:'XLVI',answer:46},{roman:'XI',answer:11},{roman:'XLIV',answer:44},{roman:'XVII',answer:17},{roman:'CCCXXXI',answer:331},
    {roman:'XXVIII',answer:28},{roman:'LXXX',answer:80},{roman:'XLV',answer:45},{roman:'IX',answer:9},{roman:'LXXXIV',answer:84},
    {roman:'DCCXCIX',answer:799},{roman:'XXXI',answer:31},{roman:'XXX',answer:30},{roman:'XIX',answer:19},{roman:'XX',answer:20}
  ],

  relations: [
    {a:{he:'אברהם',en:'Abraham'},b:{he:'יצחק',en:'Isaac'},correct:'fatherOf',choices:['fatherOf','teacherOf','brotherOf','uncleOf']},
    {a:{he:'שרה',en:'Sarah'},b:{he:'יצחק',en:'Isaac'},correct:'motherOf',choices:['motherOf','sisterOf','wifeOf','daughterInLawOf']},
    {a:{he:'מרים',en:'Miriam'},b:{he:'משה',en:'Moses'},correct:'sisterOf',choices:['sisterOf','motherOf','wifeOf','teacherOf']},
    {a:{he:'משה',en:'Moses'},b:{he:'יהושע',en:'Joshua'},correct:'teacherOf',choices:['teacherOf','fatherOf','brotherOf','successorOf']},
    {a:{he:'יהושע',en:'Joshua'},b:{he:'משה',en:'Moses'},correct:'studentOf',choices:['studentOf','brotherOf','fatherOf','uncleOf']},
    {a:{he:'רות',en:'Ruth'},b:{he:'נעמי',en:'Naomi'},correct:'daughterInLawOf',choices:['daughterInLawOf','sisterOf','motherOf','friendOf']},
    {a:{he:'דוד',en:'David'},b:{he:'יונתן',en:'Jonathan'},correct:'friendOf',choices:['friendOf','brotherOf','teacherOf','successorOf']},
    {a:{he:'רחל',en:'Rachel'},b:{he:'יעקב',en:'Jacob'},correct:'wifeOf',choices:['wifeOf','sisterOf','motherOf','daughterInLawOf']},
    {a:{he:'לאה',en:'Leah'},b:{he:'רחל',en:'Rachel'},correct:'sisterOf',choices:['sisterOf','motherOf','wifeOf','friendOf']},
    {a:{he:'דוד',en:'David'},b:{he:'שלמה',en:'Solomon'},correct:'fatherOf',choices:['fatherOf','teacherOf','brotherOf','uncleOf']},
    {a:{he:'אליהו',en:'Elijah'},b:{he:'אלישע',en:'Elisha'},correct:'teacherOf',choices:['teacherOf','brotherOf','fatherOf','friendOf']},
    {a:{he:'אברהם',en:'Abraham'},b:{he:'לוט',en:'Lot'},correct:'uncleOf',choices:['uncleOf','brotherOf','teacherOf','fatherOf']}
  ],

  equationCompletion: [
    {prompt:'8 × __ = 64', answer:8},
    {prompt:'__ + 15 = 42', answer:27},
    {prompt:'7 × __ = 49', answer:7},
    {prompt:'__ - 18 = 32', answer:50},
    {prompt:'9 × __ = 81', answer:9},
    {prompt:'__ + 36 = 100', answer:64},
    {prompt:'6 × __ = 72', answer:12},
    {prompt:'__ - 45 = 5', answer:50},
    {prompt:'4 × __ = 36', answer:9},
    {prompt:'__ + 28 = 60', answer:32},
    {prompt:'12 × __ = 144', answer:12},
    {prompt:'__ - 90 = 10', answer:100}
  ],
  inventionInventorLabels: {
    bell:{he:'אלכסנדר גרהם בל',en:'Alexander Graham Bell'},
    edison:{he:'תומאס אדיסון',en:'Thomas Edison'},
    wright:{he:'האחים רייט',en:'Wright Brothers'},
    gutenberg:{he:'יוהנס גוטנברג',en:'Johannes Gutenberg'},
    marconi:{he:'גוליילמו מרקוני',en:'Guglielmo Marconi'},
    baird:{he:"ג'ון לוגי ביירד",en:'John Logie Baird'},
    watt:{he:"ג'יימס ואט",en:'James Watt'},
    babbage:{he:"צ'רלס בבג'",en:'Charles Babbage'},
    bernersLee:{he:'טים ברנרס-לי',en:'Tim Berners-Lee'},
    jenner:{he:"אדוארד ג'נר",en:'Edward Jenner'},
    fleming:{he:'אלכסנדר פלמינג',en:'Alexander Fleming'},
    faraday:{he:'מייקל פאראדיי',en:'Michael Faraday'}
  },
  inventionInventor: [
    {invention:{he:'טלפון',en:'Telephone'}, correct:'bell', choices:['bell','edison','wright','marconi']},
    {invention:{he:'נורה חשמלית',en:'Light Bulb'}, correct:'edison', choices:['edison','bell','faraday','watt']},
    {invention:{he:'מטוס',en:'Airplane'}, correct:'wright', choices:['wright','baird','babbage','bell']},
    {invention:{he:'מכונת דפוס',en:'Printing Press'}, correct:'gutenberg', choices:['gutenberg','babbage','watt','marconi']},
    {invention:{he:'רדיו',en:'Radio'}, correct:'marconi', choices:['marconi','bell','edison','faraday']},
    {invention:{he:'טלוויזיה',en:'Television'}, correct:'baird', choices:['baird','marconi','bell','wright']},
    {invention:{he:'מנוע קיטור משופר',en:'Steam Engine'}, correct:'watt', choices:['watt','faraday','edison','babbage']},
    {invention:{he:'מחשב מכני מתוכנן',en:'Early Computer'}, correct:'babbage', choices:['babbage','gutenberg','watt','bernersLee']},
    {invention:{he:'האינטרנט העולמי / הווב',en:'World Wide Web'}, correct:'bernersLee', choices:['bernersLee','babbage','marconi','bell']},
    {invention:{he:'חיסון',en:'Vaccination'}, correct:'jenner', choices:['jenner','fleming','faraday','edison']},
    {invention:{he:'פניצילין',en:'Penicillin'}, correct:'fleming', choices:['fleming','jenner','bell','marconi']},
    {invention:{he:'גנרטור חשמלי',en:'Electric Generator'}, correct:'faraday', choices:['faraday','watt','edison','bell']}
  ],
  inventionInventorFacts: {
    bell:{
      en:'The goal was to talk to people far away by turning your voice into electricity that travels through a wire to another phone.',
      he:'המטרה הייתה לדבר עם אנשים רחוקים על ידי הפיכת הקול לחשמל שעובר דרך חוט לטלפון אחר.'
    },
    gutenberg:{
      en:'The goal was to make many books quickly by using metal letters to stamp ink onto paper over and over again.',
      he:'המטרה הייתה להכין ספרים רבים במהירות על ידי שימוש באותיות מתכת כדי להחתים דיו על נייר שוב ושוב.'
    },
    marconi:{
      en:'The goal was to send messages through the air without wires by using invisible waves called radio waves.',
      he:'המטרה הייתה לשלוח הודעות דרך האוויר ללא חוטים בעזרת גלים בלתי נראים הנקראים גלי רדיו.'
    },
    baird:{
      en:'The goal was to see moving pictures from far away by turning light into signals that a screen can turn back into a picture.',
      he:'המטרה הייתה לראות תמונות נעות מרחוק על ידי הפיכת אור לאותות שמסך יכול להפוך בחזרה לתמונה.'
    },
    bernersLee:{
      en:"The goal was to connect all the world's information so anyone with a computer can find and share pages using links.",
      he:'המטרה הייתה לחבר את כל המידע בעולם כך שכל אחד עם מחשב יוכל למצוא ולשתף דפים בעזרת קישורים.'
    },
    faraday:{
      en:'The goal was to create electricity by spinning a giant coil of wire near a magnet to make power for lights and machines.',
      he:'המטרה הייתה ליצור חשמל על ידי סיבוב סליל חוטים ענק ליד מגנט כדי לייצר כוח למנורות ומכונות.'
    },
    edison:{
      en:'The goal was to have light at night by making a thin wire inside a glass bulb glow very bright using electricity.',
      he:'המטרה הייתה שיהיה אור בלילה על ידי גרימה לחוט דק בתוך נורת זכוכית לזהור חזק בעזרת חשמל.'
    },
    watt:{
      en:'The goal was to make a powerful engine by using the pressure from boiling water (steam) to push parts that make a machine move.',
      he:'המטרה הייתה ליצור מנוע חזק על ידי שימוש בלחץ של מים רותחים (קיטור) כדי לדחוף חלקים שגורמים למכונה לזוז.'
    },
    wright:{
      en:'The goal was to fly through the sky like a bird by using a motor to spin a propeller and wings that lift the plane into the air.',
      he:'המטרה הייתה לעוף בשמיים כמו ציפור בעזרת מנוע שמסובב מדחף וכנפיים שמרימות את המטוס לאוויר.'
    },
    babbage:{
      en:'The goal was to solve very hard math problems without making mistakes by using a machine with many clicking gears.',
      he:'המטרה הייתה לפתור בעיות חשבון קשות מאוד בלי טעויות בעזרת מכונה עם גלגלי שיניים רבים.'
    },
    jenner:{
      en:'The goal was to stop people from getting sick by giving the body a "practice run" so it knows how to fight germs.',
      he:'המטרה הייתה למנוע מאנשים לחלות על ידי מתן "אימון" לגוף כדי שיידע איך להילחם בחיידקים.'
    },
    fleming:{
      en:'The goal was to cure infections by using a special medicine made from mold that kills bad bacteria in our bodies.',
      he:'המטרה הייתה לרפא זיהומים בעזרת תרופה מיוחדת שעשויה מעובש והורגת חיידקים רעים בגוף שלנו.'
    }
  },
  symptomOrganLabels: {
    heart:{he:'לב',en:'Heart'},
    lungs:{he:'ריאות',en:'Lungs'},
    brain:{he:'מוח',en:'Brain'},
    stomach:{he:'קיבה',en:'Stomach'},
    kidneys:{he:'כליות',en:'Kidneys'},
    liver:{he:'כבד',en:'Liver'},
    eyes:{he:'עיניים',en:'Eyes'},
    throatEsophagus:{he:'גרון / וושט',en:'Throat / Esophagus'}
  },
  symptomOrgan: [
    {symptom:{he:'כאב בחזה',en:'Chest pain'}, correct:'heart', choices:['heart','lungs','stomach','brain']},
    {symptom:{he:'קוצר נשימה',en:'Shortness of breath'}, correct:'lungs', choices:['lungs','heart','kidneys','brain']},
    {symptom:{he:'כאב ראש חזק',en:'Severe headache'}, correct:'brain', choices:['brain','eyes','heart','liver']},
    {symptom:{he:'בחילה אחרי אכילה',en:'Nausea after eating'}, correct:'stomach', choices:['stomach','liver','heart','kidneys']},
    {symptom:{he:'שיעול מתמשך',en:'Persistent cough'}, correct:'lungs', choices:['lungs','throatEsophagus','heart','stomach']},
    {symptom:{he:'דופק לא סדיר',en:'Irregular heartbeat'}, correct:'heart', choices:['heart','brain','lungs','kidneys']},
    {symptom:{he:'כאב בגב התחתון',en:'Lower back pain'}, correct:'kidneys', choices:['kidneys','liver','stomach','lungs']},
    {symptom:{he:'שתן תכוף',en:'Frequent urination'}, correct:'kidneys', choices:['kidneys','stomach','brain','heart']},
    {symptom:{he:'עור צהבהב',en:'Yellowish skin'}, correct:'liver', choices:['liver','kidneys','heart','eyes']},
    {symptom:{he:'סחרחורת',en:'Dizziness'}, correct:'brain', choices:['brain','heart','lungs','eyes']},
    {symptom:{he:'ראייה מטושטשת',en:'Blurred vision'}, correct:'eyes', choices:['eyes','brain','liver','lungs']},
    {symptom:{he:'קושי בבליעה',en:'Difficulty swallowing'}, correct:'throatEsophagus', choices:['throatEsophagus','lungs','heart','stomach']}
  ],
  largestCountriesRanking: [
    {order:1, he:'רוסיה', en:'Russia', flag:'🇷🇺'},
    {order:2, he:'קנדה', en:'Canada', flag:'🇨🇦'},
    {order:3, he:'ארצות הברית', en:'United States', flag:'🇺🇸'},
    {order:4, he:'סין', en:'China', flag:'🇨🇳'},
    {order:5, he:'ברזיל', en:'Brazil', flag:'🇧🇷'},
    {order:6, he:'אוסטרליה', en:'Australia', flag:'🇦🇺'},
    {order:7, he:'הודו', en:'India', flag:'🇮🇳'},
    {order:8, he:'ארגנטינה', en:'Argentina', flag:'🇦🇷'},
    {order:9, he:'קזחסטן', en:'Kazakhstan', flag:'🇰🇿'},
    {order:10, he:"אלג'יריה", en:'Algeria', flag:'🇩🇿'},
    {order:11, he:'הרפובליקה הדמוקרטית של קונגו', en:'DR Congo', flag:'🇨🇩'},
    {order:12, he:'ערב הסעודית', en:'Saudi Arabia', flag:'🇸🇦'}
  ],
  whoSaidItLabels: {
    hillel:{he:'הלל',en:'Hillel'},
    benZoma:{he:'בן זומא',en:'Ben Zoma'},
    shimon:{he:'שמעון הצדיק',en:'Shimon HaTzadik'},
    tarfon:{he:'רבי טרפון',en:'Rabbi Tarfon'},
    benAzzai:{he:'בן עזאי',en:'Ben Azzai'},
    rabbanShimon:{he:'רבן שמעון בן גמליאל',en:'Rabban Shimon ben Gamliel'},
    yose:{he:'יוסי בן יוחנן איש ירושלים',en:'Yose ben Yochanan of Jerusalem'},
    yehoshua:{he:'יהושע בן פרחיה',en:'Yehoshua ben Perachya'}
  },
  whoSaidIt: [
    {quoteHe:'אם אין אני לי מי לי', quoteEn:'If I am not for myself, who will be for me?', correct:'hillel', choices:['hillel','benZoma','shimon','tarfon']},
    {quoteHe:'איזהו חכם? הלומד מכל אדם', quoteEn:'Who is wise? One who learns from every person.', correct:'benZoma', choices:['benZoma','hillel','benAzzai','rabbanShimon']},
    {quoteHe:'איזהו גיבור? הכובש את יצרו', quoteEn:'Who is mighty? One who conquers his impulse.', correct:'benZoma', choices:['benZoma','hillel','tarfon','shimon']},
    {quoteHe:'על שלושה דברים העולם עומד: על התורה ועל העבודה ועל גמילות חסדים', quoteEn:'The world stands on three things: Torah, service, and acts of kindness.', correct:'shimon', choices:['shimon','hillel','tarfon','rabbanShimon']},
    {quoteHe:'לא עליך המלאכה לגמור, ולא אתה בן חורין להיבטל ממנה', quoteEn:'It is not your duty to finish the work, but neither are you free to neglect it.', correct:'tarfon', choices:['tarfon','hillel','benAzzai','yehoshua']},
    {quoteHe:'הוי מתלמידיו של אהרן, אוהב שלום ורודף שלום', quoteEn:'Be of the disciples of Aaron, loving peace and pursuing peace.', correct:'hillel', choices:['hillel','shimon','benAzzai','yose']},
    {quoteHe:'מצווה גוררת מצווה, ועבירה גוררת עבירה', quoteEn:'One mitzvah leads to another mitzvah, and one transgression leads to another transgression.', correct:'benAzzai', choices:['benAzzai','benZoma','hillel','tarfon']},
    {quoteHe:'סייג לחכמה שתיקה', quoteEn:'A fence for wisdom is silence.', correct:'rabbanShimon', choices:['rabbanShimon','hillel','shimon','benAzzai']},
    {quoteHe:'במקום שאין אנשים, השתדל להיות איש', quoteEn:'In a place where there are no people, strive to be a person.', correct:'hillel', choices:['hillel','tarfon','yehoshua','yose']},
    {quoteHe:'אל תדין את חברך עד שתגיע למקומו', quoteEn:'Do not judge your fellow until you reach his place.', correct:'hillel', choices:['hillel','benZoma','tarfon','rabbanShimon']},
    {quoteHe:'יהי ביתך פתוח לרווחה', quoteEn:'Let your home be open wide.', correct:'yose', choices:['yose','yehoshua','hillel','shimon']},
    {quoteHe:'עשה לך רב, וקנה לך חבר', quoteEn:'Make for yourself a teacher, and acquire for yourself a friend.', correct:'yehoshua', choices:['yehoshua','yose','hillel','tarfon']}
  ],
  mentalMathTF: [
    {he:'25 × 4 = 100', en:'25 × 4 = 100', correct:'correct'},
    {he:'99 × 10 = 990', en:'99 × 10 = 990', correct:'correct'},
    {he:'50 × 6 = 200', en:'50 × 6 = 200', correct:'wrong'},
    {he:'12 × 12 = 144', en:'12 × 12 = 144', correct:'correct'},
    {he:'15 × 8 = 110', en:'15 × 8 = 110', correct:'wrong'},
    {he:'40 × 5 = 200', en:'40 × 5 = 200', correct:'correct'},
    {he:'30 × 7 = 220', en:'30 × 7 = 220', correct:'wrong'},
    {he:'18 × 5 = 90', en:'18 × 5 = 90', correct:'correct'},
    {he:'90 × 3 = 260', en:'90 × 3 = 260', correct:'wrong'},
    {he:'14 × 6 = 84', en:'14 × 6 = 84', correct:'correct'},
    {he:'16 × 5 = 70', en:'16 × 5 = 70', correct:'wrong'},
    {he:'11 × 11 = 121', en:'11 × 11 = 121', correct:'correct'}
  ]
};

const GEMATRIA_QUOTES = {
  Truth: {
    en: '"The beginning of Your word is truth; and every one of Your righteous ordinances endures forever." (Tehillim 119:160)',
    he: '"רֹאשׁ דְּבָרְךָ אֱמֶת וּלְעוֹלָם כָּל מִשְׁפַּט צִדְקֶךָ." (תהילים קי"ט:קס)'
  },
  Peace: {
    en: '"Turn from evil and do good; seek peace and pursue it." (Tehillim 34:15)',
    he: '"סוּר מֵרָע וַעֲשֵׂה טוֹב בַּקֵּשׁ שָׁלוֹם וְרָדְפֵהוּ." (תהילים ל"ד:ט"ו)'
  },
  Love: {
    en: '"And you shall love your neighbor as yourself." (Vayikra 19:18)',
    he: '"וְאָהַבְתָּ לְרֵעֲךָ כָּמוֹךָ." (ויקרא י"ט:י"ח)'
  },
  One: {
    en: '"Hear, O Israel: The Lord our God, the Lord is One." (Devarim 6:4)',
    he: '"שְׁמַע יִשְׂרָאֵל ה׳ אֱלֹקֵינוּ ה׳ אֶחָד." (דברים ו׳:ד׳)'
  },
  Torah: {
    en: '"The Torah of the Lord is perfect, restoring the soul."',
    he: '"תּוֹרַת ה׳ תְּמִימָה מְשִׁיבַת נָפֶשׁ."'
  },
  Shabbat: {
    en: '"Remember the Sabbath day, to keep it holy."',
    he: '"זָכוֹר אֶת יוֹם הַשַּׁבָּת לְקַדְּשׁוֹ."'
  },
  Israel: {
    en: '"He who watches over Israel neither slumbers nor sleeps."',
    he: '"הִנֵּה לֹא יָנוּם וְלֹא יִישָׁן שׁוֹמֵר יִשְׂרָאֵל."'
  },
  Jerusalem: {
    en: '"If I forget you, O Jerusalem, let my right hand forget its skill."',
    he: '"אִם אֶשְׁכָּחֵךְ יְרוּשָׁלַיִם תִּשְׁכַּח יְמִינִי."'
  },
  Life: {
    en: '"Who is the man who desires life, who loves days to see good?"',
    he: '"מִי הָאִישׁ הֶחָפֵץ חַיִּים."'
  },
  Water: {
    en: '"As a deer pants for streams of water, so my soul pants for You."',
    he: '"כְּאַיָּל תַּעֲרֹג עַל אֲפִיקֵי מָיִם."'
  },
  Fire: {
    en: '"For the Lord your God is a consuming fire."',
    he: '"כִּי ה׳ אֱלֹקֶיךָ אֵשׁ אֹכְלָה הוּא."'
  },
  Spirit: {
    en: '"And renew a steadfast spirit within me."',
    he: '"וְרוּחַ נָכוֹן חַדֵּשׁ בְּקִרְבִּי."'
  },
  Soul: {
    en: '"My soul thirsts for God, for the living God."',
    he: '"צָמְאָה נַפְשִׁי לֵאלֹקִים."'
  },
  King: {
    en: '"The Lord will reign forever and ever."',
    he: '"ה׳ יִמְלֹךְ לְעֹלָם וָעֶד."'
  },
  Silver: {
    en: '"The Torah of Your mouth is better to me than thousands of gold and silver."',
    he: '"טוֹב לִי תוֹרַת פִּיךָ מֵאַלְפֵי זָהָב וָכָסֶף."'
  },
  Gold: {
    en: '"The Torah of Your mouth is better to me than thousands of gold and silver."',
    he: '"טוֹב לִי תוֹרַת פִּיךָ מֵאַלְפֵי זָהָב וָכָסֶף."'
  },
  Bread: {
    en: '"And bread to sustain the human heart."',
    he: '"וְלֶחֶם לְבַב אֱנוֹשׁ יִסְעָד."'
  },
  Honey: {
    en: '"Sweeter than honey and the drippings of the honeycomb."',
    he: '"וּמְתוּקִים מִדְּבַשׁ וְנֹפֶת צוּפִים."'
  },
  Wine: {
    en: '"And wine that gladdens the heart of man."',
    he: '"וְיַיִן יְשַׂמַּח לְבַב אֱנוֹשׁ." (תהילים ק"ד:ט"ו)'
  },
  Mitzvah: {
    en: '"For the commandment is a lamp, and the Torah is light."',
    he: '"כִּי נֵר מִצְוָה וְתוֹרָה אוֹר." (משלי ו׳:כ״ג)'
  }
};
DATA.gematria.forEach(entry => Object.assign(entry, { quoteEn: GEMATRIA_QUOTES[entry.en]?.en || '', quoteHe: GEMATRIA_QUOTES[entry.en]?.he || '' }));

const CONTINENT_FACTS = {
  "Argentina": {
    "heCountry": "ארגנטינה",
    "en": "It is one of the world's top exporters of soy, corn, and beef.",
    "he": "אחת היצואניות המובילות בעולם של סויה, תירס ובשר בקר."
  },
  "Brazil": {
    "heCountry": "ברזיל",
    "en": "It is the most biodiverse country on Earth, home to 10% of all known species in the world.",
    "he": "המדינה בעלת המגוון הביולוגי הגדול ביותר, וביתם של 10% מכלל המינים המוכרים בעולם."
  },
  "Canada": {
    "heCountry": "קנדה",
    "en": "It has more lake area than any other country in the world, holding 20% of the world's fresh water.",
    "he": "בעלת שטח האגמים הגדול בעולם, המכיל 20% מהמים המתוקים על פני כדור הארץ."
  },
  "Chile": {
    "heCountry": "צ'ילה",
    "en": "It is one of the best places in the world for space observation because of its exceptionally clear skies.",
    "he": "אחד המקומות הטובים בעולם לצפייה בכוכבים בזכות השמיים הבהירים שלו."
  },
  "China": {
    "heCountry": "סין",
    "en": "It is known as the \"World's Factory\" because it manufactures more goods than any other nation.",
    "he": "ידועה כ\"מפעל של העולם\" מכיוון שהיא מייצרת יותר סחורות מכל אומה אחרת."
  },
  "Colombia": {
    "heCountry": "קולומביה",
    "en": "It is the only country in South America that has coastlines on both the Pacific Ocean and the Caribbean Sea.",
    "he": "המדינה היחידה בדרום אמריקה שיש לה חופים גם באוקיינוס השקט וגם בים הקריבי."
  },
  "Egypt": {
    "heCountry": "מצרים",
    "en": "It controls the Suez Canal, one of the world's most important shipping routes for global trade.",
    "he": "שולטת בתעלת סואץ, אחד מנתיבי השיט החשובים בעולם לסחר עולמי."
  },
  "Ethiopia": {
    "heCountry": "אתיופיה",
    "en": "It is the only African country with its own unique ancient alphabet (Ge'ez) that is still used today.",
    "he": "המדינה האפריקאית היחידה עם אלף-בית עתיק וייחודי משלה (געז) שעדיין בשימוש כיום."
  },
  "France": {
    "heCountry": "צרפת",
    "en": "It is the most visited country in the world and a global leader in the luxury goods industry.",
    "he": "המדינה המתויירת ביותר בעולם ומובילה עולמית בתעשיית מוצרי היוקרה."
  },
  "Germany": {
    "heCountry": "גרמניה",
    "en": "It is the largest economy in Europe and the world's third-largest exporter of goods.",
    "he": "הכלכלה הגדולה ביותר באירופה והיצואנית השלישית בגודלה בעולם של סחורות."
  },
  "Greece": {
    "heCountry": "יוון",
    "en": "It has the largest merchant shipping fleet in the world, carrying goods across all oceans.",
    "he": "בעלת צי אוניות הסוחר הגדול ביותר בעולם, המוביל סחורות בכל האוקיינוסים."
  },
  "Guatemala": {
    "heCountry": "גואטמלה",
    "en": "It is the world's largest producer of Cardamom, a spice used in cooking and medicine.",
    "he": "היצרנית הגדולה בעולם של הל, תבלין המשמש לבישול ורפואה."
  },
  "India": {
    "heCountry": "הודו",
    "en": "It is the world's largest producer of milk and the largest exporter of generic medicines.",
    "he": "יצרנית החלב הגדולה בעולם והיצואנית הגדולה ביותר של תרופות גנריות."
  },
  "Indonesia": {
    "heCountry": "אינדונזיה",
    "en": "It contains the world's largest number of active volcanoes, located along the \"Ring of Fire.\"",
    "he": "מכילה את מספר הרי הגעש הפעילים הגדול ביותר בעולם, הנמצאים לאורך \"טבעת האש\"."
  },
  "Israel": {
    "heCountry": "ישראל",
    "en": "It is a world leader in water desalination and recycling, reusing nearly 90% of its wastewater.",
    "he": "מובילה עולמית בהתפלת מים ומיחזורם, עם שימוש חוזר בכמעט 90% ממי השופכין שלה."
  },
  "Italy": {
    "heCountry": "איטליה",
    "en": "It is a world leader in high-end luxury fashion and design, exporting to every corner of the globe.",
    "he": "מובילה עולמית באופנת עילית ועיצוב יוקרתי, המייצאת לכל פינה בעולם."
  },
  "Japan": {
    "heCountry": "יפן",
    "en": "It is the world leader in the automotive industry and has the most advanced high-speed train network.",
    "he": "מובילה עולמית בתעשיית הרכב ובעלת רשת הרכבות המהירות המתקדמת ביותר."
  },
  "Kenya": {
    "heCountry": "קניה",
    "en": "It is a global hub for mobile banking and was the first to implement widespread phone-based money transfers.",
    "he": "מרכז עולמי לבנקאות סלולרית והראשונה ליישם העברות כספים נרחבות דרך הטלפון."
  },
  "Mexico": {
    "heCountry": "מקסיקו",
    "en": "It is the most populous Spanish-speaking country in the entire world.",
    "he": "המדינה עם מספר דוברי הספרדית הגדול ביותר בעולם."
  },
  "Morocco": {
    "heCountry": "מרוקו",
    "en": "It holds about 70% of the world’s phosphate reserves, which are vital for global farming.",
    "he": "מחזיקה בכ-70% מעתודות הפוספט בעולם, החיוניות לחקלאות העולמית."
  },
  "Nigeria": {
    "heCountry": "ניגריה",
    "en": "It is the most populous country in Africa and has the largest economy in Africa.",
    "he": "המדינה המאוכלסת ביותר באפריקה ובעלת הכלכלה הגדולה ביותר ביבשת."
  },
  "Peru": {
    "heCountry": "פרו",
    "en": "It is the original home of the potato; today, over 3,000 different varieties of potatoes are grown there.",
    "he": "המקור של תפוח האדמה; כיום גדלים שם למעלה מ-3,000 זנים שונים של תפוחי אדמה."
  },
  "South Africa": {
    "heCountry": "דרום אפריקה",
    "en": "It is the only country in the world to have hosted the World Cups for Soccer, Rugby, and Cricket.",
    "he": "המדינה היחידה בעולם שאירחה את גביעי העולם בכדורגל, רוגבי וקריקט."
  },
  "South Korea": {
    "heCountry": "דרום קוריאה",
    "en": "It has the world’s fastest average internet speed and is a leader in semiconductor manufacturing.",
    "he": "בעלת מהירות האינטרנט הממוצעת הגבוהה בעולם ומובילה בייצור שבבים."
  },
  "Spain": {
    "heCountry": "ספרד",
    "en": "It produces nearly half of the entire world's supply of olive oil.",
    "he": "מייצרת כמעט מחצית מאספקת שמן הזית של העולם כולו."
  },
  "United Kingdom": {
    "heCountry": "בריטניה",
    "en": "It is the birthplace of the English language, which is now the most widely spoken language in the world.",
    "he": "מקום הולדתה של השפה האנגלית, שהיא כיום השפה המדוברת ביותר בעולם."
  },
  "United States": {
    "heCountry": "ארצות הברית",
    "en": "It has the world's largest economy and is a global leader in technological innovation.",
    "he": "הכלכלה הגדולה בעולם ומובילה עולמית בחדשנות טכנולוגית."
  }
};

const COUNTRY_FLAG_FACTS = {
  'Brazil': {
    en: "It is the world's largest producer of sugarcane and coffee, dominating global agricultural trade.",
    he: "היצרנית הגדולה בעולם של קנה סוכר וקפה, השולטת בסחר החקלאי העולמי."
  },
  'Canada': {
    en: "It has more lake area than any other country in the world, holding 20% of the world's fresh water.",
    he: "בעלת שטח האגמים הגדול בעולם, המכיל 20% מהמים המתוקים על פני כדור הארץ."
  },
  'France': {
    en: "It is the largest agricultural producer in the European Union, providing a huge portion of the continent's grain and wine.",
    he: "היצרנית החקלאית הגדולה ביותר באיחוד האירופי, המספקת חלק עצום מהתבואה והיין של היבשת."
  },
  'Germany': {
    en: "It is the largest economy in Europe and the world's third-largest exporter of goods.",
    he: "הכלכלה הגדולה ביותר באירופה והיצואנית השלישית בגודלה בעולם של סחורות."
  },
  'Israel': {
    en: "The only Jewish state in the world, located in the ancient Holy Land.",
    he: "המדינה היהודית היחידה בעולם, הממוקמת בארץ הקודש העתיקה."
  },
  'Italy': {
    en: "It has more World Heritage Sites than any other nation, driving a massive global tourism economy.",
    he: "בעלת מספר אתרי המורשת העולמית הגדול ביותר, מה שמניע כלכלת תיירות עולמית אדירה."
  },
  'Japan': {
    en: "It is a world leader in the automotive industry and has the most advanced high-speed train network.",
    he: "מובילה עולמית בתעשיית הרכב ובעלת רשת הרכבות המהירות המתקדמת ביותר."
  },
  'Mexico': {
    en: "It is the most populous Spanish-speaking country in the entire world.",
    he: "המדינה עם מספר דוברי הספרדית הגדול ביותר בעולם."
  },
  'Switzerland': {
    en: "It is a unique \"neutral\" nation with four official national languages (German, French, Italian, and Romansh).",
    he: "מדינה \"נייטרלית\" ייחודית עם ארבע שפות לאומיות רשמיות (גרמנית, צרפתית, איטלקית ורומאנש)."
  },
  'Ukraine': {
    en: "It is known as the \"Breadbasket of Europe\" because it is one of the world's top exporters of grain and sunflower oil.",
    he: "ידועה כ\"סל הלחם של אירופה\" כי היא אחת היצואניות המובילות בעולם של דגנים ושמן חמניות."
  },
  'United Kingdom': {
    en: "It is the birthplace of the English language, which is now the most widely spoken language in the world.",
    he: "מקום הולדתה של השפה האנגלית, שהיא כיום השפה המדוברת ביותר בעולם."
  },
  'United States': {
    en: "It is the birthplace of the internet and home to the world’s largest tech companies in Silicon Valley.",
    he: "מקום הולדתו של האינטרנט וביתן של חברות הטכנולוגיה הגדולות בעולם בעמק הסיליקון."
  }

,
  europeGeoCountries: [
    {
      id:'germany', he:'גרמניה', en:'Germany',
      population:84000000, populationLabelHe:'גדולה מאוד', populationLabelEn:'Very large',
      gdpUsd:5013574000000, economyLabelHe:'גדולה מאוד', economyLabelEn:'Very large',
      areaKm2:357588, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:59700, density:235,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'רפובליקה פדרלית פרלמנטרית', systemEn:'Federal parliamentary republic',
      regionHe:'מרכז ומערב אירופה', regionEn:'Central and Western Europe',
      sectorHe:'מכוניות, מכונות, כימיקלים', sectorEn:'Cars, machinery, chemicals',
      historyHe:'אימפריה לשעבר', historyEn:'Former empire',
      profileHe:['כלכלה גדולה מאוד', 'אוכלוסייה גדולה מאוד', 'מטבע: אירו', 'ידועה במכוניות, מכונות וכימיקלים'],
      profileEn:['Very large economy', 'Very large population', 'Currency: Euro', 'Known for cars, machinery, and chemicals'],
      teachMeHe:'לגרמניה יש את הכלכלה הגדולה באירופה והיא מעצמת ייצור ויצוא מרכזית.',
      teachMeEn:'Germany has Europe\'s largest economy and is a major manufacturing and export power.'
    },
    {
      id:'france', he:'צרפת', en:'France',
      population:68000000, populationLabelHe:'גדולה', populationLabelEn:'Large',
      gdpUsd:3361557000000, economyLabelHe:'גדולה מאוד', economyLabelEn:'Very large',
      areaKm2:551695, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:49400, density:123,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'רפובליקה חצי-נשיאותית', systemEn:'Semi-presidential republic',
      regionHe:'מערב אירופה', regionEn:'Western Europe',
      sectorHe:'תעופה וחלל, יוקרה, חקלאות', sectorEn:'Aerospace, luxury goods, agriculture',
      historyHe:'אימפריה לשעבר', historyEn:'Former empire',
      profileHe:['כלכלה גדולה מאוד', 'אוכלוסייה גדולה', 'רפובליקה חצי-נשיאותית', 'חזקה בתעופה, יוקרה וחקלאות'],
      profileEn:['Very large economy', 'Large population', 'Semi-presidential republic', 'Strong in aerospace, luxury goods, and agriculture'],
      teachMeHe:'צרפת משלבת כלכלה גדולה מאוד עם תעשייה חזקה, חקלאות, תיירות והשפעה פוליטית עולמית.',
      teachMeEn:'France combines a very large economy with strong industry, agriculture, tourism, and global political influence.'
    },
    {
      id:'uk', he:'בריטניה', en:'United Kingdom',
      population:69000000, populationLabelHe:'גדולה', populationLabelEn:'Large',
      gdpUsd:3958780000000, economyLabelHe:'גדולה מאוד', economyLabelEn:'Very large',
      areaKm2:243610, areaLabelHe:'בינונית', areaLabelEn:'Medium',
      gdpPerCapitaUsd:57400, density:284,
      currencyHe:'לירה שטרלינג', currencyEn:'Pound sterling',
      systemHe:'מונרכיה חוקתית פרלמנטרית', systemEn:'Parliamentary constitutional monarchy',
      regionHe:'צפון-מערב אירופה', regionEn:'Northwestern Europe',
      sectorHe:'פיננסים, תרופות, שירותים', sectorEn:'Finance, pharmaceuticals, services',
      historyHe:'אימפריה לשעבר', historyEn:'Former empire',
      profileHe:['כלכלה גדולה מאוד', 'אוכלוסייה גדולה', 'מטבע: לירה שטרלינג', 'מונרכיה חוקתית עם כוח פיננסי גדול'],
      profileEn:['Very large economy', 'Large population', 'Currency: Pound sterling', 'Constitutional monarchy with major financial power'],
      teachMeHe:'לבריטניה יש כלכלה גדולה מאוד, היא משתמשת בלירה שטרלינג, ובולטת בשירותים ופיננסים.',
      teachMeEn:'The UK has a very large economy, uses the pound, and stands out in finance and services.'
    },
    {
      id:'italy', he:'איטליה', en:'Italy',
      population:59000000, populationLabelHe:'גדולה', populationLabelEn:'Large',
      gdpUsd:2543677000000, economyLabelHe:'גדולה', economyLabelEn:'Large',
      areaKm2:301340, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:43100, density:196,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'רפובליקה פרלמנטרית', systemEn:'Parliamentary republic',
      regionHe:'דרום אירופה', regionEn:'Southern Europe',
      sectorHe:'מכונות, אופנה, מזון', sectorEn:'Machinery, fashion, food',
      historyHe:'ליבת אימפריה לשעבר', historyEn:'Former empire core',
      profileHe:['כלכלה גדולה', 'אוכלוסייה גדולה', 'דרום אירופה', 'ידועה בייצור, עיצוב ותיירות'],
      profileEn:['Large economy', 'Large population', 'Southern Europe', 'Known for manufacturing, design, and tourism'],
      teachMeHe:'איטליה היא כלכלה גדולה בדרום אירופה, הידועה בייצור, עיצוב ותיירות.',
      teachMeEn:'Italy is a large southern European economy known for manufacturing, design, and tourism.'
    },
    {
      id:'spain', he:'ספרד', en:'Spain',
      population:49000000, populationLabelHe:'גדולה', populationLabelEn:'Large',
      gdpUsd:1891371000000, economyLabelHe:'גדולה', economyLabelEn:'Large',
      areaKm2:505990, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:38600, density:97,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'מונרכיה חוקתית פרלמנטרית', systemEn:'Parliamentary constitutional monarchy',
      regionHe:'דרום-מערב אירופה', regionEn:'Southwestern Europe',
      sectorHe:'תיירות, מכוניות, מזון', sectorEn:'Tourism, cars, food',
      historyHe:'אימפריה לשעבר', historyEn:'Former empire',
      profileHe:['כלכלה גדולה', 'אוכלוסייה גדולה', 'מונרכיה חוקתית', 'חזקה במיוחד בתיירות'],
      profileEn:['Large economy', 'Large population', 'Constitutional monarchy', 'Especially strong in tourism'],
      teachMeHe:'ספרד משלבת כלכלה גדולה עם תיירות חזקה, תעשיית רכב וחקלאות.',
      teachMeEn:'Spain mixes a large economy with strong tourism, car production, and agriculture.'
    },
    {
      id:'netherlands', he:'הולנד', en:'Netherlands',
      population:18000000, populationLabelHe:'בינונית', populationLabelEn:'Medium',
      gdpUsd:1320635000000, economyLabelHe:'גדולה', economyLabelEn:'Large',
      areaKm2:41850, areaLabelHe:'קטנה', areaLabelEn:'Small',
      gdpPerCapitaUsd:73400, density:431,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'מונרכיה חוקתית פרלמנטרית', systemEn:'Parliamentary constitutional monarchy',
      regionHe:'מערב אירופה', regionEn:'Western Europe',
      sectorHe:'מסחר, כימיקלים, חקלאות מתקדמת', sectorEn:'Trade, chemicals, advanced agriculture',
      historyHe:'מעצמת מסחר ימית', historyEn:'Maritime trading power',
      profileHe:['שטח קטן אבל כלכלה גדולה', 'אוכלוסייה בינונית', 'אחת המדינות הצפופות באירופה', 'חזקה מאוד במסחר'],
      profileEn:['Small area but large economy', 'Medium population', 'One of Europe\'s densest countries', 'Very strong in trade'],
      teachMeHe:'הולנד קטנה בשטח אך גדולה בכלכלה, מאוד מוכוונת מסחר, ואחת המדינות הצפופות באירופה.',
      teachMeEn:'The Netherlands is small in area but large in economy, highly trade-oriented, and one of Europe\'s densest countries.'
    },
    {
      id:'poland', he:'פולין', en:'Poland',
      population:37000000, populationLabelHe:'גדולה', populationLabelEn:'Large',
      gdpUsd:1039619000000, economyLabelHe:'גדולה', economyLabelEn:'Large',
      areaKm2:312696, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:28100, density:118,
      currencyHe:'זלוטי', currencyEn:'Zloty',
      systemHe:'רפובליקה פרלמנטרית', systemEn:'Parliamentary republic',
      regionHe:'מרכז ומזרח אירופה', regionEn:'Central and Eastern Europe',
      sectorHe:'תעשייה, רהיטים, מזון', sectorEn:'Manufacturing, furniture, food',
      historyHe:'מדינה פוסט-קומוניסטית', historyEn:'Post-communist state',
      profileHe:['כלכלה גדולה', 'אוכלוסייה גדולה', 'מטבע: זלוטי', 'בסיס ייצור משמעותי במרכז-מזרח אירופה'],
      profileEn:['Large economy', 'Large population', 'Currency: Zloty', 'Major manufacturing base in Central-Eastern Europe'],
      teachMeHe:'פולין היא אחת הכלכלות הגדולות באירופה שאינן משתמשות באירו, והתפתחה לבסיס ייצור משמעותי.',
      teachMeEn:'Poland is one of Europe\'s biggest non-euro economies and has grown into a major manufacturing base.'
    },
    {
      id:'sweden', he:'שוודיה', en:'Sweden',
      population:11000000, populationLabelHe:'בינונית', populationLabelEn:'Medium',
      gdpUsd:662318000000, economyLabelHe:'בינונית', economyLabelEn:'Medium',
      areaKm2:450295, areaLabelHe:'גדולה', areaLabelEn:'Large',
      gdpPerCapitaUsd:60200, density:26,
      currencyHe:'כתר שוודי', currencyEn:'Swedish krona',
      systemHe:'מונרכיה חוקתית פרלמנטרית', systemEn:'Parliamentary constitutional monarchy',
      regionHe:'צפון אירופה', regionEn:'Northern Europe',
      sectorHe:'הנדסה, רכב, טכנולוגיה', sectorEn:'Engineering, vehicles, technology',
      historyHe:'מדינה נורדית', historyEn:'Nordic state',
      profileHe:['כלכלה בינונית', 'אוכלוסייה בינונית', 'שטח גדול וצפיפות נמוכה', 'תעשייה-טכנולוגיה חזקה'],
      profileEn:['Medium economy', 'Medium population', 'Large area and low density', 'Strong industrial-tech profile'],
      teachMeHe:'לשוודיה יש כלכלה בינונית, אוכלוסייה יחסית קטנה, שטח גדול ופרופיל חזק של תעשייה וטכנולוגיה.',
      teachMeEn:'Sweden has a medium-sized economy, a relatively small population, a large territory, and a strong industrial-tech profile.'
    },
    {
      id:'greece', he:'יוון', en:'Greece',
      population:10000000, populationLabelHe:'בינונית', populationLabelEn:'Medium',
      gdpUsd:250000000000, economyLabelHe:'קטנה', economyLabelEn:'Small',
      areaKm2:131957, areaLabelHe:'בינונית', areaLabelEn:'Medium',
      gdpPerCapitaUsd:24900, density:76,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'רפובליקה פרלמנטרית', systemEn:'Parliamentary republic',
      regionHe:'דרום-מזרח אירופה', regionEn:'Southeastern Europe',
      sectorHe:'תיירות, ספנות, מזון', sectorEn:'Tourism, shipping, food',
      historyHe:'ציוויליזציה עתיקה', historyEn:'Ancient civilization',
      profileHe:['כלכלה קטנה יחסית', 'אוכלוסייה בינונית', 'דרום-מזרח אירופה', 'בולטת בתיירות ובספנות'],
      profileEn:['Relatively small economy', 'Medium population', 'Southeastern Europe', 'Strong in tourism and shipping'],
      teachMeHe:'יוון בולטת בזכות תיירות, ספנות והיסטוריה עתיקה, עם כלכלה קטנה בהרבה מזו של המעצמות האירופיות.',
      teachMeEn:'Greece stands out for tourism, shipping, and ancient history, with a much smaller economy than Europe\'s largest states.'
    },
    {
      id:'ireland', he:'אירלנד', en:'Ireland',
      population:5300000, populationLabelHe:'קטנה', populationLabelEn:'Small',
      gdpUsd:708771000000, economyLabelHe:'בינונית', economyLabelEn:'Medium',
      areaKm2:70273, areaLabelHe:'קטנה', areaLabelEn:'Small',
      gdpPerCapitaUsd:133000, density:75,
      currencyHe:'אירו', currencyEn:'Euro',
      systemHe:'רפובליקה פרלמנטרית', systemEn:'Parliamentary republic',
      regionHe:'צפון-מערב אירופה', regionEn:'Northwestern Europe',
      sectorHe:'תרופות, טכנולוגיה, שירותים', sectorEn:'Pharmaceuticals, technology, services',
      historyHe:'רפובליקה עצמאית מודרנית', historyEn:'Modern independent republic',
      profileHe:['אוכלוסייה ושטח קטנים', 'תוצר לנפש גבוה מאוד', 'מטבע: אירו', 'חזקה בטכנולוגיה ותרופות'],
      profileEn:['Small population and area', 'Very high GDP per capita', 'Currency: Euro', 'Strong in technology and pharmaceuticals'],
      teachMeHe:'אירלנד קטנה באוכלוסייה ובשטח, אך חזקה במיוחד בתוצר ובתוצר לנפש ביחס לגודלה.',
      teachMeEn:'Ireland is small in population and area but unusually strong in GDP and GDP per capita for its size.'
    }
  ],
  europeProfileMatch: {
    countriesKey: 'europeGeoCountries'
  },
  europeCountryRanking: {
    countriesKey: 'europeGeoCountries',
    modes: {
      gdp: { he:'תמ"ג', en:'GDP', get:(item)=>item.gdpUsd },
      population: { he:'אוכלוסייה', en:'Population', get:(item)=>item.population },
      area: { he:'שטח', en:'Area', get:(item)=>item.areaKm2 },
      gdpPerCapita: { he:'תמ"ג לנפש', en:'GDP per capita', get:(item)=>item.gdpPerCapitaUsd },
      density: { he:'צפיפות אוכלוסייה', en:'Population density', get:(item)=>item.density }
    }
  }
};

// Europe geography data was intentionally kept separate from visible legacy categories.
// Expose the new quiz datasets on DATA without touching older quiz structures.
DATA.europeGeoCountries = COUNTRY_FLAG_FACTS.europeGeoCountries;
DATA.europeProfileMatch = COUNTRY_FLAG_FACTS.europeProfileMatch;
DATA.europeCountryRanking = COUNTRY_FLAG_FACTS.europeCountryRanking;

DATA.europeAdvancedCountries = [
  { id:'portugal', he:'פורטוגל', en:'Portugal', population:10500000, gdpUsd:301500000000, gdpPerCapitaUsd:28700, density:114, currencyHe:'אירו', currencyEn:'Euro', euMember:true, euroMember:true, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'דרום-מערב אירופה', regionEn:'Southwestern Europe', tourismHe:'חזקה מאוד בתיירות', tourismEn:'Very strong in tourism', exportsHe:'טקסטיל, כלי רכב, מזון', exportsEn:'Textiles, vehicles, food', industryHe:'תעשייה קלה ושירותים', industryEn:'Light industry and services' },
  { id:'belgium', he:'בלגיה', en:'Belgium', population:11800000, gdpUsd:655000000000, gdpPerCapitaUsd:55800, density:383, currencyHe:'אירו', currencyEn:'Euro', euMember:true, euroMember:true, systemHe:'מונרכיה חוקתית', systemEn:'Constitutional monarchy', regionHe:'מערב אירופה', regionEn:'Western Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'כימיקלים, תרופות, מכונות', exportsEn:'Chemicals, pharmaceuticals, machinery', industryHe:'תעשייה ושירותים', industryEn:'Industry and services' },
  { id:'austria', he:'אוסטריה', en:'Austria', population:9100000, gdpUsd:535000000000, gdpPerCapitaUsd:58800, density:109, currencyHe:'אירו', currencyEn:'Euro', euMember:true, euroMember:true, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'מרכז אירופה', regionEn:'Central Europe', tourismHe:'תיירות חזקה', tourismEn:'Strong tourism', exportsHe:'מכונות, ציוד, תעשייה', exportsEn:'Machinery, equipment, industry', industryHe:'תעשייה ושירותים', industryEn:'Industry and services' },
  { id:'switzerland', he:'שווייץ', en:'Switzerland', population:8900000, gdpUsd:947000000000, gdpPerCapitaUsd:99900, density:220, currencyHe:'פרנק שווייצרי', currencyEn:'Swiss franc', euMember:false, euroMember:false, systemHe:'רפובליקה פדרלית', systemEn:'Federal republic', regionHe:'מרכז אירופה', regionEn:'Central Europe', tourismHe:'תיירות חזקה', tourismEn:'Strong tourism', exportsHe:'תרופות, שעונים, מכונות', exportsEn:'Pharmaceuticals, watches, machinery', industryHe:'ייצור מתקדם ושירותים פיננסיים', industryEn:'Advanced manufacturing and financial services' },
  { id:'norway', he:'נורווגיה', en:'Norway', population:5600000, gdpUsd:485000000000, gdpPerCapitaUsd:87000, density:15, currencyHe:'כתר נורווגי', currencyEn:'Norwegian krone', euMember:false, euroMember:false, systemHe:'מונרכיה חוקתית', systemEn:'Constitutional monarchy', regionHe:'צפון אירופה', regionEn:'Northern Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'נפט, גז, דגים', exportsEn:'Oil, gas, fish', industryHe:'אנרגיה ומשאבים', industryEn:'Energy and resources' },
  { id:'denmark', he:'דנמרק', en:'Denmark', population:6000000, gdpUsd:420000000000, gdpPerCapitaUsd:70600, density:138, currencyHe:'כתר דני', currencyEn:'Danish krone', euMember:true, euroMember:false, systemHe:'מונרכיה חוקתית', systemEn:'Constitutional monarchy', regionHe:'צפון אירופה', regionEn:'Northern Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'תרופות, מזון, מכונות', exportsEn:'Pharmaceuticals, food, machinery', industryHe:'שירותים ותעשייה מתקדמת', industryEn:'Services and advanced industry' },
  { id:'finland', he:'פינלנד', en:'Finland', population:5600000, gdpUsd:317000000000, gdpPerCapitaUsd:56900, density:18, currencyHe:'אירו', currencyEn:'Euro', euMember:true, euroMember:true, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'צפון אירופה', regionEn:'Northern Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'טכנולוגיה, יערות, מכונות', exportsEn:'Technology, forestry, machinery', industryHe:'טכנולוגיה ותעשייה', industryEn:'Technology and industry' },
  { id:'czechia', he:'צ׳כיה', en:'Czechia', population:10900000, gdpUsd:343000000000, gdpPerCapitaUsd:31500, density:138, currencyHe:'כתר צ׳כי', currencyEn:'Czech koruna', euMember:true, euroMember:false, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'מרכז אירופה', regionEn:'Central Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'מכוניות, מכונות, תעשייה', exportsEn:'Cars, machinery, industry', industryHe:'תעשיית ייצור חזקה', industryEn:'Strong manufacturing base' },
  { id:'hungary', he:'הונגריה', en:'Hungary', population:9600000, gdpUsd:223000000000, gdpPerCapitaUsd:23000, density:106, currencyHe:'פורינט', currencyEn:'Forint', euMember:true, euroMember:false, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'מרכז אירופה', regionEn:'Central Europe', tourismHe:'תיירות בינונית', tourismEn:'Moderate tourism', exportsHe:'מכוניות, אלקטרוניקה, תרופות', exportsEn:'Cars, electronics, pharmaceuticals', industryHe:'ייצור ותעשייה', industryEn:'Manufacturing and industry' },
  { id:'romania', he:'רומניה', en:'Romania', population:19000000, gdpUsd:403000000000, gdpPerCapitaUsd:21100, density:84, currencyHe:'לאו רומני', currencyEn:'Romanian leu', euMember:true, euroMember:false, systemHe:'רפובליקה', systemEn:'Republic', regionHe:'מזרח אירופה', regionEn:'Eastern Europe', tourismHe:'תיירות מתפתחת', tourismEn:'Growing tourism', exportsHe:'מכוניות, ציוד, חקלאות', exportsEn:'Cars, equipment, agriculture', industryHe:'תעשייה וחקלאות', industryEn:'Industry and agriculture' }
];

DATA.europeCountryFits = [
  { clueHe:'מדינה עשירה במרכז אירופה, משתמשת באירו, עם תיירות ותעשייה חזקות.', clueEn:'High-income Central European country, uses the euro, with strong tourism and industry.', optionIds:['austria','switzerland','czechia','hungary'], correct:'austria', teachHe:'אוסטריה מתאימה כי היא במרכז אירופה, משתמשת באירו ומשלבת תיירות ותעשייה. שווייץ דומה, אך אינה משתמשת באירו.', teachEn:'Austria fits because it is in Central Europe, uses the euro, and combines tourism with industry. Switzerland is similar but does not use the euro.', compare:'switzerland' },
  { clueHe:'מדינה אירופית שאינה באיחוד האירופי, עשירה מאוד ומוכרת בשירותים פיננסיים.', clueEn:'European country outside the EU, very wealthy, and known for financial services.', optionIds:['switzerland','belgium','denmark','austria'], correct:'switzerland', teachHe:'שווייץ אינה חברה באיחוד האירופי, עשירה מאוד ומזוהה עם פיננסים וייצור מתקדם.', teachEn:'Switzerland is outside the EU, very wealthy, and strongly associated with finance and advanced manufacturing.', compare:'austria' },
  { clueHe:'מונרכיה חוקתית בצפון אירופה, חברה באיחוד האירופי אך לא משתמשת באירו.', clueEn:'Constitutional monarchy in Northern Europe, in the EU but not using the euro.', optionIds:['denmark','norway','finland','belgium'], correct:'denmark', teachHe:'דנמרק חברה באיחוד האירופי אך שומרת על הכתר הדני. נורווגיה דומה בצפון, אך בכלל אינה באיחוד.', teachEn:'Denmark is in the EU but keeps the Danish krone. Norway is similar in the north but is not in the EU at all.', compare:'norway' },
  { clueHe:'מדינה נורדית קטנה באוכלוסייה, משתמשת באירו ובולטת בטכנולוגיה ובתעשייה.', clueEn:'Nordic country with a small population, uses the euro, and stands out in technology and industry.', optionIds:['finland','denmark','sweden','norway'], correct:'finland', teachHe:'פינלנד נורדית, משתמשת באירו ובולטת בטכנולוגיה ותעשייה. דנמרק נורדית גם היא, אך אינה באירו.', teachEn:'Finland is Nordic, uses the euro, and stands out in technology and industry. Denmark is also Nordic, but does not use the euro.', compare:'denmark' },
  { clueHe:'מדינה במרכז אירופה שאינה באירו, עם בסיס ייצור חזק במיוחד של מכוניות ומכונות.', clueEn:'Central European country outside the euro, with a particularly strong manufacturing base in cars and machinery.', optionIds:['czechia','austria','hungary','romania'], correct:'czechia', teachHe:'צ׳כיה בולטת בייצור, במיוחד רכב ומכונות, והיא באיחוד האירופי אך לא באירו.', teachEn:'Czechia stands out in manufacturing, especially cars and machinery, and is in the EU but not in the euro area.', compare:'hungary' },
  { clueHe:'מדינה דרום-מערבית באירופה עם אירו ותלות חזקה יחסית בתיירות.', clueEn:'Southwestern European euro country with relatively strong dependence on tourism.', optionIds:['portugal','belgium','austria','romania'], correct:'portugal', teachHe:'פורטוגל ידועה בתיירות חזקה ובשירותים, ומשתמשת באירו.', teachEn:'Portugal is known for strong tourism and services, and it uses the euro.', compare:'spain' },
  { clueHe:'מדינה צפופה מאוד במערב אירופה, כלכלתה גדולה יחסית לגודל האוכלוסייה שלה.', clueEn:'Very dense Western European country whose economy is large relative to its population size.', optionIds:['belgium','portugal','romania','hungary'], correct:'belgium', teachHe:'בלגיה קטנה יחסית אך צפופה מאוד ובעלת כלכלה חזקה ומגוונת.', teachEn:'Belgium is relatively small but very dense, with a strong and diversified economy.', compare:'netherlands' },
  { clueHe:'מדינה שאינה באיחוד האירופי, עשירה מאוד, ומבוססת בחלקה על יצוא אנרגיה.', clueEn:'Country outside the EU, very wealthy, and partly built on energy exports.', optionIds:['norway','switzerland','denmark','finland'], correct:'norway', teachHe:'נורווגיה אינה באיחוד האירופי, עשירה מאוד, ובולטת ביצוא נפט וגז.', teachEn:'Norway is outside the EU, very wealthy, and stands out for oil and gas exports.', compare:'switzerland' },
  { clueHe:'מדינה מזרח-אירופית באיחוד האירופי, עם אוכלוסייה יחסית גדולה וכלכלה מתפתחת.', clueEn:'Eastern European EU country with a relatively large population and a growing economy.', optionIds:['romania','hungary','czechia','portugal'], correct:'romania', teachHe:'רומניה גדולה יחסית באוכלוסייה ובולטת ככלכלה מתפתחת במזרח אירופה.', teachEn:'Romania has a relatively large population and stands out as a growing Eastern European economy.', compare:'hungary' },
  { clueHe:'מדינה במרכז אירופה שאינה משתמשת באירו, אך גם אינה בין הכלכלות הגדולות ביבשת.', clueEn:'Central European country that does not use the euro, but is not among Europe’s largest economies.', optionIds:['hungary','austria','switzerland','belgium'], correct:'hungary', teachHe:'הונגריה אינה משתמשת באירו, נמצאת במרכז אירופה, וכלכלתה קטנה יותר ממדינות מרכז אירופה העשירות.', teachEn:'Hungary does not use the euro, is in Central Europe, and has a smaller economy than the richer Central European states.', compare:'czechia' },
  { clueHe:'מדינה אירופית עם תוצר לנפש גבוה מאוד, אך אוכלוסייה קטנה יחסית.', clueEn:'European country with very high GDP per capita but a relatively small population.', optionIds:['switzerland','romania','portugal','hungary'], correct:'switzerland', teachHe:'שווייץ קטנה יחסית באוכלוסייה אך עשירה מאוד לנפש.', teachEn:'Switzerland has a relatively small population but is extremely wealthy per person.', compare:'ireland' },
  { clueHe:'מדינה באיחוד האירופי המשתמשת באירו, עם אוכלוסייה קטנה יחסית וכלכלה בינונית.', clueEn:'EU country using the euro, with a relatively small population and a medium-sized economy.', optionIds:['finland','romania','belgium','denmark'], correct:'finland', teachHe:'פינלנד מתאימה: חברה באיחוד, משתמשת באירו, עם אוכלוסייה קטנה יחסית וכלכלה בינונית.', teachEn:'Finland fits: it is in the EU, uses the euro, and has a relatively small population with a medium-sized economy.', compare:'denmark' }
];

DATA.europeCorrectWrong = [
  { countryId:'portugal', statementHe:'מדינה זו משתמשת באירו.', statementEn:'This country uses the euro.', correct:true, teachHe:'פורטוגל חברה באזור האירו.', teachEn:'Portugal is part of the euro area.', compare:'hungary' },
  { countryId:'switzerland', statementHe:'מדינה זו חברה באיחוד האירופי.', statementEn:'This country is a member of the European Union.', correct:false, teachHe:'שווייץ אינה חברה באיחוד האירופי.', teachEn:'Switzerland is not a member of the European Union.', compare:'austria' },
  { countryId:'denmark', statementHe:'מדינה זו שייכת לאיחוד האירופי אך אינה משתמשת באירו.', statementEn:'This country is in the EU but does not use the euro.', correct:true, teachHe:'דנמרק באיחוד אך משתמשת בכתר הדני.', teachEn:'Denmark is in the EU but uses the Danish krone.', compare:'finland' },
  { countryId:'norway', statementHe:'מדינה זו היא יצואנית אנרגיה גדולה באירופה.', statementEn:'This country is a major energy exporter in Europe.', correct:true, teachHe:'נורווגיה בולטת ביצוא נפט וגז.', teachEn:'Norway is well known for oil and gas exports.', compare:'denmark' },
  { countryId:'belgium', statementHe:'מדינה זו היא רפובליקה.', statementEn:'This country is a republic.', correct:false, teachHe:'בלגיה היא מונרכיה חוקתית ולא רפובליקה.', teachEn:'Belgium is a constitutional monarchy, not a republic.', compare:'austria' },
  { countryId:'austria', statementHe:'מדינה זו נמצאת במרכז אירופה ומשתמשת באירו.', statementEn:'This country is in Central Europe and uses the euro.', correct:true, teachHe:'אוסטריה נמצאת במרכז אירופה והיא חלק מאזור האירו.', teachEn:'Austria is in Central Europe and is part of the euro area.', compare:'switzerland' },
  { countryId:'czechia', statementHe:'מדינה זו משתמשת באירו.', statementEn:'This country uses the euro.', correct:false, teachHe:'צ׳כיה באיחוד האירופי אך משתמשת בכתר הצ׳כי.', teachEn:'Czechia is in the EU but uses the Czech koruna.', compare:'austria' },
  { countryId:'romania', statementHe:'למדינה זו יש אחת האוכלוסיות הגדולות יותר בקבוצת המדינות הזו.', statementEn:'This country has one of the larger populations in this group.', correct:true, teachHe:'רומניה גדולה יחסית באוכלוסייה לעומת רוב המדינות בקבוצה.', teachEn:'Romania has a larger population than most countries in this set.', compare:'hungary' },
  { countryId:'hungary', statementHe:'כלכלה זו גדולה יותר מכלכלת שווייץ.', statementEn:'This economy is larger than Switzerland’s economy.', correct:false, teachHe:'כלכלת הונגריה קטנה בהרבה מזו של שווייץ.', teachEn:'Hungary’s economy is much smaller than Switzerland’s.', compare:'switzerland' },
  { countryId:'finland', statementHe:'מדינה זו היא מונרכיה חוקתית.', statementEn:'This country is a constitutional monarchy.', correct:false, teachHe:'פינלנד היא רפובליקה.', teachEn:'Finland is a republic.', compare:'denmark' },
  { countryId:'portugal', statementHe:'מדינה זו נשענת יחסית יותר על תיירות מאשר על תעשייה כבדה.', statementEn:'This country relies relatively more on tourism than on heavy industry.', correct:true, teachHe:'פורטוגל בולטת בתיירות ושירותים יותר מאשר בתעשייה כבדה.', teachEn:'Portugal stands out more for tourism and services than heavy industry.', compare:'czechia' },
  { countryId:'belgium', statementHe:'מדינה זו ידועה בתעשייה, כימיקלים ותרופות.', statementEn:'This country is known for industry, chemicals, and pharmaceuticals.', correct:true, teachHe:'בלגיה בולטת בכימיקלים, תרופות ותעשייה.', teachEn:'Belgium stands out in chemicals, pharmaceuticals, and industry.', compare:'portugal' },
  { countryId:'switzerland', statementHe:'מדינה זו משתמשת באירו.', statementEn:'This country uses the euro.', correct:false, teachHe:'שווייץ משתמשת בפרנק שווייצרי.', teachEn:'Switzerland uses the Swiss franc.', compare:'austria' },
  { countryId:'norway', statementHe:'מדינה זו חברה גם באיחוד האירופי וגם באזור האירו.', statementEn:'This country is both in the EU and in the euro area.', correct:false, teachHe:'נורווגיה אינה באיחוד האירופי ואינה באזור האירו.', teachEn:'Norway is neither in the EU nor in the euro area.', compare:'finland' },
  { countryId:'denmark', statementHe:'מדינה זו היא אחת המדינות הצפוניות העשירות באירופה.', statementEn:'This country is one of the wealthy northern countries in Europe.', correct:true, teachHe:'דנמרק היא מדינה צפונית עשירה עם כלכלה חזקה.', teachEn:'Denmark is a wealthy northern country with a strong economy.', compare:'norway' },
  { countryId:'czechia', statementHe:'מדינה זו מבוססת בעיקר על שירותים פיננסיים ולא על ייצור.', statementEn:'This country is primarily driven by financial services rather than manufacturing.', correct:false, teachHe:'צ׳כיה מזוהה הרבה יותר עם ייצור ותעשייה.', teachEn:'Czechia is much more associated with manufacturing and industry.', compare:'switzerland' },
  { countryId:'romania', statementHe:'מדינה זו משתמשת באירו.', statementEn:'This country uses the euro.', correct:false, teachHe:'רומניה עדיין משתמשת בלאו הרומני.', teachEn:'Romania still uses the Romanian leu.', compare:'portugal' },
  { countryId:'hungary', statementHe:'מדינה זו חברה באיחוד האירופי אך אינה משתמשת באירו.', statementEn:'This country is in the EU but does not use the euro.', correct:true, teachHe:'הונגריה חברה באיחוד האירופי אך משתמשת בפורינט.', teachEn:'Hungary is in the EU but uses the forint.', compare:'austria' },
  { countryId:'austria', statementHe:'מדינה זו היא אחת המדינות העשירות יחסית לנפש באירופה.', statementEn:'This country is one of the richer countries in Europe by GDP per capita.', correct:true, teachHe:'לאוסטריה תוצר לנפש גבוה יחסית.', teachEn:'Austria has relatively high GDP per capita.', compare:'hungary' },
  { countryId:'finland', statementHe:'מדינה זו שייכת לאיחוד האירופי ומשתמשת באירו.', statementEn:'This country belongs to the European Union and uses the euro.', correct:true, teachHe:'פינלנד חברה באיחוד האירופי ובאזור האירו.', teachEn:'Finland is in both the European Union and the euro area.', compare:'denmark' }
];


DATA.europeLandmarks = [
  { countryId:'france', clueHe:'מגדל ברזל מפורסם בעולם שנמצא בפריז.', clueEn:'A world-famous iron tower in Paris.', options:['france','italy','spain','germany'], landmarkHe:'מגדל אייפל', landmarkEn:'Eiffel Tower', cityHe:'פריז', cityEn:'Paris', teachHe:'מגדל אייפל נמצא בפריז והוא אחד הסמלים הגדולים של צרפת. קל להתבלבל עם איטליה בגלל תיירות ואתרים מפורסמים, אבל הקולוסיאום שייך לרומא.', teachEn:'The Eiffel Tower is in Paris and is one of the biggest symbols of France. Italy is another landmark-heavy country, but the Colosseum belongs to Rome.' },
  { countryId:'italy', clueHe:'אמפיתיאטרון רומאי עתיק מהידועים בעולם.', clueEn:'An ancient Roman amphitheater known around the world.', options:['italy','france','greece','spain'], landmarkHe:'הקולוסיאום', landmarkEn:'Colosseum', cityHe:'רומא', cityEn:'Rome', teachHe:'הקולוסיאום נמצא ברומא ומסמל את העולם הרומי העתיק. יוון מזוהה גם היא עם עתיקות, אבל הפרתנון נמצא באתונה.', teachEn:'The Colosseum is in Rome and symbolizes the ancient Roman world. Greece is also known for antiquity, but the Parthenon is in Athens.' },
  { countryId:'spain', clueHe:'בזיליקה מפורסמת ולא גמורה המזוהה עם ברצלונה.', clueEn:'A famous unfinished basilica closely associated with Barcelona.', options:['spain','italy','france','portugal'], landmarkHe:'סגרדה פמיליה', landmarkEn:'Sagrada Familia', cityHe:'ברצלונה', cityEn:'Barcelona', teachHe:'סגרדה פמיליה נמצאת בברצלונה והיא מהאתרים המפורסמים ביותר בספרד. פורטוגל קרובה גיאוגרפית, אבל האתר הזה הוא ספרדי לחלוטין.', teachEn:'The Sagrada Familia is in Barcelona and is one of Spain’s best-known landmarks. Portugal is nearby, but this landmark is distinctly Spanish.' },
  { countryId:'uk', clueHe:'מגדל שעון מפורסם מאוד בלונדון.', clueEn:'A very famous clock tower landmark in London.', options:['uk','france','belgium','germany'], landmarkHe:'ביג בן', landmarkEn:'Big Ben', cityHe:'לונדון', cityEn:'London', teachHe:'ביג בן מזוהה עם לונדון ובריטניה. בלגיה וגרמניה הן מדינות מרכזיות באירופה, אבל לא עם מגדל השעון הזה.', teachEn:'Big Ben is associated with London and the United Kingdom. Belgium and Germany are major European countries, but not with this clock tower.' },
  { countryId:'greece', clueHe:'מקדש עתיק המתנשא מעל אתונה.', clueEn:'An ancient temple standing above Athens.', options:['greece','italy','france','austria'], landmarkHe:'הפרתנון', landmarkEn:'Parthenon', cityHe:'אתונה', cityEn:'Athens', teachHe:'הפרתנון הוא סמל מרכזי של יוון העתיקה ונמצא באתונה. איטליה קשורה גם היא לעתיקות, אבל הקולוסיאום הוא באיטליה.', teachEn:'The Parthenon is a key symbol of ancient Greece and stands in Athens. Italy also has famous antiquity, but the Colosseum is Italian.' },
  { countryId:'germany', clueHe:'שער מפורסם בברלין שהפך לסמל של גרמניה המודרנית.', clueEn:'A famous gate in Berlin that became a symbol of modern Germany.', options:['germany','austria','france','netherlands'], landmarkHe:'שער ברנדנבורג', landmarkEn:'Brandenburg Gate', cityHe:'ברלין', cityEn:'Berlin', teachHe:'שער ברנדנבורג נמצא בברלין ומזוהה עם גרמניה המאוחדת. אוסטריה דוברת גרמנית גם היא, אבל האתר הזה שייך לגרמניה.', teachEn:'The Brandenburg Gate is in Berlin and is tied to modern unified Germany. Austria is also German-speaking, but this landmark belongs to Germany.' },
  { countryId:'netherlands', clueHe:'טחנות רוח מסורתיות המזוהות מאוד עם המדינה.', clueEn:'Traditional windmills strongly associated with the country.', options:['netherlands','belgium','denmark','france'], landmarkHe:'טחנות רוח הולנדיות', landmarkEn:'Dutch Windmills', cityHe:'אתרים שונים', cityEn:'Various locations', teachHe:'טחנות רוח הן אחד הסמלים המוכרים ביותר של הולנד. בלגיה ודנמרק קרובות תרבותית וגיאוגרפית, אבל הסמל הזה מזוהה במיוחד עם הולנד.', teachEn:'Windmills are one of the most recognizable symbols of the Netherlands. Belgium and Denmark are nearby, but this image is especially Dutch.' },
  { countryId:'belgium', clueHe:'כיכר מרכזית מפורסמת מאוד בבריסל.', clueEn:'A very famous central square in Brussels.', options:['belgium','france','netherlands','switzerland'], landmarkHe:'הגראנד פלאס', landmarkEn:'Grand Place', cityHe:'בריסל', cityEn:'Brussels', teachHe:'הגראנד פלאס נמצאת בבריסל והיא מהאתרים הבולטים של בלגיה. הולנד שכנה קרובה, אבל הכיכר הזאת בבלגיה.', teachEn:'The Grand Place is in Brussels and is one of Belgium’s standout landmarks. The Netherlands is nearby, but this square is Belgian.' },
  { countryId:'hungary', clueHe:'בניין פרלמנט מרשים על גדת הנהר בבודפשט.', clueEn:'A striking riverside parliament building in Budapest.', options:['hungary','romania','austria','czechia'], landmarkHe:'בניין הפרלמנט ההונגרי', landmarkEn:'Hungarian Parliament Building', cityHe:'בודפשט', cityEn:'Budapest', teachHe:'בניין הפרלמנט בבודפשט הוא אחד הסמלים המזוהים ביותר עם הונגריה. גם אוסטריה וצ׳כיה במרכז אירופה, אבל האתר הזה הונגרי.', teachEn:'The parliament building in Budapest is one of Hungary’s clearest symbols. Austria and Czechia are also Central European, but this landmark is Hungarian.' },
  { countryId:'austria', clueHe:'נוף הררי המזוהה במיוחד עם המדינה ועם תיירות חורף.', clueEn:'A mountain landscape especially associated with the country and winter tourism.', options:['austria','switzerland','italy','germany'], landmarkHe:'האלפים האוסטריים', landmarkEn:'Austrian Alps', cityHe:'ברחבי המדינה', cityEn:'Across the country', teachHe:'אוסטריה מזוהה מאוד עם האלפים, סקי ותיירות הרים. שווייץ דומה מאוד, ולכן זו שאלה טובה להשוואה בין שתי מדינות אלפיניות.', teachEn:'Austria is strongly associated with the Alps, skiing, and mountain tourism. Switzerland is very similar, which makes this a useful comparison between two Alpine countries.' }
];

DATA.europeExportCountries = [
  { id:'germany', he:'גרמניה', en:'Germany', profileHe:['מכוניות ומכונות תעשייתיות','מותגים: BMW, Siemens'], profileEn:['Cars and industrial machinery','Brands: BMW, Siemens'], teachHe:'גרמניה מזוהה עם תעשייה כבדה, רכב ומכונות. לעומת ספרד, היא נשענת הרבה יותר על יצוא תעשייתי כבד.', teachEn:'Germany is strongly associated with heavy industry, vehicles, and machinery. Compared with Spain, it leans much more on heavy industrial exports.' },
  { id:'france', he:'צרפת', en:'France', profileHe:['תעופה וחלל ומוצרי יוקרה','מותגים: Airbus, Louis Vuitton'], profileEn:['Aerospace and luxury goods','Brands: Airbus, Louis Vuitton'], teachHe:'צרפת משלבת תעשייה מתקדמת עם מותגי יוקרה עולמיים. לעומת איטליה, היא מזוהה יותר עם תעופה וחלל.', teachEn:'France combines advanced industry with global luxury brands. Compared with Italy, it is more associated with aerospace.' },
  { id:'italy', he:'איטליה', en:'Italy', profileHe:['אופנה ומכונות','מותגים: Gucci, Fiat'], profileEn:['Fashion and machinery','Brands: Gucci, Fiat'], teachHe:'איטליה משלבת עיצוב, אופנה וייצור. לעומת גרמניה, היצוא שלה פחות כבד ויותר מזוהה עם עיצוב וסגנון.', teachEn:'Italy combines design, fashion, and manufacturing. Compared with Germany, its exports are less heavy-industry focused and more design-driven.' },
  { id:'netherlands', he:'הולנד', en:'Netherlands', profileHe:['לוגיסטיקה, מסחר ומזון חקלאי','מותגים: Heineken, Philips'], profileEn:['Trade logistics and agri-food','Brands: Heineken, Philips'], teachHe:'הולנד קטנה יחסית אך חזקה מאוד במסחר, לוגיסטיקה וחקלאות מתקדמת. לעומת בלגיה, היא עוד יותר מזוהה עם תשתיות מסחר.', teachEn:'The Netherlands is relatively small but very strong in trade, logistics, and advanced agriculture. Compared with Belgium, it is even more closely tied to trading infrastructure.' },
  { id:'norway', he:'נורווגיה', en:'Norway', profileHe:['נפט, גז ואנרגיה','מותגים: Equinor, Yara'], profileEn:['Oil, gas, and energy','Brands: Equinor, Yara'], teachHe:'נורווגיה בולטת מאוד ביצוא אנרגיה. לעומת שווייץ, הכלכלה שלה פחות פיננסית ויותר מבוססת משאבים.', teachEn:'Norway stands out for energy exports. Compared with Switzerland, its economy is less finance-oriented and more resource-based.' },
  { id:'ireland', he:'אירלנד', en:'Ireland', profileHe:['טכנולוגיה ותרופות','מותגים: Ryanair, Medtronic'], profileEn:['Technology and pharmaceuticals','Brands: Ryanair, Medtronic'], teachHe:'אירלנד בולטת בטכנולוגיה ובתרופות ובחברות רב-לאומיות. לעומת פורטוגל, היא הרבה יותר חזקה ביצוא עתיר ערך.', teachEn:'Ireland stands out in technology, pharmaceuticals, and multinational activity. Compared with Portugal, it is much stronger in high-value exports.' },
  { id:'switzerland', he:'שווייץ', en:'Switzerland', profileHe:['תרופות ופיננסים','מותגים: Novartis, UBS'], profileEn:['Pharmaceuticals and finance','Brands: Novartis, UBS'], teachHe:'שווייץ מזוהה עם תרופות, פיננסים וייצור מדויק. לעומת נורווגיה, היא נשענת פחות על משאבים ויותר על ערך מוסף גבוה.', teachEn:'Switzerland is associated with pharmaceuticals, finance, and precision production. Compared with Norway, it depends less on resources and more on high value-added sectors.' },
  { id:'poland', he:'פולין', en:'Poland', profileHe:['ייצור ותעשייה צומחת','מותגים: Orlen, CD Projekt'], profileEn:['Manufacturing and industrial production','Brands: Orlen, CD Projekt'], teachHe:'פולין היא בסיס ייצור חשוב עם כלכלה תעשייתית צומחת. לעומת גרמניה, היא קטנה יותר אך עדיין תעשייתית מאוד.', teachEn:'Poland is an important manufacturing base with a growing industrial economy. Compared with Germany, it is smaller but still highly industrial.' },
  { id:'spain', he:'ספרד', en:'Spain', profileHe:['תיירות, מזון ומכוניות','מותגים: Zara, SEAT'], profileEn:['Tourism, food, and cars','Brands: Zara, SEAT'], teachHe:'ספרד משלבת תיירות חזקה עם יצוא מזון וכלי רכב. לעומת גרמניה, היא הרבה יותר נשענת על תיירות.', teachEn:'Spain combines strong tourism with food and vehicle exports. Compared with Germany, it relies much more on tourism.' },
  { id:'belgium', he:'בלגיה', en:'Belgium', profileHe:['כימיקלים ולוגיסטיקה','מותגים: Solvay, AB InBev'], profileEn:['Chemicals and logistics','Brands: Solvay, AB InBev'], teachHe:'בלגיה בולטת בכימיקלים, לוגיסטיקה ומסחר. לעומת הולנד, היא פחות מזוהה עם חקלאות ויותר עם כימיקלים.', teachEn:'Belgium stands out in chemicals, logistics, and trade. Compared with the Netherlands, it is less associated with agriculture and more with chemicals.' }
];

DATA.europeCompareCountries = [
  { questionHe:'לאיזו מדינה יש כלכלה גדולה יותר?', questionEn:'Which country has the larger economy?', optionIds:['germany','spain'], correct:'germany', teachHe:'לגרמניה כלכלה גדולה יותר מספרד. שתיהן מדינות גדולות באירופה, אבל גרמניה היא מעצמת תעשייה ויצוא חזקה יותר.', teachEn:'Germany has a larger economy than Spain. Both are major European countries, but Germany is the stronger industrial and export powerhouse.' },
  { questionHe:'לאיזו מדינה יש תוצר לנפש גבוה יותר?', questionEn:'Which country has higher GDP per capita?', optionIds:['ireland','italy'], correct:'ireland', teachHe:'לאירלנד תוצר לנפש גבוה יותר מאיטליה. איטליה גדולה יותר באוכלוסייה ובכלכלה הכוללת, אבל אירלנד עשירה יותר לנפש.', teachEn:'Ireland has higher GDP per capita than Italy. Italy is larger in population and total economy, but Ireland is richer per person.' },
  { questionHe:'איזו מדינה נשענת יותר על תיירות?', questionEn:'Which country relies more on tourism?', optionIds:['greece','germany'], correct:'greece', teachHe:'יוון נשענת יותר על תיירות, ספנות ושירותים. גרמניה תלויה יותר בתעשייה וביצוא.', teachEn:'Greece relies more on tourism, shipping, and services. Germany depends more on industry and exports.' },
  { questionHe:'איזו מדינה יותר תעשייתית ומבוססת יצוא?', questionEn:'Which country is more industrial and export-driven?', optionIds:['germany','portugal'], correct:'germany', teachHe:'גרמניה הרבה יותר תעשייתית ומבוססת יצוא מפורטוגל. פורטוגל נשענת יותר על שירותים ותיירות.', teachEn:'Germany is far more industrial and export-driven than Portugal. Portugal leans more on services and tourism.' },
  { questionHe:'לאיזו מדינה יש אוכלוסייה קטנה יותר אבל כלכלה חזקה יותר ביחס לגודלה?', questionEn:'Which country has a smaller population but a stronger economy relative to its size?', optionIds:['netherlands','greece'], correct:'netherlands', teachHe:'הולנד קטנה יותר אך כלכלתה חזקה בהרבה ביחס לגודל האוכלוסייה. יוון נשענת יותר על תיירות ופחות על מסחר גלובלי.', teachEn:'The Netherlands is smaller but much stronger economically relative to its population size. Greece leans more on tourism and less on global trade.' },
  { questionHe:'איזו מדינה אינה באיחוד האירופי ואינה משתמשת באירו?', questionEn:'Which country is not in the EU and does not use the euro?', optionIds:['switzerland','spain'], correct:'switzerland', teachHe:'שווייץ אינה באיחוד האירופי ואינה משתמשת באירו. ספרד חברה בשניהם.', teachEn:'Switzerland is not in the EU and does not use the euro. Spain is in both.' },
  { questionHe:'איזו מדינה מזוהה יותר עם יצוא אנרגיה?', questionEn:'Which country is more strongly associated with energy exports?', optionIds:['norway','france'], correct:'norway', teachHe:'נורווגיה מזוהה מאוד עם נפט וגז. צרפת חזקה יותר בתעשייה, תעופה וחלל ויוקרה.', teachEn:'Norway is strongly associated with oil and gas. France is stronger in industry, aerospace, and luxury.' },
  { questionHe:'איזו מדינה היא אחת ממעצמות התיירות הגדולות באירופה?', questionEn:'Which country is one of Europe’s tourism powerhouses?', optionIds:['spain','poland'], correct:'spain', teachHe:'ספרד היא אחת המדינות המתוירות ביותר באירופה. פולין גדלה תיירותית, אך אינה באותה רמה.', teachEn:'Spain is one of the most visited countries in Europe. Poland is growing in tourism, but not at the same level.' },
  { questionHe:'לאיזו מדינה יש תוצר לנפש גבוה יותר?', questionEn:'Which country has higher GDP per capita?', optionIds:['switzerland','portugal'], correct:'switzerland', teachHe:'לשווייץ תוצר לנפש גבוה בהרבה מפורטוגל. שתיהן מפורסמות ונחשבות נוחות לתיירים, אבל העושר לנפש בשווייץ גבוה מאוד.', teachEn:'Switzerland has much higher GDP per capita than Portugal. Both are well known and visitor-friendly, but Swiss wealth per person is much higher.' },
  { questionHe:'איזו מדינה קשורה יותר ללוגיסטיקה ומסחר בינלאומי?', questionEn:'Which country is more tied to logistics and international trade?', optionIds:['netherlands','italy'], correct:'netherlands', teachHe:'הולנד קשורה יותר ללוגיסטיקה ומסחר בינלאומי. איטליה חזקה יותר בעיצוב, מזון וייצור מגוון.', teachEn:'The Netherlands is more tied to logistics and international trade. Italy is stronger in design, food, and diversified manufacturing.' }
];

// Stable quiz catalog. Keep visual behavior unchanged; only add explicit metadata for safer maintenanc

const QUIZZES = {
  tanakh:{ type:'text', total:24, timedSeconds:12*60, color:'#8e44ad', dataKey:'tanakh', renderMode:'columns-3', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  shas:{ type:'text', total:69, timedSeconds:20*60, color:'#c0392b', dataKey:'shas', renderMode:'columns-6', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  parashot:{ type:'text', total:54, timedSeconds:15*60, color:'#27ae60', dataKey:'parashot', renderMode:'columns-3', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  gematria:{ type:'number', total:20, timedSeconds:5*60, color:'#e67e22', dataKey:'gematria', renderMode:'single-card', inputMode:'shared-number', submitHandler:'handleTextSubmit' },
  tannaim:{ type:'choice', total:20, timedSeconds:7*60, color:'#1a6fc4', dataKey:'tannaim', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  chronology:{ type:'placement', total:12, timedSeconds:7*60, color:'#16a085', dataKey:'chronology', renderMode:'placement', inputMode:'drag-like-selection', submitHandler:'handlePlacementSlot' },
  relations:{ type:'choice', total:12, timedSeconds:7*60, color:'#9b59b6', dataKey:'relations', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  worldCountries:{ type:'text', total:0, timedSeconds:15*60, color:'#3498db', dataKey:'worldCountries', renderMode:'grouped-text', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  worldCapitals:{ type:'text', total:20, timedSeconds:10*60, color:'#f5c518', dataKey:'worldCapitals', renderMode:'single-card', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  officialLanguages:{ type:'text', total:20, timedSeconds:8*60, color:'#2ecc71', dataKey:'officialLanguages', renderMode:'single-card', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  countryFlags:{ type:'choice', total:12, timedSeconds:8*60, color:'#9b59b6', dataKey:'countryFlags', renderMode:'flag-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  scrambledCountries:{ type:'text', total:12, timedSeconds:8*60, color:'#e67e22', dataKey:'scrambledCountries', renderMode:'single-card', inputMode:'shared-text', submitHandler:'handleTextSubmit' },
  mentalMathTF:{ type:'choice', total:12, timedSeconds:7*60, color:'#f39c12', dataKey:'mentalMathTF', renderMode:'true-false', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  equationCompletion:{ type:'grid-input', total:12, timedSeconds:3*60, color:'#ff8c42', dataKey:'equationCompletion', renderMode:'grid-input', inputMode:'grid', submitHandler:'handleGridRowInput' },
  multiplication:{ type:'number', total:144, timedSeconds:7*60, color:'#e74c3c', dataKey:'multiplication', renderMode:'times-table', inputMode:'shared-number', submitHandler:'handleTextSubmit' },
  fastMultiplication:{ type:'grid-input', total:20, timedSeconds:7*60, color:'#ff8c42', dataKey:'fastMultiplication', renderMode:'grid-input', inputMode:'grid', submitHandler:'handleGridRowInput' },
  fastAddition:{ type:'grid-input', total:20, timedSeconds:3*60, color:'#2ecc71', dataKey:'fastAddition', renderMode:'grid-input', inputMode:'grid', submitHandler:'handleGridRowInput' },
  romanNumerals:{ type:'grid-input', total:20, timedSeconds:4*60, color:'#9b59b6', dataKey:'romanNumerals', renderMode:'grid-input', inputMode:'grid', submitHandler:'handleGridRowInput' },
  tenCommandments:{ type:'placement', total:10, timedSeconds:6*60, color:'#e74c3c', dataKey:'tenCommandments', renderMode:'placement', inputMode:'drag-like-selection', submitHandler:'handleCommandmentSlot' },
  holidaysMonths:{ type:'choice', total:12, timedSeconds:6*60, color:'#16a085', dataKey:'holidaysMonths', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  continentQuiz:{ type:'continent-placement', total:27, timedSeconds:8*60, color:'#3498db', dataKey:'continentQuiz', renderMode:'continent-placement', inputMode:'continent-selection', submitHandler:'handleContinentBox' },
  romanMath:{ type:'grid-input', total:20, timedSeconds:7*60, color:'#f39c12', dataKey:'romanMath', renderMode:'grid-input', inputMode:'grid', submitHandler:'handleGridRowInput' },
  solarSystem:{ type:'solar-system', total:16, timedSeconds:8*60, color:'#3498db', dataKey:'solarSystem', renderMode:'two-stage-custom', inputMode:'planet-selection', submitHandler:'handleSolarTarget' },
  agesHumanity:{ type:'placement', total:14, timedSeconds:7*60, color:'#8e44ad', dataKey:'agesHumanity', renderMode:'placement', inputMode:'drag-like-selection', submitHandler:'handleAgeSlot' },
  humanBody:{ type:'info', total:13, timedSeconds:8*60, color:'#16a085', dataKey:'humanBody', renderMode:'three-stage-custom', inputMode:'body-selection', submitHandler:'handleBodyChoice' },
  inventionInventor:{ type:'choice', total:12, timedSeconds:5*60, color:'#2980b9', dataKey:'inventionInventor', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  symptomOrgan:{ type:'choice', total:12, timedSeconds:5*60, color:'#16a085', dataKey:'symptomOrgan', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  largestCountriesRanking:{ type:'placement', total:24, timedSeconds:6*60, color:'#3498db', dataKey:'largestCountriesRanking', renderMode:'two-stage-custom', inputMode:'rank-selection', submitHandler:'handleLargestCountrySlot' },
  europeProfileMatch:{ type:'placement', total:10, timedSeconds:7*60, color:'#1abc9c', dataKey:'europeProfileMatch', renderMode:'europe-profile-match', inputMode:'drag-like-selection', submitHandler:'handleEuropeProfileSlot' },
  europeCountryRanking:{ type:'placement', total:10, timedSeconds:7*60, color:'#2980b9', dataKey:'europeCountryRanking', renderMode:'europe-country-ranking', inputMode:'drag-like-selection', submitHandler:'handleEuropeRankingSlot' },
  europeCountryFits:{ type:'choice', total:12, timedSeconds:7*60, color:'#8e44ad', dataKey:'europeCountryFits', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  europeCorrectWrong:{ type:'choice', total:20, timedSeconds:7*60, color:'#16a085', dataKey:'europeCorrectWrong', renderMode:'true-false', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  europeLandmarks:{ type:'choice', total:10, timedSeconds:7*60, color:'#d35400', dataKey:'europeLandmarks', renderMode:'europe-landmarks', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  europeExportMatch:{ type:'placement', total:10, timedSeconds:7*60, color:'#c0392b', dataKey:'europeExportMatch', renderMode:'europe-export-match', inputMode:'drag-like-selection', submitHandler:'handleEuropeExportSlot' },
  europeCompareCountries:{ type:'choice', total:10, timedSeconds:7*60, color:'#34495e', dataKey:'europeCompareCountries', renderMode:'europe-compare-countries', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  whoSaidIt:{ type:'choice', total:12, timedSeconds:4*60, color:'#8e44ad', dataKey:'whoSaidIt', renderMode:'multiple-choice', inputMode:'choice-buttons', submitHandler:'handleChoice' },
  halacha:{ type:'halacha', total:40, timedSeconds:8*60, color:'#6b8e23', dataKey:'halacha', renderMode:'stage-tabs', inputMode:'choice-buttons', submitHandler:'handleChoice' }
};
QUIZZES.worldCountries.total = Object.values(DATA.worldCountries).reduce((s,a)=>s+a.length,0);

const SHARED_TEXT_INPUT_TYPES = new Set(['text', 'number']);
const HIDE_MAIN_INPUT_TYPES = new Set(['choice','placement','grid-input','continent-placement','solar-system','info','halacha']);

function findNextUnansweredMultiplicationCell(fromCell = null){
  const ordered = [];
  for (let r=1;r<=12;r++) for (let c=1;c<=12;c++) ordered.push({r,c,key:`${r}-${c}`});
  const startIndex = fromCell ? ordered.findIndex(cell => cell.r === fromCell.r && cell.c === fromCell.c) : -1;
  for (let i=startIndex+1;i<ordered.length;i++) {
    if (!state.guessed.has(ordered[i].key)) return {r:ordered[i].r, c:ordered[i].c};
  }
  for (let i=0;i<=startIndex;i++) {
    if (i >= 0 && !state.guessed.has(ordered[i].key)) return {r:ordered[i].r, c:ordered[i].c};
  }
  return fromCell || {r:1,c:1};
}

function focusMainAnswerInput(delay = 0){
  if (!el.answerInput || el.answerInput.disabled || el.inputRow.classList.contains('hidden')) return;
  setTimeout(() => {
    try { el.answerInput.focus(); } catch (e) {}
  }, delay);
}

// Maintenance-only maps for safer future edits. These are intentionally non-visual.
const QUIZ_DEPENDENCY_MAP = {
  tanakh:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Shared text flow.' },
  shas:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Shared text flow with grouped data.' },
  parashot:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Shared text flow.' },
  gematria:{ sharedState:['order','pointer','score','revealed','timeLeft','gematriaCalc'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Number input with calculator toggle.' },
  tannaim:{ sharedState:['order','pointer','score','revealed','timeLeft','tannaimFeedback'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  chronology:{ sharedState:['guessed','score','revealed','timeLeft','selectedPlacement','placements'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Placement flow.' },
  relations:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  worldCountries:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grouped text flow.' },
  worldCapitals:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Text flow.' },
  officialLanguages:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Text flow.' },
  countryFlags:{ sharedState:['order','pointer','score','revealed','timeLeft','countryFlagFeedback'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow with flag-specific feedback.' },
  scrambledCountries:{ sharedState:['order','pointer','score','revealed','timeLeft','scrambledFeedbackIndex','scrambledRevealIndex','scrambledTimerId'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Text flow with lock delay.' },
  mentalMathTF:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  equationCompletion:{ sharedState:['rowAnswers','rowLocked','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grid input flow.' },
  multiplication:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Times table with number input.' },
  fastMultiplication:{ sharedState:['rowAnswers','rowLocked','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grid input flow.' },
  fastAddition:{ sharedState:['rowAnswers','rowLocked','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grid input flow.' },
  romanNumerals:{ sharedState:['rowAnswers','rowLocked','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grid input flow.' },
  tenCommandments:{ sharedState:['guessed','score','revealed','timeLeft','selectedPlacement','placements'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Placement flow.' },
  holidaysMonths:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  continentQuiz:{ sharedState:['guessed','score','revealed','timeLeft','selectedPlacement'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Continent placement flow.' },
  europeProfileMatch:{ sharedState:['score','revealed','timeLeft','selectedPlacement','placements'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Custom Europe profile placement flow.' },
  europeCountryRanking:{ sharedState:['score','revealed','timeLeft','selectedPlacement','placements'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Custom Europe ranking flow with mode tabs.' },
  romanMath:{ sharedState:['rowAnswers','rowLocked','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Grid input flow.' },
  solarSystem:{ sharedState:['guessed','score','revealed','timeLeft','selectedPlacement'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Custom two-stage flow.' },
  agesHumanity:{ sharedState:['guessed','score','revealed','timeLeft','selectedPlacement','placements'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Placement flow.' },
  humanBody:{ sharedState:['guessed','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Custom staged flow.' },
  inventionInventor:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  symptomOrgan:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  largestCountriesRanking:{ sharedState:['guessed','score','revealed','timeLeft','rankStage','selectedRankFlagCountry','rankFlagMatches','rankFlagOrder'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Custom two-stage flow.' },
  whoSaidIt:{ sharedState:['order','pointer','score','revealed','timeLeft'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Choice flow.' },
  halacha:{ sharedState:['guessed','score','revealed','timeLeft','halachaStage','halachaAnswers','halachaPendingAdvance'], sharedActions:['resetQuiz','revealAnswers','revealOneAnswer','maybeComplete'], notes:'Stage-based flow.' }
};

const CONSISTENCY_AUDIT = {
  contentFlags:[
    'worldCountries badge/count text differs between language card definitions and should be reviewed before any content patch.',
    'Bilingual placeholders and instructions should be checked quiz by quiz before content edits.'
  ],
  styleFlags:[
    'Duplicate utility selectors exist (for example repeated hidden/table definitions). Leave behavior intact; redirect future edits to one canonical block only.',
    'Legacy shorthand selectors remain in responsive rules. Preserve for compatibility and stop expanding them.'
  ],
  interactionFlags:[
    'Global click routing is shared across all quizzes; route order must be preserved.',
    'Shared reveal/reset/progress/timer shell should remain untouched unless a quiz explicitly requires it.'
  ]
};

const QUIZ_CATEGORY_MAP = {
  jewish: ['tanakh','shas','parashot','gematria','tannaim','chronology','relations','tenCommandments','holidaysMonths','whoSaidIt','halacha'],
  math: ['mentalMathTF','equationCompletion','multiplication','fastMultiplication','fastAddition','romanNumerals','romanMath'],
  geography: ['worldCountries','worldCapitals','officialLanguages','countryFlags','scrambledCountries','continentQuiz','largestCountriesRanking','europeProfileMatch','europeCountryRanking','europeCountryFits','europeCorrectWrong','europeLandmarks','europeExportMatch','europeCompareCountries'],
  common: ['solarSystem','agesHumanity','humanBody','inventionInventor','symptomOrgan']
};

const QUIZ_EMOJIS = {tanakh:'📖',shas:'🕍',parashot:'🗂️',gematria:'א',tannaim:'👨‍🏫',chronology:'⏳',relations:'🔗',worldCountries:'🌍',worldCapitals:'🏛️',officialLanguages:'🗣️',countryFlags:'🏳️',scrambledCountries:'🔀',mentalMathTF:'🧠',equationCompletion:'🧮',multiplication:'✖️',fastMultiplication:'⚡',fastAddition:'➕',romanNumerals:'Ⅻ',tenCommandments:'📜',holidaysMonths:'🗓️',continentQuiz:'🌐',largestCountriesRanking:'📏',europeProfileMatch:'🧩',europeCountryRanking:'📊',europeCountryFits:'🎯',europeCorrectWrong:'✅',europeLandmarks:'🏛️',europeExportMatch:'🚢',europeCompareCountries:'⚖️',romanMath:'➕',solarSystem:'🪐',agesHumanity:'🏺',humanBody:'🫀',inventionInventor:'💡',symptomOrgan:'🩺',whoSaidIt:'💬',halacha:'⚖️'};

const ACCESS_CONTROL = (() => {
  const fallback = {
    categories: { jewish: true, math: true, geography: true, common: true },
    quizzes: {}
  };
  const supplied = window.APP_ACCESS_CONTROL || {};
  return {
    categories: { ...fallback.categories, ...(supplied.categories || {}) },
    quizzes: { ...fallback.quizzes, ...(supplied.quizzes || {}) }
  };
})();

function isCategoryEnabled(categoryId){
  return ACCESS_CONTROL.categories[categoryId] !== false;
}

function getQuizCategory(id){
  for (const [categoryId, ids] of Object.entries(QUIZ_CATEGORY_MAP)) {
    if (ids.includes(id)) return categoryId;
  }
  return null;
}

function isQuizEnabled(id){
  if (!id || !QUIZZES[id]) return false;
  const categoryId = getQuizCategory(id);
  if (categoryId && !isCategoryEnabled(categoryId)) return false;
  return ACCESS_CONTROL.quizzes[id] !== false;
}

function getVisibleQuizIds(categoryId){
  return (QUIZ_CATEGORY_MAP[categoryId] || []).filter(isQuizEnabled);
}

const state = {
  lang: localStorage.getItem('jq-lang') || 'he',
  mode: localStorage.getItem('jq-mode') || 'timed',
  activeQuiz: null,
  timerId: null,
  timeLeft: 0,
  revealed: false,
  score: 0,
  guessed: new Set(),
  order: [],
  pointer: 0,
  selectedPlacement: null,
  placements: [],
  tannaimFeedback: null,
  countryFlagFeedback: null,
  scrambledFeedbackIndex: null,
  scrambledRevealIndex: null,
  scrambledTimerId: null,
  rankStage: 'order',
  selectedRankFlagCountry: null,
  rankFlagMatches: {},
  rankFlagOrder: [],
  speechActive: false,
  recognition: null,
  selectedCell: {r:1,c:1},
  rowAnswers: {},
  rowLocked: {},
  gematriaCalc: false,
  halachaStage: 'daily',
  halachaAnswers: {},
  halachaPendingAdvance: null,
  revealAllUsed: false,
  continentFact: null,
  europeRankingMode: 'gdp'
};

const el = {
  body: document.body,
  homeScreen: document.getElementById('home-screen'),
  quizScreen: document.getElementById('quiz-screen'),
  quizGrid: document.getElementById('quiz-grid'),
  homeTitle: document.getElementById('home-title'),
  homeSubtitle: document.getElementById('home-subtitle'),
  sectionJewish: document.getElementById('section-jewish'),
  sectionMath: document.getElementById('section-math'),
  sectionGeo: document.getElementById('section-geo'),
  sectionCommon: document.getElementById('section-common'),
  quizGridMath: document.getElementById('quiz-grid-math'),
  quizGridGeo: document.getElementById('quiz-grid-geo'),
  quizGridCommon: document.getElementById('quiz-grid-common'),
  backBtn: document.getElementById('back-btn'),
  quizTitle: document.getElementById('quiz-title'),
  timerDisplay: document.getElementById('timer-display'),
  scoreDisplay: document.getElementById('score-display'),
  bestDisplay: document.getElementById('best-display'),
  revealBtn: document.getElementById('reveal-btn'),
  revealOneBtn: document.getElementById('reveal-one-btn'),
  teachBtn: document.getElementById('teach-btn'),
  resetBtn: document.getElementById('reset-btn'),
  pauseBtn: document.getElementById('pause-btn'),
  inputRow: document.getElementById('input-row'),
  answerInput: document.getElementById('answer-input'),
  micBtn: document.getElementById('mic-btn'),
  quizInstruction: document.getElementById('quiz-instruction'),
  quizBody: document.getElementById('quiz-body'),
  progressFill: document.getElementById('progress-fill')
};

function t(path){
  const parts = path.split('.');
  let cur = TEXT[state.lang];
  for (const part of parts) cur = cur?.[part];
  return cur ?? path;
}


const TEACHABLE_QUIZZES = new Set(['romanNumerals','romanMath','solarSystem','humanBody','tannaim','continentQuiz','officialLanguages','agesHumanity','europeProfileMatch','europeCountryRanking','europeCountryFits','europeCorrectWrong','europeLandmarks','europeExportMatch','europeCompareCountries']);

function canTeach(id){
  return TEACHABLE_QUIZZES.has(id);
}

function escapeHtml(str){
  return String(str ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
}

function teachList(items){
  return `<ul class="teach-list">${items.map(item => `<li>${item}</li>`).join('')}</ul>`;
}

function buildTeachBodyDiagram(){
  const labels = state.lang === 'he'
    ? { brain:'מוח', lungs:'ריאות', heart:'לב', stomach:'קיבה', kidneys:'כליות' }
    : { brain:'Brain', lungs:'Lungs', heart:'Heart', stomach:'Stomach', kidneys:'Kidneys' };
  return `<div class="body-diagram teach-diagram"><div class="body-silhouette">
      <div class="body-head"></div>
      <div class="body-zone filled" style="top:-52px;left:50%;transform:translateX(-50%);width:110px;height:42px">${labels.brain}</div>
      <div class="body-zone filled" style="top:72px;left:50%;transform:translateX(-50%);width:140px;height:52px">${labels.lungs}</div>
      <div class="body-zone filled" style="top:136px;left:50%;transform:translateX(-50%);width:110px;height:46px">${labels.heart}</div>
      <div class="body-zone filled" style="top:210px;left:50%;transform:translateX(-50%);width:130px;height:48px">${labels.stomach}</div>
      <div class="body-zone filled" style="top:276px;left:50%;transform:translateX(-50%);width:140px;height:48px">${labels.kidneys}</div>
    </div></div>`;
}

function buildTeachContent(id){
  const he = state.lang === 'he';
  if (id === 'europeLandmarks') {
    const item = DATA.europeLandmarks[state.order?.[Math.min(state.pointer, DATA.europeLandmarks.length-1)] ?? 0];
    const country = item ? getEuropeAnyCountry(item.countryId) : null;
    if (!item) return `<div class="teach-content"></div>`;
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'מהו האתר?' : 'What is the landmark?'}</h3>
          <div class="teach-note"><strong>${he ? item.landmarkHe : item.landmarkEn}</strong> — ${he ? item.cityHe : item.cityEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'למה הוא חשוב' : 'Why it matters'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'איך לזכור' : 'How to remember it'}</h3>
          ${teachList(he
            ? [
                `${item.landmarkHe} קשור ל${item.cityHe}, ולכן קודם זוכרים את העיר ואז את המדינה.`,
                `${country ? country.he : ''} מזוהה גם עם ${country ? country.industryHe : ''}.`,
                'חפש מילה עוגן אחת: פריז-אייפל, רומא-קולוסיאום, אתונה-פרתנון.'
              ]
            : [
                `${item.landmarkEn} is tied to ${item.cityEn}, so remember the city first and then the country.`,
                `${country ? country.en : ''} is also strongly associated with ${country ? country.industryEn : ''}.`,
                'Use one anchor phrase: Paris-Eiffel, Rome-Colosseum, Athens-Parthenon.'
              ])}
        </section>
      </div>`;
  }
  if (id === 'europeExportMatch') {
    const rows = DATA.europeExportCountries.map(item => `<tr><td>${he?item.he:item.en}</td><td>${(he?item.profileHe:item.profileEn)[0]}</td><td>${(he?item.profileHe:item.profileEn)[1]}</td><td>${he?item.teachHe:item.teachEn}</td></tr>`).join('');
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'איך ללמוד פרופילי יצוא' : 'How to learn export profiles'}</h3>
          ${teachList(he
            ? [
                'קודם מזהים את המנוע הכלכלי: תעשייה, אנרגיה, פיננסים, תיירות או מסחר.',
                'אחר כך משתמשים במותגים כעוגן זיכרון: BMW ו-Siemens = גרמניה, Zara ו-SEAT = ספרד.',
                'השווה זוגות דומים: גרמניה מול איטליה, הולנד מול בלגיה, נורווגיה מול שווייץ.'
              ]
            : [
                'First identify the economic engine: industry, energy, finance, tourism, or trade.',
                'Then use brands as memory anchors: BMW and Siemens = Germany, Zara and SEAT = Spain.',
                'Compare similar pairs: Germany vs Italy, Netherlands vs Belgium, Norway vs Switzerland.'
              ])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'טבלת עזר מלאה' : 'Full reference table'}</h3>
          <table class="teach-table"><thead><tr><th>${he?'מדינה':'Country'}</th><th>${he?'פרופיל יצוא':'Export profile'}</th><th>${he?'מותגים':'Brands'}</th><th>${he?'למה זה מתאים':'Why it fits'}</th></tr></thead><tbody>${rows}</tbody></table>
        </section>
      </div>`;
  }
  if (id === 'europeCompareCountries') {
    const item = DATA.europeCompareCountries[state.order?.[Math.min(state.pointer, DATA.europeCompareCountries.length-1)] ?? 0];
    if (!item) return `<div class="teach-content"></div>`;
    const a = getEuropeAnyCountry(item.optionIds[0]);
    const b = getEuropeAnyCountry(item.optionIds[1]);
    const winner = getEuropeAnyCountry(item.correct);
    const loser = item.optionIds.find(x => x !== item.correct);
    const loserCountry = getEuropeAnyCountry(loser);
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'למה זו התשובה' : 'Why this is the answer'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'השוואה צד מול צד' : 'Side-by-side comparison'}</h3>
          <table class="teach-table"><thead><tr><th>${he?'מדינה':'Country'}</th><th>${he?'אוכלוסייה':'Population'}</th><th>${he?'תמ"ג לנפש':'GDP per capita'}</th><th>${he?'תחום בולט':'Standout area'}</th></tr></thead><tbody>
            <tr><td>${a ? (he?a.he:a.en) : ''}</td><td>${a ? a.population?.toLocaleString('en-US') || '—' : '—'}</td><td>${a ? '$'+a.gdpPerCapitaUsd?.toLocaleString('en-US') || '—' : '—'}</td><td>${a ? ((he?a.profileHe?.[0]:a.profileEn?.[0]) || (he?a.industryHe:a.industryEn) || (he?a.exportsHe:a.exportsEn) || '—') : '—'}</td></tr>
            <tr><td>${b ? (he?b.he:b.en) : ''}</td><td>${b ? b.population?.toLocaleString('en-US') || '—' : '—'}</td><td>${b ? '$'+b.gdpPerCapitaUsd?.toLocaleString('en-US') || '—' : '—'}</td><td>${b ? ((he?b.profileHe?.[0]:b.profileEn?.[0]) || (he?b.industryHe:b.industryEn) || (he?b.exportsHe:b.exportsEn) || '—') : '—'}</td></tr>
          </tbody></table>
        </section>
        <section class="teach-section">
          <h3>${he ? 'מה כדאי לזכור' : 'What to remember'}</h3>
          ${teachList(he
            ? [
                `התשובה הנכונה כאן היא ${winner ? winner.he : ''} כי היתרון שלה בשאלה הזו חזק יותר.`,
                `${loserCountry ? loserCountry.he : 'האפשרות השנייה'} לא בהכרח חלשה יותר בכלל, אלא פשוט פחות מתאימה למדד שנשאל.`,
                'חפש תמיד את ההבדל המרכזי: תיירות מול תעשייה, גודל כלכלה מול עושר לנפש, או יצוא מול שירותים.'
              ]
            : [
                `The correct answer here is ${winner ? winner.en : ''} because its advantage is stronger for this specific metric.`,
                `${loserCountry ? loserCountry.en : 'The other option'} is not necessarily weaker overall, just less fitting for the metric being tested.`,
                'Always look for the key distinction: tourism vs industry, total economy vs wealth per person, or exports vs services.'
              ])}
        </section>
      </div>`;
  }
  if (id === 'romanNumerals') {
    const rows = [
      ['I','1'],['V','5'],['X','10'],['L','50'],['C','100'],['D','500'],['M','1000']
    ].map(([s,v]) => `<tr><td><strong>${s}</strong></td><td>${v}</td></tr>`).join('');
    return `
      <div class="teach-content">
        <div class="teach-grid-2">
          <section class="teach-section">
            <h3>${he ? 'ערכי הספרות הרומיות' : 'Roman numeral values'}</h3>
            <table class="teach-table"><thead><tr><th>${he ? 'ספרה' : 'Symbol'}</th><th>${he ? 'ערך' : 'Value'}</th></tr></thead><tbody>${rows}</tbody></table>
          </section>
          <section class="teach-section">
            <h3>${he ? 'חוק החיבור' : 'Addition rule'}</h3>
            ${teachList(he
              ? ['כאשר ספרה קטנה או שווה מופיעה אחרי ספרה אחרת, מחברים אותה.', 'VI = 6', 'VII = 7', 'XV = 15', 'LX = 60']
              : ['When a smaller or equal value comes after a numeral, you add it.', 'VI = 6', 'VII = 7', 'XV = 15', 'LX = 60'])}
          </section>
        </div>
        <section class="teach-section">
          <h3>${he ? 'חוק החיסור' : 'Subtraction rule'}</h3>
          ${teachList(he
            ? ['כאשר ספרה קטנה מופיעה לפני ספרה גדולה יותר, מחסרים אותה.', 'IV = 4', 'IX = 9', 'XL = 40', 'XC = 90', 'CD = 400', 'CM = 900']
            : ['When a smaller value comes before a larger one, you subtract it.', 'IV = 4', 'IX = 9', 'XL = 40', 'XC = 90', 'CD = 400', 'CM = 900'])}
        </section>
      </div>`;
  }
  if (id === 'romanMath') {
    const rows = [
      ['I','1'],['V','5'],['X','10'],['L','50'],['C','100'],['D','500'],['M','1000']
    ].map(([s,v]) => `<tr><td><strong>${s}</strong></td><td>${v}</td></tr>`).join('');
    return `
      <div class="teach-content">
        <div class="teach-grid-2">
          <section class="teach-section">
            <h3>${he ? 'ערכי הספרות הרומיות' : 'Roman numeral values'}</h3>
            <table class="teach-table"><thead><tr><th>${he ? 'ספרה' : 'Symbol'}</th><th>${he ? 'ערך' : 'Value'}</th></tr></thead><tbody>${rows}</tbody></table>
          </section>
          <section class="teach-section">
            <h3>${he ? 'חוק החיבור' : 'Addition rule'}</h3>
            ${teachList(he
              ? ['אם הסימנים מסודרים מגדול לקטן, מחברים אותם.', 'VIII = 8', 'XII = 12', 'LXV = 65']
              : ['If symbols go from larger to smaller, add them.', 'VIII = 8', 'XII = 12', 'LXV = 65'])}
          </section>
        </div>
        <div class="teach-grid-2">
          <section class="teach-section">
            <h3>${he ? 'חוק החיסור' : 'Subtraction rule'}</h3>
            ${teachList(he
              ? ['אם סימן קטן מופיע לפני סימן גדול יותר, מחסרים אותו.', 'IV = 4', 'IX = 9', 'XL = 40', 'XC = 90']
              : ['If a smaller symbol comes before a larger symbol, subtract it.', 'IV = 4', 'IX = 9', 'XL = 40', 'XC = 90'])}
          </section>
          <section class="teach-section">
            <h3>${he ? 'דוגמאות מהירות' : 'Quick examples'}</h3>
            ${teachList(['X + V = XV', 'X - I = IX', 'V + V = X', 'XL + X = L'])}
          </section>
        </div>
      </div>`;
  }
  if (id === 'solarSystem') {
    const planets = he ? [
      ['כוכב חמה','הראשון מהשמש','הכוכב הקרוב ביותר לשמש'],
      ['נוגה','השני מהשמש','כוכב הלכת החם ביותר'],
      ['כדור הארץ','השלישי מהשמש','היחיד הידוע עם חיים'],
      ['מאדים','הרביעי מהשמש','הכוכב האדום'],
      ['צדק','החמישי מהשמש','הגדול ביותר במערכת השמש'],
      ['שבתאי','השישי מהשמש','מפורסם בטבעות הגדולות שלו'],
      ['אורנוס','השביעי מהשמש','נוטה כמעט על צידו'],
      ['נפטון','השמיני מהשמש','הרחוק ביותר ויש בו רוחות חזקות מאוד']
    ] : [
      ['Mercury','1st from the Sun','Closest to the Sun'],
      ['Venus','2nd from the Sun','The hottest planet'],
      ['Earth','3rd from the Sun','The only known planet with life'],
      ['Mars','4th from the Sun','The red planet'],
      ['Jupiter','5th from the Sun','The largest planet'],
      ['Saturn','6th from the Sun','Known for its giant rings'],
      ['Uranus','7th from the Sun','Tilted almost on its side'],
      ['Neptune','8th from the Sun','Farthest planet with very strong winds']
    ];
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'סדר כוכבי הלכת מהשמש' : 'Planet order from the Sun'}</h3>
          <table class="teach-table"><thead><tr><th>${he ? 'כוכב לכת' : 'Planet'}</th><th>${he ? 'סדר' : 'Order'}</th><th>${he ? 'מאפיין בולט' : 'Standout property'}</th></tr></thead><tbody>${planets.map(row => `<tr><td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td></tr>`).join('')}</tbody></table>
        </section>
        <section class="teach-section">
          <h3>${he ? 'קבוצות מועילות' : 'Helpful groups'}</h3>
          ${teachList(he
            ? ['כוכבי לכת פנימיים: כוכב חמה, נוגה, כדור הארץ, מאדים', 'ענקי גז/קרח: צדק, שבתאי, אורנוס, נפטון']
            : ['Inner planets: Mercury, Venus, Earth, Mars', 'Gas/ice giants: Jupiter, Saturn, Uranus, Neptune'])}
        </section>
      </div>`;
  }
  if (id === 'agesHumanity') {
    const rows = he ? [
      ['תקופת האבן','התקופה בה בני האדם השתמשו בכלים פשוטים מאבן וצדו חיות כדי לשרוד.'],
      ['תקופת הברונזה','התקופה בה החלו להשתמש במתכת ליצירת כלים חזקים יותר וצמחו הערים הראשונות.'],
      ['תקופת הברזל','תקופה של התקדמות טכנולוגית שבה השימוש בברזל אפשר הקמת אימפריות גדולות וחקלאות יעילה יותר.'],
      ['ימי הביניים','תקופת האבירים והטירות, שבה הדת והמסחר החלו לעצב את העולם מחדש.'],
      ['הרנסאנס','תקופה של "לידה מחדש" באמנות ובמדע, שבה המצאת הדפוס שינתה את הדרך שבה אנו לומדים.'],
      ['המהפכה התעשייתית','המעבר מעבודת יד למכונות קיטור ומפעלים, שיצר את עולם הייצור ההמוני.'],
      ['עידן המידע','העידן הנוכחי שלנו, שבו המחשבים והאינטרנט מחברים את כל העולם ברגע אחד.']
    ] : [
      ['Stone Age','This era represents the very beginning of human history, where people lived as hunter-gatherers and used simple tools made from stone, bone, and wood.'],
      ['Bronze Age','Humanity began using metal for the first time by mixing copper and tin to create bronze, which led to the creation of the first organized cities and writing systems.'],
      ['Iron Age','Technology advanced as people learned to smelt iron, a much tougher and more abundant metal than bronze, allowing for the growth of massive empires and more efficient farming.'],
      ['Middle Ages','This period, also known as the Medieval era, was defined by life around castles and knights, and the spread of major world religions across Europe and the Middle East.'],
      ['Renaissance','Meaning "rebirth," this was a time of incredible growth in art, science, and philosophy, fueled by the invention of the printing press and new global explorations.'],
      ['Industrial Revolution','A massive shift where humans moved from hand-making goods to using steam-powered machines and factories, leading to the modern world of mass production and fast travel.'],
      ['Information Age','Our current era, defined by the invention of computers and the internet, allowing information to travel instantly across the globe.']
    ];
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'עידני האנושות' : 'Ages of Humanity'}</h3>
          <table class="teach-table"><thead><tr><th>${he ? 'תקופה' : 'Era'}</th><th>${he ? 'הסבר' : 'Explanation'}</th></tr></thead><tbody>${rows.map(row => `<tr><td><strong>${row[0]}</strong></td><td>${row[1]}</td></tr>`).join('')}</tbody></table>
        </section>
      </div>`;
  }
  if (id === 'humanBody') {
    const organRows = he ? [
      ['מוח','שולט בחשיבה, בתנועה ובפעולות הגוף'],
      ['לב','מזרים דם'],
      ['ריאות','מסייעות בנשימה'],
      ['קיבה','מפרקת מזון'],
      ['כבד','מעבד חומרים מזינים ומסלק רעלים'],
      ['כליות','מסננות פסולת מהדם'],
      ['מעיים','סופגים חומרים מזינים ומעבירים פסולת']
    ] : [
      ['Brain','Controls thinking, movement, and body functions'],
      ['Heart','Pumps blood'],
      ['Lungs','Help breathing'],
      ['Stomach','Breaks down food'],
      ['Liver','Processes nutrients and removes toxins'],
      ['Kidneys','Filter waste from blood'],
      ['Intestines','Absorb nutrients and move waste']
    ];
    const systems = he
      ? ['מערכת העצבים = מוח, חוט שדרה, עצבים', 'מערכת הדם = לב, דם, כלי דם', 'מערכת הנשימה = ריאות, דרכי נשימה', 'מערכת העיכול = קיבה, כבד, מעיים', 'מערכת השתן = כליות, שלפוחית השתן']
      : ['Nervous system = brain, spinal cord, nerves', 'Circulatory system = heart, blood, blood vessels', 'Respiratory system = lungs, airways', 'Digestive system = stomach, liver, intestines', 'Urinary system = kidneys, bladder'];
    return `
      <div class="teach-content">
        <div class="teach-body-wrap">
          ${buildTeachBodyDiagram()}
          <div class="teach-body-legend">
            <section class="teach-section">
              <h3>${he ? 'איברים עיקריים ותפקידיהם' : 'Main organs and functions'}</h3>
              <table class="teach-table"><thead><tr><th>${he ? 'איבר' : 'Organ'}</th><th>${he ? 'תפקיד' : 'Function'}</th></tr></thead><tbody>${organRows.map(row => `<tr><td>${row[0]}</td><td>${row[1]}</td></tr>`).join('')}</tbody></table>
            </section>
            <section class="teach-section">
              <h3>${he ? 'מערכות הגוף' : 'Body systems'}</h3>
              ${teachList(systems)}
            </section>
          </div>
        </div>
      </div>`;
  }
  if (id === 'tannaim') {
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'הרעיון המרכזי' : 'Main idea'}</h3>
          ${teachList(he
            ? ['תנאים = חכמי תקופת המשנה', 'אמוראים = חכמי תקופת הגמרא']
            : ['Tannaim = sages of the Mishnah period', 'Amoraim = sages of the Gemara period'])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'כלל זיכרון פשוט' : 'Simple memory rule'}</h3>
          ${teachList(he
            ? ['תנאים היו מוקדמים יותר', 'אמוראים באו אחריהם']
            : ['Tannaim came earlier', 'Amoraim came later'])}
        </section>
      </div>`;
  }
  if (id === 'continentQuiz') {
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'יבשות' : 'Continents'}</h3>
          ${teachList(he
            ? ['אסיה', 'אפריקה', 'אירופה', 'אמריקה הצפונית', 'אמריקה הדרומית', 'אוסטרליה', 'אנטארקטיקה']
            : ['Asia', 'Africa', 'Europe', 'North America', 'South America', 'Australia', 'Antarctica'])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'תזכורות גיאוגרפיות מהירות' : 'Quick geography reminders'}</h3>
          ${teachList(he
            ? ['קנדה, ארה״ב, מקסיקו = אמריקה הצפונית', 'ברזיל, ארגנטינה, צ׳ילה = אמריקה הדרומית', 'מצרים, ניגריה, קניה = אפריקה', 'צרפת, גרמניה, איטליה = אירופה', 'סין, הודו, יפן = אסיה', 'אוסטרליה = אוסטרליה', 'באנטארקטיקה אין מדינות']
            : ['Canada, USA, Mexico = North America', 'Brazil, Argentina, Chile = South America', 'Egypt, Nigeria, Kenya = Africa', 'France, Germany, Italy = Europe', 'China, India, Japan = Asia', 'Australia = Australia', 'Antarctica has no countries'])}
        </section>
      </div>`;
  }
  if (id === 'europeProfileMatch' || id === 'europeCountryRanking') {
    const countries = DATA.europeGeoCountries;
    const rows = countries.map(item => `<tr><td>${state.lang==='he'?item.he:item.en}</td><td>${item.population.toLocaleString('en-US')}</td><td>$${Math.round(item.gdpUsd/1000000000).toLocaleString('en-US')}B</td><td>$${item.gdpPerCapitaUsd.toLocaleString('en-US')}</td><td>${item.areaKm2.toLocaleString('en-US')}</td><td>${state.lang==='he'?item.sectorHe:item.sectorEn}</td></tr>`).join('');
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'איך ללמוד את המדינות' : 'How to learn the countries'}</h3>
          ${teachList(he
            ? ['השווה בין גודל הכלכלה לגודל האוכלוסייה', 'חפש מדינות קטנות עם תוצר לנפש גבוה', 'בדוק אילו מדינות בולטות בתיירות, ייצור או שירותים', 'שים לב להבדל בין מונרכיה לרפובליקה ובין מטבעות שונים']
            : ['Compare economy size to population size', 'Look for small countries with very high GDP per capita', 'Notice which countries stand out in tourism, manufacturing, or services', 'Pay attention to monarchy vs republic and different currencies'])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'טבלת עזר' : 'Reference table'}</h3>
          <table class="teach-table"><thead><tr><th>${he?'מדינה':'Country'}</th><th>${he?'אוכלוסייה':'Population'}</th><th>${he?'תמ"ג':'GDP'}</th><th>${he?'תמ"ג לנפש':'GDP per capita'}</th><th>${he?'שטח':'Area'}</th><th>${he?'בולט ב':'Known for'}</th></tr></thead><tbody>${rows}</tbody></table>
        </section>
      </div>`;
  }
  if (id === 'europeCountryFits') {
    const item = DATA.europeCountryFits[state.order?.[Math.min(state.pointer, DATA.europeCountryFits.length-1)] ?? 0];
    const country = item ? DATA.europeAdvancedCountries.find(c=>c.id===item.correct) : null;
    const compare = item?.compare ? DATA.europeAdvancedCountries.find(c=>c.id===item.compare) : null;
    if (!item || !country) return `<div class="teach-content"></div>`;
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'למה זו התשובה הנכונה' : 'Why this is the correct answer'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'תמונת מצב מהירה' : 'Quick snapshot'}</h3>
          ${teachList([
            `${he?'מדינה':'Country'}: <strong>${he?country.he:country.en}</strong>`,
            `${he?'אזור':'Region'}: ${he?country.regionHe:country.regionEn}`,
            `${he?'מטבע':'Currency'}: ${he?country.currencyHe:country.currencyEn}`,
            `${he?'איחוד אירופי':'EU'}: ${country.euMember ? (he?'כן':'Yes') : (he?'לא':'No')}`,
            `${he?'אירו':'Euro'}: ${country.euroMember ? (he?'כן':'Yes') : (he?'לא':'No')}`,
            `${he?'תחום בולט':'Known for'}: ${he?country.industryHe:country.industryEn}`
          ])}
        </section>
        ${compare ? `<section class="teach-section"><h3>${he ? 'השוואה מהירה' : 'Quick comparison'}</h3><div class="teach-note">${he ? `${country.he} דומה ל${compare.he} בחלק מהמאפיינים, אבל ${country.he} ${country.euroMember ? 'משתמשת' : 'לא משתמשת'} באירו ו${compare.he} ${compare.euroMember ? 'משתמשת' : 'לא משתמשת'} באירו.` : `${country.en} is similar to ${compare.en} in some ways, but ${country.en} ${country.euroMember ? 'uses' : 'does not use'} the euro while ${compare.en} ${compare.euroMember ? 'uses' : 'does not use'} the euro.`}</div></section>` : ''}<section class="teach-section"><h3>${he ? 'עוד מה לזכור' : 'What else to remember'}</h3>${teachList([`${he?'אוכלוסייה':'Population'}: ${country.population.toLocaleString('en-US')}`, `${he?'תמ"ג לנפש':'GDP per capita'}: $${country.gdpPerCapitaUsd.toLocaleString('en-US')}`, `${he?'תיירות':'Tourism'}: ${he?country.tourismHe:country.tourismEn}`])}</section>
      </div>`;
  }
  if (id === 'europeCorrectWrong') {
    const item = DATA.europeCorrectWrong[state.order?.[Math.min(state.pointer, DATA.europeCorrectWrong.length-1)] ?? 0];
    const country = item ? DATA.europeAdvancedCountries.find(c=>c.id===item.countryId) : null;
    const compare = item?.compare ? DATA.europeAdvancedCountries.find(c=>c.id===item.compare) : null;
    if (!item || !country) return `<div class="teach-content"></div>`;
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'הסבר' : 'Explanation'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'תמונת מצב מהירה' : 'Quick snapshot'}</h3>
          ${teachList([
            `${he?'מדינה':'Country'}: <strong>${he?country.he:country.en}</strong>`,
            `${he?'מטבע':'Currency'}: ${he?country.currencyHe:country.currencyEn}`,
            `${he?'איחוד אירופי':'EU'}: ${country.euMember ? (he?'כן':'Yes') : (he?'לא':'No')}`,
            `${he?'אירו':'Euro'}: ${country.euroMember ? (he?'כן':'Yes') : (he?'לא':'No')}`,
            `${he?'שיטת משטר':'System'}: ${he?country.systemHe:country.systemEn}`,
            `${he?'תחומי יצוא':'Export profile'}: ${he?country.exportsHe:country.exportsEn}`
          ])}
        </section>
        ${compare ? `<section class="teach-section"><h3>${he ? 'השוואה מהירה' : 'Quick comparison'}</h3><div class="teach-note">${he ? `${country.he} מושווית כאן ל${compare.he} כדי לחזק את ההבדל המרכזי בשאלה.` : `${country.en} is compared here to ${compare.en} to reinforce the key distinction in the question.`}</div></section>` : ''}
      </div>`;
  }
  if (id === 'officialLanguages') {
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'דוגמאות נפוצות' : 'Common examples'}</h3>
          ${teachList(he
            ? ['ישראל = עברית', 'ארה״ב = אנגלית', 'צרפת = צרפתית', 'ספרד = ספרדית', 'גרמניה = גרמנית', 'איטליה = איטלקית', 'יפן = יפנית', 'ברזיל = פורטוגזית', 'סין = סינית מנדרינית', 'ערב הסעודית = ערבית']
            : ['Israel = Hebrew', 'USA = English', 'France = French', 'Spain = Spanish', 'Germany = German', 'Italy = Italian', 'Japan = Japanese', 'Brazil = Portuguese', 'China = Mandarin Chinese', 'Saudi Arabia = Arabic'])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'טיפ' : 'Tip'}</h3>
          <div class="teach-note">${he ? 'שפה רשמית אינה תמיד השפה היחידה שמדברים במדינה.' : 'The official language is not always the only language people speak.'}</div>
        </section>
      </div>`;
  }
  return `<div class="teach-note"></div>`;
}


let continentFactTimer = null;

function clearContinentFactTimer(){
  if (continentFactTimer) {
    clearTimeout(continentFactTimer);
    continentFactTimer = null;
  }
}

function showContinentFact(item){
  const fact = CONTINENT_FACTS[item.en];
  if (!fact) return;
  state.continentFact = item.en;
  const overlay = document.getElementById('continent-fact-overlay');
  const kicker = document.getElementById('continent-fact-kicker');
  const country = document.getElementById('continent-fact-country');
  const statement = document.getElementById('continent-fact-statement');
  const closeBtn = document.getElementById('continent-fact-close-btn');
  if (!overlay || !kicker || !country || !statement || !closeBtn) return;
  kicker.textContent = t('didYouKnow');
  closeBtn.textContent = t('close');
  country.innerHTML = `${renderFlagBox(item.flag)}<span>${state.lang==='he' ? (fact.heCountry || item.he) : item.en}</span>`;
  statement.textContent = state.lang==='he' ? fact.he : fact.en;
  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden','false');
  clearContinentFactTimer();
  continentFactTimer = setTimeout(hideContinentFact, 3500);
}

function hideContinentFact(){
  clearContinentFactTimer();
  state.continentFact = null;
  const overlay = document.getElementById('continent-fact-overlay');
  const country = document.getElementById('continent-fact-country');
  const statement = document.getElementById('continent-fact-statement');
  if (overlay) {
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden','true');
  }
  if (country) country.innerHTML = '';
  if (statement) statement.textContent = '';
}

let countryFlagFactTimer = null;
let countryFlagFactPending = null;

function clearCountryFlagFactTimer(){
  if (countryFlagFactTimer) {
    clearTimeout(countryFlagFactTimer);
    countryFlagFactTimer = null;
  }
}

function finalizeCountryFlagFact(){
  if (!countryFlagFactPending) return;
  hideCountryFlagFact();
  state.pointer++;
  maybeComplete();
  renderQuiz();
}

function showCountryFlagFact(item){
  const fact = COUNTRY_FLAG_FACTS[item.country.en];
  if (!fact) {
    state.pointer++;
    maybeComplete();
    renderQuiz();
    return;
  }
  countryFlagFactPending = item.country.en;
  const overlay = document.getElementById('country-flag-fact-overlay');
  const kicker = document.getElementById('country-flag-fact-kicker');
  const country = document.getElementById('country-flag-fact-country');
  const statement = document.getElementById('country-flag-fact-statement');
  const closeBtn = document.getElementById('country-flag-fact-close-btn');
  if (!overlay || !kicker || !country || !statement || !closeBtn) {
    state.pointer++;
    maybeComplete();
    renderQuiz();
    return;
  }
  kicker.textContent = t('didYouKnow');
  closeBtn.textContent = t('close');
  country.innerHTML = `${renderFlagBox(item.correct)}<span>${state.lang==='he' ? item.country.he : item.country.en}</span>`;
  statement.textContent = state.lang==='he' ? fact.he : fact.en;
  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden','false');
  clearCountryFlagFactTimer();
  countryFlagFactTimer = setTimeout(finalizeCountryFlagFact, 3500);
}

function hideCountryFlagFact(){
  clearCountryFlagFactTimer();
  countryFlagFactPending = null;
  const overlay = document.getElementById('country-flag-fact-overlay');
  const country = document.getElementById('country-flag-fact-country');
  const statement = document.getElementById('country-flag-fact-statement');
  if (overlay) {
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden','true');
  }
  if (country) country.innerHTML = '';
  if (statement) statement.textContent = '';
}

function showTeachOverlay(){
  if (!state.activeQuiz || !canTeach(state.activeQuiz)) return;
  const overlay = document.getElementById('teach-overlay');
  const title = document.getElementById('teach-title');
  const subtitle = document.getElementById('teach-subtitle');
  const content = document.getElementById('teach-content');
  const closeBtn = document.getElementById('teach-close-btn');
  if (!overlay || !title || !subtitle || !content || !closeBtn) return;
  const info = t(`quizCards.${state.activeQuiz}`);
  title.textContent = `${t('teachMe')} · ${info.title}`;
  subtitle.textContent = info.desc;
  closeBtn.textContent = t('close');
  content.innerHTML = buildTeachContent(state.activeQuiz);
  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden', 'false');
}

function hideTeachOverlay(){
  const overlay = document.getElementById('teach-overlay');
  const content = document.getElementById('teach-content');
  if (overlay) {
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden', 'true');
  }
  if (content) content.innerHTML = '';
}



function setLang(lang){
  state.lang = lang;
  localStorage.setItem('jq-lang', lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'he' ? 'rtl' : 'ltr';
  el.body.setAttribute('dir', document.documentElement.dir);
  updateToggleButtons();
  renderHome();
  if (state.activeQuiz) renderQuiz();
  if (document.getElementById('teach-overlay')?.classList.contains('active')) showTeachOverlay();
  if (document.getElementById('continent-fact-overlay')?.classList.contains('active') && state.continentFact) {
    const item = DATA.continentQuiz.countries.find(c => c.en === state.continentFact);
    if (item) showContinentFact(item);
  }
}

function setMode(mode){
  const prevMode = state.mode;
  state.mode = mode;
  localStorage.setItem('jq-mode', mode);
  const cfg = state.activeQuiz ? QUIZZES[state.activeQuiz] : null;
  clearInterval(state.timerId);
  state.timerId = null;
  if (mode === 'untimed') {
    state.paused = false;
  } else if (state.activeQuiz && cfg?.timedSeconds && !state.revealed) {
    if (!state.timeLeft || state.timeLeft <= 0) state.timeLeft = cfg.timedSeconds;
    if (prevMode === 'untimed') state.paused = false;
    if (!state.paused) startTimer();
  }
  updateToggleButtons();
  if (state.activeQuiz) renderQuiz();
}

function updateToggleButtons(){
  document.querySelectorAll('#home-screen [data-lang]').forEach(btn => btn.classList.toggle('active', btn.dataset.lang === state.lang));
  document.querySelectorAll('#quiz-screen [data-mode="timed"]').forEach(btn => { btn.textContent = t('timed'); btn.classList.toggle('active', state.mode==='timed'); });
  document.querySelectorAll('#quiz-screen [data-mode="untimed"]').forEach(btn => { btn.textContent = t('untimed'); btn.classList.toggle('active', state.mode==='untimed'); });
  if (el.micBtn) el.micBtn.title = t('voiceInput');
  if (el.pauseBtn) el.pauseBtn.textContent = state.paused ? t('resume') : t('pause');
}

function formatDisplay(item){
  return state.lang === 'he'
    ? `${item.he} <span class="secondary">(${item.en})</span>`
    : `${item.en} <span class="secondary">(${item.he})</span>`;
}

function formatCountryWithCapital(item){
  if (!item?.country || !item?.capital) return '';
  if (state.lang === 'he') {
    return `${item.country.he} <span class="secondary">(${item.country.en})</span> <span class="secondary">— ${item.capital.he} (${item.capital.en})</span>`;
  }
  return `${item.country.en} <span class="secondary">(${item.country.he})</span> <span class="secondary">— ${item.capital.en} (${item.capital.he})</span>`;
}

function renderFlagBox(flag){
  return `<div class="flag-box">${flagSvg(flag)}</div>`;
}

const COUNTRY_FACTS = {
  'Israel': [
    'The Dead Sea: The lowest point on Earth is in Israel! The water in the Dead Sea is so salty that you can float on it effortlessly without even trying to swim.',
    'Hebrew Script: In Hebrew, people write from right to left, which is the exact opposite of English!'
  ],
  'Brazil': [
    'The Amazon Rainforest: Most of the Amazon Rainforest is in Brazil; it is the world\'s largest forest and creates much of our oxygen.',
    'The Amazon River: Brazil is home to the Amazon River, which carries more water than any other river on Earth.'
  ],
  'Germany': [
    'Engineering Powerhouse: Germany is the largest economy in Europe and is famous for producing high-quality machinery and cars, including world-famous brands like Volkswagen, BMW, and Mercedes-Benz.',
    'The Printing Press: The first moving-type printing press was invented in Germany, which allowed people all over the world to finally start sharing books and stories.'
  ],
  'France': [
    'The Eiffel Tower: The Eiffel Tower grows about 15 cm every summer because heat expands its metal.',
    'Tourism Leader: France is the most visited country in the world, welcoming more international tourists than any other nation.'
  ],
  'Japan': [
    'Bullet Trains: Japan has super-fast "Bullet Trains" that almost never arrive more than 30 seconds late.',
    'Cat Island: Japan has an entire island (Tashirojima) where there are many more cats living there than humans.'
  ],
  'Mexico': [
    'The World of Chocolate: Mexico is where chocolate was first discovered—long ago, people even drank it with chili peppers!',
    'The Floating City: The capital, Mexico City, is built on an ancient lake and is slowly sinking every year.'
  ],
  'Italy': [
    'Volcanoes: Italy is the only country in mainland Europe with active volcanoes that erupt from time to time.',
    'The Radio: The Italian inventor Marconi was the first to successfully send messages through the air using radio waves.'
  ],
  'Canada': [
    'Wildlife: Canada has about 2.4 million caribou and moose, and it’s one of the best places to see polar bears in the wild.',
    'Maple Syrup: Canada produces almost all of the world\'s maple syrup—it comes from the sap of the maple tree, which is also on their flag!'
  ],
  'United Kingdom': [
    'Football Origins: Although many countries play football (soccer), the modern rules of the game were invented in the UK.',
    'The Underground: London is home to the world\'s oldest underground railway system, known as the "Tube," which opened in 1863.'
  ],
  'Ukraine': [
    'The World’s Largest Plane: Ukraine built the world’s heaviest and largest airplane ever flown, called the "Mriya."',
    'The Breadbasket: Ukraine is known as the "Breadbasket of Europe" because it is one of the world\'s top exporters of grain and sunflower oil.'
  ],
  'Switzerland': [
    'The Alps: Switzerland is home to the snowy Alps and has over 200 mountains higher than 3,000 meters!',
    'Chocolate Kingdom: The Swiss eat the most chocolate in the world, and they were the ones who actually invented milk chocolate.'
  ],
  'United States': [
    'World’s Largest Economy: The United States has the world’s largest economy, producing a huge portion of the world\'s goods, services, and technology.',
    'The Internet: The internet we use every day was invented in the United States as a military and scientific project.'
  ]
};

const COUNTRY_FACTS_HE = {
  'Israel': [
    'ים המלח: הנקודה הנמוכה ביותר על פני כדור הארץ נמצאת בישראל. המים בים המלח כל כך מלוחים שאפשר לצוף בהם כמעט בלי להתאמץ.',
    'כתב עברי: בעברית כותבים מימין לשמאל, בדיוק הפוך מאנגלית.'
  ],
  'Brazil': [
    'יער האמזונס: רוב יער האמזונס נמצא בברזיל; זהו היער הגדול בעולם והוא מייצר חלק גדול מהחמצן שלנו.',
    'נהר האמזונס: בברזיל נמצא נהר האמזונס, שמעביר יותר מים מכל נהר אחר בעולם.'
  ],
  'Germany': [
    'מעצמת הנדסה: גרמניה היא הכלכלה הגדולה ביותר באירופה ומפורסמת בייצור מכונות ומכוניות איכותיות, כולל מותגים ידועים כמו פולקסווגן, BMW ומרצדס-בנץ.',
    'מכונת הדפוס: מכונת הדפוס הראשונה עם אותיות נעות הומצאה בגרמניה, ואפשרה לאנשים ברחבי העולם להפיץ ספרים וסיפורים.'
  ],
  'France': [
    'מגדל אייפל: מגדל אייפל גדל בכ-15 סנטימטרים בכל קיץ כי החום מרחיב את המתכת שלו.',
    'מובילה בתיירות: צרפת היא המדינה המתוירת ביותר בעולם ומקבלת יותר תיירים בינלאומיים מכל מדינה אחרת.'
  ],
  'Japan': [
    'רכבות קליע: ביפן יש רכבות קליע מהירות במיוחד שכמעט אף פעם אינן מאחרות ביותר מ-30 שניות.',
    "אי החתולים: ביפן יש אי שלם, טשירוג'ימה, שבו יש יותר חתולים מבני אדם."
  ],
  'Mexico': [
    'עולם השוקולד: מקסיקו היא המקום שבו התגלה השוקולד לראשונה — ובעבר אפילו נהגו לשתות אותו עם פלפל חריף.',
    'העיר הצפה: עיר הבירה מקסיקו סיטי בנויה על אגם עתיק והיא שוקעת לאט בכל שנה.'
  ],
  'Italy': [
    'הרי געש: איטליה היא המדינה היחידה ביבשת אירופה שיש בה הרי געש פעילים שמתפרצים מדי פעם.',
    'הרדיו: הממציא האיטלקי מרקוני היה הראשון שהצליח להעביר מסרים באוויר באמצעות גלי רדיו.'
  ],
  'Canada': [
    'חיות בר: בקנדה יש כ-2.4 מיליון איילי צפון ואיילים גדולים, והיא אחד המקומות הטובים בעולם לראות בהם דובי קוטב בטבע.',
    'סירופ מייפל: קנדה מייצרת כמעט את כל סירופ המייפל בעולם — הוא מופק ממוהל עץ המייפל, שמופיע גם על הדגל שלה.'
  ],
  'United Kingdom': [
    'מקור הכדורגל: למרות שמדינות רבות משחקות כדורגל, החוקים המודרניים של המשחק הומצאו בבריטניה.',
    'הרכבת התחתית: לונדון היא ביתה של מערכת הרכבת התחתית הוותיקה בעולם, "הטיוב", שנפתחה בשנת 1863.'
  ],
  'Ukraine': [
    'המטוס הגדול בעולם: אוקראינה בנתה את המטוס הכבד והגדול ביותר שאי פעם טס, שנקרא "מריה".',
    'אסם הלחם של אירופה: אוקראינה ידועה כ"אסם הלחם של אירופה" משום שהיא אחת היצואניות הגדולות בעולם של דגנים ושמן חמניות.'
  ],
  'Switzerland': [
    'האלפים: שווייץ היא ביתם של הרי האלפים המושלגים ויש בה יותר מ-200 הרים שגובהם מעל 3,000 מטרים.',
    'ממלכת השוקולד: השווייצרים אוכלים הכי הרבה שוקולד בעולם, והם גם אלה שהמציאו את שוקולד החלב.'
  ],
  'United States': [
    'הכלכלה הגדולה בעולם: לארצות הברית יש הכלכלה הגדולה בעולם, והיא מייצרת חלק עצום מהמוצרים, השירותים והטכנולוגיה בעולם.',
    'האינטרנט: האינטרנט שבו אנחנו משתמשים בכל יום הומצא בארצות הברית במסגרת פרויקט צבאי ומדעי.'
  ]
};

function getCountryFactLines(item){
  const key = item?.country?.en;
  if (!key) return [];
  if (state.lang === 'he') return COUNTRY_FACTS_HE[key] || [];
  const facts = COUNTRY_FACTS[key];
  if (Array.isArray(facts)) return facts;
  return facts?.en || [];
}

function renderCountryFactHtml(item){
  const lines = getCountryFactLines(item);
  if (!lines.length) return '';
  return `<div class="review-row" style="margin-top:16px">${lines.map(line => `<div class="review-answer" style="margin-top:8px">${line}</div>`).join('')}</div>`;
}

const SCRAMBLED_COUNTRY_FACTS = {
  "India": {
    en: "India is most known for being the world's largest democracy and home to the iconic Taj Mahal, as well as its rich diversity of cultures and spices.",
    he: "הודו ידועה בעיקר בתור הדמוקרטיה הגדולה בעולם, ביתו של הטאג' מהאל האייקוני, ובזכות המגוון העשיר של תרבויות ותבלינים."
  },
  "Brazil": {
    en: "Brazil is famous for the Amazon Rainforest, its vibrant Carnival festival, and being the only country to have won the FIFA World Cup five times.",
    he: "ברזיל מפורסמת בזכות יער האמזונס, פסטיבל הקרנבל התוסס שלה, ובתור המדינה היחידה שזכתה בחמישה גביעי עולם בכדורגל."
  },
  "Japan": {
    en: "Japan is known for its unique blend of ancient traditions and futuristic technology, including sushi, anime, and super-fast bullet trains.",
    he: "יפן ידועה בשילוב הייחודי שלה בין מסורות עתיקות לטכנולוגיה עתידנית, כולל סושי, ורכבות קליע מהירות במיוחד."
  },
  "France": {
    en: "France is the most visited country in the world, renowned for its art, the Eiffel Tower, and its world-class bread and cheese.",
    he: "צרפת היא המדינה המתויירת ביותר בעולם, והיא ידועה באמנות שלה, במגדל אייפל ובלחמים ובגבינות ברמה עולמית."
  },
  "Germany": {
    en: "Germany is a global leader in engineering and car manufacturing, famous for the Autobahn and high-quality brands like BMW and Mercedes-Benz.",
    he: "גרמניה היא מובילה עולמית בהנדסה ובייצור מכוניות, ומפורסמת בזכות האוטובאן ומותגים איכותיים כמו BMW ומרצדס-בנץ."
  },
  "Canada": {
    en: "Canada is known for its vast natural beauty, including the Rocky Mountains, and for producing the vast majority of the world's maple syrup.",
    he: "קנדה ידועה ביופי הטבעי העצום שלה, כולל הרי הרוקי, ובייצור הרוב המוחלט של סירופ המייפל בעולם."
  },
  "Mexico": {
    en: "Mexico is famous for its ancient Aztec and Mayan pyramids, its spicy cuisine, and for being the birthplace of chocolate.",
    he: "מקסיקו מפורסמת בזכות פירמידות האצטקים והמאיה העתיקות שלה, המטבח החריף שלה, ובהיותה מקום הולדתו של השוקולד."
  },
  "Italy": {
    en: "Italy is renowned for its incredible history, being the home of the Roman Empire, and for gifting the world pizza and pasta.",
    he: "איטליה ידועה בהיסטוריה המדהימה שלה בתור ביתה של האימפריה הרומית, ובכך שהעניקה לעולם את הפיצה והפסטה."
  },
  "Egypt": {
    en: "Egypt is world-famous for its ancient civilization and the Great Pyramids of Giza, the only one of the Seven Wonders of the Ancient World still standing.",
    he: "מצרים מפורסמת בעולם בזכות הציוויליזציה העתיקה שלה והפירמידות הגדולות של גיזה, היחידות מבין שבעת פלאי העולם העתיק שעדיין עומדות על תלן."
  },
  "Israel": {
    en: "Israel is known for its deep religious history, being home to Jerusalem's holy sites, and for its leading role in modern high-tech innovation.",
    he: "ישראל ידועה בהיסטוריה הדתית העמוקה שלה, בהיותה ביתם של המקומות הקדושים בירושלים, ובחלק המרכזי שהיא לוקחת בחדשנות טכנולוגית מודרנית."
  },
  "Korea": {
    en: "Korea is known for its massive global cultural influence through K-Pop, K-dramas, and world-leading electronics companies like Samsung.",
    he: "קוריאה ידועה בהשפעה התרבותית העולמית העצומה שלה דרך ה-K-Pop, דרמות קוריאניות וחברות אלקטרוניקה מובילות כמו סמסונג."
  },
  "Nigeria": {
    en: "Nigeria is known as the \"Giant of Africa\" for having the continent's largest population and for its huge Nollywood film industry.",
    he: "ניגריה ידועה בתור \"הענקית של אפריקה\" בשל היותה המדינה עם האוכלוסייה הגדולה ביותר ביבשת ובזכות תעשיית הקולנוע הענקית שלה, \"נוליווד\"."
  }
};

function getScrambledCountryFact(item){
  const fact = SCRAMBLED_COUNTRY_FACTS[item?.item?.en];
  if (!fact) return '';
  return state.lang === 'he' ? fact.he : fact.en;
}

function renderScrambledCountryFactHtml(item){
  const line = getScrambledCountryFact(item);
  if (!line) return '';
  return `<div class="review-row" style="margin-top:16px"><div class="review-answer">${line}</div></div>`;
}


const TEN_COMMANDMENT_FACTS = {
  'I am the Lord your God': {
    en: 'To believe that there is only one Creator who runs the world.',
    he: 'להאמין שיש בורא אחד ויחיד המנהיג את העולם.'
  },
  'No other gods': {
    en: 'Putting nothing else, such as money or fame, as more important than our values.',
    he: 'לא להציב שום דבר אחר, כמו כסף או פרסום, כחשוב יותר מהערכים שלנו.'
  },
  'Do not take God’s name in vain': {
    en: 'Respecting the power of our words and the importance of keeping our promises.',
    he: 'לכבד את כוחן של המילים שלנו ואת החשיבות של עמידה בהבטחות.'
  },
  'Remember the Sabbath': {
    en: 'Recognizing the sanctity of time by setting aside a day for spiritual rest.',
    he: 'להכיר בקדושת הזמן על ידי הקדשת יום למנוחה רוחנית.'
  },
  'Honor your father and mother': {
    en: 'Showing gratitude and respect to those who brought us into the world.',
    he: 'להפגין הכרת טוב וכבוד לאלו שהביאו אותנו לעולם.'
  },
  'Do not murder': {
    en: 'Protecting and valuing the physical and emotional life of every human being.',
    he: 'להגן ולהעריך את החיים הפיזיים והרגשיים של כל בן אנוש.'
  },
  'Do not commit adultery': {
    en: 'Being loyal and faithful to the people we love and the commitments we make.',
    he: 'להיות נאמנים לאנשים שאנו אוהבים ולמחויבויות שאנו לוקחים על עצמנו.'
  },
  'Do not steal': {
    en: 'Respecting the boundaries and the hard work of others by not taking what is not ours.',
    he: 'לכבד את הגבולות ואת העבודה הקשה של אחרים על ידי אי-לקיחת מה שאינו שלנו.'
  },
  'Do not bear false witness': {
    en: 'Understanding the vital importance of being a person of truth in all communications.',
    he: 'להבין את החשיבות המכרעת של להיות איש אמת בכל תקשורת.'
  },
  'Do not covet': {
    en: 'Being happy with what you have rather than focusing on what others possess.',
    he: 'להיות שמח בחלקך במקום להתמקד במה שיש לאחרים.'
  }
};

function getTenCommandmentFact(item){
  const fact = TEN_COMMANDMENT_FACTS[item?.en];
  if (!fact) return '';
  return state.lang === 'he' ? fact.he : fact.en;
}

function renderTenCommandmentFactHtml(item){
  const line = getTenCommandmentFact(item);
  if (!line) return '';
  return `<div class="review-row" style="margin-top:16px"><div class="review-answer" style="font-size:1.06rem; line-height:1.7">${line}</div></div>`;
}

const CHRONOLOGY_FIGURE_FACTS = {
  Adam: {
    en: 'Adam was the first human according to the Bible and is described as the ancestor of all humanity.',
    he: 'אדם היה האדם הראשון לפי התנ״ך, והוא מתואר כאב הקדמון של האנושות כולה.'
  },
  Noah: {
    en: 'Noah is known for building the ark and surviving the flood, preserving his family and the animal world.',
    he: 'נח ידוע בכך שבנה את התיבה ושרד את המבול, ובכך שמר על משפחתו ועל עולם החי.'
  },
  Abraham: {
    en: 'Abraham is regarded as the founding patriarch of the people of Israel and is known for his covenant with God.',
    he: 'אברהם נחשב לאב המייסד של עם ישראל, וידוע בזכות הברית שכרת עם אלוהים.'
  },
  Isaac: {
    en: 'Isaac was the son of Abraham and Sarah and became the father of Jacob and Esau.',
    he: 'יצחק היה בנם של אברהם ושרה, והפך לאביהם של יעקב ועשיו.'
  },
  Jacob: {
    en: 'Jacob, also called Israel, was the father of the twelve tribes that became the nation of Israel.',
    he: 'יעקב, שנקרא גם ישראל, היה אביהם של שנים עשר השבטים שהפכו לעם ישראל.'
  },
  Joseph: {
    en: 'Joseph was sold into Egypt by his brothers, rose to power there, and later saved his family during famine.',
    he: 'יוסף נמכר למצרים בידי אחיו, עלה שם לגדולה, ובהמשך הציל את משפחתו בזמן רעב.'
  },
  Moses: {
    en: 'Moses led the Israelites out of Egypt and is central to the giving of the Torah at Mount Sinai.',
    he: 'משה הנהיג את בני ישראל ביציאת מצרים, והוא דמות מרכזית במתן התורה בהר סיני.'
  },
  Joshua: {
    en: 'Joshua succeeded Moses and led the Israelites into the Land of Israel.',
    he: 'יהושע הנהיג את בני ישראל אחרי משה והכניס אותם לארץ ישראל.'
  },
  Samuel: {
    en: 'Samuel was a prophet and judge who anointed Saul and later David as kings.',
    he: 'שמואל היה נביא ושופט שמָשַׁח את שאול ולאחר מכן את דוד למלכים.'
  },
  David: {
    en: 'David was the king who established Jerusalem as the political center of Israel and became one of its most famous rulers.',
    he: 'דוד היה המלך שקבע את ירושלים כמרכז המדיני של ישראל, והפך לאחד משליטיה המפורסמים ביותר.'
  },
  Solomon: {
    en: 'Solomon, the son of David, is known for his wisdom and for building the First Temple in Jerusalem.',
    he: 'שלמה, בנו של דוד, ידוע בחוכמתו ובכך שבנה את בית המקדש הראשון בירושלים.'
  },
  Isaiah: {
    en: 'Isaiah was a major prophet whose messages focused on justice, repentance, and hope for redemption.',
    he: 'ישעיהו היה מנביאי ישראל המרכזיים, ונבואותיו עסקו בצדק, בתשובה ובתקווה לגאולה.'
  }
};

function getChronologyFigureFact(item){
  const fact = CHRONOLOGY_FIGURE_FACTS[item?.en];
  if (!fact) return '';
  return state.lang === 'he' ? fact.he : fact.en;
}

function renderChronologyFigureFactHtml(item){
  const line = getChronologyFigureFact(item);
  if (!line) return '';
  return `<div class="review-row" style="margin-top:16px"><div class="review-answer">${line}</div></div>`;
}

function flash(msg, isError=false){
  const div = document.createElement('div');
  div.className = `flash${isError?' error':''}`;
  div.textContent = msg;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 1600);
}

function normalize(str){
  return String(str || '')
    .toLowerCase()
    .trim()
    .replace(/["׳״'`]/g,'')
    .replace(/[-–—]/g,' ')
    .replace(/\s+/g,' ')
    .replace(/[.,!?;:()]/g,'')
    .replace(/\bthe\b/g,'')
    .trim();
}

function levenshtein(a,b){
  if (a===b) return 0;
  const m = Array.from({length:b.length+1}, (_,i)=>[i]);
  for (let j=0;j<=a.length;j++) m[0][j]=j;
  for (let i=1;i<=b.length;i++){
    for (let j=1;j<=a.length;j++){
      m[i][j]=b.charAt(i-1)===a.charAt(j-1)
        ? m[i-1][j-1]
        : Math.min(m[i-1][j-1]+1,m[i][j-1]+1,m[i-1][j]+1);
    }
  }
  return m[b.length][a.length];
}

function fuzzyMatch(input, candidates){
  const n = normalize(input);
  if (!n) return false;
  for (const candidate of candidates) {
    const c = normalize(candidate);
    if (n === c) return true;
    if (Math.abs(n.length - c.length) <= 1 && n.length >= 5 && levenshtein(n,c) <= 1) return true;
    if (n.length >= 8 && levenshtein(n,c) <= 2) return true;
  }
  return false;
}

function personalBestKey(id){ return `jq-best-${id}-${state.mode}`; }
function getBest(id){ return localStorage.getItem(personalBestKey(id)); }
function setBest(id, value){ localStorage.setItem(personalBestKey(id), value); }

function renderHome(){
  el.homeTitle.textContent = t('appTitle');
  el.homeSubtitle.textContent = t('appSubtitle');
  el.sectionJewish.textContent = t('categoryJewish');
  el.sectionMath.textContent = t('categoryMath');
  el.sectionGeo.textContent = t('categoryGeo');
  el.sectionCommon.textContent = t('categoryCommon');
  el.quizGrid.innerHTML = '';
  el.quizGridMath.innerHTML = '';
  el.quizGridGeo.innerHTML = '';
  el.quizGridCommon.innerHTML = '';

  const setHomeSectionVisible = (gridEl, visible) => {
    if (!gridEl) return;
    const titleEl = gridEl.previousElementSibling;
    if (titleEl) titleEl.classList.toggle('hidden', !visible);
    gridEl.classList.toggle('hidden', !visible);
  };

  const addCard = (id, target) => {
    const cfg = QUIZZES[id], info = t(`quizCards.${id}`);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'quiz-card';
    btn.dataset.quiz = id;
    btn.style.setProperty('--card-color', cfg.color);
    btn.innerHTML = `<span class="emoji">${QUIZ_EMOJIS[id] || '🧠'}</span><h3>${info.title}</h3><p>${info.desc}</p><span class="badge">${info.badge} · ${cfg.timedSeconds ? secondsToText(cfg.timedSeconds) : t('untimed')}</span>`;
    btn.addEventListener('click', () => startQuiz(id));
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        startQuiz(id);
      }
    });
    target.appendChild(btn);
  };

  const jewishIds = getVisibleQuizIds('jewish');
  const mathIds = getVisibleQuizIds('math');
  const geoIds = getVisibleQuizIds('geography');
  const commonIds = getVisibleQuizIds('common');

  jewishIds.forEach(id => addCard(id, el.quizGrid));
  mathIds.forEach(id => addCard(id, el.quizGridMath));
  geoIds.forEach(id => addCard(id, el.quizGridGeo));
  commonIds.forEach(id => addCard(id, el.quizGridCommon));

  setHomeSectionVisible(el.quizGrid, jewishIds.length > 0 && isCategoryEnabled('jewish'));
  setHomeSectionVisible(el.quizGridMath, mathIds.length > 0 && isCategoryEnabled('math'));
  setHomeSectionVisible(el.quizGridGeo, geoIds.length > 0 && isCategoryEnabled('geography'));
  setHomeSectionVisible(el.quizGridCommon, commonIds.length > 0 && isCategoryEnabled('common'));
}

function secondsToText(sec){
  const mins = Math.floor(sec/60);
  return state.lang === 'he' ? `${mins} דקות` : `${mins} min`;
}

function startQuiz(id){
  if (!id || !QUIZZES[id] || !isQuizEnabled(id)) return;
  state.activeQuiz = id;
  el.homeScreen.classList.remove('active');
  el.quizScreen.classList.add('active');
  try {
    resetQuiz(true);
  } catch (err) {
    console.error('startQuiz failed', id, err);
    const info = t(`quizCards.${id}`) || { title: id };
    el.quizTitle.textContent = info.title || id;
    el.quizInstruction.textContent = '';
    el.quizBody.innerHTML = `<div class="classify-card"><div class="center" style="font-size:1.2rem;font-weight:700">${state.lang==='he' ? 'שגיאה בטעינת החידון' : 'Quiz loading error'}</div></div>`;
  }
}

function goHome(){
  hideCompletionOverlay();
  hideTeachOverlay();
  clearInterval(state.timerId);
  state.timerId = null;
  clearTimeout(state.scrambledTimerId);
  state.scrambledTimerId = null;
  state.scrambledFeedbackIndex = null;
  state.scrambledRevealIndex = null;
  state.activeQuiz = null;
  state.revealAllUsed = false;
  el.quizScreen.classList.remove('active');
  el.homeScreen.classList.add('active');
  renderHome();
}

function resetQuiz(fromStart=false){
  hideTeachOverlay();
  clearInterval(state.timerId);
  state.timerId = null;
  clearTimeout(state.scrambledTimerId);
  state.scrambledTimerId = null;
  state.revealed = false;
  state.revealAllUsed = false;
  state.score = 0;
  state.tannaimFeedback = null;
  state.countryFlagFeedback = null;
  state.halachaPendingAdvance && clearTimeout(state.halachaPendingAdvance);
  state.halachaPendingAdvance = null;
  state.scrambledFeedbackIndex = null;
  state.scrambledRevealIndex = null;
  state.guessed = new Set();
  state.pointer = 0;
  state.selectedPlacement = null;
  state.selectedRankFlagCountry = null;
  state.rankStage = 'order';
  state.rankFlagMatches = {};
  state.rankFlagOrder = [];
  state.placements = [];
  state.paused = false;
  state.rowAnswers = {};
  state.rowLocked = {};
  state.selectedCell = {r:1,c:1};
  const cfg = QUIZZES[state.activeQuiz];
  state.timeLeft = cfg.timedSeconds || 0;
  prepareQuizState();
  if (state.mode === 'timed' && cfg.timedSeconds) startTimer();
  renderQuiz();
  if (fromStart && el.answerInput && !el.answerInput.disabled && !el.inputRow.classList.contains('hidden')) {
    setTimeout(()=>el.answerInput.focus(),60);
  }
}

function prepareQuizState(){
  state.order = [];
  state.rowAnswers = {};
  state.rowLocked = {};
  state.selectedCell = {r:1,c:1};

  if (state.activeQuiz === 'multiplication') {
    state.selectedCell = findNextUnansweredMultiplicationCell();
  }

  if (state.activeQuiz === 'gematria') {
    state.order = DATA.gematria.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'tannaim') {
    state.order = DATA.tannaim.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'relations') {
    state.order = DATA.relations.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'countryFlags') {
    state.order = DATA.countryFlags.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'mentalMathTF') {
    state.order = DATA.mentalMathTF.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'inventionInventor') {
    state.order = DATA.inventionInventor.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'symptomOrgan') {
    state.order = DATA.symptomOrgan.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'whoSaidIt') {
    state.order = DATA.whoSaidIt.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'holidaysMonths') {
    state.order = DATA.holidaysMonths.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'chronology') {
    state.order = DATA.chronology.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.chronology.length).fill(null);
  } else if (state.activeQuiz === 'largestCountriesRanking') {
    state.order = DATA.largestCountriesRanking.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.largestCountriesRanking.length).fill(null);
    state.rankStage = 'order';
    state.rankFlagMatches = {};
    state.rankFlagOrder = DATA.largestCountriesRanking.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'tenCommandments') {
    state.order = DATA.tenCommandments.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.tenCommandments.length).fill(null);
  } else if (state.activeQuiz === 'agesHumanity') {
    state.order = DATA.agesHumanity.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.agesHumanity.length).fill(null);
    state.ageStage = 'order';
    state.ageDetailOrder = DATA.agesHumanity.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.ageMatches = {};
  } else if (state.activeQuiz === 'solarSystem') {
    state.order = DATA.solarSystem.planets.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.solarMatches = {};
    state.solarStage = 'match';
    state.solarDetailOrder = DATA.solarSystem.planets.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.solarDetailMatches = {};
    state.placements = Array(DATA.solarSystem.planets.length).fill(null);
  } else if (state.activeQuiz === 'continentQuiz') {
    state.order = DATA.continentQuiz.countries.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.continentMap = {};
  } else if (state.activeQuiz === 'europeProfileMatch') {
    state.order = DATA.europeGeoCountries.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.europeGeoCountries.length).fill(null);
  } else if (state.activeQuiz === 'europeCountryRanking') {
    state.order = DATA.europeGeoCountries.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.europeGeoCountries.length).fill(null);
    state.europeRankingMode = 'gdp';
  } else if (state.activeQuiz === 'europeCountryFits') {
    state.order = DATA.europeCountryFits.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'europeCorrectWrong') {
    state.order = DATA.europeCorrectWrong.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'europeLandmarks') {
    state.order = DATA.europeLandmarks.map((_,i)=>i).sort(()=>Math.random()-.5);
  } else if (state.activeQuiz === 'europeExportMatch') {
    state.order = DATA.europeExportCountries.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.placements = Array(DATA.europeExportCountries.length).fill(null);
  } else if (state.activeQuiz === 'europeCompareCountries') {
    state.order = DATA.europeCompareCountries.map((_,i)=>i).sort(()=>Math.random()-.5);
    state.compareOptionOrders = {};
  } else if (state.activeQuiz === 'halacha') {
    state.halachaStage = 'daily';
    state.halachaAnswers = { daily:{}, shabbat:{}, kosher:{}, interpersonal:{} };
  } else if (state.activeQuiz === 'humanBody') {
    state.bodyStage = 'organ';
    state.bodyAnswers = {};
    state.bodySystemAnswers = {};
    state.bodyLabelMap = {};
  }
}

function startTimer(){
  clearInterval(state.timerId);
  if (state.paused) return;
  state.timerId = setInterval(() => {
    if (state.paused) return;
    state.timeLeft -= 1;
    updateToolbar();
    if (state.timeLeft <= 0) {
      clearInterval(state.timerId);
      state.timerId = null;
      revealAnswers();
    }
  }, 1000);
}

function togglePause(){
  const cfg = QUIZZES[state.activeQuiz];
  if (!state.activeQuiz || state.mode !== 'timed' || !cfg?.timedSeconds || state.revealed) return;
  state.paused = !state.paused;
  if (state.paused) {
    clearInterval(state.timerId);
    state.timerId = null;
    if (state.speechActive && state.recognition) {
      try { state.recognition.stop(); } catch (e) {}
    }
  } else {
    startTimer();
  }
  updateToggleButtons();
  updateToolbar();
}

function updateToolbar(){
  const cfg = QUIZZES[state.activeQuiz];
  if (state.mode === 'untimed' || !cfg.timedSeconds) {
    el.timerDisplay.textContent = t('noLimit');
    el.timerDisplay.classList.remove('urgent');
    if (el.pauseBtn) el.pauseBtn.classList.add('hidden');
  } else {
    const m = Math.floor(Math.max(0,state.timeLeft)/60);
    const s = Math.max(0,state.timeLeft)%60;
    el.timerDisplay.textContent = state.paused ? `${t('paused')} · ${m}:${String(s).padStart(2,'0')}` : `${m}:${String(s).padStart(2,'0')}`;
    el.timerDisplay.classList.toggle('urgent', !state.paused && state.timeLeft <= 30);
    if (el.pauseBtn) {
      el.pauseBtn.classList.remove('hidden');
      el.pauseBtn.textContent = state.paused ? t('resume') : t('pause');
    }
  }
  const metricLabel = ['tannaim','relations','chronology'].includes(state.activeQuiz) ? t('score') : t('guessed');
  el.scoreDisplay.textContent = `${metricLabel}: ${state.score} / ${QUIZZES[state.activeQuiz].total}`;
  el.progressFill.style.width = `${(state.score / QUIZZES[state.activeQuiz].total) * 100}%`;
  const best = getBest(state.activeQuiz);
  el.bestDisplay.textContent = best ? `${t('personalBest')}: ${best}` : '';
}

function canRevealOne(id){
  return ['tanakh','shas','parashot','worldCountries','worldCapitals','officialLanguages','scrambledCountries','gematria','equationCompletion','fastMultiplication','fastAddition','romanNumerals','romanMath','countryFlags','relations','mentalMathTF','inventionInventor','symptomOrgan','whoSaidIt','tannaim','holidaysMonths','chronology','tenCommandments','multiplication','agesHumanity','solarSystem','humanBody','continentQuiz','largestCountriesRanking','europeProfileMatch','europeCountryRanking','europeCountryFits','europeCorrectWrong','europeLandmarks','europeExportMatch','europeCompareCountries','halacha'].includes(id);
}

function getHalachaStageDef(stageId){
  return DATA.halacha.stages.find(stage => stage.id === stageId) || DATA.halacha.stages[0];
}
function getHalachaStageAnswers(stageId){
  state.halachaAnswers ||= { daily:{}, shabbat:{}, kosher:{}, interpersonal:{} };
  state.halachaAnswers[stageId] ||= {};
  return state.halachaAnswers[stageId];
}
function getHalachaCurrentIndex(stageId){
  const stage = getHalachaStageDef(stageId);
  const answers = getHalachaStageAnswers(stageId);
  for (let i=0;i<stage.items.length;i++) {
    if (!(i in answers)) return i;
  }
  return stage.items.length;
}
function updateHalachaScore(){
  state.score = DATA.halacha.stages.reduce((sum, stage) => {
    const answers = getHalachaStageAnswers(stage.id);
    return sum + Object.values(answers).reduce((acc, val) => acc + ((val === true) ? 1 : 0), 0);
  }, 0);
}
function advanceHalachaStageIfNeeded(){
  const current = getHalachaStageDef(state.halachaStage);
  if (getHalachaCurrentIndex(current.id) < current.items.length) return;
  const next = DATA.halacha.stages.find(stage => getHalachaCurrentIndex(stage.id) < stage.items.length);
  if (next) state.halachaStage = next.id;
}

function revealOneAnswer(){
  const id = state.activeQuiz;
  if (!id || state.revealed || state.paused || !canRevealOne(id)) return;
  if (id === 'tanakh') {
    const next = DATA.tanakh.find(item => !state.guessed.has(item.id));
    if (next) { state.guessed.add(next.id); state.score++; renderQuiz(); maybeComplete(); }
    return;
  }
  if (id === 'shas') {
    for (const [key,seder] of Object.entries(DATA.shas)) {
      const sid=`seder:${key}`;
      if (!state.guessed.has(sid)) { state.guessed.add(sid); state.score++; renderQuiz(); maybeComplete(); return; }
      for (let i=0;i<seder.tractates.length;i++) {
        const mid=`m:${key}:${i}`;
        if (!state.guessed.has(mid)) { state.guessed.add(mid); state.score++; renderQuiz(); maybeComplete(); return; }
      }
    }
    return;
  }
  if (id === 'parashot') {
    const next = DATA.parashot.find(item => !state.guessed.has(item.index));
    if (next) { state.guessed.add(next.index); state.score++; renderQuiz(); maybeComplete(); }
    return;
  }
  if (id === 'worldCountries') {
    for (const [cont,list] of Object.entries(DATA.worldCountries)) {
      for (const item of list) {
        const gid=`${cont}:${item.en}`;
        if (!state.guessed.has(gid)) { state.guessed.add(gid); state.score++; renderQuiz(); maybeComplete(); return; }
      }
    }
    return;
  }
  if (id === 'scrambledCountries') {
    const nextIndex = DATA.scrambledCountries.findIndex((_,i)=>!state.guessed.has(i));
    if (nextIndex >= 0) {
      clearTimeout(state.scrambledTimerId);
      state.scrambledFeedbackIndex = null;
      state.scrambledRevealIndex = nextIndex;
      state.guessed.add(nextIndex);
      state.score++;
      renderQuiz();
      state.scrambledTimerId = setTimeout(() => {
        state.scrambledRevealIndex = null;
        state.scrambledTimerId = null;
        maybeComplete();
        renderQuiz();
      }, 5000);
    }
    return;
  }
  if (id === 'worldCapitals' || id === 'officialLanguages') {
    const dataMap = {worldCapitals: DATA.worldCapitals, officialLanguages: DATA.officialLanguages};
    const arr = dataMap[id];
    for (let i=0;i<arr.length;i++) {
      if (!state.guessed.has(i)) { state.guessed.add(i); state.score++; renderQuiz(); maybeComplete(); return; }
    }
    return;
  }
  if (id === 'gematria') {
    if (state.pointer < state.order.length) {
      state.guessed.add(state.order[state.pointer]);
      state.pointer++;
      state.score++;
      renderQuiz();
      maybeComplete();
    }
    return;
  }
  if (['equationCompletion','fastMultiplication','fastAddition','romanNumerals','romanMath'].includes(id)) {
    const dataMap = {equationCompletion: DATA.equationCompletion, fastMultiplication: DATA.fastMultiplication, fastAddition: DATA.fastAddition, romanNumerals: DATA.romanNumerals, romanMath: DATA.romanMath};
    const arr = dataMap[id];
    for (let i=0;i<arr.length;i++) {
      if (!state.rowLocked[i]) {
        state.rowLocked[i] = true;
        state.rowAnswers[i] = arr[i].answer;
        state.score = Object.keys(state.rowLocked).length;
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'chronology') {
    for (let i=0;i<DATA.chronology.length;i++) {
      if (state.placements[i] !== i+1) {
        const fromIndex = state.placements.findIndex(v => v === i+1);
        if (fromIndex >= 0) state.placements[fromIndex] = null;
        state.placements[i] = i+1;
        state.selectedPlacement = null;
        state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'agesHumanity') {
    if (state.ageStage === 'order') {
      for (let i=0;i<DATA.agesHumanity.length;i++) {
        if (state.placements[i] !== i+1) {
          const fromIndex = state.placements.findIndex(v => v === i+1);
          if (fromIndex >= 0) state.placements[fromIndex] = null;
          state.placements[i] = i+1;
          state.selectedPlacement = null;
          state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
          if (state.score >= DATA.agesHumanity.length) state.ageStage = 'details';
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    } else {
      for (let i=0;i<state.ageDetailOrder.length;i++) {
        const itemIdx = state.ageDetailOrder[i];
        const correctOrder = DATA.agesHumanity[itemIdx].order;
        if (state.ageMatches[i] !== correctOrder) {
          state.ageMatches[i] = correctOrder;
          const detailCorrect = state.ageDetailOrder.reduce((sum, idx2, j) => sum + ((state.ageMatches[j] === DATA.agesHumanity[idx2].order) ? 1 : 0), 0);
          state.score = DATA.agesHumanity.length + detailCorrect;
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    }
    return;
  }
  if (id === 'solarSystem') {
    if (state.solarStage === 'match') {
      for (let i=0;i<DATA.solarSystem.planets.length;i++) {
        const correctId = DATA.solarSystem.planets[i].id;
        if (state.solarMatches[i] !== correctId) {
          state.solarMatches[i] = correctId;
          const matchCorrect = DATA.solarSystem.planets.reduce((sum, planet, idx2) => sum + ((state.solarMatches[idx2] === planet.id) ? 1 : 0), 0);
          state.score = matchCorrect;
          if (Object.keys(state.solarMatches).length >= DATA.solarSystem.planets.length) {
            state.solarStage = 'details';
            state.score = DATA.solarSystem.planets.length;
          }
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    } else {
      for (let i=0;i<state.solarDetailOrder.length;i++) {
        const itemIdx = state.solarDetailOrder[i];
        const correctId = DATA.solarSystem.planets[itemIdx].id;
        if (state.solarDetailMatches[i] !== correctId) {
          state.solarDetailMatches[i] = correctId;
          const detailCorrect = state.solarDetailOrder.reduce((sum, idx2, j) => sum + ((state.solarDetailMatches[j] === DATA.solarSystem.planets[idx2].id) ? 1 : 0), 0);
          state.score = DATA.solarSystem.planets.length + detailCorrect;
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    }
    return;
  }
  if (id === 'humanBody') {
    if (state.bodyStage === 'organ') {
      const idx = Object.keys(state.bodyAnswers).length;
      const item = DATA.humanBodySet.organFunction[idx];
      if (item) {
        state.bodyAnswers[idx] = item.correct;
        state.score = Object.keys(state.bodyAnswers).length;
        if (Object.keys(state.bodyAnswers).length >= DATA.humanBodySet.organFunction.length) state.bodyStage = 'system';
        renderQuiz();
        maybeComplete();
      }
      return;
    }
    if (state.bodyStage === 'system') {
      const idx = Object.keys(state.bodySystemAnswers).length;
      const item = DATA.humanBodySet.systemMatch[idx];
      if (item) {
        state.bodySystemAnswers[idx] = item.correct;
        const organCorrect = Object.keys(state.bodyAnswers).reduce((s,k)=>s + (state.bodyAnswers[k]===DATA.humanBodySet.organFunction[Number(k)].correct),0);
        state.score = organCorrect + Object.keys(state.bodySystemAnswers).length;
        if (Object.keys(state.bodySystemAnswers).length >= DATA.humanBodySet.systemMatch.length) state.bodyStage = 'label';
        renderQuiz();
        maybeComplete();
      }
      return;
    }
    for (const item of DATA.humanBodySet.labels) {
      if (state.bodyLabelMap[item.zone] !== item.id) {
        state.bodyLabelMap[item.zone] = item.id;
        state.selectedPlacement = null;
        const labelCorrect = DATA.humanBodySet.labels.reduce((sum,x)=>sum + (state.bodyLabelMap[x.zone]===x.id ? 1 : 0), 0);
        const organCorrect = Object.keys(state.bodyAnswers).reduce((s,k)=>s + (state.bodyAnswers[k]===DATA.humanBodySet.organFunction[Number(k)].correct),0);
        const systemCorrect = Object.keys(state.bodySystemAnswers).reduce((s,k)=>s + (state.bodySystemAnswers[k]===DATA.humanBodySet.systemMatch[Number(k)].correct),0);
        state.score = organCorrect + systemCorrect + labelCorrect;
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'continentQuiz') {
    for (let i=0;i<DATA.continentQuiz.countries.length;i++) {
      const item = DATA.continentQuiz.countries[i];
      if (state.continentMap[item.en] !== item.continent) {
        state.continentMap[item.en] = item.continent;
        state.selectedPlacement = null;
        state.score = DATA.continentQuiz.countries.filter(c => state.continentMap[c.en] === c.continent).length;
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'europeProfileMatch') {
    const correctIds = DATA.europeGeoCountries.map(item => item.id);
    for (let i=0;i<correctIds.length;i++) {
      if (state.placements[i] !== correctIds[i]) {
        const fromIndex = state.placements.findIndex(v => v === correctIds[i]);
        if (fromIndex >= 0) state.placements[fromIndex] = null;
        state.placements[i] = correctIds[i];
        state.selectedPlacement = null;
        state.score = getEuropeProfileCorrectCount();
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'europeCountryRanking') {
    const correctIds = getEuropeRankingSortedIds();
    for (let i=0;i<correctIds.length;i++) {
      if (state.placements[i] !== correctIds[i]) {
        const fromIndex = state.placements.findIndex(v => v === correctIds[i]);
        if (fromIndex >= 0) state.placements[fromIndex] = null;
        state.placements[i] = correctIds[i];
        state.selectedPlacement = null;
        state.score = getEuropeRankingCorrectCount();
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'europeCountryFits') {
    const item = DATA.europeCountryFits[state.order[state.pointer]];
    if (item) { state.score++; state.pointer++; renderQuiz(); maybeComplete(); }
    return;
  }
  if (id === 'europeCorrectWrong') {
    const item = DATA.europeCorrectWrong[state.order[state.pointer]];
    if (item) {
      const correct = item.correct ? 'correct' : 'wrong';
      const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
      buttons.forEach(btn => {
        if (btn.dataset.choice === correct) btn.classList.add('correct');
        if (btn.dataset.choice !== correct) btn.classList.add('wrong');
        btn.disabled = true;
      });
      state.score++; state.pointer++; updateToolbar();
      setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    }
    return;
  }
  if (id === 'europeLandmarks') {
    const item = DATA.europeLandmarks[state.order[state.pointer]];
    if (item) {
      const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
      buttons.forEach(btn => {
        if (btn.dataset.choice === item.countryId) btn.classList.add('correct');
        else btn.classList.add('wrong');
        btn.disabled = true;
      });
      state.score++; state.pointer++; updateToolbar();
      setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    }
    return;
  }
  if (id === 'europeExportMatch') {
    const correctIds = DATA.europeExportCountries.map(item => item.id);
    for (let i=0;i<correctIds.length;i++) {
      if (state.placements[i] !== correctIds[i]) {
        const fromIndex = state.placements.findIndex(v => v === correctIds[i]);
        if (fromIndex >= 0) state.placements[fromIndex] = null;
        state.placements[i] = correctIds[i];
        state.selectedPlacement = null;
        state.score = getEuropeExportCorrectCount();
        renderEuropeExportMatch();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'europeCompareCountries') {
    const item = DATA.europeCompareCountries[state.order[state.pointer]];
    if (item) {
      const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
      buttons.forEach(btn => {
        if (btn.dataset.choice === item.correct) btn.classList.add('correct');
        else btn.classList.add('wrong');
        btn.disabled = true;
      });
      state.score++; state.pointer++; updateToolbar();
      setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    }
    return;
  }
  if (id === 'halacha') {
    const stage = getHalachaStageDef(state.halachaStage);
    const idx = getHalachaCurrentIndex(stage.id);
    if (idx < stage.items.length) {
      handleChoice(stage.items[idx].correct);
    }
    return;
  }
  if (id === 'largestCountriesRanking') {
    if (state.rankStage === 'order') {
      for (let i=0;i<DATA.largestCountriesRanking.length;i++) {
        if (state.placements[i] !== i+1) {
          const fromIndex = state.placements.findIndex(v => v === i+1);
          if (fromIndex >= 0) state.placements[fromIndex] = null;
          state.placements[i] = i+1;
          state.selectedPlacement = null;
          state.score = getLargestCountriesCorrectCount();
          if (maybeAdvanceLargestCountriesStage()) return;
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    } else {
      for (let slotIdx=0;slotIdx<state.rankFlagOrder.length;slotIdx++) {
        const itemIdx = state.rankFlagOrder[slotIdx];
        const expected = DATA.largestCountriesRanking[itemIdx].order;
        if (state.rankFlagMatches[slotIdx] !== expected) {
          const previousEntry = Object.entries(state.rankFlagMatches).find(([, value]) => value === expected);
          if (previousEntry) delete state.rankFlagMatches[previousEntry[0]];
          state.rankFlagMatches[slotIdx] = expected;
          state.selectedRankFlagCountry = null;
          state.score = DATA.largestCountriesRanking.length + getLargestCountriesFlagCorrectCount();
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    }
    return;
  }
  if (id === 'tenCommandments') {
    for (let i=0;i<DATA.tenCommandments.length;i++) {
      if (state.placements[i] !== i+1) {
        const fromIndex = state.placements.findIndex(v => v === i+1);
        if (fromIndex >= 0) state.placements[fromIndex] = null;
        state.placements[i] = i+1;
        state.selectedPlacement = null;
        state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
        renderQuiz();
        maybeComplete();
        return;
      }
    }
    return;
  }
  if (id === 'multiplication') {
    for (let r=1;r<=12;r++) {
      for (let c=1;c<=12;c++) {
        const key = `${r}-${c}`;
        if (!state.guessed.has(key)) {
          state.guessed.add(key);
          state.score = state.guessed.size;
          renderQuiz();
          maybeComplete();
          return;
        }
      }
    }
    return;
  }

  if (['countryFlags','relations','mentalMathTF','inventionInventor','symptomOrgan','whoSaidIt','tannaim','holidaysMonths'].includes(id)) {
    let item, correct;
    if (id === 'holidaysMonths') {
      item = DATA.holidaysMonths[state.order[state.pointer]];
      correct = item?.month?.he;
    } else if (id === 'countryFlags') {
      item = DATA.countryFlags[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'relations') {
      item = DATA.relations[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'mentalMathTF') {
      item = DATA.mentalMathTF[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'inventionInventor') {
      item = DATA.inventionInventor[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'symptomOrgan') {
      item = DATA.symptomOrgan[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'whoSaidIt') {
      item = DATA.whoSaidIt[state.order[state.pointer]];
      correct = item?.correct;
    } else if (id === 'tannaim') {
      item = DATA.tannaim[state.order[state.pointer]];
      correct = item?.type;
    }
    if (item && correct != null) handleChoice(correct);
    return;
  }
}

const QUIZ_RENDERERS = {
  tanakh: renderTanakh,
  shas: renderShas,
  parashot: renderParashot,
  gematria: renderGematria,
  tannaim: renderTannaim,
  chronology: renderChronology,
  relations: renderRelations,
  worldCountries: renderWorldCountries,
  worldCapitals: renderWorldCapitals,
  officialLanguages: renderOfficialLanguages,
  countryFlags: renderCountryFlags,
  scrambledCountries: renderScrambledCountries,
  mentalMathTF: renderMentalMathTF,
  equationCompletion: renderEquationCompletion,
  multiplication: renderMultiplication,
  fastMultiplication: renderFastMultiplication,
  fastAddition: renderFastAddition,
  romanNumerals: renderRomanNumerals,
  tenCommandments: renderTenCommandments,
  holidaysMonths: renderHolidaysMonths,
  continentQuiz: renderContinentQuiz,
  europeProfileMatch: renderEuropeProfileMatch,
  europeCountryRanking: renderEuropeCountryRanking,
  europeCountryFits: renderEuropeCountryFits,
  europeCorrectWrong: renderEuropeCorrectWrong,
  europeLandmarks: renderEuropeLandmarks,
  europeExportMatch: renderEuropeExportMatch,
  europeCompareCountries: renderEuropeCompareCountries,
  romanMath: renderRomanMath,
  solarSystem: renderSolarSystem,
  agesHumanity: renderAgesHumanity,
  humanBody: renderHumanBody,
  inventionInventor: renderInventionInventor,
  symptomOrgan: renderSymptomOrgan,
  largestCountriesRanking: renderLargestCountriesRanking,
  whoSaidIt: renderWhoSaidIt,
  halacha: renderHalacha
};

function applyQuizScopeAttributes(id){
  el.quizScreen.setAttribute('data-quiz-screen', id);
  el.quizBody.setAttribute('data-quiz-scope', id);
  el.quizBody.setAttribute('data-quiz-type', QUIZZES[id].type);
}

function renderQuiz(){
  const id = state.activeQuiz;
  if (!id) return;
  const cfg = QUIZZES[id];
  const info = t(`quizCards.${id}`);
  const scrambledLocked = id === 'scrambledCountries' && (state.scrambledFeedbackIndex != null || state.scrambledRevealIndex != null);
  const hideMainInput = HIDE_MAIN_INPUT_TYPES.has(cfg.type);
  const canUseSpeech = !state.revealed && cfg.type === 'text' && !scrambledLocked;

  applyQuizScopeAttributes(id);
  el.backBtn.textContent = t('back');
  el.quizTitle.textContent = info.title;
  el.revealBtn.textContent = t('reveal');
  if (el.revealOneBtn) {
    el.revealOneBtn.textContent = t('revealOne');
    el.revealOneBtn.classList.toggle('hidden', !canRevealOne(id));
  }
  if (el.teachBtn) {
    el.teachBtn.textContent = t('teachMe');
    el.teachBtn.classList.toggle('hidden', !canTeach(id));
  }
  el.resetBtn.textContent = t('reset');
  if (el.pauseBtn) el.pauseBtn.textContent = state.paused ? t('resume') : t('pause');
  el.quizInstruction.textContent = t(`instructions.${id}`);
  el.answerInput.placeholder = t(`placeholders.${id}`) || t('placeholders.default');
  el.answerInput.type = (cfg.type === 'number' && !(id==='gematria' && state.gematriaCalc)) ? 'number' : 'text';
  el.answerInput.disabled = state.revealed || state.paused || hideMainInput || scrambledLocked;
  el.inputRow.classList.toggle('hidden', hideMainInput);
  if (el.micBtn) el.micBtn.classList.toggle('hidden', !canUseSpeech);
  el.micBtn.classList.toggle('active', !!state.speechActive && canUseSpeech);
  updateToolbar();

  const renderer = QUIZ_RENDERERS[id];
  if (renderer) renderer();
  if (id === 'multiplication' && !state.revealed && !state.paused) focusMainAnswerInput(0);
}

function renderTanakh(){
  const sections = ['torah','neviim','ketuvim'];
  const body = document.createElement('div');
  body.className='columns-3';
  for (const section of sections) {
    const col = document.createElement('div');
    col.className='column';
    col.innerHTML = `<div class="column-header" style="background:${section==='torah'?'#27ae60':section==='neviim'?'#2980b9':'#8e44ad'}">${t(`sections.${section}`)}</div>`;
    DATA.tanakh.filter(x => x.section===section).forEach(item => {
      const slot = document.createElement('div');
      slot.className='slot';
      if (state.guessed.has(item.id) || state.revealed) {
        slot.innerHTML = `<span class="answer-main ${!state.guessed.has(item.id)&&state.revealed?'answer-revealed':''}">${formatDisplay(item)}</span>`;
      }
      col.appendChild(slot);
    });
    body.appendChild(col);
  }
  el.quizBody.replaceChildren(body);
}

function renderShas(){
  const body = document.createElement('div');
  body.className='columns-6';
  Object.entries(DATA.shas).forEach(([key,seder]) => {
    const col = document.createElement('div');
    col.className='column';
    const sederDone = state.guessed.has(`seder:${key}`);
    col.innerHTML = `<div class="column-header" style="background:${seder.color}">${formatDisplay({he:seder.he,en:seder.en})}${sederDone ? ' ✓' : ''}</div>`;
    seder.tractates.forEach((masechta, idx) => {
      const id = `m:${key}:${idx}`;
      const slot = document.createElement('div');
      slot.className='slot';
      if (state.guessed.has(id) || state.revealed) {
        slot.innerHTML = `<span class="answer-main ${!state.guessed.has(id)&&state.revealed?'answer-revealed':''}">${formatDisplay(masechta)}</span>`;
      }
      col.appendChild(slot);
    });
    body.appendChild(col);
  });
  el.quizBody.replaceChildren(body);
}

function renderParashot(){
  const body = document.createElement('div');
  body.className='parasha-list';
  const dividers = [
    {start:1,end:12,key:'bereshit',labelHe:'בראשית',labelEn:'Bereishit'},
    {start:13,end:23,key:'shemot',labelHe:'שמות',labelEn:'Shemot'},
    {start:24,end:33,key:'vayikra',labelHe:'ויקרא',labelEn:'Vayikra'},
    {start:34,end:43,key:'bamidbar',labelHe:'במדבר',labelEn:'Bamidbar'},
    {start:44,end:54,key:'devarim',labelHe:'דברים',labelEn:'Devarim'}
  ];
  DATA.parashot.forEach(item => {
    const divider = dividers.find(d => d.start === item.index);
    if (divider) {
      const d = document.createElement('div');
      d.className = `book-divider book-${divider.key}`;
      d.textContent = state.lang === 'he' ? divider.labelHe : divider.labelEn;
      body.appendChild(d);
    }
    const row = document.createElement('div');
    row.className='parasha-item';
    row.innerHTML = `<span class="parasha-num">${item.index}</span><span class="answer-main ${!state.guessed.has(item.index)&&state.revealed?'answer-revealed':''}">${state.guessed.has(item.index)||state.revealed ? formatDisplay(item) : ''}</span>`;
    body.appendChild(row);
  });
  el.quizBody.replaceChildren(body);
}

function gematriaValue(str){
  const map = {א:1,ב:2,ג:3,ד:4,ה:5,ו:6,ז:7,ח:8,ט:9,י:10,כ:20,ך:20,ל:30,מ:40,ם:40,נ:50,ן:50,ס:60,ע:70,פ:80,ף:80,צ:90,ץ:90,ק:100,ר:200,ש:300,ת:400};
  return [...String(str||'')].reduce((sum,ch)=>sum + (map[ch]||0),0);
}
function getGematriaQuote(item){
  if (!item) return '';
  return state.lang==='he' ? (item.quoteHe || '') : (item.quoteEn || '');
}
function renderGematria(){
  const item = DATA.gematria[state.order[state.pointer]];
  const wrapper = document.createElement('div');
  wrapper.className='gematria-card';
  if (!state.revealed && item) {
    wrapper.innerHTML = `<div class="gematria-prompt">${state.lang==='he'?item.he:item.en}</div><p class="center subtle">${t('promptGematria')} ${state.lang==='he'?`<span class="secondary">(${item.en})</span>`:`<span class="secondary">(${item.he})</span>`}</p>`;
  } else if (!item) {
    renderCompletedPlaceholder(wrapper);
  }
  const table = document.createElement('table');
  table.className='table';
  table.innerHTML = `<thead><tr><th>${state.lang==='he'?'מילה':'Word'}</th><th>${state.lang==='he'?'ערך':'Value'}</th></tr></thead>`;
  const tbody = document.createElement('tbody');
  DATA.gematria.forEach((entry, idx) => {
    if (state.guessed.has(idx) || state.revealed) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td class="${!state.guessed.has(idx)&&state.revealed?'answer-revealed':''}">${formatDisplay(entry)}</td><td class="${!state.guessed.has(idx)&&state.revealed?'answer-revealed':''}">${entry.value}</td>`;
      tbody.appendChild(tr);
      const quote = getGematriaQuote(entry);
      if (quote) {
        const quoteTr = document.createElement('tr');
        quoteTr.innerHTML = `<td colspan="2"><div class="subtle ${!state.guessed.has(idx)&&state.revealed?'answer-revealed':''}" style="margin-top:4px">${quote}</div></td>`;
        tbody.appendChild(quoteTr);
      }
    }
  });
  table.appendChild(tbody);
  wrapper.appendChild(table);
  const calc = document.createElement('div');
  calc.className = 'gem-calc';
  calc.innerHTML = `<button type="button" class="answer-btn" data-gemcalc-toggle="1">${t('gematriaCalculator')}</button>`;
  if (state.gematriaCalc) {
    const live = gematriaValue(el.answerInput.value.trim());
    calc.innerHTML += `<div style="margin-top:12px"><div class="subtle">${t('gematriaLiveValue')}: <strong>${live}</strong></div><div class="subtle" style="margin-top:6px">${state.lang==='he'?'הקלד בתיבה למעלה כל מילה בעברית כדי לראות את הערך.':'Type any Hebrew word in the top box to see its value.'}</div></div>`;
    el.answerInput.placeholder = t('placeholders.gematriaCalc');
    el.answerInput.type = 'text';
  }
  wrapper.appendChild(calc);
  el.quizBody.replaceChildren(wrapper);
}


function getTannaimQuote(item){
  if (!item) return '';
  return state.lang==='he' ? item.quoteHe : item.quoteEn;
}

function renderTannaim(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.tannaim.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${formatDisplay(item)}</div><div class="review-answer">${item.type==='tanna' ? t('categoryTanna') : t('categoryAmora')}</div><div class="subtle" style="margin-top:8px">${getTannaimQuote(item)}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.tannaim[state.order[state.pointer]];
  const feedback = state.tannaimFeedback && item && state.tannaimFeedback.itemOrder === item.type + '|' + item.en ? state.tannaimFeedback : null;
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `
      <div class="center" style="font-size:2rem;font-weight:900;color:var(--gold)">${state.lang==='he'?item.he:item.en}</div>
      <div class="center subtle" style="margin-bottom:18px">${state.lang==='he'?item.en:item.he}</div>
      <div class="answers-grid">
        <button type="button" class="answer-btn${feedback?.correctChoice==='tanna'?' correct':''}${feedback?.choice==='tanna' && feedback?.choice!==feedback?.correctChoice?' wrong':''}" data-choice="tanna" ${feedback?'disabled':''}>${t('categoryTanna')}</button>
        <button type="button" class="answer-btn${feedback?.correctChoice==='amora'?' correct':''}${feedback?.choice==='amora' && feedback?.choice!==feedback?.correctChoice?' wrong':''}" data-choice="amora" ${feedback?'disabled':''}>${t('categoryAmora')}</button>
      </div>
      ${feedback?.isCorrect ? `<div class="review-row" style="margin-top:16px"><div class="review-answer">${getTannaimQuote(item)}</div></div>` : ''}`;
  }
  el.quizBody.replaceChildren(card);
}

function renderChronology(){
  const wrap = document.createElement('div');
  wrap.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${t('chronologyPool')}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  state.order.forEach(idx => {
    const item = DATA.chronology[idx];
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.order?' selected':''}${state.placements.includes(item.order)?' used':''}`;
    btn.dataset.figure=String(item.order);
    btn.innerHTML = state.lang==='he' ? `${item.he} <span class="secondary">(${item.en})</span>` : `${item.en} <span class="secondary">(${item.he})</span>`;
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);
  if (state.selectedPlacement != null) {
    const selectedItem = DATA.chronology.find(x=>x.order===state.selectedPlacement);
    if (selectedItem) {
      left.insertAdjacentHTML('beforeend', renderChronologyFigureFactHtml(selectedItem));
    }
  }

  const right = document.createElement('div');
  right.className='slots-panel';
  const correctCount = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
  right.innerHTML = `<h3 style="margin-top:0">${t('chronologySlots')}</h3><p class="subtle">${t('correctPlacements')}: ${correctCount}/${DATA.chronology.length}</p><p class="subtle">${t('movePlacedHint')}</p>`;
  const slotList = document.createElement('div');
  slotList.className='slot-list';
  DATA.chronology.forEach((_, idx) => {
    const value = state.placements[idx];
    const actualItem = value ? DATA.chronology.find(x=>x.order===value) : null;
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`slot-btn${value?' filled':''}${state.selectedPlacement!=null && value===state.selectedPlacement?' picked-up':''}`;
    btn.dataset.slot=String(idx);
    const revealedWrong = state.revealed && value !== idx+1;
    btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main ${revealedWrong?'answer-revealed':''}">${actualItem ? formatDisplay(actualItem) : ''}</span>`;
    if (state.revealed && !value) {
      btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main answer-revealed">${formatDisplay(DATA.chronology[idx])}</span>`;
    }
    slotList.appendChild(btn);
  });
  right.appendChild(slotList);
  wrap.append(left,right);
  el.quizBody.replaceChildren(wrap);
  state.score = correctCount;
  updateToolbar();
}

function relationText(key){ return t(`relations.${key}`); }
function renderRelations(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.relations.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      const first = state.lang==='he' ? `${item.a.he} <span class="secondary">(${item.a.en})</span>` : `${item.a.en} <span class="secondary">(${item.a.he})</span>`;
      const second = state.lang==='he' ? `${item.b.he} <span class="secondary">(${item.b.en})</span>` : `${item.b.en} <span class="secondary">(${item.b.he})</span>`;
      row.innerHTML = `<div class="review-title">${first} → ${second}</div><div class="review-answer">${relationText(item.correct)}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.relations[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='mc-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    const first = state.lang==='he' ? `${item.a.he} <span class="secondary">(${item.a.en})</span>` : `${item.a.en} <span class="secondary">(${item.a.he})</span>`;
    const second = state.lang==='he' ? `${item.b.he} <span class="secondary">(${item.b.en})</span>` : `${item.b.en} <span class="secondary">(${item.b.he})</span>`;
    card.innerHTML = `
      <div class="center" style="font-size:1.45rem;font-weight:900;color:var(--gold);margin-bottom:14px">${first} → ${second}</div>
      <p class="center subtle">${t('relationQuestion')}</p>
      <div class="answers-grid">
        ${item.choices.map(choice => `<button type="button" class="answer-btn" data-rel="${choice}">${relationText(choice)}</button>`).join('')}
      </div>`;
  }
  el.quizBody.replaceChildren(card);
}


function renderSimpleChoiceQuiz(item, titleHtml, options, labels){
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `<div class="center" style="font-size:1.8rem;font-weight:900;color:var(--gold);margin-bottom:18px">${titleHtml}</div><div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    options.forEach(choice=>{
      const b=document.createElement('button');
      b.type='button';
      b.className='answer-btn';
      b.dataset.choice=choice;
      b.innerHTML = formatDisplay(labels[choice]);
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}

function renderInventionInventor(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.inventionInventor.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      const fact = DATA.inventionInventorFacts[item.correct];
      const factText = fact ? (state.lang==='he' ? fact.he : fact.en) : '';
      row.innerHTML = `<div class="review-title">${formatDisplay(item.invention)}</div><div class="review-answer">${formatDisplay(DATA.inventionInventorLabels[item.correct])}</div>${factText ? `<div class="subtle" style="margin-top:8px;line-height:1.7;font-size:1.02rem">${factText}</div>` : ''}`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.inventionInventor[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    const fact = DATA.inventionInventorFacts[item.correct];
    const factText = fact ? (state.lang==='he' ? fact.he : fact.en) : '';
    card.innerHTML = `
      <div class="center" style="font-size:1.8rem;font-weight:900;color:var(--gold);margin-bottom:18px">${formatDisplay(item.invention)}</div>
      ${factText ? `<div class="subtle center" style="margin:0 auto 18px;max-width:760px;line-height:1.8;font-size:1.04rem">${factText}</div>` : ''}
      <div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    (item.choices || []).forEach(choice=>{
      const b=document.createElement('button');
      b.type='button';
      b.className='answer-btn';
      b.dataset.choice=choice;
      b.innerHTML = formatDisplay(DATA.inventionInventorLabels[choice]);
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}

function renderSymptomOrgan(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.symptomOrgan.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${formatDisplay(item.symptom)}</div><div class="review-answer">${formatDisplay(DATA.symptomOrganLabels[item.correct])}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.symptomOrgan[state.order[state.pointer]];
  renderSimpleChoiceQuiz(item, formatDisplay(item?.symptom), item?.choices || [], DATA.symptomOrganLabels);
}

function renderWhoSaidIt(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.whoSaidIt.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.quoteHe : item.quoteEn}</div><div class="review-answer">${formatDisplay(DATA.whoSaidItLabels[item.correct])}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.whoSaidIt[state.order[state.pointer]];
  renderSimpleChoiceQuiz(item, state.lang==='he' ? item?.quoteHe : item?.quoteEn, item?.choices || [], DATA.whoSaidItLabels);
}

function getLargestCountriesCorrectCount(){
  return state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
}

function getLargestCountriesFlagCorrectCount(){
  return state.rankFlagOrder.reduce((sum,itemIdx,slotIdx)=>{
    const expected = DATA.largestCountriesRanking[itemIdx].order;
    return sum + (state.rankFlagMatches[slotIdx] === expected ? 1 : 0);
  }, 0);
}

function maybeAdvanceLargestCountriesStage(){
  if (state.rankStage === 'order' && getLargestCountriesCorrectCount() === DATA.largestCountriesRanking.length && !state.revealed) {
    state.rankStage = 'flags';
    state.selectedPlacement = null;
    state.selectedRankFlagCountry = null;
    state.rankFlagMatches = {};
    flash(state.lang==='he' ? 'שלב 2: התאם לדגלים' : 'Stage 2: Match the flags');
    renderLargestCountriesRanking();
    return true;
  }
  return false;
}

function renderLargestCountriesRanking(){
  const wrap = document.createElement('div');
  wrap.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'מאגר לבחירה' : 'Pool'}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';

  if (state.rankStage === 'order') {
    state.order.forEach(idx => {
      const item = DATA.largestCountriesRanking[idx];
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`pick-item${state.selectedPlacement===item.order?' selected':''}${state.placements.includes(item.order)?' used':''}`;
      btn.dataset.countryrank=String(item.order);
      btn.innerHTML = formatDisplay(item);
      pickList.appendChild(btn);
    });
    left.appendChild(pickList);

    const right = document.createElement('div');
    right.className='slots-panel';
    const correctCount = getLargestCountriesCorrectCount();
    right.innerHTML = `<h3 style="margin-top:0">${state.lang==='he'?'שלב 1: מהגדולה לקטנה':'Stage 1: Largest to Smallest'}</h3><p class="subtle">${t('correctPlacements')}: ${correctCount}/${DATA.largestCountriesRanking.length}</p><p class="subtle">${t('movePlacedHint')}</p>`;
    const slotList = document.createElement('div');
    slotList.className='slot-list';
    DATA.largestCountriesRanking.forEach((_, idx) => {
      const value = state.placements[idx];
      const actualItem = value ? DATA.largestCountriesRanking.find(x=>x.order===value) : null;
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`slot-btn${value?' filled':''}${state.selectedPlacement!=null && value===state.selectedPlacement?' picked-up':''}`;
      btn.dataset.rankslot=String(idx);
      const revealedWrong = state.revealed && value !== idx+1;
      btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main ${revealedWrong?'answer-revealed':''}">${actualItem ? formatDisplay(actualItem) : ''}</span>`;
      if (state.revealed && !value) {
        btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main answer-revealed">${formatDisplay(DATA.largestCountriesRanking[idx])}</span>`;
      }
      slotList.appendChild(btn);
    });
    right.appendChild(slotList);
    wrap.append(left,right);
    state.score = correctCount;
  } else {
    state.order.forEach(idx => {
      const item = DATA.largestCountriesRanking[idx];
      const used = Object.values(state.rankFlagMatches).includes(item.order);
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`pick-item${state.selectedRankFlagCountry===item.order?' selected':''}${used?' used':''}`;
      btn.dataset.rankflagcountry=String(item.order);
      btn.innerHTML = formatDisplay(item);
      pickList.appendChild(btn);
    });
    left.appendChild(pickList);

    const right = document.createElement('div');
    right.className='slots-panel';
    const correctCount = getLargestCountriesFlagCorrectCount();
    right.innerHTML = `<h3 style="margin-top:0">${state.lang==='he'?'שלב 2: מדינה לדגל':'Stage 2: Country to Flag'}</h3><p class="subtle">${t('correctPlacements')}: ${correctCount}/${DATA.largestCountriesRanking.length}</p><p class="subtle">${state.lang==='he' ? 'בחר מדינה ואז לחץ על הדגל המתאים.' : 'Pick a country, then click the matching flag.'}</p>`;
    const slotList = document.createElement('div');
    slotList.className='slot-list';
    state.rankFlagOrder.forEach((itemIdx, slotIdx) => {
      const flagItem = DATA.largestCountriesRanking[itemIdx];
      const value = state.rankFlagMatches[slotIdx];
      const actualItem = value ? DATA.largestCountriesRanking.find(x=>x.order===value) : null;
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`slot-btn${value?' filled':''}${state.selectedRankFlagCountry!=null && value===state.selectedRankFlagCountry?' picked-up':''}`;
      btn.dataset.rankflagslot=String(slotIdx);
      const revealedWrong = state.revealed && value !== flagItem.order;
      btn.innerHTML = `${renderFlagBox(flagItem.flag)}<span class="answer-main ${revealedWrong?'answer-revealed':''}">${actualItem ? formatDisplay(actualItem) : ''}</span>`;
      if (state.revealed && !value) {
        btn.innerHTML = `${renderFlagBox(flagItem.flag)}<span class="answer-main answer-revealed">${formatDisplay(flagItem)}</span>`;
      }
      slotList.appendChild(btn);
    });
    right.appendChild(slotList);
    wrap.append(left,right);
    state.score = DATA.largestCountriesRanking.length + correctCount;
  }

  el.quizBody.replaceChildren(wrap);
  updateToolbar();
}

function handleLargestCountryFigure(order){
  if (state.revealed || state.rankStage !== 'order') return;
  state.selectedPlacement = Number(order);
  renderLargestCountriesRanking();
}

function handleLargestCountrySlot(index){
  if (state.revealed || state.rankStage !== 'order') return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];

  if (state.selectedPlacement == null) {
    if (currentValue != null) {
      state.selectedPlacement = currentValue;
      state.placements[slotIndex] = null;
      state.score = getLargestCountriesCorrectCount();
      renderLargestCountriesRanking();
    }
    return;
  }

  const previousIndex = state.placements.findIndex(val => val === state.selectedPlacement);
  if (previousIndex !== -1) state.placements[previousIndex] = null;

  if (currentValue != null) {
    state.placements[slotIndex] = state.selectedPlacement;
    if (previousIndex !== -1) state.placements[previousIndex] = currentValue;
    else state.selectedPlacement = currentValue;
  } else {
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }

  state.score = getLargestCountriesCorrectCount();
  if (maybeAdvanceLargestCountriesStage()) return;
  renderLargestCountriesRanking();
}

function handleLargestCountryFlagCountry(order){
  if (state.revealed || state.rankStage !== 'flags') return;
  state.selectedRankFlagCountry = Number(order);
  renderLargestCountriesRanking();
}

function handleLargestCountryFlagSlot(index){
  if (state.revealed || state.rankStage !== 'flags') return;
  const slotIndex = Number(index);
  const currentValue = state.rankFlagMatches[slotIndex] ?? null;

  if (state.selectedRankFlagCountry == null) {
    if (currentValue != null) {
      state.selectedRankFlagCountry = currentValue;
      delete state.rankFlagMatches[slotIndex];
      renderLargestCountriesRanking();
    }
    return;
  }

  const previousEntry = Object.entries(state.rankFlagMatches).find(([, value]) => value === state.selectedRankFlagCountry);
  const previousIndex = previousEntry ? Number(previousEntry[0]) : -1;
  if (previousIndex !== -1) delete state.rankFlagMatches[previousIndex];

  if (currentValue != null) {
    state.rankFlagMatches[slotIndex] = state.selectedRankFlagCountry;
    if (previousIndex !== -1) state.rankFlagMatches[previousIndex] = currentValue;
    else state.selectedRankFlagCountry = currentValue;
  } else {
    state.rankFlagMatches[slotIndex] = state.selectedRankFlagCountry;
    state.selectedRankFlagCountry = null;
  }

  state.score = DATA.largestCountriesRanking.length + getLargestCountriesFlagCorrectCount();
  if (getLargestCountriesFlagCorrectCount() === DATA.largestCountriesRanking.length) {
    saveBest();
    maybeComplete();
  }
  renderLargestCountriesRanking();
}


function getEuropeProfileCorrectCount(){
  return DATA.europeGeoCountries.reduce((sum,item,idx)=>sum + (state.placements[idx] === item.id ? 1 : 0), 0);
}

function renderEuropeProfileMatch(){
  const wrap = document.createElement('div');
  wrap.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'מאגר מדינות' : 'Country pool'}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  state.order.forEach(idx => {
    const item = DATA.europeGeoCountries[idx];
    const used = state.placements.includes(item.id);
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.id?' selected':''}${used?' used':''}`;
    btn.dataset.euprofilecountry=item.id;
    btn.innerHTML=formatDisplay(item);
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);

  const right = document.createElement('div');
  right.className='slots-panel';
  right.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'התאם מדינה לפרופיל' : 'Match each profile'}</h3><p class="subtle">${t('correctPlacements')}: ${getEuropeProfileCorrectCount()}/${DATA.europeGeoCountries.length}</p><p class="subtle">${state.lang==='he' ? 'בחר מדינה ואז לחץ על תיבת הפרופיל המתאימה.' : 'Pick a country, then click the matching profile box.'}</p>`;
  const slotList = document.createElement('div');
  slotList.className='slot-list';
  DATA.europeGeoCountries.forEach((item, idx) => {
    const value = state.placements[idx];
    const actualItem = value ? DATA.europeGeoCountries.find(x=>x.id===value) : null;
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`slot-btn${value?' filled':''}`;
    btn.dataset.euprofileslot=String(idx);
    const clueLines = (state.lang==='he' ? item.profileHe : item.profileEn).map(line=>`<div>${line}</div>`).join('');
    const revealedWrong = state.revealed && value !== item.id;
    let answerHtml = actualItem ? `<div class="answer-main ${revealedWrong?'answer-revealed':''}">${formatDisplay(actualItem)}</div>` : '';
    if (state.revealed && !value) answerHtml = `<div class="answer-main answer-revealed">${formatDisplay(item)}</div>`;
    btn.innerHTML = `<span class="slot-index">${idx+1}</span><div style="display:grid;gap:8px"><div class="subtle">${clueLines}</div>${answerHtml}</div>`;
    slotList.appendChild(btn);
  });
  right.appendChild(slotList);
  wrap.append(left,right);
  state.score = getEuropeProfileCorrectCount();
  el.quizBody.replaceChildren(wrap);
  updateToolbar();
}

function handleEuropeProfileCountry(id){
  if (state.revealed) return;
  state.selectedPlacement = id;
  renderEuropeProfileMatch();
}

function handleEuropeProfileSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];
  if (state.selectedPlacement == null) {
    if (currentValue != null) {
      state.selectedPlacement = currentValue;
      state.placements[slotIndex] = null;
      state.score = getEuropeProfileCorrectCount();
      renderEuropeProfileMatch();
    }
    return;
  }
  const previousIndex = state.placements.findIndex(val => val === state.selectedPlacement);
  if (previousIndex !== -1) state.placements[previousIndex] = null;
  if (currentValue != null) {
    state.placements[slotIndex] = state.selectedPlacement;
    if (previousIndex !== -1) state.placements[previousIndex] = currentValue;
    else state.selectedPlacement = currentValue;
  } else {
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }
  state.score = getEuropeProfileCorrectCount();
  renderEuropeProfileMatch();
  maybeComplete();
}

function getEuropeRankingModeDef(){
  return DATA.europeCountryRanking.modes[state.europeRankingMode] || DATA.europeCountryRanking.modes.gdp;
}

function getEuropeRankingSortedIds(){
  const mode = getEuropeRankingModeDef();
  return [...DATA.europeGeoCountries].sort((a,b)=>mode.get(b)-mode.get(a)).map(item=>item.id);
}

function getEuropeRankingCorrectCount(){
  const correctIds = getEuropeRankingSortedIds();
  return correctIds.reduce((sum,id,idx)=>sum + (state.placements[idx] === id ? 1 : 0), 0);
}

function formatRankingValue(item, modeKey){
  if (modeKey === 'gdp') return `$${Math.round(item.gdpUsd/1000000000).toLocaleString('en-US')}B`;
  if (modeKey === 'population') return item.population.toLocaleString('en-US');
  if (modeKey === 'area') return `${item.areaKm2.toLocaleString('en-US')} km²`;
  if (modeKey === 'gdpPerCapita') return `$${item.gdpPerCapitaUsd.toLocaleString('en-US')}`;
  if (modeKey === 'density') return `${item.density.toLocaleString('en-US')}/km²`;
  if (id === 'europeLandmarks') {
    const item = DATA.europeLandmarks[state.order?.[Math.min(state.pointer, DATA.europeLandmarks.length-1)] ?? 0];
    const country = item ? DATA.europeAdvancedCountries.find(c=>c.id===item.countryId) : null;
    if (!item) return `<div class="teach-content"></div>`;
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'מהו האתר?' : 'What is the landmark?'}</h3>
          <div class="teach-note"><strong>${he ? item.landmarkHe : item.landmarkEn}</strong> — ${he ? item.cityHe : item.cityEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'למה זה חשוב' : 'Why it matters'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'תמונת מצב מהירה' : 'Quick snapshot'}</h3>
          ${teachList([`${he?'מדינה':'Country'}: <strong>${country ? (he?country.he:country.en) : ''}</strong>`, `${he?'אזור':'Region'}: ${country ? (he?country.regionHe:country.regionEn) : ''}`, `${he?'ידועה גם ב':'Also known for'}: ${country ? (he?country.industryHe:country.industryEn) : ''}`])}
        </section>
      </div>`;
  }
  if (id === 'europeExportMatch') {
    const rows = DATA.europeExportCountries.map(item => `<tr><td>${he?item.he:item.en}</td><td>${(he?item.profileHe:item.profileEn)[0]}</td><td>${(he?item.profileHe:item.profileEn)[1]}</td></tr>`).join('');
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'איך ללמוד יצוא' : 'How to study exports'}</h3>
          ${teachList(he ? ['חפש אם המדינה בולטת בתעשייה, אנרגיה, פיננסים, תיירות או מסחר.', 'המותגים עוזרים לזכור את הסקטור המרכזי.', 'השווה בין מדינות דומות: גרמניה מול איטליה, הולנד מול בלגיה, נורווגיה מול שווייץ.'] : ['Look for whether the country stands out in industry, energy, finance, tourism, or trade.', 'Brands help anchor the main sector in memory.', 'Compare similar countries: Germany vs Italy, Netherlands vs Belgium, Norway vs Switzerland.'])}
        </section>
        <section class="teach-section">
          <h3>${he ? 'טבלת עזר' : 'Reference table'}</h3>
          <table class="teach-table"><thead><tr><th>${he?'מדינה':'Country'}</th><th>${he?'פרופיל יצוא':'Export profile'}</th><th>${he?'מותגים':'Brands'}</th></tr></thead><tbody>${rows}</tbody></table>
        </section>
      </div>`;
  }
  if (id === 'europeCompareCountries') {
    const item = DATA.europeCompareCountries[state.order?.[Math.min(state.pointer, DATA.europeCompareCountries.length-1)] ?? 0];
    if (!item) return `<div class="teach-content"></div>`;
    const a = getEuropeAnyCountry(item.optionIds[0]);
    const b = getEuropeAnyCountry(item.optionIds[1]);
    const winner = getEuropeAnyCountry(item.correct);
    return `
      <div class="teach-content">
        <section class="teach-section">
          <h3>${he ? 'למה זו התשובה' : 'Why this is the answer'}</h3>
          <div class="teach-note">${he ? item.teachHe : item.teachEn}</div>
        </section>
        <section class="teach-section">
          <h3>${he ? 'השוואה מהירה' : 'Quick comparison'}</h3>
          <table class="teach-table"><thead><tr><th>${he?'מדינה':'Country'}</th><th>${he?'תחום בולט':'Standout area'}</th></tr></thead><tbody><tr><td>${a ? (he?a.he:a.en) : ''}</td><td>${a ? ((he?a.profileHe?.[0]:a.profileEn?.[0]) || (he?a.industryHe:a.industryEn)) : ''}</td></tr><tr><td>${b ? (he?b.he:b.en) : ''}</td><td>${b ? ((he?b.profileHe?.[0]:b.profileEn?.[0]) || (he?b.industryHe:b.industryEn)) : ''}</td></tr></tbody></table>
          <div class="teach-note" style="margin-top:10px">${he ? 'התשובה הנכונה:' : 'Correct answer:'} <strong>${winner ? (he?winner.he:winner.en) : ''}</strong></div>
        </section>
      </div>`;
  }
  return '';
}

function setEuropeRankingMode(mode){
  if (!DATA.europeCountryRanking.modes[mode]) return;
  if (state.europeRankingMode === mode) return;
  state.europeRankingMode = mode;
  state.selectedPlacement = null;
  state.placements = Array(DATA.europeGeoCountries.length).fill(null);
  state.score = 0;
  renderEuropeCountryRanking();
}

function renderEuropeCountryRanking(){
  const mode = getEuropeRankingModeDef();
  const wrap = document.createElement('div');
  wrap.style.display='grid';
  wrap.style.gap='14px';
  const tabs = document.createElement('div');
  tabs.className='mini-tabs';
  Object.entries(DATA.europeCountryRanking.modes).forEach(([key,def]) => {
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`mini-tab${state.europeRankingMode===key?' active':''}`;
    btn.dataset.eurankmode=key;
    btn.textContent=state.lang==='he' ? def.he : def.en;
    tabs.appendChild(btn);
  });
  wrap.appendChild(tabs);
  const chooser = document.createElement('div');
  chooser.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'מאגר מדינות' : 'Country pool'}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  state.order.forEach(idx => {
    const item = DATA.europeGeoCountries[idx];
    const used = state.placements.includes(item.id);
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.id?' selected':''}${used?' used':''}`;
    btn.dataset.eurankcountry=item.id;
    btn.innerHTML=formatDisplay(item);
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);
  const right = document.createElement('div');
  right.className='slots-panel';
  right.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'דרג מהגבוה לנמוך' : 'Rank from highest to lowest'}</h3><p class="subtle">${state.lang==='he' ? 'מצב:' : 'Mode:'} ${state.lang==='he' ? mode.he : mode.en}</p><p class="subtle">${t('correctPlacements')}: ${getEuropeRankingCorrectCount()}/${DATA.europeGeoCountries.length}</p>`;
  const slotList = document.createElement('div');
  slotList.className='slot-list';
  const correctIds = getEuropeRankingSortedIds();
  DATA.europeGeoCountries.forEach((_, idx) => {
    const value = state.placements[idx];
    const actualItem = value ? DATA.europeGeoCountries.find(x=>x.id===value) : null;
    const correctItem = DATA.europeGeoCountries.find(x=>x.id===correctIds[idx]);
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`slot-btn${value?' filled':''}`;
    btn.dataset.eurankslot=String(idx);
    const revealedWrong = state.revealed && value !== correctIds[idx];
    let answerHtml = actualItem ? `<div class="answer-main ${revealedWrong?'answer-revealed':''}">${formatDisplay(actualItem)} <span class="secondary">— ${formatRankingValue(actualItem, state.europeRankingMode)}</span></div>` : '';
    if (state.revealed && !value) answerHtml = `<div class="answer-main answer-revealed">${formatDisplay(correctItem)} <span class="secondary">— ${formatRankingValue(correctItem, state.europeRankingMode)}</span></div>`;
    btn.innerHTML = `<span class="slot-index">${idx+1}</span><span>${answerHtml}</span>`;
    slotList.appendChild(btn);
  });
  right.appendChild(slotList);
  chooser.append(left,right);
  wrap.appendChild(chooser);
  state.score = getEuropeRankingCorrectCount();
  el.quizBody.replaceChildren(wrap);
  updateToolbar();
}

function handleEuropeRankCountry(id){
  if (state.revealed) return;
  state.selectedPlacement = id;
  renderEuropeCountryRanking();
}


function handleEuropeRankingCountry(id){
  handleEuropeRankCountry(id);
}

function handleEuropeRankingSlot(index){
  handleEuropeRankSlot(index);
}

function handleEuropeRankSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];
  if (state.selectedPlacement == null) {
    if (currentValue != null) {
      state.selectedPlacement = currentValue;
      state.placements[slotIndex] = null;
      state.score = getEuropeRankingCorrectCount();
      renderEuropeCountryRanking();
    }
    return;
  }
  const previousIndex = state.placements.findIndex(val => val === state.selectedPlacement);
  if (previousIndex !== -1) state.placements[previousIndex] = null;
  if (currentValue != null) {
    state.placements[slotIndex] = state.selectedPlacement;
    if (previousIndex !== -1) state.placements[previousIndex] = currentValue;
    else state.selectedPlacement = currentValue;
  } else {
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }
  state.score = getEuropeRankingCorrectCount();
  renderEuropeCountryRanking();
  maybeComplete();
}

function renderEuropeCountryFits(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.europeCountryFits.forEach(item => {
      const country = DATA.europeAdvancedCountries.find(c=>c.id===item.correct);
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.clueHe : item.clueEn}</div><div class="review-answer">${country ? (state.lang==='he' ? country.he : country.en) : item.correct}</div><div class="subtle" style="margin-top:8px;line-height:1.7">${state.lang==='he' ? item.teachHe : item.teachEn}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.europeCountryFits[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `<div class="center" style="font-size:1.45rem;font-weight:900;color:var(--gold);margin-bottom:18px;line-height:1.55">${state.lang==='he' ? item.clueHe : item.clueEn}</div><div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    item.optionIds.forEach(id => {
      const country = DATA.europeAdvancedCountries.find(c=>c.id===id);
      const b = document.createElement('button');
      b.type='button';
      b.className='answer-btn';
      b.dataset.choice=id;
      b.textContent = country ? (state.lang==='he' ? country.he : country.en) : id;
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}

function renderEuropeCorrectWrong(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.europeCorrectWrong.forEach(item => {
      const country = DATA.europeAdvancedCountries.find(c=>c.id===item.countryId);
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${country ? (state.lang==='he' ? country.he : country.en) + ': ' : ''}${state.lang==='he' ? item.statementHe : item.statementEn}</div><div class="review-answer">${item.correct ? t('correct') : t('wrong')}</div><div class="subtle" style="margin-top:8px;line-height:1.7">${state.lang==='he' ? item.teachHe : item.teachEn}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.europeCorrectWrong[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    const country = DATA.europeAdvancedCountries.find(c=>c.id===item.countryId);
    card.innerHTML = `
      <div class="center" style="font-size:1.1rem;color:var(--muted);margin-bottom:10px">${country ? (state.lang==='he' ? country.he : country.en) : ''}</div>
      <div class="center" style="font-size:1.5rem;font-weight:900;color:var(--gold);margin-bottom:18px;line-height:1.55">${state.lang==='he' ? item.statementHe : item.statementEn}</div>
      <div class="answers-grid">
        <button type="button" class="answer-btn" data-choice="correct">${t('correct')}</button>
        <button type="button" class="answer-btn" data-choice="wrong">${t('wrong')}</button>
      </div>`;
  }
  el.quizBody.replaceChildren(card);
}



function getEuropeAnyCountry(id){
  return DATA.europeExportCountries?.find(c=>c.id===id)
    || DATA.europeAdvancedCountries?.find(c=>c.id===id)
    || DATA.europeGeoCountries?.find(c=>c.id===id)
    || null;
}

function renderEuropeLandmarks(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.europeLandmarks.forEach(item => {
      const country = getEuropeAnyCountry(item.countryId);
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.clueHe : item.clueEn}</div><div class="review-answer">${country ? (state.lang==='he' ? country.he : country.en) : item.countryId}</div><div class="subtle" style="margin-top:8px;line-height:1.7">${state.lang==='he' ? item.teachHe : item.teachEn}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.europeLandmarks[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `<div class="center" style="font-size:1.1rem;color:var(--muted);margin-bottom:10px">${state.lang==='he' ? (item.landmarkHe + ' — ' + item.cityHe) : (item.landmarkEn + ' — ' + item.cityEn)}</div><div class="center" style="font-size:1.45rem;font-weight:900;color:var(--gold);margin-bottom:18px;line-height:1.55">${state.lang==='he' ? item.clueHe : item.clueEn}</div><div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    item.options.forEach(id => {
      const country = getEuropeAnyCountry(id);
      const b = document.createElement('button');
      b.type='button';
      b.className='answer-btn';
      b.dataset.choice=id;
      b.textContent = country ? (state.lang==='he' ? country.he : country.en) : id;
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}

function getEuropeExportCorrectCount(){
  return DATA.europeExportCountries.reduce((sum,item,idx)=>sum + (state.placements[idx] === item.id ? 1 : 0), 0);
}

function renderEuropeExportMatch(){
  const wrap = document.createElement('div');
  wrap.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'מאגר מדינות' : 'Country pool'}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  state.order.forEach(idx => {
    const item = DATA.europeExportCountries[idx];
    const used = state.placements.includes(item.id);
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.id?' selected':''}${used?' used':''}`;
    btn.dataset.euexportcountry=item.id;
    btn.innerHTML=formatDisplay(item);
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);

  const right = document.createElement('div');
  right.className='slots-panel';
  right.innerHTML = `<h3 style="margin-top:0">${state.lang==='he' ? 'התאם מדינה לפרופיל יצוא' : 'Match each export profile'}</h3><p class="subtle">${t('correctPlacements')}: ${getEuropeExportCorrectCount()}/${DATA.europeExportCountries.length}</p><p class="subtle">${state.lang==='he' ? 'בחר מדינה ואז לחץ על תיבת פרופיל היצוא המתאימה.' : 'Pick a country, then click the matching export profile box.'}</p>`;
  const slotList = document.createElement('div');
  slotList.className='slot-list';
  DATA.europeExportCountries.forEach((item, idx) => {
    const value = state.placements[idx];
    const actualItem = value ? DATA.europeExportCountries.find(x=>x.id===value) : null;
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`slot-btn${value?' filled':''}`;
    btn.dataset.euexportslot=String(idx);
    const clueLines = (state.lang==='he' ? item.profileHe : item.profileEn).map(line=>`<div>${line}</div>`).join('');
    const revealedWrong = state.revealed && value !== item.id;
    let answerHtml = actualItem ? `<div class="answer-main ${revealedWrong?'answer-revealed':''}">${formatDisplay(actualItem)}</div>` : '';
    if (state.revealed && !value) answerHtml = `<div class="answer-main answer-revealed">${formatDisplay(item)}</div>`;
    btn.innerHTML = `<span class="slot-index">${idx+1}</span><div style="display:grid;gap:8px"><div class="subtle">${clueLines}</div>${answerHtml}</div>`;
    slotList.appendChild(btn);
  });
  right.appendChild(slotList);
  wrap.append(left,right);
  state.score = getEuropeExportCorrectCount();
  el.quizBody.replaceChildren(wrap);
  updateToolbar();
}

function handleEuropeExportCountry(id){
  if (state.revealed) return;
  state.selectedPlacement = id;
  renderEuropeExportMatch();
}

function handleEuropeExportSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];
  if (state.selectedPlacement == null) {
    if (currentValue != null) {
      state.selectedPlacement = currentValue;
      state.placements[slotIndex] = null;
      state.score = getEuropeExportCorrectCount();
      renderEuropeExportMatch();
    }
    return;
  }
  const previousIndex = state.placements.findIndex(val => val === state.selectedPlacement);
  if (previousIndex !== -1) state.placements[previousIndex] = null;
  if (currentValue != null) {
    state.placements[slotIndex] = state.selectedPlacement;
    if (previousIndex !== -1) state.placements[previousIndex] = currentValue;
    else state.selectedPlacement = currentValue;
  } else {
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }
  state.score = getEuropeExportCorrectCount();
  renderEuropeExportMatch();
  maybeComplete();
}

function renderEuropeCompareCountries(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.europeCompareCountries.forEach(item => {
      const country = getEuropeAnyCountry(item.correct);
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.questionHe : item.questionEn}</div><div class="review-answer">${country ? (state.lang==='he' ? country.he : country.en) : item.correct}</div><div class="subtle" style="margin-top:8px;line-height:1.7">${state.lang==='he' ? item.teachHe : item.teachEn}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.europeCompareCountries[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `<div class="center" style="font-size:1.45rem;font-weight:900;color:var(--gold);margin-bottom:18px;line-height:1.55">${state.lang==='he' ? item.questionHe : item.questionEn}</div><div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    const orderKey = state.order[state.pointer];
    if (!state.compareOptionOrders) state.compareOptionOrders = {};
    if (!state.compareOptionOrders[orderKey]) {
      state.compareOptionOrders[orderKey] = [...item.optionIds].sort(() => Math.random() - 0.5);
    }
    state.compareOptionOrders[orderKey].forEach(id => {
      const country = getEuropeAnyCountry(id);
      const b = document.createElement('button');
      b.type='button';
      b.className='answer-btn';
      b.dataset.choice=id;
      b.textContent = country ? (state.lang==='he' ? country.he : country.en) : id;
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}

function renderMentalMathTF(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.mentalMathTF.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.he : item.en}</div><div class="review-answer">${item.correct === 'correct' ? t('correct') : t('wrong')}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.mentalMathTF[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) {
    renderCompletedPlaceholder(card);
  } else {
    card.innerHTML = `
      <div class="center" style="font-size:2rem;font-weight:900;color:var(--gold);margin-bottom:16px">${state.lang==='he' ? item.he : item.en}</div>
      <div class="answers-grid">
        <button type="button" class="answer-btn" data-choice="correct">${t('correct')}</button>
        <button type="button" class="answer-btn" data-choice="wrong">${t('wrong')}</button>
      </div>`;
  }
  el.quizBody.replaceChildren(card);
}

function ensureRecognition(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;
  if (!state.recognition) {
    const rec = new SR();
    rec.lang = state.lang === 'he' ? 'he-IL' : 'en-US';
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onstart = () => { state.speechActive = true; el.micBtn.classList.add('active'); flash(t('micStart')); };
    rec.onend = () => { state.speechActive = false; el.micBtn.classList.remove('active'); };
    rec.onerror = () => { state.speechActive = false; el.micBtn.classList.remove('active'); };
    rec.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript?.trim();
      if (!transcript) return;
      el.answerInput.value = transcript;
      handleTextSubmit();
    };
    state.recognition = rec;
  }
  state.recognition.lang = state.lang === 'he' ? 'he-IL' : 'en-US';
  return state.recognition;
}

function toggleSpeech(){
  if (!state.activeQuiz || state.paused || QUIZZES[state.activeQuiz]?.type !== 'text') return;
  const rec = ensureRecognition();
  if (!rec) { flash(t('speechUnsupported'), true); return; }
  try {
    if (state.speechActive) { rec.stop(); flash(t('micStop')); }
    else { rec.start(); }
  } catch (err) {
    flash(t('speechUnsupported'), true);
  }
}

function handleTextSubmit(){
  const raw = el.answerInput.value.trim();
  if (!raw || state.revealed || state.paused) return;
  if (state.activeQuiz==='gematria' && state.gematriaCalc) {
    if (!/^\d+$/.test(raw)) { renderGematria(); return; }
  }
  let matched = false;

  if (state.activeQuiz === 'tanakh') {
    for (const item of DATA.tanakh) {
      if (state.guessed.has(item.id)) continue;
      if (fuzzyMatch(raw,[item.he,item.en,...item.aliases])) { state.guessed.add(item.id); state.score++; matched = true; break; }
    }
  } else if (state.activeQuiz === 'shas') {
    for (const [key,seder] of Object.entries(DATA.shas)) {
      if (!state.guessed.has(`seder:${key}`) && fuzzyMatch(raw,[seder.he,seder.en])) { state.guessed.add(`seder:${key}`); state.score++; matched=true; break; }
    }
    if (!matched) {
      outer1: for (const [key,seder] of Object.entries(DATA.shas)) {
        for (let i=0;i<seder.tractates.length;i++) {
          const item = seder.tractates[i], id = `m:${key}:${i}`;
          if (state.guessed.has(id)) continue;
          if (fuzzyMatch(raw,[item.he,item.en,...(item.aliases||[])])) { state.guessed.add(id); state.score++; matched=true; break outer1; }
        }
      }
    }
  } else if (state.activeQuiz === 'parashot') {
    for (const item of DATA.parashot) {
      if (state.guessed.has(item.index)) continue;
      if (fuzzyMatch(raw,[item.he,item.en,...item.aliases])) { state.guessed.add(item.index); state.score++; matched=true; break; }
    }
  } else if (state.activeQuiz === 'worldCountries') {
    outer2: for (const [cont,list] of Object.entries(DATA.worldCountries)) {
      for (const item of list) {
        const id = `${cont}:${item.en}`;
        if (state.guessed.has(id)) continue;
        if (fuzzyMatch(raw,[item.he,item.en])) { state.guessed.add(id); state.score++; matched = true; break outer2; }
      }
    }
  } else if (state.activeQuiz === 'worldCapitals') {
    for (let i=0;i<DATA.worldCapitals.length;i++) {
      if (state.guessed.has(i)) continue;
      const item = DATA.worldCapitals[i];
      if (fuzzyMatch(raw,[item.capital.he,item.capital.en])) { state.guessed.add(i); state.score++; matched = true; break; }
    }
  } else if (state.activeQuiz === 'officialLanguages') {
    for (let i=0;i<DATA.officialLanguages.length;i++) {
      if (state.guessed.has(i)) continue;
      const item = DATA.officialLanguages[i];
      if (fuzzyMatch(raw,[item.country.he,item.country.en])) { state.guessed.add(i); state.score++; matched = true; break; }
    }
  } else if (state.activeQuiz === 'scrambledCountries') {
    for (let i=0;i<DATA.scrambledCountries.length;i++) {
      if (state.guessed.has(i)) continue;
      const item = DATA.scrambledCountries[i];
      if (fuzzyMatch(raw,[item.item.he,item.item.en,...(item.aliases||[])])) {
        state.guessed.add(i);
        state.score++;
        state.scrambledRevealIndex = null;
        state.scrambledFeedbackIndex = i;
        matched = true;
        clearTimeout(state.scrambledTimerId);
        state.scrambledTimerId = setTimeout(() => {
          state.scrambledFeedbackIndex = null;
          state.scrambledTimerId = null;
          maybeComplete();
          renderQuiz();
        }, 3000);
        break;
      }
    }
  } else if (state.activeQuiz === 'multiplication') {
    if (!state.selectedCell || state.guessed.has(`${state.selectedCell.r}-${state.selectedCell.c}`)) {
      state.selectedCell = findNextUnansweredMultiplicationCell(state.selectedCell || null);
    }
    const {r,c} = state.selectedCell;
    const key = `${r}-${c}`;
    const value = Number(raw);
    if (!state.guessed.has(key) && value === r*c) {
      state.guessed.add(key);
      state.score++;
      state.selectedCell = findNextUnansweredMultiplicationCell({r,c});
      matched = true;
    }
  } else if (state.activeQuiz === 'gematria') {
    const expected = DATA.gematria[state.order[state.pointer]];
    const value = Number(raw);
    if (expected && value === expected.value) { state.guessed.add(state.order[state.pointer]); state.pointer++; state.score++; matched = true; }
  }

  if (matched) {
    el.answerInput.value = '';
    pulseInput(true);
    if (state.activeQuiz === 'scrambledCountries') {
      renderQuiz();
    } else {
      maybeComplete();
      renderQuiz();
    }
  } else {
    pulseInput(false);
  }
}

function pulseInput(ok){
  el.answerInput.classList.remove('correct','wrong');
  void el.answerInput.offsetWidth;
  el.answerInput.classList.add(ok ? 'correct' : 'wrong');
  setTimeout(()=>el.answerInput.classList.remove('correct','wrong'), 350);
}

function maybeComplete(){
  const total = QUIZZES[state.activeQuiz].total;
  if (state.score >= total) {
    state.revealAllUsed = false;
    clearInterval(state.timerId);
    state.timerId = null;
    saveBest();
    scheduleCompletionOverlay(0, 10000);
  }
}

function saveBest(){
  const id = state.activeQuiz;
  if (!id) return;
  if (state.mode === 'timed' && QUIZZES[id].timedSeconds) {
    const remaining = Math.max(0,state.timeLeft);
    const previous = Number(getBest(id) || -1);
    if (remaining > previous) setBest(id, String(remaining));
  } else {
    const previous = Number(getBest(id) || 0);
    if (state.score > previous) setBest(id, String(state.score));
  }
}

function revealAnswers(){
  const preservedScore = Number(state.score || 0);
  state.revealed = true;
  state.revealAllUsed = true;
  clearInterval(state.timerId);
  state.timerId = null;
  if (state.speechActive && state.recognition) { try { state.recognition.stop(); } catch (e) {} }
  const id = state.activeQuiz;
  if (id === 'worldCountries') {
    Object.entries(DATA.worldCountries).forEach(([cont,list]) => list.forEach(item => state.guessed.add(`${cont}:${item.en}`)));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'worldCapitals') {
    DATA.worldCapitals.forEach((_,i)=>state.guessed.add(i));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'officialLanguages') {
    DATA.officialLanguages.forEach((_,i)=>state.guessed.add(i));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'scrambledCountries') {
    DATA.scrambledCountries.forEach((_,i)=>state.guessed.add(i));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'mentalMathTF') {
    state.pointer = DATA.mentalMathTF.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'inventionInventor') {
    state.pointer = DATA.inventionInventor.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'symptomOrgan') {
    state.pointer = DATA.symptomOrgan.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'whoSaidIt') {
    state.pointer = DATA.whoSaidIt.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'tannaim') {
    state.pointer = DATA.tannaim.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'relations') {
    state.pointer = DATA.relations.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'countryFlags') {
    state.pointer = DATA.countryFlags.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'multiplication') {
    for (let r=1;r<=12;r++) for (let c=1;c<=12;c++) state.guessed.add(`${r}-${c}`);
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'fastMultiplication') {
    DATA.fastMultiplication.forEach((item,i)=>{state.rowLocked[i]=true; state.rowAnswers[i]=item.answer;});
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'equationCompletion') {
    DATA.equationCompletion.forEach((item,i)=>{state.rowLocked[i]=true; state.rowAnswers[i]=item.answer;});
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'fastAddition') {
    DATA.fastAddition.forEach((item,i)=>{state.rowLocked[i]=true; state.rowAnswers[i]=item.answer;});
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'romanNumerals') {
    DATA.romanNumerals.forEach((item,i)=>{state.rowLocked[i]=true; state.rowAnswers[i]=item.answer;});
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'romanMath') {
    DATA.romanMath.forEach((item,i)=>{state.rowLocked[i]=true; state.rowAnswers[i]=item.answer;});
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'humanBody') {
    state.bodyAnswers = {};
    state.bodySystemAnswers = {};
    state.bodyLabelMap = {};
    DATA.humanBodySet.organFunction.forEach((item,i)=>state.bodyAnswers[i]=item.correct);
    DATA.humanBodySet.systemMatch.forEach((item,i)=>state.bodySystemAnswers[i]=item.correct);
    DATA.humanBodySet.labels.forEach(item=>state.bodyLabelMap[item.zone]=item.id);
    state.bodyStage = 'label';
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'solarSystem') {
    state.solarStage = 'details';
    state.solarMatches = Object.fromEntries(DATA.solarSystem.planets.map((p,i)=>[i,p.id]));
    state.solarDetailMatches = Object.fromEntries(state.solarDetailOrder.map((itemIdx,i)=>[i, DATA.solarSystem.planets[itemIdx].id]));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'agesHumanity') {
    state.ageStage = 'details';
    state.placements = DATA.agesHumanity.map(x=>x.order);
    state.ageMatches = Object.fromEntries(state.ageDetailOrder.map((itemIdx,i)=>[i, DATA.agesHumanity[itemIdx].order]));
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'tenCommandments') {
    state.placements = DATA.tenCommandments.map(x=>x.order);
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'largestCountriesRanking') {
    state.placements = DATA.largestCountriesRanking.map(x=>x.order);
    state.rankStage = 'flags';
    state.rankFlagMatches = Object.fromEntries(DATA.largestCountriesRanking.map((item,idx)=>[idx,item.order]));
    state.rankFlagOrder = DATA.largestCountriesRanking.map((_,i)=>i);
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'holidaysMonths') {
    state.pointer = DATA.holidaysMonths.length;
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'continentQuiz') {
    DATA.continentQuiz.countries.forEach(c=>state.continentMap[c.en]=c.continent);
    // reveal-all keeps the current earned score; answers are shown without awarding full credit.
  } else if (id === 'europeProfileMatch') {
    state.placements = DATA.europeGeoCountries.map(item => item.id);
  } else if (id === 'europeCountryRanking') {
    state.placements = getEuropeRankingSortedIds();
  } else if (id === 'europeCountryFits') {
    state.pointer = DATA.europeCountryFits.length;
  } else if (id === 'europeCorrectWrong') {
    state.pointer = DATA.europeCorrectWrong.length;
  } else if (id === 'europeLandmarks') {
    state.pointer = DATA.europeLandmarks.length;
  } else if (id === 'europeExportMatch') {
    state.placements = DATA.europeExportCountries.map(item => item.id);
  } else if (id === 'europeCompareCountries') {
    state.pointer = DATA.europeCompareCountries.length;
  } else if (id === 'halacha') {
    DATA.halacha.stages.forEach(stage => {
      const answers = getHalachaStageAnswers(stage.id);
      stage.items.forEach((item, i) => answers[i] = item.correct);
    });
    state.halachaStage = 'interpersonal';
    updateHalachaScore();
  }
  state.score = preservedScore;
  renderQuiz();
  scheduleCompletionOverlay(10000, 3000);
}

function handleChoice(choice){
  if (state.revealed || state.paused) return;
  if (state.activeQuiz === 'tannaim') {
    const item = DATA.tannaim[state.order[state.pointer]];
    const correct = item.type;
    const isCorrect = choice === correct;
    if (isCorrect) state.score++;
    state.tannaimFeedback = { choice, correctChoice: correct, isCorrect, itemOrder: item.type + '|' + item.en };
    updateToolbar();
    renderQuiz();
    setTimeout(() => {
      state.pointer++;
      state.tannaimFeedback = null;
      state.countryFlagFeedback = null;
      maybeComplete();
      renderQuiz();
    }, isCorrect ? 3000 : 700);
    return;
  }
  if (state.activeQuiz === 'holidaysMonths') {
    const item = DATA.holidaysMonths[state.order[state.pointer]];
    const correct = item.month.he;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.month === correct) btn.classList.add('correct');
      if (btn.dataset.month === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }
  if (state.activeQuiz === 'countryFlags') {
    const item = DATA.countryFlags[state.order[state.pointer]];
    const correct = item.correct;
    const isCorrect = choice === correct;
    if (isCorrect) state.score++;
    state.countryFlagFeedback = { choice, correctChoice: correct, isCorrect, itemKey: item.country.en };
    updateToolbar();
    renderQuiz();
    setTimeout(() => {
      state.countryFlagFeedback = null;
      renderQuiz();
      if (isCorrect) {
        showCountryFlagFact(item);
      } else {
        state.pointer++;
        maybeComplete();
        renderQuiz();
      }
    }, 850);
    return;
  }
  if (state.activeQuiz === 'relations') {
    const item = DATA.relations[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.rel === correct) btn.classList.add('correct');
      if (btn.dataset.rel === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }
  if (state.activeQuiz === 'mentalMathTF') {
    const item = DATA.mentalMathTF[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }

  if (state.activeQuiz === 'inventionInventor') {
    const item = DATA.inventionInventor[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }
  if (state.activeQuiz === 'symptomOrgan') {
    const item = DATA.symptomOrgan[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }
  if (state.activeQuiz === 'whoSaidIt') {
    const item = DATA.whoSaidIt[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
  }
  if (state.activeQuiz === 'europeCountryFits') {
    const item = DATA.europeCountryFits[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    return;
  }
  if (state.activeQuiz === 'europeCorrectWrong') {
    const item = DATA.europeCorrectWrong[state.order[state.pointer]];
    const correct = item.correct ? 'correct' : 'wrong';
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    return;
  }
  if (state.activeQuiz === 'europeLandmarks') {
    const item = DATA.europeLandmarks[state.order[state.pointer]];
    const correct = item.countryId;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    return;
  }
  if (state.activeQuiz === 'europeCompareCountries') {
    const item = DATA.europeCompareCountries[state.order[state.pointer]];
    const correct = item.correct;
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      if (btn.dataset.choice === correct) btn.classList.add('correct');
      if (btn.dataset.choice === choice && choice !== correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    if (choice === correct) state.score++;
    state.pointer++;
    updateToolbar();
    setTimeout(() => { maybeComplete(); renderQuiz(); }, 700);
    return;
  }
  if (state.activeQuiz === 'halacha') {
    const stage = getHalachaStageDef(state.halachaStage);
    const answers = getHalachaStageAnswers(stage.id);
    const idx = getHalachaCurrentIndex(stage.id);
    const item = stage.items[idx];
    if (!item) return;
    const normalized = choice === true || choice === 'true';
    const buttons = [...el.quizBody.querySelectorAll('.answer-btn')];
    buttons.forEach(btn => {
      const btnChoice = btn.dataset.halachachoice === 'true';
      if (btnChoice === item.correct) btn.classList.add('correct');
      if (btnChoice === normalized && normalized !== item.correct) btn.classList.add('wrong');
      btn.disabled = true;
    });
    answers[idx] = (normalized === item.correct);
    updateHalachaScore();
    updateToolbar();
    clearTimeout(state.halachaPendingAdvance);
    state.halachaPendingAdvance = setTimeout(() => {
      state.halachaPendingAdvance = null;
      advanceHalachaStageIfNeeded();
      maybeComplete();
      renderQuiz();
    }, 700);
    return;
  }
}


function handleAgeFigure(order){
  if (state.revealed) return;
  state.selectedPlacement = Number(order);
  renderAgesHumanity();
}
function handleAgeSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  if (state.ageStage === 'order') {
    const currentValue = state.placements[slotIndex];
    if (state.selectedPlacement == null) {
      if (currentValue != null) { state.selectedPlacement = currentValue; state.placements[slotIndex] = null; }
    } else {
      const fromIndex = state.placements.findIndex(v => v === state.selectedPlacement);
      if (fromIndex !== -1) state.placements[fromIndex] = currentValue ?? null;
      state.placements[slotIndex] = state.selectedPlacement;
      state.selectedPlacement = null;
    }
    state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
    if (state.placements.every(v => v != null)) {
      state.ageStage = 'details';
      state.selectedPlacement = null;
    }
    maybeComplete();
    renderAgesHumanity();
    return;
  }
  if (state.selectedPlacement == null) return;
  const boxIdx = Number(index);
  state.ageMatches[boxIdx] = Number(state.selectedPlacement);
  state.selectedPlacement = null;
  const detailCorrect = state.ageDetailOrder.reduce((sum, itemIdx, i) => sum + ((state.ageMatches[i] === DATA.agesHumanity[itemIdx].order) ? 1 : 0), 0);
  state.score = DATA.agesHumanity.length + detailCorrect;
  maybeComplete();
  renderAgesHumanity();
}
function handleSolarPlanet(index){
  if (state.revealed) return;
  state.selectedPlacement = Number(index);
  renderSolarSystem();
}
function handleSolarTarget(index){
  if (state.revealed || state.selectedPlacement==null) return;
  const slot = Number(index);
  const item = DATA.solarSystem.planets[state.selectedPlacement];
  state.solarMatches[slot] = item.id;
  state.selectedPlacement = null;
  if (Object.keys(state.solarMatches).length >= DATA.solarSystem.planets.length) {
    state.solarStage = 'details';
    state.score = DATA.solarSystem.planets.length;
    state.selectedPlacement = null;
  }
  renderSolarSystem();
}
function handleSolarOrder(index){
  if (state.revealed) return;
  state.selectedPlacement = Number(index);
  renderSolarSystem();
}
function handleSolarOrderSlot(index){
  if (state.revealed || state.solarStage !== 'details' || state.selectedPlacement==null) return;
  const boxIdx = Number(index);
  const item = DATA.solarSystem.planets[state.selectedPlacement];
  state.solarDetailMatches[boxIdx] = item.id;
  state.selectedPlacement = null;
  const detailCorrect = state.solarDetailOrder.reduce((sum, itemIdx, i) => sum + ((state.solarDetailMatches[i] === DATA.solarSystem.planets[itemIdx].id) ? 1 : 0), 0);
  state.score = DATA.solarSystem.planets.length + detailCorrect;
  maybeComplete();
  renderSolarSystem();
}



function handleBodyStage(stage){
  if (state.revealed) return;
  state.bodyStage = stage;
  state.selectedPlacement = null;
  renderHumanBody();
}
function handleBodyChoice(choice){
  if (state.revealed) return;
  if (state.bodyStage === 'organ') {
    const idx = Object.keys(state.bodyAnswers).length;
    const item = DATA.humanBodySet.organFunction[idx];
    if (!item) return;
    state.bodyAnswers[idx] = choice;
    if (choice === item.correct) state.score++;
    if (Object.keys(state.bodyAnswers).length >= DATA.humanBodySet.organFunction.length) state.bodyStage = 'system';
    renderHumanBody(); maybeComplete(); return;
  }
  if (state.bodyStage === 'system') {
    const idx = Object.keys(state.bodySystemAnswers).length;
    const item = DATA.humanBodySet.systemMatch[idx];
    if (!item) return;
    state.bodySystemAnswers[idx] = choice;
    if (choice === item.correct) state.score++;
    if (Object.keys(state.bodySystemAnswers).length >= DATA.humanBodySet.systemMatch.length) state.bodyStage = 'label';
    renderHumanBody(); maybeComplete(); return;
  }
}
function handleBodyLabel(index){
  if (state.revealed) return;
  state.selectedPlacement = Number(index);
  renderHumanBody();
}
function handleBodyZone(zone){
  if (state.revealed || state.selectedPlacement==null) return;
  const item = DATA.humanBodySet.labels[state.selectedPlacement];
  state.bodyLabelMap[zone] = item.id;
  state.selectedPlacement = null;
  const labelCorrect = DATA.humanBodySet.labels.reduce((sum,x)=>sum + (state.bodyLabelMap[x.zone]===x.id ? 1 : 0), 0);
  const organCorrect = Object.keys(state.bodyAnswers).reduce((s,k)=>s + (state.bodyAnswers[k]===DATA.humanBodySet.organFunction[Number(k)].correct),0);
  const systemCorrect = Object.keys(state.bodySystemAnswers).reduce((s,k)=>s + (state.bodySystemAnswers[k]===DATA.humanBodySet.systemMatch[Number(k)].correct),0);
  state.score = organCorrect + systemCorrect + labelCorrect;
  maybeComplete();
  renderHumanBody();
}

function handleCommandmentFigure(order){
  if (state.revealed) return;
  state.selectedPlacement = Number(order);
  renderTenCommandments();
}
function handleCommandmentSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];
  if (state.selectedPlacement == null) {
    if (currentValue != null) { state.selectedPlacement = currentValue; state.placements[slotIndex] = null; }
  } else {
    const fromIndex = state.placements.findIndex(v => v === state.selectedPlacement);
    if (fromIndex !== -1) state.placements[fromIndex] = currentValue ?? null;
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }
  state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
  maybeComplete();
  renderTenCommandments();
}
function handleContinentCountry(index){
  if (state.revealed) return;
  state.selectedPlacement = Number(index);
  renderContinentQuiz();
}
function handleContinentBox(continent){
  if (state.revealed || state.selectedPlacement==null) return;
  const item = DATA.continentQuiz.countries[state.selectedPlacement];
  const isCorrect = continent === item.continent;
  state.continentMap[item.en] = continent;
  state.selectedPlacement = null;
  state.score = DATA.continentQuiz.countries.filter(c => state.continentMap[c.en] === c.continent).length;
  maybeComplete();
  renderContinentQuiz();
  if (isCorrect) showContinentFact(item);
}
function handlePlacementFigure(order){
  if (state.revealed) return;
  state.selectedPlacement = Number(order);
  renderChronology();
}

function handlePlacementSlot(index){
  if (state.revealed) return;
  const slotIndex = Number(index);
  const currentValue = state.placements[slotIndex];

  if (state.selectedPlacement == null) {
    if (currentValue != null) {
      state.selectedPlacement = currentValue;
      state.placements[slotIndex] = null;
      state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
      renderChronology();
    }
    return;
  }

  const previousIndex = state.placements.findIndex(val => val === state.selectedPlacement);
  if (previousIndex !== -1) state.placements[previousIndex] = null;

  if (currentValue != null) {
    state.placements[slotIndex] = state.selectedPlacement;
    if (previousIndex !== -1) state.placements[previousIndex] = currentValue;
    else state.selectedPlacement = currentValue;
  } else {
    state.placements[slotIndex] = state.selectedPlacement;
    state.selectedPlacement = null;
  }

  state.score = state.placements.reduce((sum,val,idx)=>sum + (val === idx+1 ? 1 : 0), 0);
  const filled = state.placements.filter(Boolean).length;
  if (filled === DATA.chronology.length) saveBest();
  renderChronology();
}




function renderSolarSystem(){
  const wrap = document.createElement('div');
  wrap.className = 'solar-wrap';
  const board = document.createElement('div');
  board.className = 'solar-board';
  board.innerHTML = `<img class="solar-image" src="${DATA.solarSystem.image}" alt="Solar System">`;
  wrap.appendChild(board);

  if (state.revealed) {
    const review = document.createElement('div');
    review.className = 'review-list';
    DATA.solarSystem.planets.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${formatDisplay(item)}</div><div class="review-answer">${state.lang==='he' ? item.detailHe : item.detailEn}</div>`;
      review.appendChild(row);
    });
    wrap.appendChild(review);
    el.quizBody.replaceChildren(wrap);
    return;
  }

  const stageLabel = document.createElement('p');
  stageLabel.className = 'subtle';
  stageLabel.textContent = state.solarStage === 'match' ? t('solarMatchStage') : t('solarOrderStage');
  wrap.appendChild(stageLabel);

  if (state.solarStage === 'match') {
    const pool = document.createElement('div');
    pool.className = 'solar-pool';
    DATA.solarSystem.planets.forEach((planet, idx) => {
      const used = Object.values(state.solarMatches || {}).includes(planet.id);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `solar-chip${used ? ' used' : ''}${state.selectedPlacement===idx ? ' selected' : ''}`;
      btn.dataset.solarplanet = String(idx);
      btn.innerHTML = formatDisplay(planet);
      pool.appendChild(btn);
    });
    wrap.appendChild(pool);

    const targets = document.createElement('div');
    targets.className = 'solar-targets';
    DATA.solarSystem.planets.forEach((planet, idx) => {
      const target = document.createElement('button');
      target.type = 'button';
      target.className = `solar-target${state.solarMatches?.[idx] ? ' filled' : ''}`;
      target.dataset.solartarget = String(idx);
      const matchedId = state.solarMatches?.[idx];
      const matched = matchedId ? DATA.solarSystem.planets.find(p=>p.id===matchedId) : null;
      target.innerHTML = `<div class="solar-target-title">${idx+1}</div><div class="answer-main">${matched ? formatDisplay(matched) : ''}</div>`;
      targets.appendChild(target);
    });
    wrap.appendChild(targets);
  } else {
    const grid = document.createElement('div');
    grid.className = 'detail-grid';

    const left = document.createElement('div');
    left.className = 'picker';
    const pickList = document.createElement('div');
    pickList.className = 'pick-list';
    DATA.solarSystem.planets.forEach((item, idx) => {
      const used = Object.values(state.solarDetailMatches || {}).includes(item.id);
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`pick-item${state.selectedPlacement===idx?' selected':''}${used?' used':''}`;
      btn.dataset.solarorder = String(idx);
      btn.innerHTML = formatDisplay(item);
      pickList.appendChild(btn);
    });
    left.appendChild(pickList);

    const right = document.createElement('div');
    right.className = 'detail-boxes';
    state.solarDetailOrder.forEach((itemIdx, boxIdx) => {
      const detailItem = DATA.solarSystem.planets[itemIdx];
      const matchedId = state.solarDetailMatches?.[boxIdx];
      const matched = matchedId ? DATA.solarSystem.planets.find(p=>p.id===matchedId) : null;
      const box = document.createElement('button');
      box.type='button';
      box.className=`detail-box${matched?' filled':''}`;
      box.dataset.solarorderslot=String(boxIdx);
      box.innerHTML = `<div class="review-title">${state.lang==='he'?detailItem.detailHe:detailItem.detailEn}</div><div class="answer-main">${matched ? formatDisplay(matched) : ''}</div>`;
      right.appendChild(box);
    });
    grid.append(left,right);
    wrap.appendChild(grid);
  }

  el.quizBody.replaceChildren(wrap);
}

function renderAgesHumanity(){
  if (state.revealed) {
    const review = document.createElement('div');
    review.className='review-list';
    DATA.agesHumanity.forEach(item => {
      const row = document.createElement('div');
      row.className='review-row';
      row.innerHTML = `<div class="review-title">${state.lang==='he'?item.he:item.en}</div><div class="review-answer">${state.lang==='he'?item.detailHe:item.detailEn}</div>`;
      review.appendChild(row);
    });
    el.quizBody.replaceChildren(review);
    return;
  }

  if (state.ageStage === 'order') {
    const wrap = document.createElement('div');
    wrap.className='chooser';
    const left = document.createElement('div');
    left.className='picker';
    left.innerHTML = `<h3 style="margin-top:0">${t('chronologyPool')}</h3>`;
    const pickList = document.createElement('div');
    pickList.className='pick-list';
    state.order.forEach(idx => {
      const item = DATA.agesHumanity[idx];
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`pick-item${state.selectedPlacement===item.order?' selected':''}${state.placements.includes(item.order)?' used':''}`;
      btn.dataset.agefigure=String(item.order);
      btn.innerHTML = `<div class="era-title">${state.lang==='he'?item.he:item.en}</div><div class="era-desc">${state.lang==='he'?item.descHe:item.descEn}</div>`;
      pickList.appendChild(btn);
    });
    left.appendChild(pickList);

    const right = document.createElement('div');
    right.className='slots-panel';
    const slotList = document.createElement('div');
    slotList.className='slot-list';
    DATA.agesHumanity.forEach((_, idx) => {
      const value = state.placements[idx];
      const actualItem = value ? DATA.agesHumanity.find(x=>x.order===value) : null;
      const btn = document.createElement('button');
      btn.type='button';
      btn.className=`slot-btn${value?' filled':''}`;
      btn.dataset.ageslot=String(idx);
      btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main">${actualItem ? `${state.lang==='he'?actualItem.he:actualItem.en}<span class="secondary">${state.lang==='he'?actualItem.descHe:actualItem.descEn}</span>` : ''}</span>`;
      slotList.appendChild(btn);
    });
    right.appendChild(slotList);
    wrap.append(left,right);
    el.quizBody.replaceChildren(wrap);
    return;
  }

  const grid = document.createElement('div');
  grid.className='detail-grid';
  const left = document.createElement('div');
  left.className='picker';
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  DATA.agesHumanity.forEach(item => {
    const used = Object.values(state.ageMatches || {}).includes(item.order);
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.order?' selected':''}${used?' used':''}`;
    btn.dataset.agefigure=String(item.order);
    btn.innerHTML = `<div class="era-title">${state.lang==='he'?item.he:item.en}</div>`;
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);

  const right = document.createElement('div');
  right.className='detail-boxes';
  state.ageDetailOrder.forEach((itemIdx, boxIdx) => {
    const detailItem = DATA.agesHumanity[itemIdx];
    const matchedOrder = state.ageMatches?.[boxIdx];
    const matched = matchedOrder ? DATA.agesHumanity.find(x=>x.order===matchedOrder) : null;
    const box = document.createElement('button');
    box.type='button';
    box.className=`detail-box${matched?' filled':''}`;
    box.dataset.ageslot=String(boxIdx);
    box.innerHTML = `<div class="review-title">${state.lang==='he'?detailItem.detailHe:detailItem.detailEn}</div><div class="answer-main">${matched ? (state.lang==='he'?matched.he:matched.en) : ''}</div>`;
    right.appendChild(box);
  });
  grid.append(left,right);
  el.quizBody.replaceChildren(grid);
}

function renderHumanBody(){
  const labels = {
    heart:['לב','Heart'],
    lungs:['ריאות','Lungs'],
    kidneys:['כליות','Kidneys'],
    stomach:['קיבה','Stomach'],
    brain:['מוח','Brain'],
    nervous:['מערכת העצבים','Nervous system'],
    digestive:['מערכת העיכול','Digestive system'],
    respiratory:['מערכת הנשימה','Respiratory system'],
    skeletal:['מערכת השלד','Skeletal system'],
    circulatory:['מערכת הדם','Circulatory system']
  };

  const wrap = document.createElement('div');

  if (state.revealed) {
    const review = document.createElement('div');
    review.className='review-list';
    DATA.humanBodySet.organFunction.forEach(item => {
      const row=document.createElement('div'); row.className='review-row';
      row.innerHTML=`<div class="review-title">${state.lang==='he'?item.promptHe:item.promptEn}</div><div class="review-answer">${state.lang==='he'?labels[item.correct][0]:labels[item.correct][1]}</div>`;
      review.appendChild(row);
    });
    DATA.humanBodySet.systemMatch.forEach(item => {
      const row=document.createElement('div'); row.className='review-row';
      row.innerHTML=`<div class="review-title">${state.lang==='he'?item.promptHe:item.promptEn}</div><div class="review-answer">${state.lang==='he'?labels[item.correct][0]:labels[item.correct][1]}</div>`;
      review.appendChild(row);
    });
    DATA.humanBodySet.labels.forEach(item => {
      const row=document.createElement('div'); row.className='review-row';
      row.innerHTML=`<div class="review-title">${state.lang==='he'?item.he:item.en}</div><div class="review-answer">${item.zone}</div>`;
      review.appendChild(row);
    });
    el.quizBody.replaceChildren(review);
    return;
  }

  const tabs = document.createElement('div');
  tabs.className='mini-tabs';
  tabs.innerHTML = `
    <button type="button" class="mini-tab ${state.bodyStage==='organ'?'active':''}" data-bodystage="organ">${t('bodyOrganStage')}</button>
    <button type="button" class="mini-tab ${state.bodyStage==='system'?'active':''}" data-bodystage="system">${t('bodySystemStage')}</button>
    <button type="button" class="mini-tab ${state.bodyStage==='label'?'active':''}" data-bodystage="label">${t('bodyLabelStage')}</button>`;
  wrap.appendChild(tabs);

  if (state.bodyStage === 'organ') {
    const idx = Object.keys(state.bodyAnswers).length;
    const item = DATA.humanBodySet.organFunction[idx] || null;
    const card = document.createElement('div');
    card.className='classify-card';
    if (!item) {
      card.innerHTML = `<p class="center">${state.lang==='he'?'השלמת את שלב האיברים.' :'You completed the organ stage.'}</p>`;
    } else {
      card.innerHTML = `<div class="center" style="font-size:1.5rem;font-weight:900;color:var(--gold);margin-bottom:14px">${state.lang==='he'?item.promptHe:item.promptEn}</div><div class="answers-grid"></div>`;
      const grid=card.querySelector('.answers-grid');
      item.choices.forEach(choice=>{
        const b=document.createElement('button');
        b.type='button'; b.className='answer-btn'; b.dataset.bodychoice = choice;
        b.textContent = state.lang==='he' ? labels[choice][0] : labels[choice][1];
        grid.appendChild(b);
      });
    }
    wrap.appendChild(card);
  } else if (state.bodyStage === 'system') {
    const idx = Object.keys(state.bodySystemAnswers).length;
    const item = DATA.humanBodySet.systemMatch[idx] || null;
    const card = document.createElement('div');
    card.className='classify-card';
    if (!item) {
      card.innerHTML = `<p class="center">${state.lang==='he'?'השלמת את שלב המערכות.' :'You completed the systems stage.'}</p>`;
    } else {
      card.innerHTML = `<div class="center" style="font-size:2rem;font-weight:900;color:var(--gold);margin-bottom:14px">${state.lang==='he'?item.promptHe:item.promptEn}</div><div class="answers-grid"></div>`;
      const grid=card.querySelector('.answers-grid');
      item.choices.forEach(choice=>{
        const b=document.createElement('button');
        b.type='button'; b.className='answer-btn'; b.dataset.bodysystem = choice;
        b.textContent = state.lang==='he' ? labels[choice][0] : labels[choice][1];
        grid.appendChild(b);
      });
    }
    wrap.appendChild(card);
  } else {
    const area = document.createElement('div');
    area.className='detail-grid';
    const left = document.createElement('div');
    left.className='picker';
    const list=document.createElement('div'); list.className='pick-list';
    DATA.humanBodySet.labels.forEach((item, idx)=>{
      const used=Object.values(state.bodyLabelMap||{}).includes(item.id);
      const btn=document.createElement('button');
      btn.type='button'; btn.className=`pick-item${state.selectedPlacement===idx?' selected':''}${used?' used':''}`;
      btn.dataset.bodylabel = String(idx);
      btn.innerHTML = state.lang==='he'?item.he:item.en;
      list.appendChild(btn);
    });
    left.appendChild(list);

    const labelFor = (zone, fallback) => {
      const id = state.bodyLabelMap[zone];
      const item = id ? DATA.humanBodySet.labels.find(x=>x.id===id) : null;
      return item ? (state.lang==='he' ? item.he : item.en) : fallback;
    };

    const right = document.createElement('div');
    right.className='body-diagram';
    right.innerHTML = `<div class="body-silhouette">
      <div class="body-head"></div>
      <button type="button" class="body-zone ${state.bodyLabelMap.brain?'filled':''}" data-bodyzone="brain" style="top:-52px;left:50%;transform:translateX(-50%);width:110px;height:42px">${labelFor('brain', state.lang==='he'?'ראש / מוח':'Head / Brain')}</button>
      <button type="button" class="body-zone ${state.bodyLabelMap.lungs?'filled':''}" data-bodyzone="lungs" style="top:72px;left:50%;transform:translateX(-50%);width:140px;height:52px">${labelFor('lungs', state.lang==='he'?'חזה / ריאות':'Chest / Lungs')}</button>
      <button type="button" class="body-zone ${state.bodyLabelMap.heart?'filled':''}" data-bodyzone="heart" style="top:136px;left:50%;transform:translateX(-50%);width:110px;height:46px">${labelFor('heart', state.lang==='he'?'לב':'Heart')}</button>
      <button type="button" class="body-zone ${state.bodyLabelMap.stomach?'filled':''}" data-bodyzone="stomach" style="top:210px;left:50%;transform:translateX(-50%);width:130px;height:48px">${labelFor('stomach', state.lang==='he'?'בטן / קיבה':'Abdomen / Stomach')}</button>
      <button type="button" class="body-zone ${state.bodyLabelMap.kidneys?'filled':''}" data-bodyzone="kidneys" style="top:276px;left:50%;transform:translateX(-50%);width:140px;height:48px">${labelFor('kidneys', state.lang==='he'?'כליות':'Kidneys')}</button>
    </div>`;
    area.append(left,right);
    wrap.appendChild(area);
  }

  el.quizBody.replaceChildren(wrap);
}


function renderHalacha(){
  const wrap = document.createElement('div');
  if (state.revealed) {
    const review = document.createElement('div');
    review.className = 'review-list';
    DATA.halacha.stages.forEach(stage => {
      const header = document.createElement('div');
      header.className = 'book-divider';
      header.style.background = '#6b8e23';
      header.textContent = state.lang === 'he' ? stage.he : stage.en;
      review.appendChild(header);
      stage.items.forEach(item => {
        const row = document.createElement('div');
        row.className = 'review-row';
        row.innerHTML = `<div class="review-title">${state.lang==='he' ? item.he : item.en}</div><div class="review-answer">${item.correct ? t('correct') : t('wrong')}</div>`;
        review.appendChild(row);
      });
    });
    el.quizBody.replaceChildren(review);
    return;
  }

  const tabs = document.createElement('div');
  tabs.className = 'mini-tabs';
  DATA.halacha.stages.forEach(stage => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `mini-tab ${state.halachaStage===stage.id ? 'active' : ''}`;
    btn.dataset.halachastage = stage.id;
    btn.textContent = t(stage.key);
    tabs.appendChild(btn);
  });
  wrap.appendChild(tabs);

  const stage = getHalachaStageDef(state.halachaStage);
  const idx = getHalachaCurrentIndex(stage.id);
  const item = stage.items[idx] || null;
  const card = document.createElement('div');
  card.className = 'classify-card';
  if (!item) {
    card.innerHTML = `<p class="center">${state.lang==='he' ? `השלמת את קטגוריית ${stage.he}.` : `You completed the ${stage.en} category.`}</p>`;
  } else {
    card.innerHTML = `
      <div class="center" style="font-size:1.6rem;font-weight:900;color:var(--gold);margin-bottom:16px">${state.lang==='he' ? item.he : item.en}</div>
      <div class="answers-grid">
        <button type="button" class="answer-btn" data-halachachoice="true">${t('correct')}</button>
        <button type="button" class="answer-btn" data-halachachoice="false">${t('wrong')}</button>
      </div>`;
  }
  wrap.appendChild(card);
  el.quizBody.replaceChildren(wrap);
}

function renderTenCommandments(){
  const wrap = document.createElement('div');
  wrap.className='chooser';
  const left = document.createElement('div');
  left.className='picker';
  left.innerHTML = `<h3 style="margin-top:0">${t('commandmentsPool')}</h3>`;
  const pickList = document.createElement('div');
  pickList.className='pick-list';
  state.order.forEach(idx => {
    const item = DATA.tenCommandments[idx];
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`pick-item${state.selectedPlacement===item.order?' selected':''}${state.placements.includes(item.order)?' used':''}`;
    btn.dataset.commandment=String(item.order);
    btn.innerHTML = `<span style="font-size:1.06rem; line-height:1.6">${formatDisplay(item)}</span>`;
    pickList.appendChild(btn);
  });
  left.appendChild(pickList);
  if (state.selectedPlacement != null) {
    const selectedItem = DATA.tenCommandments.find(x=>x.order===state.selectedPlacement);
    if (selectedItem && !state.placements.includes(selectedItem.order)) {
      left.insertAdjacentHTML('beforeend', renderTenCommandmentFactHtml(selectedItem));
    }
  }
  const right = document.createElement('div');
  right.className='slots-panel';
  const slotList = document.createElement('div');
  slotList.className='slot-list';
  DATA.tenCommandments.forEach((_, idx) => {
    const value = state.placements[idx];
    const actualItem = value ? DATA.tenCommandments.find(x=>x.order===value) : null;
    const btn = document.createElement('button');
    btn.type='button';
    btn.className=`slot-btn${value?' filled':''}${state.selectedPlacement!=null && value===state.selectedPlacement?' picked-up':''}`;
    btn.dataset.commandmentslot=String(idx);
    btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main ${state.revealed && value !== idx+1?'answer-revealed':''}">${actualItem ? formatDisplay(actualItem) : ''}</span>`;
    if (state.revealed && !value) btn.innerHTML = `<span class="slot-index">${idx+1}</span><span class="answer-main answer-revealed">${formatDisplay(DATA.tenCommandments[idx])}</span>`;
    slotList.appendChild(btn);
  });
  right.appendChild(slotList);
  wrap.append(left,right);
  el.quizBody.replaceChildren(wrap);
}
function renderHolidaysMonths(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'review-list';
    DATA.holidaysMonths.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-row';
      row.innerHTML = `<div class="review-title">${formatDisplay(item.holiday)}</div><div class="review-answer">${formatDisplay(item.month)}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const item = DATA.holidaysMonths[state.order[state.pointer]];
  const card = document.createElement('div');
  card.className='classify-card';
  if (!item) { 
    renderCompletedPlaceholder(card); 
  } else {
    const months = ['תשרי','חשוון','כסלו','טבת','שבט','אדר','ניסן','אייר','סיון','תמוז','אב','אלול'];
    const monthsEn = ['Tishrei','Cheshvan','Kislev','Tevet','Shevat','Adar','Nisan','Iyar','Sivan','Tammuz','Av','Elul'];
    const options = months.map((m,i)=>({he:m,en:monthsEn[i]})).sort(()=>Math.random()-.5).slice(0,3);
    if (!options.some(x=>x.he===item.month.he)) options[0] = item.month;
    card.innerHTML = `<div class="center" style="font-size:2rem;font-weight:900;color:var(--gold)">${formatDisplay(item.holiday)}</div><div class="answers-grid"></div>`;
    const grid = card.querySelector('.answers-grid');
    options.sort(()=>Math.random()-.5).forEach(opt=>{
      const b = document.createElement('button');
      b.type='button'; b.className='answer-btn'; b.dataset.month=opt.he;
      b.innerHTML = state.lang==='he' ? `${opt.he} <span class="secondary">(${opt.en})</span>` : `${opt.en} <span class="secondary">(${opt.he})</span>`;
      grid.appendChild(b);
    });
  }
  el.quizBody.replaceChildren(card);
}
function renderContinentQuiz(){
  const wrap = document.createElement('div');
  wrap.className='continent-wrap';
  const left = document.createElement('div');
  left.className='continent-pool';
  left.innerHTML = `<h3 style="margin-top:0">${t('chronologyPool')}</h3>`;
  const pool = document.createElement('div');
  pool.className='continent-choice';
  state.order.forEach(idx=>{
    const item = DATA.continentQuiz.countries[idx];
    const used = !!state.continentMap[item.en];
    const btn = document.createElement('button');
    btn.type='button'; btn.className=`continent-country${used?' used':''}${state.selectedPlacement===idx?' selected':''}`;
    btn.dataset.continentcountry=String(idx);
    btn.innerHTML = `${renderFlagBox(item.flag)}<span style="color:var(--gold);font-weight:700">${state.lang==='he'?item.he:item.en}</span>${state.lang==='he' ? ` <span class="secondary">(${item.en})</span>` : ` <span class="secondary">(${item.he})</span>`}`;
    pool.appendChild(btn);
  });
  left.appendChild(pool);
  const right = document.createElement('div');
  right.className='continent-boxes';
  right.innerHTML = `<h3 style="margin-top:0">${t('continentBoxes')}</h3>`;
  const grid = document.createElement('div');
  grid.className='month-grid';
  DATA.continentQuiz.continents.forEach(cont=>{
    const box = document.createElement('button');
    box.type='button'; box.className='continent-box'; box.dataset.continentbox=cont.id;
    const placed = DATA.continentQuiz.countries.filter(c=>state.continentMap[c.en]===cont.id);
    box.innerHTML = `<div class="book-divider" style="margin:0;background:${cont.color}">${state.lang==='he'?cont.he:cont.en}</div><div class="continent-placed">${placed.map(item=>`<span style="display:inline-flex;align-items:center;gap:6px;color:var(--gold);font-weight:700">${renderFlagBox(item.flag)}<span>${state.lang==='he'?item.he:item.en}</span></span>`).join('')}</div>`;
    grid.appendChild(box);
  });
  right.appendChild(grid);
  wrap.append(left,right);
  el.quizBody.replaceChildren(wrap);
}
function renderRomanMath(){ renderGridInputQuiz(DATA.romanMath); }


function renderWorldCountries(){
  const body = document.createElement('div');
  body.className='columns-5';
  const names = {
    europe: state.lang==='he' ? 'אירופה' : 'Europe',
    asia: state.lang==='he' ? 'אסיה' : 'Asia',
    africa: state.lang==='he' ? 'אפריקה' : 'Africa',
    northAmerica: state.lang==='he' ? 'אמריקה הצפונית' : 'North America',
    southAmerica: state.lang==='he' ? 'אמריקה הדרומית' : 'South America',
    oceania: state.lang==='he' ? 'אוקיאניה' : 'Oceania'
  };
  const colors = {europe:'#3498db', asia:'#c0392b', africa:'#8e44ad', northAmerica:'#f39c12', southAmerica:'#27ae60', oceania:'#16a085'};
  for (const [cont,list] of Object.entries(DATA.worldCountries)) {
    const col = document.createElement('div');
    col.className='column';
    col.innerHTML = `<div class="column-header" style="background:${colors[cont]||'#3498db'}">${names[cont]}</div>`;
    list.forEach(item=>{
      const slot = document.createElement('div');
      slot.className='slot';
      const id = `${cont}:${item.en}`;
      if (state.guessed.has(id) || state.revealed) slot.innerHTML = `<span class="answer-main ${!state.guessed.has(id)&&state.revealed?'answer-revealed':''}">${formatDisplay(item)}</span>`;
      col.appendChild(slot);
    });
    body.appendChild(col);
  }
  el.quizBody.replaceChildren(body);
}
function renderWorldCapitals(){
  const table = document.createElement('table');
  table.className='table';
  table.innerHTML = `<thead><tr><th>${state.lang==='he'?'מדינה':'Country'}</th><th>${state.lang==='he'?'בירה':'Capital'}</th></tr></thead>`;
  const tbody = document.createElement('tbody');
  DATA.worldCapitals.forEach((item,i)=>{
    const tr=document.createElement('tr');
    tr.innerHTML = `<td>${formatDisplay(item.country)}</td><td><span class="answer-main ${!state.guessed.has(i)&&state.revealed?'answer-revealed':''}">${state.guessed.has(i)||state.revealed ? formatDisplay(item.capital):''}</span></td>`;
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  el.quizBody.replaceChildren(table);
}
function renderOfficialLanguages(){
  const body = document.createElement('div');
  body.className='row-input-list';
  DATA.officialLanguages.forEach((item,i)=>{
    const row=document.createElement('div');
    row.className='country-card';
    row.innerHTML = `<div class="country-label">${state.lang==='he'?item.langs.he:item.langs.en}</div><div class="answer-main ${!state.guessed.has(i)&&state.revealed?'answer-revealed':''}">${state.guessed.has(i)||state.revealed ? formatCountryWithCapital(item):''}</div>`;
    body.appendChild(row);
  });
  el.quizBody.replaceChildren(body);
}

function flagSvg(flag){
  const f = String(flag || '');
  const map = {
    '🇮🇱': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><rect y="6" width="72" height="5" fill="#1e4fa1"/><rect y="37" width="72" height="5" fill="#1e4fa1"/><polygon points="36,16 30,27 42,27" fill="none" stroke="#1e4fa1" stroke-width="2"/><polygon points="36,32 30,21 42,21" fill="none" stroke="#1e4fa1" stroke-width="2"/></svg>`,
    '🇬🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#0d5eaf"/><g fill="#fff"><rect y="5" width="72" height="5"/><rect y="15" width="72" height="5"/><rect y="25" width="72" height="5"/><rect y="35" width="72" height="5"/><rect width="28" height="24"/><rect x="11" width="6" height="24" fill="#0d5eaf"/><rect y="9" width="28" height="6" fill="#0d5eaf"/></g></svg>`,
    '🇫🇮': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><rect x="18" width="10" height="48" fill="#0d5eaf"/><rect y="19" width="72" height="10" fill="#0d5eaf"/></svg>`,
    '🇦🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#74acdf"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#74acdf"/><circle cx="36" cy="24" r="5" fill="#f6b40e"/></svg>`,
    '🇯🇵': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><circle cx="36" cy="24" r="12" fill="#bc002d"/></svg>`,
    '🇰🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><path d="M36 15a9 9 0 1 1-9 9 9 9 0 0 0 9-9z" fill="#cd2e3a"/><path d="M36 33a9 9 0 1 1 9-9 9 9 0 0 0-9 9z" fill="#0047a0"/></svg>`,
    '🇧🇩': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#006a4e"/><circle cx="31" cy="24" r="12" fill="#f42a41"/></svg>`,
    '🇨🇭': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#d52b1e"/><rect x="30" y="10" width="12" height="28" fill="#fff"/><rect x="22" y="18" width="28" height="12" fill="#fff"/></svg>`,
    '🇲🇽': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#006847"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#ce1126"/><circle cx="36" cy="24" r="4" fill="#a67c52"/></svg>`,
    '🇧🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#009b3a"/><polygon points="36,8 58,24 36,40 14,24" fill="#ffdf00"/><circle cx="36" cy="24" r="9" fill="#002776"/></svg>`,
    '🇵🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="28" height="48" fill="#006600"/><rect x="28" width="44" height="48" fill="#ff0000"/><circle cx="28" cy="24" r="6" fill="#ffcc00"/></svg>`,
    '🇦🇺': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#012169"/><circle cx="54" cy="30" r="4" fill="#fff"/><circle cx="46" cy="18" r="2.5" fill="#fff"/><circle cx="24" cy="12" r="6" fill="#fff"/></svg>`,
    '🇧🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#000"/><rect x="24" width="24" height="48" fill="#ffd90c"/><rect x="48" width="24" height="48" fill="#ef3340"/></svg>`,
    '🇩🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#000"/><rect y="16" width="72" height="16" fill="#dd0000"/><rect y="32" width="72" height="16" fill="#ffce00"/></svg>`,
    '🇪🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#4891d9"/><rect y="16" width="72" height="16" fill="#000"/><rect y="32" width="72" height="16" fill="#fff"/></svg>`,
    '🇱🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#fdb913"/><rect y="16" width="72" height="16" fill="#006a44"/><rect y="32" width="72" height="16" fill="#c1272d"/></svg>`,
    '🇫🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#0055a4"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#ef4135"/></svg>`,
    '🇮🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#009246"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#ce2b37"/></svg>`,
    '🇷🇴': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#002b7f"/><rect x="24" width="24" height="48" fill="#fcd116"/><rect x="48" width="24" height="48" fill="#ce1126"/></svg>`,
    '🇳🇱': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#ae1c28"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#21468b"/></svg>`,
    '🇨🇦': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="14" height="48" fill="#d80621"/><rect x="58" width="14" height="48" fill="#d80621"/><rect x="14" width="44" height="48" fill="#fff"/><polygon points="36,10 39,18 47,16 42,23 48,28 40,29 41,38 36,33 31,38 32,29 24,28 30,23 25,16 33,18" fill="#d80621"/></svg>`,
    '🇦🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#ed2939"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#ed2939"/></svg>`,
    '🇵🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#d91023"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#d91023"/></svg>`,
    '🇩🇰': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#c60c30"/><rect x="22" width="6" height="48" fill="#fff"/><rect y="21" width="72" height="6" fill="#fff"/></svg>`,
    '🇬🇧': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#012169"/><path d="M0 0L72 48M72 0L0 48" stroke="#fff" stroke-width="8"/><path d="M0 0L72 48M72 0L0 48" stroke="#c8102e" stroke-width="4"/><path d="M36 0v48M0 24h72" stroke="#fff" stroke-width="12"/><path d="M36 0v48M0 24h72" stroke="#c8102e" stroke-width="6"/></svg>`,
    '🇳🇿': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#012169"/><circle cx="52" cy="16" r="3" fill="#ff0000" stroke="#fff" stroke-width="1"/><circle cx="58" cy="26" r="3" fill="#ff0000" stroke="#fff" stroke-width="1"/><circle cx="48" cy="32" r="3" fill="#ff0000" stroke="#fff" stroke-width="1"/></svg>`,
    '🇺🇸': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><g fill="#b22234"><rect width="72" height="4"/><rect y="8" width="72" height="4"/><rect y="16" width="72" height="4"/><rect y="24" width="72" height="4"/><rect y="32" width="72" height="4"/><rect y="40" width="72" height="4"/></g><rect width="30" height="22" fill="#3c3b6e"/></svg>`,
    '🇺🇦': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="24" fill="#005bbb"/><rect y="24" width="72" height="24" fill="#ffd500"/></svg>`,
    '🇸🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#006aa7"/><rect x="20" width="8" height="48" fill="#fecc00"/><rect y="20" width="72" height="8" fill="#fecc00"/></svg>`,
    '🇵🇱': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="24" fill="#fff"/><rect y="24" width="72" height="24" fill="#dc143c"/></svg>`,
    '🇭🇺': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#ce2939"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#477050"/></svg>`,
    '🇮🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#169b62"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#ff883e"/></svg>`,
    '🇱🇷': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><g fill="#bf0a30"><rect width="72" height="4"/><rect y="8" width="72" height="4"/><rect y="16" width="72" height="4"/><rect y="24" width="72" height="4"/><rect y="32" width="72" height="4"/><rect y="40" width="72" height="4"/></g><rect width="28" height="22" fill="#002868"/></svg>`,
    '🇲🇾': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#fff"/><g fill="#cc0001"><rect width="72" height="4"/><rect y="8" width="72" height="4"/><rect y="16" width="72" height="4"/><rect y="24" width="72" height="4"/><rect y="32" width="72" height="4"/><rect y="40" width="72" height="4"/></g><rect width="32" height="24" fill="#010066"/><circle cx="15" cy="12" r="7" fill="#ffcc00"/></svg>`
  };
  Object.assign(map,{
    '🇷🇺': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#fff"/><rect y="16" width="72" height="16" fill="#0039a6"/><rect y="32" width="72" height="16" fill="#d52b1e"/></svg>`
    ,'🇨🇳': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#de2910"/><polygon points="15,8 17,14 23,14 18,18 20,24 15,20 10,24 12,18 7,14 13,14" fill="#ffde00"/></svg>`
    ,'🇮🇳': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#ff9933"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#138808"/><circle cx="36" cy="24" r="5" fill="none" stroke="#000080" stroke-width="1.5"/></svg>`
    ,'🇰🇿': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#00afca"/><circle cx="36" cy="24" r="7" fill="#f8d548"/></svg>`
    ,'🇩🇿': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="36" height="48" fill="#006233"/><rect x="36" width="36" height="48" fill="#fff"/><circle cx="39" cy="24" r="9" fill="none" stroke="#d21034" stroke-width="3"/><circle cx="42" cy="24" r="7" fill="#fff"/></svg>`
    ,'🇨🇩': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#00a3e0"/><polygon points="0,42 72,6 72,0 0,36" fill="#f7d618"/><polygon points="0,40 72,4 72,8 0,44" fill="#ce1021"/></svg>`
    ,'🇸🇦': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#006c35"/><rect x="18" y="30" width="36" height="3" fill="#fff"/></svg>`
    ,'🇪🇸': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="12" fill="#aa151b"/><rect y="12" width="72" height="24" fill="#f1bf00"/><rect y="36" width="72" height="12" fill="#aa151b"/></svg>`
    ,'🇪🇬': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#ce1126"/><rect y="16" width="72" height="16" fill="#fff"/><rect y="32" width="72" height="16" fill="#000"/></svg>`
    ,'🇰🇪': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#000"/><rect y="16" width="72" height="16" fill="#bb0000"/><rect y="32" width="72" height="16" fill="#006600"/><rect y="15" width="72" height="2" fill="#fff"/><rect y="31" width="72" height="2" fill="#fff"/></svg>`
    ,'🇳🇬': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#008753"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#008753"/></svg>`
    ,'🇲🇦': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#c1272d"/><polygon points="36,13 39,22 48,22 41,27 44,36 36,30 28,36 31,27 24,22 33,22" fill="none" stroke="#006233" stroke-width="2"/></svg>`
    ,'🇬🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="24" height="48" fill="#4997d0"/><rect x="24" width="24" height="48" fill="#fff"/><rect x="48" width="24" height="48" fill="#4997d0"/></svg>`
    ,'🇨🇱': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="24" fill="#fff"/><rect y="24" width="72" height="24" fill="#d52b1e"/><rect width="26" height="24" fill="#0039a6"/><circle cx="13" cy="12" r="4" fill="#fff"/></svg>`
    ,'🇿🇦': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#002395"/><polygon points="0,0 30,24 0,48" fill="#000"/><polygon points="0,6 24,24 0,42" fill="#ffb612"/><polygon points="0,10 20,24 0,38 72,38 72,10" fill="#007a4d"/></svg>`
    ,'🇪🇹': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="16" fill="#078930"/><rect y="16" width="72" height="16" fill="#fcdd09"/><rect y="32" width="72" height="16" fill="#da121a"/></svg>`
    ,'🇮🇩': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="24" fill="#ce1126"/><rect y="24" width="72" height="24" fill="#fff"/></svg>`
    ,'🇨🇴': `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="24" fill="#fcd116"/><rect y="24" width="72" height="12" fill="#003893"/><rect y="36" width="72" height="12" fill="#ce1126"/></svg>`
  });
  return map[f] || `<svg viewBox="0 0 72 48" xmlns="http://www.w3.org/2000/svg"><rect width="72" height="48" fill="#334"/><text x="36" y="29" text-anchor="middle" font-size="12" fill="#fff">${f}</text></svg>`;
}

function renderCountryFlags(){
  if (state.revealed || state.pointer >= DATA.countryFlags.length) {
    const body = document.createElement('div');
    body.className='review-list';
    DATA.countryFlags.forEach(item=>{
      const row = document.createElement('div');
      row.className='review-row';
      row.innerHTML = `<div class="review-title">${formatDisplay(item.country)}</div><div class="flag-box">${flagSvg(item.correct)}</div>${renderCountryFactHtml(item)}`;
      body.appendChild(row);
    });
    el.quizBody.replaceChildren(body);
    return;
  }
  const item = DATA.countryFlags[state.order[state.pointer]];
  const feedback = state.countryFlagFeedback && item && state.countryFlagFeedback.itemKey === item.country.en ? state.countryFlagFeedback : null;
  const card = document.createElement('div'); card.className='flag-card';
  card.innerHTML = `<div class="center" style="font-size:1.8rem;font-weight:800">${formatDisplay(item.country)}</div><p class="center subtle">${t('matchFlag')}</p>`;
  const opts = document.createElement('div'); opts.className='flag-options';
  item.choices.forEach(flag=>{
    const b=document.createElement('button');
    b.type='button';
    b.className=`flag-btn${feedback?.correctChoice===flag?' correct':''}${feedback?.choice===flag && feedback?.choice!==feedback?.correctChoice?' wrong':''}`;
    b.dataset.flag=flag;
    b.disabled = !!feedback;
    b.innerHTML = `<div class="flag-box">${flagSvg(flag)}</div>`;
    opts.appendChild(b);
  });
  card.appendChild(opts);
  el.quizBody.replaceChildren(card);
}
function renderScrambledCountries(){
  if (state.revealed) {
    const wrap = document.createElement('div');
    wrap.className = 'scramble-list';
    DATA.scrambledCountries.forEach(item => {
      const row = document.createElement('div');
      row.className = 'scramble-row';
      const scrambled = (item.scrambled && typeof item.scrambled==='object')
        ? (state.lang==='he'?item.scrambled.he:item.scrambled.en)
        : String(item.scrambled);
      row.innerHTML = `<div class="scramble-word">${scrambled}</div>
      <div class="answer-main">${formatDisplay(item.item || item)}</div>`;
      wrap.appendChild(row);
    });
    el.quizBody.replaceChildren(wrap);
    return;
  }
  const activeIndex = state.scrambledFeedbackIndex != null ? state.scrambledFeedbackIndex : state.scrambledRevealIndex;
  const item = activeIndex != null ? DATA.scrambledCountries[activeIndex] : DATA.scrambledCountries.find((_,i)=>!state.guessed.has(i));
  const card = document.createElement('div'); card.className='scramble-card';
  if (!item) { renderCompletedPlaceholder(card); el.quizBody.replaceChildren(card); return; }
  const scrambled = (item.scrambled && typeof item.scrambled==='object')
    ? (state.lang==='he'?item.scrambled.he:item.scrambled.en)
    : String(item.scrambled);
  card.innerHTML = `<div class="scramble-word">${scrambled}</div>`;
  if (state.scrambledFeedbackIndex != null || state.scrambledRevealIndex != null) {
    card.innerHTML += `<div class="answer-main center" style="margin-top:14px">${formatDisplay(item.item || item)}</div>`;
    if (state.scrambledFeedbackIndex != null) card.innerHTML += renderScrambledCountryFactHtml(item);
  } else {
    card.innerHTML += `<p class="center subtle">${t('scrambledCountryHint')}</p>`;
  }
  el.quizBody.replaceChildren(card);
}
function renderMultiplication(){
  const wrap=document.createElement('div'); wrap.className='matrix';
  const table=document.createElement('table');
  const thead=document.createElement('thead');
  const hr=document.createElement('tr'); hr.innerHTML='<th>×</th>' + Array.from({length:12},(_,i)=>`<th>${i+1}</th>`).join('');
  thead.appendChild(hr); table.appendChild(thead);
  const tbody=document.createElement('tbody');
  for(let r=1;r<=12;r++){
    const tr=document.createElement('tr');
    tr.innerHTML=`<th>${r}</th>`;
    for(let c=1;c<=12;c++){
      const key=`${r}-${c}`;
      const td=document.createElement('td'); td.dataset.cell=key;
      if (state.selectedCell.r===r && state.selectedCell.c===c) td.classList.add('active');
      if (state.guessed.has(key)) { td.classList.add('filled'); td.textContent=r*c; }
      else if (state.revealed) { td.classList.add('reveal'); td.textContent=r*c; }
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
  table.appendChild(tbody); wrap.appendChild(table); el.quizBody.replaceChildren(wrap);
}
function renderGridInputQuiz(items, inputType='number'){
  const body=document.createElement('div');
  body.className='row-input-list';
  items.forEach((item,i)=>{
    const row=document.createElement('div');
    row.className='row-input-item';
    const problem=document.createElement('div');
    problem.className='row-problem';
    problem.textContent = item.prompt || item.roman;
    const inp=document.createElement('input');
    inp.className='inline-input';
    inp.dataset.row=String(i);
    inp.dataset.grid='1';
    inp.type=inputType;
    inp.placeholder = state.lang === 'he' ? 'תשובה...' : 'Answer...';
    if (state.rowLocked[i]) {
      inp.value=String(state.rowAnswers[i]);
      inp.disabled=true;
      inp.classList.add('ok');
    } else if (state.revealed) {
      inp.value=String(item.answer);
      inp.disabled=true;
      inp.classList.add('ok');
    }
    row.append(problem,inp);
    body.appendChild(row);
  });
  el.quizBody.replaceChildren(body);
}
function renderFastMultiplication(){ renderGridInputQuiz(DATA.fastMultiplication); }
function renderEquationCompletion(){ renderGridInputQuiz(DATA.equationCompletion); }
function renderFastAddition(){ renderGridInputQuiz(DATA.fastAddition); }
function renderRomanNumerals(){ renderGridInputQuiz(DATA.romanNumerals); }
function renderRomanMath(){ renderGridInputQuiz(DATA.romanMath); }
function handleGridRowInput(index, value){
  if (state.paused || state.revealed) return;
  const i=Number(index);
  let item, expected;
  if (state.activeQuiz==='fastMultiplication'){ item=DATA.fastMultiplication[i]; expected=item.answer; }
  if (state.activeQuiz==='equationCompletion'){ item=DATA.equationCompletion[i]; expected=item.answer; }
  if (state.activeQuiz==='fastAddition'){ item=DATA.fastAddition[i]; expected=item.answer; }
  if (state.activeQuiz==='romanNumerals'){ item=DATA.romanNumerals[i]; expected=item.answer; }
  if (state.activeQuiz==='romanMath'){ item=DATA.romanMath[i]; expected=item.answer; }
  if (String(value).trim()!=='' && Number(value)===expected && !state.rowLocked[i]) {
    state.rowLocked[i]=true; state.rowAnswers[i]=expected; state.score = Object.keys(state.rowLocked).length;
    renderQuiz(); maybeComplete();
  }
}

const CLICK_ROUTES = [
  { selector:'[data-lang]', action:(node) => setLang(node.dataset.lang) },
  { selector:'[data-mode]', action:(node) => setMode(node.dataset.mode) },
  { selector:'[data-quiz]', action:(node) => startQuiz(node.dataset.quiz) },
  { selector:'#back-btn', action:() => goHome() },
  { selector:'#reveal-btn', action:() => revealAnswers() },
  { selector:'#reveal-one-btn', action:() => revealOneAnswer() },
  { selector:'#teach-btn', action:() => showTeachOverlay() },
  { selector:'[data-teach-close]', action:() => hideTeachOverlay() },
  { selector:'[data-fact-close]', action:() => hideContinentFact() },
  { selector:'[data-flag-fact-close]', action:() => finalizeCountryFlagFact() },
  { selector:'#reset-btn', action:() => resetQuiz(false) },
  { selector:'#pause-btn', action:() => togglePause() },
  { selector:'#mic-btn', action:() => toggleSpeech() },
  { selector:'[data-choice]', action:(node) => handleChoice(node.dataset.choice) },
  { selector:'[data-bodychoice]', action:(node) => handleBodyChoice(node.dataset.bodychoice) },
  { selector:'[data-bodysystem]', action:(node) => handleBodyChoice(node.dataset.bodysystem) },
  { selector:'[data-month]', action:(node) => handleChoice(node.dataset.month) },
  { selector:'[data-rel]', action:(node) => handleChoice(node.dataset.rel) },
  { selector:'[data-flag]', action:(node) => handleChoice(node.dataset.flag) },
  { selector:'[data-figure]', action:(node) => handlePlacementFigure(node.dataset.figure) },
  { selector:'[data-countryrank]', action:(node) => handleLargestCountryFigure(node.dataset.countryrank) },
  { selector:'[data-rankflagcountry]', action:(node) => handleLargestCountryFlagCountry(node.dataset.rankflagcountry) },
  { selector:'[data-commandment]', action:(node) => handleCommandmentFigure(node.dataset.commandment) },
  { selector:'[data-agefigure]', action:(node) => handleAgeFigure(node.dataset.agefigure) },
  { selector:'[data-solarplanet]', action:(node) => handleSolarPlanet(node.dataset.solarplanet) },
  { selector:'[data-solarorder]', action:(node) => handleSolarOrder(node.dataset.solarorder) },
  { selector:'[data-slot]', action:(node) => handlePlacementSlot(node.dataset.slot) },
  { selector:'[data-rankslot]', action:(node) => handleLargestCountrySlot(node.dataset.rankslot) },
  { selector:'[data-rankflagslot]', action:(node) => handleLargestCountryFlagSlot(node.dataset.rankflagslot) },
  { selector:'[data-commandmentslot]', action:(node) => handleCommandmentSlot(node.dataset.commandmentslot) },
  { selector:'[data-ageslot]', action:(node) => handleAgeSlot(node.dataset.ageslot) },
  { selector:'[data-solartarget]', action:(node) => handleSolarTarget(node.dataset.solartarget) },
  { selector:'[data-solarorderslot]', action:(node) => handleSolarOrderSlot(node.dataset.solarorderslot) },
  { selector:'[data-bodystage]', action:(node) => handleBodyStage(node.dataset.bodystage) },
  { selector:'[data-halachastage]', action:(node) => { state.halachaStage = node.dataset.halachastage; renderQuiz(); } },
  { selector:'[data-halachachoice]', action:(node) => handleChoice(node.dataset.halachachoice) },
  { selector:'[data-bodylabel]', action:(node) => handleBodyLabel(node.dataset.bodylabel) },
  { selector:'[data-bodyzone]', action:(node) => handleBodyZone(node.dataset.bodyzone) },
  { selector:'[data-continentcountry]', action:(node) => handleContinentCountry(node.dataset.continentcountry) },
  { selector:'[data-continentbox]', action:(node) => handleContinentBox(node.dataset.continentbox) },
  { selector:'[data-euprofilecountry]', action:(node) => handleEuropeProfileCountry(node.dataset.euprofilecountry) },
  { selector:'[data-euprofileslot]', action:(node) => handleEuropeProfileSlot(node.dataset.euprofileslot) },
  { selector:'[data-eurankcountry]', action:(node) => handleEuropeRankingCountry(node.dataset.eurankcountry) },
  { selector:'[data-eurankslot]', action:(node) => handleEuropeRankingSlot(node.dataset.eurankslot) },
  { selector:'[data-eurankmode]', action:(node) => setEuropeRankingMode(node.dataset.eurankmode) },
  { selector:'[data-euexportcountry]', action:(node) => handleEuropeExportCountry(node.dataset.euexportcountry) },
  { selector:'[data-euexportslot]', action:(node) => handleEuropeExportSlot(node.dataset.euexportslot) },
  { selector:'[data-gemcalc-toggle]', action:() => { state.gematriaCalc = !state.gematriaCalc; renderQuiz(); } },
  { selector:'[data-cell]', action:(node) => { const [r,c] = node.dataset.cell.split('-').map(Number); state.selectedCell = {r,c}; renderQuiz(); focusMainAnswerInput(0); } }
];

function globalClickHandler(e){
  for (const route of CLICK_ROUTES) {
    const node = e.target.closest(route.selector);
    if (node) return route.action(node);
  }
}

function globalKeyHandler(e){
  if (state.paused) return;
  if (e.key === 'Enter' && document.activeElement === el.answerInput) {
    handleTextSubmit();
  }
}

document.addEventListener('click', globalClickHandler);
document.addEventListener('keydown', globalKeyHandler);
el.answerInput.addEventListener('input', () => {
  if (!state.activeQuiz || state.revealed || state.paused) return;
  if (state.activeQuiz === 'gematria' && state.gematriaCalc) {
    renderGematria();
    return;
  }
  const type = QUIZZES[state.activeQuiz]?.type;
  if (SHARED_TEXT_INPUT_TYPES.has(type)) handleTextSubmit();
});
document.addEventListener('input', (e) => {
  const row = e.target.closest('[data-grid]');
  if (!row || !state.activeQuiz) return;
  handleGridRowInput(e.target.dataset.row, e.target.value);
});

window.startQuiz = startQuiz;

setLang(state.lang);
updateToggleButtons();
renderHome();

document.addEventListener('click', (e) => {
  const selector = '.quiz-card,.pick-item,.slot-btn,.answer-btn,.mcopt,.ropt,.solar-chip,.solar-target,.detail-box,.body-zone,.mini-tab,[data-figure],[data-slot],[data-commandmentfigure],[data-commandmentslot],[data-month],[data-holiday],[data-bodylabel],[data-bodyzone],[data-bodystage],[data-continentcountry],[data-continentslot],[data-solartarget],[data-solarplanet],[data-solarorder],[data-solarorderslot],[data-agefigure],[data-ageslot],[data-euprofilecountry],[data-euprofileslot],[data-eurankcountry],[data-eurankslot],[data-eurankmode]';
  const el = e.target.closest(selector);
  if (!el) return;

  const groups = [
    '.pick-item', '.slot-btn', '.solar-chip', '.solar-target', '.detail-box', '.body-zone',
    '[data-figure]','[data-slot]','[data-commandmentfigure]','[data-commandmentslot]',
    '[data-month]','[data-holiday]','[data-bodylabel]','[data-bodyzone]','[data-bodystage]',
    '[data-continentcountry]','[data-continentslot]','[data-solartarget]','[data-solarplanet]',
    '[data-solarorder]','[data-solarorderslot]','[data-agefigure]','[data-ageslot]','[data-euprofilecountry]','[data-euprofileslot]','[data-eurankcountry]','[data-eurankslot]','[data-eurankmode]'
  ];

  for (const group of groups) {
    if (el.matches(group)) {
      const parent = el.parentElement || document;
      parent.querySelectorAll(group + '.selected').forEach(node => {
        if (node !== el) node.classList.remove('selected');
      });
      el.classList.add('selected');
      break;
    }
  }
});


const COMPLETION_MESSAGES = {
  en: {
    high: 'Incredible! You are a True Master!',
    mid: 'Keep it up',
    low: "You're getting smarter every day!",
    review: 'Try again — every day you get better!!'
  },
  he: {
    high: 'מדהים! אתם אלוף אמיתי!',
    mid: 'מקסים תמשיך ככה!!',
    low: 'להמשיך ככה! כל יום יותר טוב',
    review: 'נסה שוב, כל יום יותר טוב!!'
  }
};

let completionOverlayTimer = null;
let completionDelayTimer = null;
let completionOverlayPending = false;

function clearCompletionOverlayTimers(){
  if (completionOverlayTimer) { clearTimeout(completionOverlayTimer); completionOverlayTimer = null; }
  if (completionDelayTimer) { clearTimeout(completionDelayTimer); completionDelayTimer = null; }
  completionOverlayPending = false;
}

function hideCompletionOverlay(){
  const overlay = document.getElementById('completion-overlay');
  const confetti = document.getElementById('completion-confetti');
  if (overlay) {
    overlay.classList.remove('active');
    overlay.setAttribute('aria-hidden', 'true');
  }
  if (confetti) confetti.innerHTML = '';
  clearCompletionOverlayTimers();
}

function makeCompletionConfetti(count){
  const confetti = document.getElementById('completion-confetti');
  if (!confetti) return;
  confetti.innerHTML = '';
  for (let i = 0; i < count; i++) {
    const piece = document.createElement('div');
    piece.className = 'completion-confetti-piece';
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.background = `hsl(${Math.floor(Math.random() * 360)} 92% 60%)`;
    piece.style.animationDuration = `${(4.2 + Math.random() * 1.8).toFixed(2)}s`;
    piece.style.animationDelay = `${(Math.random() * 0.5).toFixed(2)}s`;
    piece.style.setProperty('--dx', `${(-20 + Math.random() * 40).toFixed(1)}vw`);
    confetti.appendChild(piece);
  }
}

function getCompletionTotal(){
  const cfg = QUIZZES[state.activeQuiz];
  if (!cfg) return 0;
  return Number(cfg.total || 0);
}

function getCompletionScoreText(){
  const total = getCompletionTotal();
  const score = Number(state.score || 0);
  return total > 0 ? `${score}/${total}` : String(score);
}

function returnHomeAfterCompletion(){
  hideCompletionOverlay();
  goHome();
}

function showCompletionOverlay(durationMs = 3000){
  const overlay = document.getElementById('completion-overlay');
  const scoreEl = document.getElementById('completion-score');
  const msgEl = document.getElementById('completion-message');
  const iconEl = document.getElementById('completion-icon');
  const lang = state.lang === 'he' ? 'he' : 'en';
  const total = getCompletionTotal();
  const score = Number(state.score || 0);
  const pct = total > 0 ? (score / total) * 100 : 0;

  if (!overlay || !scoreEl || !msgEl || !iconEl) return;

  clearCompletionOverlayTimers();
  scoreEl.textContent = getCompletionScoreText();
  msgEl.textContent = '';
  iconEl.style.display = 'none';
  iconEl.textContent = '👍';

  const confetti = document.getElementById('completion-confetti');
  if (confetti) confetti.innerHTML = '';

  if (state.revealAllUsed) {
    msgEl.textContent = COMPLETION_MESSAGES[lang].review;
    iconEl.style.display = 'block';
  } else if (pct >= 80) {
    msgEl.textContent = COMPLETION_MESSAGES[lang].high;
    makeCompletionConfetti(140);
  } else if (pct >= 65) {
    msgEl.textContent = COMPLETION_MESSAGES[lang].mid;
    iconEl.style.display = 'block';
  } else {
    msgEl.textContent = COMPLETION_MESSAGES[lang].low;
  }

  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden', 'false');
  completionOverlayTimer = setTimeout(returnHomeAfterCompletion, durationMs);
}

function scheduleCompletionOverlay(delayMs = 0, durationMs = 3000){
  if (completionOverlayPending) return;
  completionOverlayPending = true;
  clearInterval(state.timerId);
  state.timerId = null;
  completionDelayTimer = setTimeout(() => {
    completionOverlayPending = false;
    showCompletionOverlay(durationMs);
  }, delayMs);
}

function renderCompletedPlaceholder(node){
  if (node) node.innerHTML = '<div style="height:120px"></div>';
  scheduleCompletionOverlay(0, 10000);
}
